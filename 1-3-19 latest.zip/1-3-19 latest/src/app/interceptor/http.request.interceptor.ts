
import { Observable } from 'rxjs';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { AppConfig } from '../app.config';
import { Injectable } from '@angular/core';
import { UserData } from '../shared/models/user-data-model';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
@Injectable()
export class HttpRequestInterceptor implements HttpInterceptor {
    userData: UserData;
    token: string = '';

    constructor(private router: Router, private appConfig: AppConfig) {
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.token = localStorage.getItem('token') != null ? localStorage.getItem('token') : '';
        if (request.url.search(environment.baseUrl) !== -1) {
            request = request.clone({
                setHeaders: {
                    'x-functions-key': environment.apiKey,
                    'Authorization': this.token
                }
            });
        }
        return next.handle(request).pipe(tap(event => {
            if (event instanceof HttpResponse) {
                if (event.body !== null) {
                    if (event.body.Errors !== undefined) {
                        var message = event.body.Errors[0] !== undefined ? event.body.Errors[0].Message : '';
                        if (message.search('AuthenticationException') !== -1 && message.search('User is not authorized') !== -1) {
                            this.appConfig.removeCurrentUser();
                            this.router.navigate(["/login"]);
                        } else {
                            return event;
                        }
                    }
                }
            }
        }, (err: any) => {
            if (err instanceof HttpErrorResponse) {
                console.log('error>> ', err);
                return event;
            }
        }))

    }
}
