import { Component, AfterViewInit, OnInit, Injector } from '@angular/core';
import { LoginApiService } from './services/login-api.service';
import { AppConfig } from 'src/app/app.config';
import { ArcRequestApiService } from './services/arc-request-api.service';
import { Router } from '@angular/router';
import { MatDialogRef, MatDialog, MatSnackBar } from '@angular/material';
import { ThankYouComponent } from './shared/component/thank-you/thank-you.component';
import { AppInsightsService } from './services/app-insights.service';
import { NotificationService } from './shared/services/notification.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'app';
  resData;
  notificationService: NotificationService;
  isLogin;
  // currentURL: boolean = false;


  ngOnInit() {
    
  }


  constructor(
    private service: LoginApiService, private arcService: ArcRequestApiService,
    private injector: Injector,
    private readonly snb: MatSnackBar,
    appInsightsService: AppInsightsService,
        private readonly appConfig: AppConfig, private router: Router) 
    {
      this.notificationService = new NotificationService(snb);
      this.appConfig.isAuthenticated();
      appInsightsService.logPageView('MainPage');
      // this.appConfig.isLoggedIn.subscribe(
      // (login) => {
      //   this.isLogin = login;
      // }
      // );
    }

  getData() {
    this.service.login(localStorage.getItem('email'), '').subscribe(res => {
      this.resData = res
      if (this.resData.Errors.length !== 0)
        this.notificationService.showNotification("Invalid UserName or Password");
      else {
        this.appConfig.setCurrentUser(this.resData);
      }
    },
      (err) => {
        console.log(err);
      }
    );
  }

  
}
