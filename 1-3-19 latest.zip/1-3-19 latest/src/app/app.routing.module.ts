import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UnauthGuard } from './shared/guards/unauth.guard';
import { PmLandingComponent } from './property-management/pm-landing/pm-landing.component';
import { CheckUrlGuard } from './shared/guards/check-url.guard';
//import { AnnouncementsComponent } from './components/announcements/announcements.component';
import { CsrMeetingComponent } from './property-management/csr-landing/csr-meeting/csr-meeting.component';
import { CsrTaskTodoComponent } from './property-management/csr-landing/csr-task-todo/csr-task-todo.component';
//import { EmailsComponent } from './property-management/csr-landing/emails/emails.component';
import { LeveloneformComponent } from './property-management/leveloneform/leveloneform.component';
import { LevelonecaseComponent } from './property-management/csr-landing/levelonecase/levelonecase.component';
//import { CorporateServicesComponent } from './corporate/corporate-services/corporate-services.component';
import { UserFeedbackComponent } from './property-management/user-feedback/user-feedback.component';


const routes: Routes = [
    {
        path: '',
        pathMatch: 'full',
        loadChildren: './components/association-landing/association-landing.module#AssociationLandingModule',
        canActivate: [CheckUrlGuard]
    },
    // corporate
    {
        path: 'corporate',
        loadChildren: './corporate/corporate.module#CorporateModule',
    },
    // {
    //     path: 'announcements',
    //     component: AnnouncementsComponent
    // },
    {
        path: 'login',
        loadChildren: './components/login/login.module#LoginModule',
        canActivate: [UnauthGuard]
    }
    ,
    {
        path: 'forgot-password',
        loadChildren: './components/forgot-password/forgot-password.module#ForgotPasswordModule',
        canActivate: [UnauthGuard]
    }
    ,
    {
        path: 'update-password',
        loadChildren: './components/update-password/update-password.module#UpdatePasswordModule',
        canActivate: [UnauthGuard]
    }
    ,
    {
        path: 'sign-up',
        loadChildren: './components/sign-up/sign-up.module#SignUpModule',
        canActivate: [UnauthGuard]
    },
    {
        path: 'association-landing',
        loadChildren: './components/association-landing/association-landing.module#AssociationLandingModule',
        canActivate: [CheckUrlGuard]
    },
    {
        path: 'association',
        loadChildren: './components/main.module#MainModule',
        //canActivate: [AuthGuard]
    },
   
    {
        path: 'association-market-list',
        loadChildren: './components/association-market-place/association-market-place.module#AssociationMarketPlaceModule',
    },
    {
        path: 'pm-landing',
        component: PmLandingComponent
    },
    // {
    //     path: 'csr-header',
    //     component: CsrHeaderComponent
    // },
    {
        path: 'csr-meeting',
        component: CsrMeetingComponent
    },
    {
        path: 'csr-task-todo',
        component: CsrTaskTodoComponent
    },
    // {
    //     path: 'emails',
    //     component: EmailsComponent
    // },
    // {
    //     path: 'association/recent-updates',
    //     component: RecentUpdateComponent
    // }, 
    {
        path: 'levelonecase',
        component: LevelonecaseComponent
    },
    {
        path: 'leveloneform',
        component: LeveloneformComponent
    },

    // {
    //     path: 'user-feedback',
    //     component: UserFeedbackComponent
    // },

    // {
    //     path: 'corporate-services',
    //     component: CorporateServicesComponent
    // },

];


@NgModule({
    //imports: [RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'})],
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})


export class AppRoutingModule { }
