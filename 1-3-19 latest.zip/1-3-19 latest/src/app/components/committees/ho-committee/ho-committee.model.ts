export class AssociationCommitteeJoinRequest {
    CreatedByUserId: string
    CreatedByUserName: string
    Message: string
}