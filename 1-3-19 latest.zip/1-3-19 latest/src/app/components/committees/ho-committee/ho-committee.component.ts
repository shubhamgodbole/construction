import { Component, OnInit, ViewChild } from '@angular/core';
import { CommitteeApiService } from 'src/app/services/committee-api.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar } from '@angular/material';
import { FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { CommonService } from 'src/app/services/common.service';
@Component({
  selector: 'app-ho-committee',
  templateUrl: './ho-committee.component.html',
  styleUrls: ['./ho-committee.component.scss']
})
export class HoCommitteeComponent implements OnInit {

  messagecommittee = false;
  committeeData: any;
  userJoinRequestForm: FormGroup;
  listData: any;
  AssociationId: string;
  userData: UserData;
  domain: string;
  associationName: string;
  showError: boolean = false;
  @ViewChild('requestformDirective') requestformDirective: FormGroupDirective;
  notificationService: NotificationService;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  constructor(private committeeService: CommitteeApiService, private formBuilder: FormBuilder, private readonly appConfig: AppConfig,
    private progressbarService: ProgeressBarService, private readonly snb: MatSnackBar, 
    public commonService: CommonService) {
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    this.AssociationId = this.userData.UserAssociations[0].AssociationId;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.associationName = this.userData.UserAssociations[0].Name;
    // this.domain =  this.userData.UserAssociations[0].Domain;
    this.committeeService.domain = this.domain;
  }

  ngOnInit() {
    this.userJoinRequestForm = this.formBuilder.group({
      subject: ['', Validators.required],
      message: ['', [Validators.required, Validators.maxLength(200)]],

    });
    this.getAllCommittee();
  }
  getAllCommittee() {
    this.progressbarService.show();
    this.committeeService.getAllCommittee(this.AssociationId, this.domain).subscribe(
      (response: any) => {
        this.progressbarService.hide();
        this.committeeData = response.AssociationCommitteeList;
      }
    );
  }
  messagecommitteeToggle(list) {
    this.listData = list;
    if (this.messagecommittee) {

      this.messagecommittee = false;
      this.reset();
    }
    else
      this.messagecommittee = true;
  }
  reset() {
    this.userJoinRequestForm.reset();
    this.requestformDirective.resetForm();
    this.messagecommittee = false;
  }
  changeMessage() {
    if (this.userJoinRequestForm.controls.message.value === '') {
      this.showError = true;
    }
    else {
      this.showError = false;
    }
  }

  senMessageModel() {
    let model = {
      Message: this.userJoinRequestForm.controls.message.value,
      Subject: this.userJoinRequestForm.controls.subject.value,
      CreatedByUserId: this.listData.CreatedByUserId,
      CreatedByUserName: this.listData.CreatedByUserName,
      AssociationCommitteeId: this.listData.id,
      AssociationName: this.listData.AssociationName,
      AssociationCommittee: this.listData.CommitteeType === 'Other' ? this.listData.CustomCommitteeName : this.listData.CommitteeType,

    }
    return model;
  }
  senRequest() {
    let CommitteeContactData = this.senMessageModel();
    if (this.userJoinRequestForm.valid) {
      this.progressbarService.show();
      this.committeeService.sendMessage(CommitteeContactData).subscribe(
        (response: any) => {
          this.progressbarService.hide();
          if (response.success) {
            this.reset();
            this.notificationService.showNotification('Message is send successfully');
            console.log('Send Message');
          }
        }
      );
    }
  }
  // senRequest() {
  //   let AssociationCommitteeJoinRequest = this.associationCommitteeJoinRequestModel();
  //   if(this.userJoinRequestForm.controls.message.value === '') {
  //     this.showError = true;
  //   }
  //   if(this.userJoinRequestForm.valid) {
  //     this.committeeService.sendUserJoinRequest(AssociationCommitteeJoinRequest,this.listData.id).subscribe(
  //       (response: any) => {
  //         if(response.success) {
  //             console.log('Send Request Successfully');
  //             this.notificationService.showNotification('Message is send successfully');
  //             this.reset();
  //         }
  //         else {
  //           console.log('Error In SendRequest');
  //         }
  //       }
  //     );
  //   }

  // }
  // associationCommitteeJoinRequestModel() {
  //   let model = {
  //     CreatedByUserId : this.listData.CreatedByUserId,
  //     CreatedByUserName : this.listData.CreatedByUserName,
  //     Message: this.userJoinRequestForm.controls.message.value,
  //     Subject: this.userJoinRequestForm.controls.subject.value,
  //   }
  //   return model;
  // }
}
