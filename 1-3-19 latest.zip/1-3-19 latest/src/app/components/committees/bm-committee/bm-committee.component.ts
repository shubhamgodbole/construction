import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { CommitteeApiService } from 'src/app/services/committee-api.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { AddCommittee, AddCommitteeMember, EditCommittee, CommitteeContactData } from './bm-committee.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import * as _ from 'lodash';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { TypeOfDocument, RoleEnum, NoDataFoundCaseFeatureName, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar, MatAutocompleteTrigger } from '@angular/material';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonService } from 'src/app/services/common.service';
import { ValidationService } from 'src/app/shared/services/validation.service';

@Component({
  selector: 'app-bm-committee',
  templateUrl: './bm-committee.component.html',
  styleUrls: ['./bm-committee.component.scss']
})
export class BmCommitteeComponent implements OnInit {
  addCommitteeForm: FormGroup;
  editCommitteeForm: FormGroup;
  addCommitteeMemberForm: FormGroup;
  sendMessageForm: FormGroup;
  editcommittee = false;
  addcommittee = false;
  addCommitteemember = false;
  editCommitteemember: any;
  messagecommittee = false;
  committeeData: any;
  committeeTypesData: any;
  designationData: any;
  memberData: any[] = [];
  memberDataAutocompleteList: any[] = [];
  @ViewChild('memberAssociationAutoComplete', { read: MatAutocompleteTrigger })
  memberAssociationtrigger: MatAutocompleteTrigger;
  userProfileId: string;
  showCommitteeName: boolean = false;
  fileData: any = [];
  oldImage: string = "";
  newImage: any;
  errorMsg: string;
  associationId: string;
  associationName: string;
  editData: any = {};
  editMembers: any = [];
  AssociationCommitteeId: string;
  AssociationCommittee: string;
  isEdit: boolean = false;
  editAssociationCommitteeUserId = "";
  newDesignation: string = "";
  newStartdate: string = "";
  newEnddate: string = "";
  minDate: any;
  isMemeberExistMsg = "";
  domain: string;
  userData: UserData;
  showImgErro: boolean = false;
  comityNameValidation: boolean = false;
  discriptionValidation: boolean = false;
  designamtionValidation: boolean = false;
  discriptionValidatio: boolean = false;
  userRole: string;
  userName: string;
  userId: string
  isVoting: boolean = false;
  myModel: boolean = false;
  isComponentLoad: boolean = false;
  isAddCommitteeButton: boolean = false;
  isEditCommitteeButton: boolean = false;
  isAddCommitteeMemberButton: boolean = false;
  isMessageButton: boolean = false;
  @ViewChild('formDirective') formDirective: FormGroupDirective;
  @ViewChild('cmtformDirective') cmtformDirective: FormGroupDirective;
  @ViewChild('msgformDirective') msgformDirective: FormGroupDirective;
  notificationService: NotificationService;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  /*Reset mat auto compelte*/
  @ViewChild('homeOwnerAutoComplete', { read: MatAutocompleteTrigger })
  homeOwnertrigger: MatAutocompleteTrigger;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  isInvalidDate:boolean = false;
  
  isApiResponceCome = false;
  constructor(private committeeService: CommitteeApiService,
    private router: Router,
    private readonly snb: MatSnackBar,
    public commonService: CommonService,
    private formBuilder: FormBuilder, private readonly appConfig: AppConfig,
    private cdRef: ChangeDetectorRef, private progressbarService: ProgeressBarService, ) {
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.committeeService.domain = this.domain;
  }

  ngOnInit() {

    this.userRole = this.userData.Role;
    // if (this.userData.Role === RoleEnum.Member) {
    //   this.router.navigate([AppRouteUrl.mainCommitteeHORouteUrl]);
    // }
    if (this.userData.Role === RoleEnum.PropertyManager) {
      this.router.navigate([AppRouteUrl.mainCommitteePMRouteUrl]);
    }

    this.addCommitteeForm = this.formBuilder.group({
      committeeName: ['', Validators.maxLength(30)],
      committeeType: ['', Validators.required],
      description: ['', [Validators.required, Validators.maxLength(2000),ValidationService.noWhiteSpace]],
      attechment: ['', Validators.required],
      votting: ['']
    });
    this.editCommitteeForm = this.formBuilder.group({
      committeeName: [''],
      committeeType: ['', Validators.required],
      description: ['', [Validators.required,Validators.maxLength(2000),ValidationService.noWhiteSpace]],
      attechment: [''],
      designation: ['', Validators.required],
      startData: ['', Validators.required],
      endDate: [''],
      votting: ['']
    });
    this.addCommitteeMemberForm = this.formBuilder.group({
      memberName: ['', Validators.required],
      designation: ['', Validators.required],
      startData: ['', Validators.required],
      endDate: [''],
    });
    this.sendMessageForm = this.formBuilder.group({
      subject: ['', Validators.required],
      message: ['', [Validators.required, Validators.maxLength(200)]],
    });
    this.getAllCommittee();
    this.getMasterData();
  }
  // get all committee
  getAllCommittee() {
    let resData;
    this.progressbarService.show();
    this.committeeService.getAllCommittee(this.associationId, this.domain).subscribe(
      (response: any) => {
        this.isApiResponceCome = true;
        if (response.success) {
          this.progressbarService.hide();
          resData = response;
          this.committeeData = resData.AssociationCommitteeList;
          this.committeeData.map((a) => { a.CommitteeImageBlobPath = a.CommitteeImageBlobPath + this.showProfilePhoto() });
          this.isComponentLoad = true;
        }

      }
    );
  }
  // get all Type
  getMasterData() {
    let resData;
    this.committeeService.getMasterData().subscribe(
      (response: any) => {
        resData = response;
        this.committeeTypesData = resData.CommitteeType.CommitteeTypes;
        this.designationData = resData.CommitteeType.DesignationTypes;
      }
    );
  }
  // get all members
  getAllMember(AssociationCommitteeId) {
    //this.progressbarService.show();
    this.committeeService.getAllMember(this.associationId, AssociationCommitteeId).subscribe(
      (response: any) => {
        // this.progressbarService.hide();        
        let member: any = response.Users;
        this.memberData = _.orderBy(member, (a) => a.UserName, 'asc');
        this.memberDataAutocompleteList = _.orderBy(member, (a) => a.UserName, 'asc');
      }
    );
  }
  getCheckboxes() {
    console.log(this.addCommitteeForm.controls.votting.value);
  }
  editcommitteeToggle(list) {
    if (this.editcommittee) {
      this.resetEditComittee();
      this.editcommittee = false;
    }
    else {
      this.edit(list);
      this.editcommittee = true;
    }

  }
  addcommitteeToggle() {
    if (this.addcommittee) {
      this.reset();
      this.addcommittee = false;
    }
    else {
      this.addcommittee = true;
    }

  }
  addcommitteeMemberToggle(id) {
    this.AssociationCommitteeId = id;
    if (this.addCommitteemember) {
      this.resetComitteeMamber();
      this.addCommitteemember = false;
    }
    else {
      this.getAllMember(id);
      this.addCommitteemember = true;
    }

  }

  messagecommitteeToggle(committeeName, id) {
    this.AssociationCommittee = committeeName;
    this.AssociationCommitteeId = id;
    if (this.messagecommittee) {
      this.resetSendMessageForm();
      this.messagecommittee = false;
    }
    else
      this.messagecommittee = true;

  }
  onUploadChange(evt: any) {
    // this.imgFlag = false;
    this.fileData = [];
    this.errorMsg = "";
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      var reader = new FileReader();
      reader.onload = (event: any) => {
        let type = evt.target.files[0].name.split(".");
          if (type[type.length -1].toLowerCase() === 'jpeg' || type[type.length -1].toLowerCase() === 'jpg' || type[type.length -1].toLowerCase() === 'png' || type[type.length -1].toLowerCase() === 'gif' || type[type.length -1].toLowerCase() === 'bmp' || type[type.length -1].toLowerCase() === 'jfif' || type[1].toLowerCase() === 'tif' || type[type.length -1].toLowerCase() === 'tiff') {
            this.fileData.push({
              inputStream: event.target.result,
              name: evt.target.files[0].name,
              type: evt.target.files[0].type,
              CreatedByUserName: this.userName
            });
            this.errorMsg = "";
          }
          else {
           this.errorMsg = "Select Only Images";
            // this.shoInvalidImageMsg = true;
          }
      }
      reader.readAsDataURL(evt.target.files[0]);
      // this.newImage = this.fileData[0].inputStream;
    }

  }
  // reset Add Committee Form
  reset() {
    this.addCommitteeForm.reset();
    this.formDirective.resetForm();
    this.addcommittee = false;
    this.fileData = [];
    this.errorMsg = "";
    this.showCommitteeName = false;
    this.isAddCommitteeButton = false;
  }
  // reset Add Committee Member Form
  resetComitteeMamber() {
    this.addCommitteeMemberForm.reset();
    this.cmtformDirective.resetForm();
    this.addCommitteemember = false;
    this.isAddCommitteeMemberButton = false;
  }
  // reset Edit Committee Form
  resetEditComittee() {
    this.editCommitteeForm.reset();
    this.editcommittee = false;
    this.isEdit = false;
    this.comityNameValidation = false;
    this.isEditCommitteeButton = false;
    this.errorMsg = "";
  }
  resetSendMessageForm() {
    this.sendMessageForm.reset();
    this.msgformDirective.resetForm();
    this.messagecommittee = false;
  }
  // get Committee Type 
  // if Committee Type is Other then show TextBox for CommitteeName
  getCommitteeType(type) {
    this.errorMsg = "";
    this.showCommitteeName = false;
    this.addCommitteeForm.controls.committeeName.setValue('');
    if (type.value === 'Others') {
      this.showCommitteeName = true;
      this.isAddCommitteeButton = false;
    }
  }
  // add Committee 
  addCommittee() {
    const addCommitteeData = this.createCommitteeModel();
    if (this.fileData.length === 0) {
      this.errorMsg = "Please select image";
    }
    if (this.addCommitteeForm.valid) {
      this.isAddCommitteeButton = true;      
      this.committeeService.addCommittee(addCommitteeData, this.fileData[0].inputStream).subscribe(
        (response: any) => {          
          if (response.success) {
            this.getAllCommittee();
            this.reset();
            this.notificationService.showNotification('Added new Committee successfully');
          }
          else {
            this.errorMsg = "This Committee is already exist";
            console.log('Add Committee : ', this.errorMsg);
            this.isAddCommitteeButton = false;
          }
        }
      );
    }
  }
  // add Committee Model
  createCommitteeModel() {
    let model: AddCommittee = {
      CustomCommitteeName: this.addCommitteeForm.controls.committeeName.value,
      CommitteeType: this.addCommitteeForm.controls.committeeType.value,
      Description: this.addCommitteeForm.controls.description.value,
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      CreatedOn: new Date(),
      IsVotingRequired: this.addCommitteeForm.controls.votting.value ? this.addCommitteeForm.controls.votting.value : false
    };
    return model;
  }

  changeMemberName() {
    this.isMemeberExistMsg = '';
  }
  // add Committee Member
  addCommitteeMember() {
    let memberData = this.createCommitteeMemberModel();
    if (this.addCommitteeMemberForm.valid) {
      this.isAddCommitteeMemberButton = true;
      this.progressbarService.show();
      this.committeeService.addCommitteeMember(memberData, this.AssociationCommitteeId).subscribe(
        (response: any) => {
          this.progressbarService.hide();
          if (response.success) {
            this.resetComitteeMamber();
            this.getAllCommittee();
            console.log('Added new Committee Member');
            this.notificationService.showNotification('Added new Committee Member');
          }
          else {
            this.isMemeberExistMsg = response.Errors[0].Message;
            console.log('Added new Committee Member : ', this.isMemeberExistMsg);
          }
        });
      console.log(memberData);
    }
  }
  // add Committee Member Model
  createCommitteeMemberModel() {
    let model: AddCommitteeMember = {
      UserProfileId: this.addCommitteeMemberForm.controls.memberName.value.UserProfileId,
      CommitteeMemberName: this.addCommitteeMemberForm.controls.memberName.value.UserName,
      StartDate: this.addCommitteeMemberForm.controls.startData.value,
      EndDate: this.addCommitteeMemberForm.controls.endDate.value,
      AssociationCommitteeUserDesignation: this.addCommitteeMemberForm.controls.designation.value,
    }
    return model;
  }
  // get Start date
  // set minDate for EndDate
  changeSDate() {
    this.minDate = this.addCommitteeMemberForm.controls.startData.value;
    this.addCommitteeMemberForm.controls.endDate.setValue('');
  }
  // get committeeData For Edit
  edit(editCommitteeData) {
    this.oldImage = "";
    let randomNumber = new Date().getTime();;
    this.oldImage = editCommitteeData.CommitteeImageBlobPath + "?ce=" + randomNumber;
    this.AssociationCommitteeId = editCommitteeData.id;
    this.editCommitteeForm.controls.description.setValue(editCommitteeData.Description);
    this.editCommitteeForm.controls.committeeName.setValue(editCommitteeData.CustomCommitteeName);
    this.editCommitteeForm.controls.committeeType.setValue(editCommitteeData.CommitteeType);
    this.editCommitteemember = editCommitteeData.AssociationCommitteeUsers;
    editCommitteeData.IsVotingRequired ? this.myModel = true : this.myModel = false
    this.editCommitteeForm.controls.votting.setValue(this.myModel);
    this.showCommitteeName = false;
    if (editCommitteeData.CommitteeType === 'Others') {
      this.showCommitteeName = true;
      if (this.editCommitteeForm.controls.committeeName.value === ' ' || this.editCommitteeForm.controls.committeeName.value === null) {
        this.comityNameValidation = true;
        this.errorMsg = "Committee name is required";
      }
    }
  }
  // get MemberData for Edit
  editMember(editMemberData) {
    this.editAssociationCommitteeUserId = editMemberData.AssociationCommitteeUserId;
    this.isEdit = !this.isEdit;
    let id = editMemberData.AssociationCommitteeUserId;
    this.editCommitteeForm.controls.designation.setValue(editMemberData.AssociationCommitteeUserDesignation);
    this.editCommitteeForm.controls.startData.setValue(editMemberData.StartDate);
    this.editCommitteeForm.controls.endDate.setValue(editMemberData.EndDate);
    this.newStartdate = editMemberData.StartDate;
    this.userProfileId = editMemberData.UserProfileId;
  }
  // change Designation for Edit
  changeDesignation(MemberData) {
    this.newDesignation = this.editCommitteeForm.controls.designation.value;
    if (this.newDesignation === '' || this.newDesignation === null) {
      this.designamtionValidation = true;
    }
    this.createUpdateMemberModel(MemberData);
  }
  // Change Start Date for Edit
  changeStartdate(MemberData) {
    this.newStartdate = this.editCommitteeForm.controls.startData.value;
    this.createUpdateMemberModel(MemberData);
  }
  // change End Date for Edit
  changeEndDate(MemberData) {
    if(this.editCommitteeForm.controls.endDate.invalid) {
      this.isInvalidDate = true; 
    }
    else {
      this.newEnddate = this.editCommitteeForm.controls.endDate.value;
      this.createUpdateMemberModel(MemberData);
      this.isInvalidDate = false; 
    }
  }
  // hide error msg on chage committee name
  changeName() {
    this.errorMsg = "";
    if( this.addCommitteeForm.controls.committeeName.value === ' ') {
      this.addCommitteeForm.controls.committeeName.setValue('');
    }
    if (this.editCommitteeForm.controls.committeeType.value === 'Others') {
      if( this.editCommitteeForm.controls.committeeName.value === ' ') {
        this.editCommitteeForm.controls.committeeName.setValue('');
      }
      else {
        if (this.editCommitteeForm.controls.committeeName.value === '' || this.editCommitteeForm.controls.committeeName.value === null) {
          this.comityNameValidation = true;
         // this.errorMsg = "Committee name is required";
        }
        else {
          this.comityNameValidation = false;
          this.errorMsg = "";
        }
      }
      
    }
    
  }
  // update Committee
  update() {
    let updateCommitteeData = this.createUpdateModel();
    let ImageStream = this.fileData.length > 0 ? this.fileData[0].inputStream : '';

    if (this.editCommitteeForm.controls.description.value !== '') {

      this.discriptionValidation = false;
    }
    else {

      this.discriptionValidation = true;
    }
    this.errorMsg = "";
    if (this.editCommitteeForm.controls.committeeType.value === 'Others') {

      if (this.editCommitteeForm.controls.committeeName.value === '' || this.editCommitteeForm.controls.committeeName.value === null) {
        this.comityNameValidation = true;
       // this.errorMsg = "Committee name is required";
      }
      else {
        this.comityNameValidation = false;
        this.errorMsg = "";
      }
    }
    else {
      this.comityNameValidation = false;
    }
    if (!this.comityNameValidation && !this.designamtionValidation && !this.discriptionValidation && !this.isInvalidDate) {
      this.isEditCommitteeButton = true;
      //  this.progressbarService.show();
      this.committeeService.updateCommittee(updateCommitteeData, ImageStream).subscribe(
        (response: any) => {
          console.log('update', response);
          // this.progressbarService.hide();
          if (response.success) {
            console.log('Update Committee');
            this.fileData = [];
            this.getAllCommittee();
            this.myModel = false;
            this.resetEditComittee();
            this.notificationService.showNotification('Update Committee successfully');
          }
          else {
            this.isEditCommitteeButton = false;
            this.errorMsg = "This Committee is already exist";
            console.log('Update Committee : ', this.errorMsg);
            console.log('Error in Update Committee');
          }

        });
    }


  }
  // update Memeber Model
  createUpdateMemberModel(editMemberData) {
    this.editMembers.push({
      AssociationCommitteeUserId: editMemberData.AssociationCommitteeUserId,
      AssociationCommitteeUserDesignation: this.newDesignation !== "" ? this.newDesignation : editMemberData.AssociationCommitteeUserDesignation,
      StartDate: this.newStartdate !== "" ? this.newStartdate : editMemberData.StartDate,
      EndDate: this.newEnddate !== "" ? this.newEnddate : editMemberData.EndDate,
      CommitteeMemberName: editMemberData.CommitteeMemberName,
      AssociationCommitteeCompositionId: editMemberData.AssociationCommitteeCompositionId,
      CommitteeMemberImagePath: editMemberData.CommitteeMemberImagePath,
      UserProfileId: this.userProfileId
    });
    console.log(this.editMembers);
    return this.editMembers;
  }
  // Update Committee Model
  createUpdateModel() {
    let model = {
      id: this.AssociationCommitteeId,
      CustomCommitteeName: this.editCommitteeForm.controls.committeeName.value,
      CommitteeType: this.editCommitteeForm.controls.committeeType.value,
      Description: this.editCommitteeForm.controls.description.value,
      AssociationCommitteeUsers: this.editMembers,
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      IsVotingRequired: this.myModel
    }
    return model;
  }
  senMessageModel() {
    let model = {
      Message: this.sendMessageForm.controls.message.value,
      Subject: this.sendMessageForm.controls.subject.value,
      AssociationCommitteeId: this.AssociationCommitteeId,
      AssociationName: this.associationName,
      AssociationCommittee: this.AssociationCommittee
    }
    return model;
  }
  senMessage() {
    let CommitteeContactData = this.senMessageModel();
    if (this.sendMessageForm.valid) {
      this.isMessageButton = true;
      this.progressbarService.show();
      this.committeeService.sendMessage(CommitteeContactData).subscribe(
        (response: any) => {
          this.progressbarService.hide();
          if (response.success) {
            this.resetSendMessageForm();
            this.notificationService.showNotification('Message is send successfully');
            console.log('Send Message');
          }
        }
      );
    }
  }

  showProfilePhoto() {
    let randomNumber = new Date().getTime();
    let url = "?c=" + randomNumber;
    return url;
  }

  /*auto complete*/

  /*Reset mat auto compelte*/
  ngAfterViewInit() {
    this.memberAssociationtrigger.panelClosingActions
      .subscribe(e => {
        if (!(e && e.source)) {
          this.addCommitteeMemberForm.controls.memberName.setValue('');
          this.memberAssociationtrigger.closePanel();
          this.memberDataAutocompleteList = this.memberData;
        }
      });
  }

  /**Auto complete Display Function**/
  displayFnAutoCompleteMember(member) {
    if (member != null && member.UserName != null) {
      return member.UserName;
    } else member;
  }

  /**Auto complete filter on change**/
  onInputChanged(searchStr: string): void {
    this.memberDataAutocompleteList = [];
    this.memberDataAutocompleteList = this.memberData.filter(option =>
      option.UserName.toLowerCase().includes(searchStr.toLowerCase()));
  }
}
