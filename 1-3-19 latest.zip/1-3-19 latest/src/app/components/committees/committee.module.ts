import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BmCommitteeComponent } from './bm-committee/bm-committee.component';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatCheckboxModule, MatAutocompleteModule, MatTooltipModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { AllowOnlyDateModule } from 'src/app/shared/directives/allow-only-date/allow-only-date.module';

const routes: Routes = [
  {
    path: '',
    component: BmCommitteeComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MatBottomSheetModule,
    NumberOnlyDirectiveModule,
    MatButtonModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    FormsModule,
    MatCheckboxModule,
    NoDataFoundModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule,
    AllowOnlyDateModule,
    MatTooltipModule,

  ],
  declarations: [BmCommitteeComponent]
})
export class CommitteeModule { }
