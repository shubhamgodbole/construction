import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatAutocompleteModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HoCommitteeComponent } from './ho-committee/ho-committee.component';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';

const routes: Routes = [
  {
    path: '',
    component: HoCommitteeComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatBottomSheetModule,
    MatButtonModule,
    NumberOnlyDirectiveModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    NoDataFoundModule,
    FormsModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule
  ],
  declarations: [HoCommitteeComponent]
})
export class HoCommitteeModule { }
