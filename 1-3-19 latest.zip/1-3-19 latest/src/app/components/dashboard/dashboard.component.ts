import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { UserData } from 'src/app/shared/models/user-data-model';
import { DashboardService } from 'src/app/services/dashboard.service';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { ChartsModule, Color } from 'ng2-charts';
import { TypeOfDocument, RoleEnum, ImageNameEnums, FeatureName, SourceType, TriggerType, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { AddEvent, AddPoll, ParentSocialEvent, ChildSocialEvent, AddPhotos, AddAnnouncementModel, LikeText } from './dashboard.model';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar, mixinDisableRipple, MatDialogRef, MatDialog, MatAutocompleteTrigger } from '@angular/material';
import * as _ from 'lodash';
import { Guid } from 'guid-typescript';
import { CookieService } from 'ngx-cookie-service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { LoginApiService } from 'src/app/services/login-api.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { WelcomeDialogComponent } from 'src/app/shared/component/welcome-dialog/welcome-dialog.component';
import { Moment } from 'moment';
import { CommonService } from 'src/app/services/common.service';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { AudienceType } from '../board-tasks/board-task.model';
import { AcceptFilesConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  showFiller = false;
  //Welcome Dialogue
  confirmDialogRateAndReviewRef: MatDialogRef<WelcomeDialogComponent>;
  welcomedialogRef: any;
  //For Send Notification
  announcementFeatureId: string;
  pmCompanyAssociationMappingId: string;

  userData: UserData;
  associationId: string;
  associationName: string;
  domain: string;
  userId: string;
  userName: string;
  userRole: string;
  userProfile: string;
  associationDashBoard: any;
  fileData: any = [];
  @ViewChild('mycanvas')
  canvas: ElementRef;
  @ViewChild('mycanvas1')
  canvas1: ElementRef;
  @ViewChild('mycanvas2')
  canvas2: ElementRef;
  @ViewChild('mycanvas3')
  canvas3: ElementRef;
  @ViewChild('mycanvas4')
  canvas4: ElementRef;
  @ViewChild('mycanvas5')
  canvas5: ElementRef;
  @ViewChild('mycanvas6')
  canvas6: ElementRef;
  options: any;
  options1: any;
  boardTskCountData: Array<any> = [];
  serviveRequestCountData: Array<any> = [];
  arcRequestCountData: Array<any> = [];
  violationCountData: Array<any> = [];
  boardTaskTtal: string;
  serviceRequestTtal: string;
  arcRequestTtal: string;
  violationTtal: string;
  isShowAssociationDasBoard: boolean = false;
  errorMsg: string;
  question: string;
  isShowEventButtons: boolean = true;
  today = new Date();
  isUserEnable: any = [];
  width = 20;
  minDate: Date;
  maxDate: Date;

  bsRangeValue: Date[] = [];
  bsRangeValueMy: Date[] = [];
  months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  currtentDate = new Date();
  currentMonth = this.months[this.currtentDate.getMonth()];
  currentYear = this.currtentDate.getFullYear();
  tocurrentMonth: any = "";
  tocurrentYear: any = "";
  myCurrentMonth = this.months[this.currtentDate.getMonth()];
  myCurrentYear = this.currtentDate.getFullYear();
  myToCurrentMonth: any = "";
  myToCurrentYear: any = "";
  firstDay: any;
  lastDay: any;
  newfirstDay: any;
  newlastDay: any;
  eventData: any = [];
  tempData: any = [];
  notificationService: NotificationService;
  // add Event
  addEventForm: FormGroup;
  @ViewChild('addEventDirective') addEventDirective: FormGroupDirective;
  isEventShow: boolean = false;

  // add poll 
  addpollForm: FormGroup;
  @ViewChild('addPollDirective') addPollDirective: FormGroupDirective;
  isPollShow: boolean = false;

  // add comment
  addCommentForm: FormGroup;
  @ViewChild('addCommentDirective') addCommentDirective: FormGroupDirective;
  isCommentBtn: boolean = false;

  // add Photos
  addPhotosForm: FormGroup;
  @ViewChild('addPhotosDirective') addPhotosDirective: FormGroupDirective;
  isPhotosShow: boolean = false;
  isComponentLoad: boolean = false;
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  // add Announcement
  addAnnouncementForm: FormGroup;
  @ViewChild('addAnnouncementDirective') addAnnouncementDirective: FormGroupDirective;
  isAnnouncementShow: boolean = false;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;

  // show comment tab
  isShowCommentTab: boolean = false;
  commentTabID: any = [];

  //For Association
  associationData: any[] = [];
  associationDdlAutocompleteList: any[] = [];
  @ViewChild('documentAssociationAutoComplete', { read: MatAutocompleteTrigger })
  announcementAssociationtrigger: MatAutocompleteTrigger;

  // event types
  eventType: string = "event";
  pollType: string = "poll";
  photoType: string = "photos";
  announcementType = "announcement"
  responseData: any;
  userForOption1 = 0;
  userForOption2 = 0;
  totalEvents: number = 0;
  totalPolls: number = 0;
  totalAnnouncement: number = 0;
  boardTaskTotal: number = 0;
  arcTotal: number = 0;
  serviceRequestTotal: number = 0;
  violationTotal: number = 0;
  photosDescription: string = "";
  isPostShow: boolean = true;
  isShowComments: boolean = false;
  isShowLikers: boolean = false;
  commentID: string;
  likeID: string;
  commentsData: any;
  showNcomments: any = 3;
  loadMoreCommentsLabel: string = "Read more";
  eventDescriptionLength: any = 100;
  eventReadMoreDescriptionLabel: string = " Read more ";
  readMoreBtn: boolean = false;
  isPostButton: boolean = false;
  isPollButton: boolean = false;
  isEventButton: boolean = false;
  isAnnouncementButton: boolean = false;
  redirectionLinks: any = [];
  like_status: boolean = false;
  isAssociationDataLoad: boolean = false;
  isMyDashboardDataLoad: boolean = false;
  counter = 3;
  isAllLoaded: boolean = false;
  sendTo: any = [];
  SendtoData: any;
  FromtoData: any;
  isAnnouncementDesError: boolean = false;
  isAnnouncementSendToError: boolean = false;
  roleEnum = RoleEnum;
  cnt: any = 0;

  // multi select drop-down
  dropdownSettings = {};
  selected: { startDate: Moment, endDate: Moment };
  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentPreview: boolean = false;
  associationRangeValue: Date[];
  myRangeValue: Date[];
  eventCategoryData: any;
  eventSubCategoryData: any;
  audienceType: any;
  currentPost: string = 'All';
  total: number;
  isDateFilterResponceLoad: boolean = false;
  likeText = LikeText;
  isSpinnerShow: boolean = false;
  isResponse: boolean;
  isComment: boolean = false;
  constructor(public service: DashboardService,
    private progressbarService: ProgeressBarService, private loginService: LoginApiService,
    private _matDialog: MatDialog,
    private cookieService: CookieService,
    private router: Router,
    private readonly appConfig: AppConfig,
    private formBuilder: FormBuilder,
    public commonService: CommonService,
    private emailNotification: EmailNotificationService,
    private readonly snb: MatSnackBar) {
    // this.getUserData();  
    // let ldata = JSON.parse(String(localStorage.getItem('userData')));
    setTimeout(() => {
      this.userData = this.appConfig.getCurrentUser();
      // this.userData = JSON.parse(String(localStorage.getItem('userData')))
      if (this.userData !== null) {
        this.setData(this.userData);
      }
    }, 2000);
    this.notificationService = new NotificationService(snb);
    setTimeout(() => {
      this.getDashboardData();
      this.getSocialCount();
      this.getSocialLanding();
    }, 3000);

  }
  @HostListener("window:scroll", [])
  onWindowScroll() {
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight;

    if (pos == max) {
      this.loadMore();
    }
  }

  loadMore() {
    if (this.counter < this.total && !this.isAllLoaded) {
      this.progressbarService.show();
      if (this.counter === this.total) {
        this.isAllLoaded = true;
      }
      else {
        this.counter = this.counter + 3;
        this.counter = this.counter > this.total ? this.total : this.counter;
        //  this.eventData = [];     

        if (this.currentPost === 'All') {
          this.getSocialLanding();
          window.scrollTo(0, document.body.scrollHeight);
        }
        else {
          this.showAllPost(this.currentPost);
          window.scrollTo(0, document.body.scrollHeight);
        }
      }
      this.progressbarService.hide();

    }
  }


  setData(userClaim) {
    this.userId = userClaim.UserProfileId;
    this.userRole = userClaim.Role;
    this.userName = userClaim.UserName;
    this.associationId = userClaim.UserAssociations[0].AssociationId;
    this.associationName = userClaim.UserAssociations[0].Name;
    this.userProfile = userClaim.UserProfileBlobPath;
    this.domain = userClaim.UserAssociations[0].Domain;
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.SocialAnnouncement) {
          this.announcementFeatureId = feature.FeatureId
        }
      });
  }

  ngOnInit() {
    this.addEventForm = this.formBuilder.group({
      eventName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      startDate: ['', Validators.required],
      endDate: ['', [Validators.required]],
      category: ['Birth', Validators.required],
      subCategory: ['day', Validators.required],
      location: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      detail: ['', [Validators.required, Validators.maxLength(1000), ValidationService.notStartWhiteSpace]],
      attechment: [''],
    });
    this.addpollForm = this.formBuilder.group({
      question: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      options1: ['', [Validators.required, Validators.maxLength(10), ValidationService.notStartWhiteSpace]],
      options2: ['', [Validators.required, Validators.maxLength(10), ValidationService.notStartWhiteSpace]],
      endDate: ['', [Validators.required]],
    });
    this.addCommentForm = this.formBuilder.group({
      comment: ['', [Validators.required,Validators.maxLength(500)]],
      attechment: [''],
    });
    this.addPhotosForm = this.formBuilder.group({
      comment: ['', [Validators.required, Validators.maxLength(200)]],
      attechment: [''],
    });
    this.addAnnouncementForm = this.formBuilder.group({
      sendTo: ['', [Validators.required, Validators.maxLength(200)]],
      from: [''],
      //password: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      subject: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      description: ['', [Validators.required, Validators.maxLength(2000)]],
      association: [''],
    });
    // this.addAnnouncementForm.controls.description.valueChanges.subscribe(value => {
    //   if (value === ' ')
    //     this.addAnnouncementForm.get('description').setValidators([ValidationService.notStartWhiteSpace]);
    // })
    if (this.userRole === this.roleEnum.PropertyManager) {
      this.addAnnouncementForm.controls.from.setValidators([Validators.required, ValidationService.emailValidator, ValidationService.notStartWhiteSpace]);
      this.addAnnouncementForm.controls.association.setValidators([Validators.required]);
      this.audienceType = AudienceType.PropertyManager;
    }
    else {
      this.audienceType = AudienceType.BoardMember;
    }
  }
  // editor Formating Option
  public editorOptions = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote'],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'script': 'sub' }, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
      [{ 'font': [] }],
      [{ 'align': [] }],
      ['clean'],                                         // remove formatting button
    ]
  };
  // Doughnut

  public doughnutChartType: string = 'doughnut';
  public PieData: any;
  public BoardTaskDatasets: any[] = [{
    data: this.boardTskCountData,
    // data: [1, 2, 3, 4],
    backgroundColor: [
      "#4b91e4",
      "#8ac74a ",
      "#E74C3C ",
      "#FFCE56"
    ]
  }];
  public serviceRequestdatasets: any[] = [
    {
      data: this.serviveRequestCountData,
      //data: [0, 0, 0, 0],
      backgroundColor: [
        "#4b91e4",
        "#8ac74a ",
        "#E74C3C ",
        "#FFCE56"
      ]
    }];
  public arcRequestdatasets: any[] = [
    {
      data: this.arcRequestCountData,
      // data: [1, 2, 3, 4],
      backgroundColor: [
        "#4b91e4",
        "#8ac74a ",
        "#E74C3C ",
        "#FFCE56"
      ]
    }];
  public violationdatasets: any[] = [
    {
      // data: this.violationCountData,
      data: this.violationCountData,
      backgroundColor: [
        "#4b91e4",
        "#8ac74a ",
        "#E74C3C ",
        "#FFCE56"
      ]
    }];
  public labels: string[] = ['New', 'Solved', 'Canceled', 'Pending'];
  public colors: Array<Color> = [{}];

  public chartOptions = {
    // Boolean - Whether we should show a stroke on each segment
    segmentShowStroke: true,
    // String - The colour of each segment stroke
    segmentStrokeColor: '#fff',
    // Number - The width of each segment stroke
    segmentStrokeWidth: 1,
    // Number - The percentage of the chart that we cut out of the middle
    percentageInnerCutout: 85, // This is 0 for Pie charts
    // Number - Amount of animation steps
    animationSteps: 100,
    // String - Animation easing effect
    animationEasing: 'easeOutBounce',
    // Boolean - Whether we animate the rotation of the Doughnut
    animateRotate: true,
    // Boolean - Whether we animate scaling the Doughnut from the centre
    animateScale: false,
    // Boolean - whether to make the chart responsive to window resizing
    responsive: true,
    // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
    maintainAspectRatio: false,
    // String - A legend template
    legendTemplate: '<ul class=\'<%=name.toLowerCase()%>-legend\'><% for (var i=0; i<segments.length; i++){%><li><span style=\'background-color:<%=segments[i].fillColor%>\'></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>',
    // String - A tooltip template
    tooltipTemplate: '<%=value %> <%=label%>',
    fullWidth: true,
    tooltipFontSize: 0,
    showTooltips: false,
    hover: { mode: null },
    tooltip: {
      enabled: false
    },

  };
  // events
  public chartClicked(e: any): void {
  }

  public chartHovered(e: any): void {
  }
  changeSDate() {
    this.minDate = this.addEventForm.controls.startDate.value;

  }
  changeEDate() {
    this.maxDate = this.addEventForm.controls.endDate.value;
  }
  // draw charts
  associationDashboardCarts() {


    let me = this;
    this.options = {
      cutoutPercentage: 89,
      circumference: 2 * Math.PI,
      rotation: Math.PI + Math.PI,
      animation: {
        onComplete: function () {
        }
      },
      segmentShowStroke: true,
      // String - The colour of each segment stroke
      segmentStrokeColor: '#fff',
      // Number - The width of each segment stroke
      segmentStrokeWidth: 1,
      // Number - The percentage of the chart that we cut out of the middle
      percentageInnerCutout: 85, // This is 0 for Pie charts
      // Number - Amount of animation steps
      animationSteps: 100,
      // String - Animation easing effect
      animationEasing: 'easeOutBounce',
      // Boolean - Whether we animate the rotation of the Doughnut
      animateRotate: true,
      // Boolean - Whether we animate scaling the Doughnut from the centre
      animateScale: false,
      // Boolean - whether to make the chart responsive to window resizing
      responsive: true,
      // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio: false,
      // String - A legend template
      legendTemplate: '<ul class=\'<%=name.toLowerCase()%>-legend\'><% for (var i=0; i<segments.length; i++){%><li><span style=\'background-color:<%=segments[i].fillColor%>\'></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>',
      // String - A tooltip template
      // tooltipTemplate: '<%=value %> <%=label%>',
      fullWidth: false,
      tooltipFontSize: 0,
      showTooltips: false,
      events: []
    };

  }
  // get dashboard data
  getDashboardData() {

    var date = new Date();
    this.firstDay = this.firstDay === undefined ? new Date(date.getFullYear(), date.getMonth(), 1) : '';
    this.lastDay = this.lastDay === undefined ? new Date(date.getFullYear(), date.getMonth() + 1, 0) : '';
    this.service.getDashboardData(this.associationId, this.userId, this.userRole, this.firstDay, this.lastDay, 3).subscribe(
      (response: any) => {

        if (response.Success) {
          // this.eventData = [];
          this.isAssociationDataLoad = true;
          this.userForOption1 = 0;
          this.userForOption2 = 0;
          this.addWelcomeDialog();
           this.userRole === RoleEnum.Member && response.GetSocialLanding.DashBoard.IsCommitteeMember ? this.isShowAssociationDasBoard = true : this.userRole === RoleEnum.Member ? this.isShowAssociationDasBoard = false : this.isShowAssociationDasBoard = true;
         // this.userRole === RoleEnum.Member ? this.isShowAssociationDasBoard = false : this.isShowAssociationDasBoard = true;
          if (!this.isShowAssociationDasBoard) {
            document.getElementById('myTab').click();
            this.myDashboard();
          }

          if (this.userRole === RoleEnum.PropertyManager) {
            this.redirectionLinks[0] = AppRouteUrl.mainBoardTasksPMRouteUrl;
            this.redirectionLinks[1] = AppRouteUrl.mainServiceRequestPMRouteUrl;
            this.redirectionLinks[2] = AppRouteUrl.mainArcPMRouteUrl;
            this.redirectionLinks[3] = AppRouteUrl.mainViolationsPMRouteUrl;
          }
          else if (this.userRole === RoleEnum.BoardMember && response.GetSocialLanding.DashBoard.IsCommitteeMember === false) {
            this.redirectionLinks[0] = AppRouteUrl.mainBoardTasksBMRouteUrl;
            this.redirectionLinks[1] = AppRouteUrl.mainServiceRequestBMRouteUrl;
            this.redirectionLinks[2] = AppRouteUrl.mainArcBMRouteUrl;
            this.redirectionLinks[3] = AppRouteUrl.mainViolationsBMRouteUrl;
          }
          else if (this.userRole === RoleEnum.BoardMember && response.GetSocialLanding.DashBoard.IsCommitteeMember === true) {
            this.redirectionLinks[0] = AppRouteUrl.mainBoardTasksBMRouteUrl;
            this.redirectionLinks[1] = AppRouteUrl.mainServiceRequestBMRouteUrl;
            this.redirectionLinks[2] = AppRouteUrl.mainArcCMRouteUrl;
            this.redirectionLinks[3] = AppRouteUrl.mainViolationsBMRouteUrl;
          }
          this.associationDashBoard = response.GetSocialLanding.DashBoard;
          if (response.GetSocialLanding.DashBoard.BoardTaskCount) {
            this.boardTaskTtal = response.GetSocialLanding.DashBoard.BoardTaskCount.TotalBoardTask;
            let New = response.GetSocialLanding.DashBoard.BoardTaskCount.NewBoardtask;
            let Solved = response.GetSocialLanding.DashBoard.BoardTaskCount.CompletedBoardTask;
            let Cancle = response.GetSocialLanding.DashBoard.BoardTaskCount.CanceledBoardTask;
            let Pending = response.GetSocialLanding.DashBoard.BoardTaskCount.AwaitingBoardDecisionBoardTask + response.GetSocialLanding.DashBoard.BoardTaskCount.InProgressBoardTask;
            if (New + Solved + Cancle + Pending === 0) {
              this.boardTskCountData[0] = 1;
              this.boardTskCountData[1] = 0;
              this.boardTskCountData[2] = 0;
              this.boardTskCountData[3] = 0;
              this.boardTaskTotal = 0;
            }
            else {
              this.boardTskCountData[0] = response.GetSocialLanding.DashBoard.BoardTaskCount.NewBoardtask;
              this.boardTskCountData[1] = response.GetSocialLanding.DashBoard.BoardTaskCount.CompletedBoardTask;
              this.boardTskCountData[2] = response.GetSocialLanding.DashBoard.BoardTaskCount.CanceledBoardTask;
              this.boardTskCountData[3] = response.GetSocialLanding.DashBoard.BoardTaskCount.AwaitingBoardDecisionBoardTask + + response.GetSocialLanding.DashBoard.BoardTaskCount.InProgressBoardTask;
              this.boardTaskTotal = this.boardTskCountData[0] + this.boardTskCountData[1] + this.boardTskCountData[2] + this.boardTskCountData[3];
            }
          }
          if (response.GetSocialLanding.DashBoard.ServiceRequestCount) {
            this.serviceRequestTtal = response.GetSocialLanding.DashBoard.ServiceRequestCount.TotalServiceRequest
            let New = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
            let Solved = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
            let Cancle = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
            let Pending = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
            if (New + Solved + Cancle + Pending === 0) {
              this.serviveRequestCountData[0] = 1;
              this.serviveRequestCountData[1] = 0;
              this.serviveRequestCountData[2] = 0;
              this.serviveRequestCountData[3] = 0;
              this.serviceRequestTotal = 0;
            }
            else {
              this.serviveRequestCountData[0] = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
              this.serviveRequestCountData[1] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
              this.serviveRequestCountData[2] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
              this.serviveRequestCountData[3] = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
              this.serviceRequestTotal = this.serviveRequestCountData[0] + this.serviveRequestCountData[1] + this.serviveRequestCountData[2] + this.serviveRequestCountData[3];
            }
          }
          if (response.GetSocialLanding.DashBoard.ArcCount) {
            this.arcRequestTtal = response.GetSocialLanding.DashBoard.ArcCount.TotalARC;
            let New = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
            let Solved = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
            let Cancle = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
            let Pending = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest + response.GetSocialLanding.DashBoard.ArcCount.DeniedArc + response.GetSocialLanding.DashBoard.ArcCount.ApprovedArc;
            if (New + Solved + Cancle + Pending === 0) {
              this.arcRequestCountData[0] = 1;
              this.arcRequestCountData[1] = 0;
              this.arcRequestCountData[2] = 0;
              this.arcRequestCountData[3] = 0;
              this.arcTotal = 0;
            }
            else {
              this.arcRequestCountData[0] = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
              this.arcRequestCountData[1] = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
              this.arcRequestCountData[2] = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
              this.arcRequestCountData[3] = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest + response.GetSocialLanding.DashBoard.ArcCount.DeniedArc + response.GetSocialLanding.DashBoard.ArcCount.ApprovedArc;
              this.arcTotal = this.arcRequestCountData[0] + this.arcRequestCountData[1] + this.arcRequestCountData[2] + this.arcRequestCountData[3];
            }

          }
          if (response.GetSocialLanding.DashBoard.ViolationCount) {
            this.violationTtal = response.GetSocialLanding.DashBoard.ViolationCount.TotalVoialation;
            let New = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
            let Solved = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
            let Cancle = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
            let Pending = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
            if (New + Solved + Cancle + Pending === 0) {
              this.violationCountData[0] = 1;
              this.violationCountData[1] = 0;
              this.violationCountData[2] = 0;
              this.violationCountData[3] = 0;
              this.violationTotal = 0;
            }
            else {
              this.violationCountData[0] = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
              this.violationCountData[1] = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
              this.violationCountData[2] = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
              this.violationCountData[3] = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
              this.violationTotal = this.violationCountData[0] + this.violationCountData[1] + this.violationCountData[2] + this.violationCountData[3];
            }
          }
          this.associationDashboardCarts();
          this.isComponentLoad = true;
        }

      }
    );
  }
  allEventsData() {
    this.eventData = [];
    this.responseData.SocialLandingList.forEach((event) => {
      if (event.PostType === "Event") {
        if (event.EventLikeIds !== null) {
          event.Like_details = event.EventLikeIds.SocialEventLikeDetails;
          if (event.EventLikeIds.SocialEventLikeDetails.length > 0) {
              event.Likes = event.EventLikeIds.SocialEventLikeDetails.length;
              var likesData =  event.EventLikeIds.SocialEventLikeDetails.filter(f => f.ChoosenByUserIds === this.userId );
              likesData.length > 0 ? event.likeText = this.likeText.Unlike : event.likeText = this.likeText.Like;
          }
          else {
            event.likeText = this.likeText.Like;
            event.Likes = 0;
          }
        }
        else {
          event.Likes = 0;
          event.likeText = this.likeText.Like;
          event.Like_details = [];
        }
        this.eventData.push(event);
      }
      if (event.PostType === "Announcement") {
        if (event.AnnouncementLikeIds !== null) {
          event.Like_details = event.AnnouncementLikeIds.SocialAnnouncementLikeDetails;
          if (event.AnnouncementLikeIds.SocialAnnouncementLikeDetails.length > 0) {
            event.Likes = event.AnnouncementLikeIds.SocialAnnouncementLikeDetails.length;
            var likesData =  event.AnnouncementLikeIds.SocialAnnouncementLikeDetails.filter(f => f.ChoosenByUserIds === this.userId );
            likesData.length > 0 ? event.likeText = this.likeText.Unlike : event.likeText = this.likeText.Like;
          }
          else {
            event.likeText = this.likeText.Like;
            event.Likes = 0;
          }
        }
        else {
          event.likeText = this.likeText.Like;
          event.Like_details = [];
          event.Likes = 0;
        }
        this.eventData.push(event);
      }
      if (event.PostType === "Poll") {
        this.userForOption1 = 0;
        this.userForOption2 = 0;
       // if (new Date(event.PollEndDate) >= new Date()) {
          if (event.Options[0].ChoosenByUserIds !== null) {
            event.Options[0].ChoosenByUserIds.forEach((e) => {
              if (e === this.userId) {
                this.userForOption1 = 1;

              }
            });
            if (this.userForOption1 === 1) {
              event.userEnablaed = false;
            }
            else {
              if (event.Options[1].ChoosenByUserIds !== null) {
                event.Options[1].ChoosenByUserIds.forEach((e) => {
                  if (e === this.userId) {
                    this.userForOption2 = 1;

                  }
                });
                this.userForOption2 === 1 ? event.userEnablaed = false : event.userEnablaed = true;
              }
            }
          }
          if (event.PollLikeIds !== null) {
            if (event.PollLikeIds.SocialPollLikeDetails.length > 0) {
              event.Likes = event.PollLikeIds.SocialPollLikeDetails.length;
              event.Like_details = event.PollLikeIds.SocialPollLikeDetails;
              var likesData =  event.PollLikeIds.SocialPollLikeDetails.filter(f => f.ChoosenByUserIds === this.userId );
              likesData.length > 0 ? event.likeText = this.likeText.Unlike : event.likeText = this.likeText.Like;
            }
            else {
              event.likeText = this.likeText.Like;
              event.Likes = 0;
            }
          }
          else {
            event.likeText = this.likeText.Like;
            event.Like_details = [];
            event.Likes = 0;
          }
          this.eventData.push(event);
       // }
      }
    });
  }
  getSocialLanding() {
    this.isSpinnerShow = true;
    //this.eventData = [];
    this.service.getSocialLandingData(this.associationId, this.userId, this.userRole, this.firstDay, this.lastDay, this.counter).subscribe(
      (response: any) => {
        this.isComponentLoad = true;
        this.getSocialCount();
        if (response.Success) {
         this.isSpinnerShow = false;
          if (response.GetSocialLanding !== null) {
            this.responseData = response.GetSocialLanding.GetSocialList;
            this.allEventsData();
          }
          else{
            this.isResponse = false;
          }

        }
        else {
          this.isResponse = false;
        }

      }
    );
  }

  getSocialCount() {
    var date = new Date();
    this.firstDay = this.firstDay === undefined ? new Date(date.getFullYear(), date.getMonth(), 1) : '';
    this.lastDay = this.lastDay === undefined ? new Date(date.getFullYear(), date.getMonth() + 1, 0) : '';

    this.service.getSocialCount(this.associationId, this.userId, this.userRole, this.firstDay, this.lastDay, 3).subscribe(
      (response: any) => {
        if (response.Success) {
          this.totalEvents =response.GetSocialLanding.GetSocialLandingCount.SocialEvent;
          this.totalPolls= response.GetSocialLanding.GetSocialLandingCount.SocialPoll;
          this.totalAnnouncement = response.GetSocialLanding.GetSocialLandingCount.SocialAnnouncement;
          this.total = this.totalEvents + this.totalPolls + this.totalAnnouncement;
        }
      }
    );
  }

  // get My Dashboard Data
  myDashboard() {
    this.isAssociationDataLoad = false;
    this.isMyDashboardDataLoad = false;
    this.isDateFilterResponceLoad = true;
    var date = new Date();
    this.firstDay = (this.firstDay === undefined || this.firstDay === '' || this.firstDay === null) ? new Date(date.getFullYear(), date.getMonth(), 1) : this.firstDay;
    this.lastDay = (this.lastDay === undefined || this.lastDay === '' || this.lastDay === null) ? new Date(date.getFullYear(), date.getMonth() + 1, 0) : this.lastDay;

    this.service.myDashboardData(this.associationId, this.userId, this.userRole, this.firstDay, this.lastDay).subscribe(
      (response: any) => {
        this.isDateFilterResponceLoad = false;
        if (response.Success) {
          this.isMyDashboardDataLoad = true;
          this.associationDashBoard = response.GetSocialLanding.DashBoard;
          if (response.GetSocialLanding.DashBoard.ServiceRequestCount) {
            this.serviceRequestTtal = response.GetSocialLanding.DashBoard.ServiceRequestCount.TotalServiceRequest
            let New = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
            let Solved = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
            let Cancle = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
            let Pending = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
            let inprogress = response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
            if (New + Solved + Cancle + Pending === 0) {
              this.serviveRequestCountData[0] = 1;
              this.serviveRequestCountData[1] = 0;
              this.serviveRequestCountData[2] = 0;
              this.serviveRequestCountData[3] = 0;
              this.serviceRequestTotal = 0;
            }
            else {
              this.serviveRequestCountData[0] = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
              this.serviveRequestCountData[1] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
              this.serviveRequestCountData[2] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
              this.serviveRequestCountData[3] = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
              this.serviceRequestTotal = this.serviveRequestCountData[0] + this.serviveRequestCountData[1] + this.serviveRequestCountData[2] + this.serviveRequestCountData[3];
            }
          }
          if (response.GetSocialLanding.DashBoard.ArcCount) {
            this.arcRequestTtal = response.GetSocialLanding.DashBoard.ArcCount.TotalARC;
            let New = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
            let Solved = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
            let Cancle = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
            let Pending = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest + response.GetSocialLanding.DashBoard.ArcCount.DeniedArc + response.GetSocialLanding.DashBoard.ArcCount.ApprovedArc;
            if (New + Solved + Cancle + Pending === 0) {
              this.arcRequestCountData[0] = 1;
              this.arcRequestCountData[1] = 0;
              this.arcRequestCountData[2] = 0;
              this.arcRequestCountData[3] = 0;
              this.arcTotal = 0;
            }
            else {
              this.arcRequestCountData[0] = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
              this.arcRequestCountData[1] = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
              this.arcRequestCountData[2] = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
              this.arcRequestCountData[3] = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest + response.GetSocialLanding.DashBoard.ArcCount.DeniedArc + response.GetSocialLanding.DashBoard.ArcCount.ApprovedArc;
              this.arcTotal = this.arcRequestCountData[0] + this.arcRequestCountData[1] + this.arcRequestCountData[2] + this.arcRequestCountData[3];
            }

          }
          if (response.GetSocialLanding.DashBoard.ViolationCount) {
            this.violationTtal = response.GetSocialLanding.DashBoard.ViolationCount.TotalVoialation;
            let New = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
            let Solved = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
            let Cancle = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
            let Pending = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
            if (New + Solved + Cancle + Pending === 0) {
              this.violationCountData[0] = 1;
              this.violationCountData[1] = 0;
              this.violationCountData[2] = 0;
              this.violationCountData[3] = 0;
              this.violationTotal = 0;
            }
            else {
              this.violationCountData[0] = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
              this.violationCountData[1] = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
              this.violationCountData[2] = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
              this.violationCountData[3] = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
              this.violationTotal = this.violationCountData[0] + this.violationCountData[1] + this.violationCountData[2] + this.violationCountData[3];
            }
          }
          this.associationDashboardCarts();

        }

      }
    );
  }
  // get Association Dashboard Data
  associationDashBoardData() {
    this.isDateFilterResponceLoad = true;
    this.isAssociationDataLoad = false;
    this.isMyDashboardDataLoad = false; 
    document.getElementById('assoinfo-tab').click();
    var date = new Date();
    this.firstDay = (this.newfirstDay === undefined || this.newfirstDay === '' || this.newfirstDay === null) ? new Date(date.getFullYear(), date.getMonth(), 1) : this.newfirstDay;
    this.lastDay = (this.newlastDay === undefined || this.newlastDay === '' || this.newlastDay === null) ? new Date(date.getFullYear(), date.getMonth() + 1, 0) : this.newlastDay;
    this.service.associationDashBoardData(this.associationId, this.userId, this.userRole, this.firstDay, this.lastDay).subscribe(
      (response: any) => {
        this.isDateFilterResponceLoad = false;
        if (response.Success) {
          this.isAssociationDataLoad = true;
          this.associationDashBoard = response.GetSocialLanding.DashBoard;

          if (response.GetSocialLanding.DashBoard.BoardTaskCount) {
            this.boardTaskTtal = response.GetSocialLanding.DashBoard.BoardTaskCount.TotalBoardTask;
            let New = response.GetSocialLanding.DashBoard.BoardTaskCount.NewBoardtask;
            let Solved = response.GetSocialLanding.DashBoard.BoardTaskCount.CompletedBoardTask;
            let Cancle = response.GetSocialLanding.DashBoard.BoardTaskCount.CanceledBoardTask;
            let Pending = response.GetSocialLanding.DashBoard.BoardTaskCount.AwaitingBoardDecisionBoardTask + response.GetSocialLanding.DashBoard.BoardTaskCount.InProgressBoardTask;
            if (New + Solved + Cancle + Pending === 0) {
              this.boardTskCountData[0] = 1;
              this.boardTskCountData[1] = 0;
              this.boardTskCountData[2] = 0;
              this.boardTskCountData[3] = 0;
              this.boardTaskTotal = 0;
            }
            else {
              this.boardTskCountData[0] = response.GetSocialLanding.DashBoard.BoardTaskCount.NewBoardtask;
              this.boardTskCountData[1] = response.GetSocialLanding.DashBoard.BoardTaskCount.CompletedBoardTask;
              this.boardTskCountData[2] = response.GetSocialLanding.DashBoard.BoardTaskCount.CanceledBoardTask;
              this.boardTskCountData[3] = response.GetSocialLanding.DashBoard.BoardTaskCount.AwaitingBoardDecisionBoardTask + response.GetSocialLanding.DashBoard.BoardTaskCount.InProgressBoardTask;
              this.boardTaskTotal = this.boardTskCountData[0] + this.boardTskCountData[1] + this.boardTskCountData[2] + this.boardTskCountData[3];
            }
          }
          if (response.GetSocialLanding.DashBoard.ServiceRequestCount) {
            this.serviceRequestTtal = response.GetSocialLanding.DashBoard.ServiceRequestCount.TotalServiceRequest
            let New = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
            let Solved = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
            let Cancle = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
            let Pending = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
            if (New + Solved + Cancle + Pending === 0) {
              this.serviveRequestCountData[0] = 1;
              this.serviveRequestCountData[1] = 0;
              this.serviveRequestCountData[2] = 0;
              this.serviveRequestCountData[3] = 0;
              this.serviceRequestTotal = 0;
            }
            else {
              this.serviveRequestCountData[0] = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
              this.serviveRequestCountData[1] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
              this.serviveRequestCountData[2] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
              this.serviveRequestCountData[3] = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
              this.serviceRequestTotal = this.serviveRequestCountData[0] + this.serviveRequestCountData[1] + this.serviveRequestCountData[2] + this.serviveRequestCountData[3];
            }
          }
          if (response.GetSocialLanding.DashBoard.ArcCount) {
            this.arcRequestTtal = response.GetSocialLanding.DashBoard.ArcCount.TotalARC;
            let New = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
            let Solved = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
            let Cancle = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
            let Pending = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest + response.GetSocialLanding.DashBoard.ArcCount.DeniedArc + response.GetSocialLanding.DashBoard.ArcCount.ApprovedArc;
            if (New + Solved + Cancle + Pending === 0) {
              this.arcRequestCountData[0] = 1;
              this.arcRequestCountData[1] = 0;
              this.arcRequestCountData[2] = 0;
              this.arcRequestCountData[3] = 0;
              this.arcTotal = 0;
            }
            else {
              this.arcRequestCountData[0] = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
              this.arcRequestCountData[1] = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
              this.arcRequestCountData[2] = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
              this.arcRequestCountData[3] = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest + response.GetSocialLanding.DashBoard.ArcCount.DeniedArc + response.GetSocialLanding.DashBoard.ArcCount.ApprovedArc;
              this.arcTotal = this.arcRequestCountData[0] + this.arcRequestCountData[1] + this.arcRequestCountData[2] + this.arcRequestCountData[3];
            }

          }
          if (response.GetSocialLanding.DashBoard.ViolationCount) {
            this.violationTtal = response.GetSocialLanding.DashBoard.ViolationCount.TotalVoialation;
            let New = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
            let Solved = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
            let Cancle = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
            let Pending = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
            if (New + Solved + Cancle + Pending === 0) {
              this.violationCountData[0] = 1;
              this.violationCountData[1] = 0;
              this.violationCountData[2] = 0;
              this.violationCountData[3] = 0;
              this.violationTotal = 0;
            }
            else {
              this.violationCountData[0] = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
              this.violationCountData[1] = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
              this.violationCountData[2] = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
              this.violationCountData[3] = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
              this.violationTotal = this.violationCountData[0] + this.violationCountData[1] + this.violationCountData[2] + this.violationCountData[3];
            }
          }
          this.associationDashboardCarts();
        }

      }
    );
  }
  // Add Event Panel
  showEvents() {
    this.getEventCatagory();
    this.isEventShow = true;
    this.isPollShow = false;
    this.isPhotosShow = false;
    this.isPostShow = false;
    this.fileData = [];
    this.photosDescription = "";
    this.errorMsg = "";
    this.isPostButton = false;
    this.isEventButton = false;
    this.isAnnouncementShow = false;
  }
  // on file upload
  onUploadChange(evt: any) {
    // this.imgFlag = false;
    this.fileData = [];
    this.errorMsg = "";
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      var reader = new FileReader();
      reader.onload = (event: any) => {
        let type = evt.target.files[0].name.split(".");
        if (type[type.length -1].toLowerCase() === 'jpeg' || type[type.length -1].toLowerCase() === 'jpg' || type[type.length -1].toLowerCase() === 'png' || type[type.length -1].toLowerCase() === 'gif' || type[type.length -1].toLowerCase() === 'bmp' || type[type.length -1].toLowerCase() === 'jfif' || type[1].toLowerCase() === 'tif' || type[type.length -1].toLowerCase() === 'tiff') {
          this.fileData.push({
            inputStream: event.target.result,
            name: evt.target.files[0].name,
            type: evt.target.files[0].type
          });
        }
        else {
          this.errorMsg = "Select only images";
        }

      }
      reader.readAsDataURL(evt.target.files[0]);
      // this.newImage = this.fileData[0].inputStream;
    }

  }
  // on file upload
  onPhotosChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      this.errorMsg = "";
      this.showPhotos();
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {

          let type = evt.target.files[i].name.split(".");
          if (type[type.length -1].toLowerCase() === 'jpeg' || type[type.length -1].toLowerCase() === 'jpg' || type[type.length -1].toLowerCase() === 'png' || type[type.length -1].toLowerCase() === 'gif' || type[type.length -1].toLowerCase() === 'bmp' || type[type.length -1].toLowerCase() === 'jfif' || type[1].toLowerCase() === 'tif' || type[type.length -1].toLowerCase() === 'tiff') {
            this.fileData.push({
              imageId: Guid.create(),
              inputStream: event.target.result,
              name: evt.target.files[i].name,
              type: evt.target.files[i].type,
              mediaType: type[type.length -1],
              CreatedByUserName: this.userName
            });
          }
          else {
            this.errorMsg = "Select only images";
            this.isPostButton = false;
            this.isPhotosShow = false;
            this.notificationService.showNotification('Select only images');
          }

        }
        reader.readAsDataURL(evt.target.files[i]);
      }

    }

  }
  // remove uploaded images
  removeImage(guid) {
    var tempArray = [];
    this.fileData.forEach((e) => {
      if (e.imageId !== guid) {
        tempArray.push(e);
      }
    });
    this.fileData = tempArray;
    if (this.fileData.length === 0) {
      //  this.imgFlag = true;
      this.isPostButton = false;
    }
  }
  getEventCatagory() {
    this.service.getCategoryEvent().subscribe(
      (response: any) => {
        if (response.Success) {
          this.eventCategoryData = response.EventCategory;
        }
      }
    );
  }
  getSelectedCategory(category) {
    this.eventCategoryData.find((event) => {
      if (event.Name === category.value) {
        this.eventSubCategoryData = event.EventSubCategories;
      }
    });
  }
  // Add Event Model
  addEventModel() {
    let model = {
      AssociationId: this.associationId,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      Attachments: [{
        InputStream: this.fileData[0].inputStream,
        FileName: this.fileData[0].name
      }],
      EventName: this.addEventForm.controls.eventName.value,
      StartDate: this.addEventForm.controls.startDate.value,
      EndDate: this.addEventForm.controls.endDate.value,
      Category: this.addEventForm.controls.category.value,
      SubCategory: this.addEventForm.controls.subCategory.value,
      Location: this.addEventForm.controls.location.value,
      CreatedOn: new Date(),
      EventType: this.eventType,
      BodyText: this.addEventForm.controls.detail.value,
      ModifiedOn: new Date()
    }
    return model;
  }
  // Add Event Method
  addEvent() {
    if (this.fileData.length === 0) {
      this.errorMsg = "Please select image";
      window.scrollTo(0, 0);
    }
    else {
      let model = this.addEventModel();
      if (this.addEventForm.valid) {
        this.isEventButton = true;
        this.service.addEvent(this.associationId, model).subscribe(
          (response: any) => {
            if (response.Success) {
              this.resetEventForm();
              this.getSocialLanding();
              this.notificationService.showNotification(response.Message);
            }
            else {
              console.log('Error');
            }
          }
        );
      }


    }


  }
  // Reset Add Event Form
  resetEventForm() {
    this.addEventForm.reset();
    this.addEventDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.isEventShow = false;
    this.minDate = null;
    this.maxDate = null;
    this.isPostShow = true;
    this.isPostButton = false;
    //this.isShowEventButtons = true;
  }
  // Add Poll Model
  showPoll() {
    this.isPollShow = true;
    this.isEventShow = false;
    this.isPhotosShow = false;
    //this.isShowEventButtons = false;
    this.isPostShow = false;
    this.fileData = [];
    this.photosDescription = "";
    this.errorMsg = "";
    this.isPostButton = false;
    this.isPollButton = false;
    this.isAnnouncementShow = false;

  }
  // 
  getQuestion(event) {

    this.question = event.target.value;
  }
  // Cancle Poll
  canclePoll() {
    this.isShowEventButtons = true;
    this.isPollShow = false;
    this.isPostShow = true;
    this.isPostButton = false;
    this.isAnnouncementShow = false;
    this.addpollForm.reset();
    this.addPollDirective.resetForm();

  }
  // Add Poll Model
  addPollModel() {
    let model: AddPoll = {
      AssociationId: this.associationId,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      Question: this.addpollForm.controls.question.value,
      PollEndDate: this.addpollForm.controls.endDate.value,
      Options: [{
        Description: this.addpollForm.controls.options1.value
      },
      {
        Description: this.addpollForm.controls.options2.value
      }],
      CreatedOn: new Date(),
      ModifiedOn: new Date()
    };
    return model;
  }
  // Add Poll Method
  addPoll() {

    let model = this.addPollModel();

    if (this.addpollForm.valid) {
      this.isPollButton = true;
      this.service.addPoll(this.associationId, model).subscribe(
        (response: any) => {

          if (response.Success) {
            this.isPollButton = false;
            this.resetPollForm();
            this.getSocialLanding();
            this.notificationService.showNotification(response.Message);
          }
          else {
            console.log('Error');
          }
        }
      );
    }
  }
  // Reset Add Poll Form
  resetPollForm() {
    this.addpollForm.reset();
    this.addPollDirective.resetForm();
    this.canclePoll();
    let a: any = document.getElementById('questions');
    a.value = "";
  }
  // Parent Model
  parentModel(id) {
    let attechment = [];
    if (this.fileData.length > 0) {
      attechment = [{
        InputStream: this.fileData[0].inputStream,
        FileName: this.fileData[0].name
      }];
    }

    let model: ParentSocialEvent = {
      AssociationId: this.associationId,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      BodyText: this.addCommentForm.controls.comment.value.trim(),
      id: id,
      Attachments: attechment,
      ModifiedOn: new Date()
    }
    return model;
  }
  // Child Model
  childModel() {
    let attechment = [];
    if (this.fileData.length > 0) {
      attechment = [{
        InputStream: this.fileData[0].inputStream,
        FileName: this.fileData[0].name
      }];
    }
    let model1: ChildSocialEvent = {
      AssociationId: this.associationId,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      BodyText: this.addCommentForm.controls.comment.value.trim(),
      Attachments: attechment,
      ModifiedOn: new Date()
    }
    return model1;
  }
  // Add Comment Method
  addComment(id, type) {
    let parentModel = this.parentModel(id);
    let childModel = this.childModel();
    if(this.addCommentForm.valid && parentModel.BodyText !== '' && !this.isComment) {
      this.isComment = true;
    if (type === this.eventType) {
      this.service.addSocialEventComment(this.associationId, parentModel, childModel).subscribe(
        (response: any) => {

          if (response.Success) {
            this.getCommentsData(id, type);
            this.getSocialLanding();
            this.resetCommentForm();
          }
        }
      );
    }
    else if (type === this.pollType) {
      this.service.addPollComment(this.associationId, parentModel, childModel).subscribe(
        (response: any) => {
          if (response.Success) {
            this.getCommentsData(id, type);
            this.getSocialLanding();
            this.resetCommentForm();
          }
        }
      );
    }
    else {
      this.service.addAnnouncementComment(this.associationId, parentModel, childModel).subscribe(
        (response: any) => {
          if (response.Success) {
            this.getCommentsData(id, type);
            this.getSocialLanding();
            this.resetCommentForm();
          }
        }
      );
    }
  }
  }

  resetCommentForm() {
    this.addCommentForm.reset();
    this.fileData = [];
    this.errorMsg = "";
    this.isComment = false;
  }

  updatePoll(poll: any, option, isUserEnable) {
    poll.id = poll.PostId;
    if (isUserEnable === true || isUserEnable === undefined) {
      if (option === 'option1') {
        if (poll.Options[0].ChoosenByUserIds === null) {
          poll.Options[0].ChoosenByUserIds = [this.userId];
        }
        else {
          poll.Options[0].ChoosenByUserIds.push(this.userId);
        }
      }
      else {
        if (poll.Options[1].ChoosenByUserIds === null) {
          poll.Options[1].ChoosenByUserIds = [this.userId];
        }
        else {
          poll.Options[1].ChoosenByUserIds.push(this.userId);
        }
      }


      let model = poll;
      this.service.updatePoll(this.associationId, model).subscribe(
        (response: any) => {
          if (response.Success) {
            this.getSocialLanding();
          }
        }
      );
    }
    else {
      console.log('User has already Reviewed');
      this.notificationService.showNotification('User has already Reviewed');
    }
  }

  like(post: any, type) {
    //  post.Likes = post.Likes + 1;
    if(post.id) {
      post.PostId = post.id;
    }
    let model = post;
    if (type === this.pollType) {
      this.service.likePoll(this.associationId, post.PostId, this.userId, this.userName, this.counter).subscribe(
        (response: any) => {
          if (response.Success) {
         this.responseData = response.GetSocialList;
            if(this.currentPost === this.pollType) {
              this.allPolls();
            }
            else {
              this.allEventsData();
            }
          }
        }
      );
    }
    else if (type === this.eventType) {
      this.service.likeEvent(this.associationId, post.PostId, this.userId, this.userName, this.counter).subscribe(
        (response: any) => {
          if (response.Success) {
          this.responseData = response.GetSocialList;
          if(this.currentPost === this.eventType) {
            this.allEvents();
          }
          else {
            this.allEventsData();
          }
          }
        }
      );
    }
    else {
      this.service.likeAnnouncement(this.associationId, post.PostId, this.userId, this.userName, this.counter).subscribe(
        (response: any) => {
          if (response.Success) {
            this.responseData = response.GetSocialList;
            if(this.currentPost === this.announcementType) {
              this.allAnnouncements();
            }
            else {
              this.allEventsData();
            }
          }
        });
    }
  }

  firstTimeShowAllPost(type) {
    this.eventData=[];
    this.counter = 3;
    this.showAllPost(type)
  }
  allEvents() {
    this.eventData=[];
    this.responseData.SocialEventList.forEach(
      (event) => {
        event.PostId = event.id;
        if (event.LikeIds !== null) {
          if (event.LikeIds.SocialEventLikeDetails.length > 0) {
            event.Likes = event.LikeIds.SocialEventLikeDetails.length;
            event.Like_details = event.LikeIds.SocialEventLikeDetails;
            var likesData =  event.LikeIds.SocialEventLikeDetails.filter(f => f.ChoosenByUserIds === this.userId );
            likesData.length > 0 ? event.likeText = this.likeText.Unlike : event.likeText = this.likeText.Like;
          }
          else {
            event.likeText = this.likeText.Like;
            event.Like_details = [];
            event.Likes = 0;
          }
        }
        else {
          event.likeText = this.likeText.Like;
          event.Like_details = [];
          event.Likes = 0;
        }
        this.eventData.push(event);
      });
  }
  allPolls() {
    this.eventData = [];
    this.responseData.SocialPollList.forEach(
      (poll: any) => {
      //  if (new Date(poll.PollEndDate) >= new Date()) {
          poll.PostId = poll.id;
          if (poll.Options[0].ChoosenByUserIds !== null) {
            poll.Options[0].ChoosenByUserIds.forEach((e) => {
              if (e === this.userId) {
                this.userForOption1 = 1;
              }
            });
            this.userForOption1 === 1 ? poll.userEnablaed = false : poll.userEnablaed = true;
          }
          if (poll.Options[1].ChoosenByUserIds !== null) {
            poll.Options[1].ChoosenByUserIds.forEach((e) => {
              if (e === this.userId) {
                this.userForOption2 = 1;
              }
            });
            this.userForOption2 === 1 ? poll.userEnablaed = false : poll.userEnablaed = true;
          }
          if (poll.LikeIds !== null) {
            if (poll.LikeIds.SocialPollLikeDetails.length > 0) {
              poll.Likes = poll.LikeIds.SocialPollLikeDetails.length;
              poll.Like_details = poll.LikeIds.SocialPollLikeDetails;
              var likesData =  poll.LikeIds.SocialPollLikeDetails.filter(f => f.ChoosenByUserIds === this.userId );
              likesData.length > 0 ? poll.likeText = this.likeText.Unlike : poll.likeText = this.likeText.Like;
            }
            else {
              poll.likeText = this.likeText.Like;
              poll.Like_details = [];
              poll.Likes = 0;
            }
          }
          else {
            poll.likeText = this.likeText.Like;
            poll.Like_details = [];
            poll.Likes =0;
          }
          this.eventData.push(poll);
       // }
      });
  }
  allAnnouncements() {
    this.eventData =[];
    this.responseData.SocialAnnouncementList.forEach(
      (announcement) => {
        announcement.PostId = announcement.id;
        if (announcement.LikeIds !== null) {
          if (announcement.LikeIds.SocialAnnouncementLikeDetails.length > 0) {
            announcement.Likes = announcement.LikeIds.SocialAnnouncementLikeDetails.length;
            announcement.Like_details = announcement.LikeIds.SocialAnnouncementLikeDetails;
            var likesData = announcement.LikeIds.SocialAnnouncementLikeDetails.filter(f => f.ChoosenByUserIds === this.userId );
              likesData.length > 0 ? announcement.likeText = this.likeText.Unlike : announcement.likeText = this.likeText.Like;
          }
          else {
            announcement.likeText = this.likeText.Like;
            announcement.Like_details = [];
            announcement.Likes =0;
          }
        }
        else {
          announcement.likeText = this.likeText.Like;
          announcement.Like_details = [];
          announcement.Likes =0;
        }
        this.eventData.push(announcement);
      });
  }
  showAllPost(type) {
    this.counter = this.counter > 3 ? this.counter : 3;
    if (type === this.eventType) {
      this.currentPost = type;
      if(this.totalEvents > 0) {
        //this.eventData =[];
        this.isSpinnerShow = true;
        this.isResponse = true;
        this.total = this.totalEvents;
        this.service.getSocialEvent(this.associationId, this.counter).subscribe(
          (response: any) => {
            this.isSpinnerShow = false;
            if (response.Success) {
              this.eventData = [];
              this.responseData = response.GetSocialList;
              this.allEvents();
            }
            else {
              this.isResponse = false;
              this.eventData = [];
            }
          });
      } 
      else {
        this.eventData = [];
      }
    }
    else if (type === this.pollType) {
      this.currentPost = type;
      if(this.totalPolls > 0) {
       // this.eventData =[];
        this.isResponse = true;
        this.total = this.totalPolls;
        this.isSpinnerShow = true;
        this.service.getSocialPoll(this.associationId, this.counter).subscribe(
          (response: any) => {
            this.isSpinnerShow = false;
            if (response.Success) {
              this.eventData = [];
              this.responseData = response.GetSocialList;
              this.allPolls();
            }
            else {
              this.eventData = [];
              this.isResponse = false;
            }
          });
      } 
      else{
        this.eventData = [];
      }
    }
    else if (type === this.announcementType) {
      this.currentPost = type;
      if(this.totalAnnouncement > 0) {
     // this.eventData = [];
      this.isSpinnerShow = true;
      this.isResponse = true;
      this.total = this.totalAnnouncement;
        this.service.getSocialAnnouncement(this.associationId, this.counter).subscribe(
          (response: any) => {
            this.isSpinnerShow = false;
            if (response.Success) {
              this.eventData = [];
              this.responseData = response.GetSocialList;
              this.allAnnouncements();
            }
            else {
              this.eventData = [];
              this.isResponse = false;
            }
          });
      }
      else {
         this.eventData = [];
      }
    }
    else {
      this.currentPost = 'All';
      this.counter = 3;
      this.getSocialLanding();
    }



  }
  showPhotos() {
    this.isPhotosShow = true;
    this.isPollShow = false;
    this.isEventShow = false;
    this.isPostShow = true;
    this.isPostButton = true;
    this.isAnnouncementShow = false;

  }
  getEventDesc() {
    if (this.photosDescription[0] === ' ' || this.photosDescription === '\n') {
      this.photosDescription = this.photosDescription.trim();
      return false;
    }

    if (this.photosDescription.length > 0) {
      this.isPostButton = true;
    }
    else {
      this.isPostButton = false;
    }
  }
  addPhotosModel() {
    let model: AddPhotos = {
      AssociationId: this.associationId,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      Attachments: this.fileData,
      EventType: this.photoType,
      BodyText: this.photosDescription,
      CreatedOn: new Date(),
      ModifiedOn: new Date()
    };
    return model;
  }
  addPhotos() {
    let model = this.addPhotosModel();
    this.isPostButton = false;
    this.service.addEvent(this.associationId, model).subscribe(
      (response: any) => {
        if (response.Success) {
          this.resetPhotosForm();
          this.getSocialLanding();
          this.notificationService.showNotification('Post Saved Successfully.');
        }
        else {
          console.log('Error');
        }
      }
    );
  }
  // Reset Add Poll Form
  resetPhotosForm() {
    this.addPhotosForm.reset();
    this.errorMsg = "";
    this.fileData = [];
    this.isPhotosShow = false;
    this.photosDescription = "";
  }

  showLikers(id) {
    // this.likeID = id;
    // this.commentID = "";
    var y = document.getElementById(id);
    if (y.style.display === "none") {
      y.style.display = "block";
    } else {
      y.style.display = "none";
    }

  }


  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.eventReadMoreDescriptionLabel = "Read more";
    }
    else {
      this.readMoreBtn = true;
      this.eventReadMoreDescriptionLabel = "Read less";
    }
  }
  viewMoreEventDesc(length) {

    if (this.eventDescriptionLength === 50) {
      this.eventDescriptionLength = length;
      this.eventReadMoreDescriptionLabel = "Read less";
    }
    else {
      this.eventDescriptionLength = 50;
      this.eventReadMoreDescriptionLabel = "Read more";
    }

  }
  loadMoreComments() {
    if (this.showNcomments === 3) {
      this.showNcomments = this.commentsData.length;
      this.loadMoreCommentsLabel = "Read less"
    }
    else {
      this.showNcomments = 3;
      this.loadMoreCommentsLabel = "Read more"
    }
  }
  getCommentsData(id, type) {
    if (type === this.pollType) {
      if (!this.isShowComments) {
        this.isShowComments = true;
        this.service.getPostPollReplies(id).subscribe(
          (response: any) => {
            if (response.Success) {
              this.commentsData = response.GetSocial.SocialPoll.ChildReplies;
            }
          }
        );
      }
      else {
        this.isShowComments = false;
      }
    }
    else if (type === this.eventType) {
      if (!this.isShowComments) {
        this.isShowComments = true;
        this.service.getPostEventReplies(id).subscribe(
          (response: any) => {
            if (response.Success) {
              this.commentsData = response.GetSocial.SocialEvent.ChildReplies;
            }
          }
        );
      }
      else {
        this.isShowComments = false;
      }
    }
    else {
      if (!this.isShowComments) {
        this.isShowComments = true;
        this.service.getPostAnnouncmentReplies(id).subscribe(
          (response: any) => {
            if (response.Success) {
              this.commentsData = response.GetSocial.SocialAnnouncement.ChildReplies;
            }
          }
        );
      }
      else {
        this.isShowComments = false;
      }
    }

  }
  showComments(id, type) {
    this.likeID = "";
    this.commentID = id;
    this.getCommentsData(id, type);

    // let i = id.split('_')[1];  
    //   var y = document.getElementById(id);
    // if (y.style.display === "none") {
    //   y.style.display = "block";
    // } else {
    //   y.style.display = "none";
    // }
  }
  showCommentTab(id) {
    // this.commentTabID = id;
    // console.log('find', this.commentTabID.find(x=>x === id));
    var x = document.getElementById(id);
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
  }
  getAnnoucementdesc() {
    if (this.addAnnouncementForm.controls.description.value === '<p> </p>') {
      this.addAnnouncementForm.controls.description.setValue(null);
      return false;
    }
    else {
      if (this.addAnnouncementForm.controls.description.value && this.addAnnouncementForm.controls.description.value.length > 0) {
        this.isAnnouncementDesError = false;
      }
    }
  }
  showAnnouncement() {
    this.getSendToData();
    this.getAssociation();
    this.isPollShow = false;
    this.isEventShow = false;
    this.isPhotosShow = false;
    //this.isShowEventButtons = false;
    this.isPostShow = false;
    this.fileData = [];
    this.photosDescription = "";
    this.errorMsg = "";
    this.isPostButton = false;
    this.isPollButton = false;
    this.isAnnouncementShow = true;
    this.isAnnouncementButton = false;
  }
  resetAnnouncementForm() {
    this.isPostShow = true;
    this.isPostButton = false;
    this.addAnnouncementForm.reset();
    this.addAnnouncementDirective.resetForm();
    this.isAnnouncementShow = false;
    this.isAnnouncementDesError = false;
    this.sendTo = [];
    this.fileData = [];
    this.cnt = 0;
    this.isAnnouncementSendToError = false;
  }

  // on file upload
  onAnnouncementDocChange(evt: any) {
    // this.imgFlag = false;
    // this.fileData = [];
    this.errorMsg = "";
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            fileName: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }
  // remove uploaded Documents
  removeAnnouncementDocs(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };
  onItemSelect(item: any) {
    this.isAnnouncementSendToError = false;
  }
  addAnnouncementModel() {
    let model: AddAnnouncementModel = {
      SendTo: this.addAnnouncementForm.controls.sendTo.value,
      Subject: this.addAnnouncementForm.controls.subject.value,
      BodyText: this.addAnnouncementForm.controls.description.value,
      From: this.addAnnouncementForm.controls.from.value,
      AssociationId: this.userRole !== this.roleEnum.PropertyManager ? this.associationId : this.addAnnouncementForm.controls.association.value.id,
      Attachments: this.fileData,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      CreatedOn: new Date(),
      ModifiedOn: new Date()
    }
    return model;
  }
  addAnnouncement() {
    let model = this.addAnnouncementModel();
    if (model.BodyText === '' || model.BodyText === null) {
      this.isAnnouncementDesError = true;
    }
    else {
      this.isAnnouncementDesError = false;
    }
    if (model.SendTo === '' || model.SendTo === null || model.SendTo.length === 0) {
      this.isAnnouncementSendToError = true;
    }
    else {
      this.isAnnouncementSendToError = false;
    }

    if (this.addAnnouncementForm.valid) {
      this.isAnnouncementButton = true;
      this.service.addAnnouncement(model.AssociationId, model).subscribe(
        (response: any) => {
          if (response.Success) {
            this.getSocialLanding();
            this.notificationService.showNotification('Announcement Saved Successfully');
            this.emailNotification.sendNotifications(this.announcementFeatureId, response.RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.SocialAnnouncement, TriggerType.Create,
              this.audienceType).subscribe(res => {
              });
            this.resetAnnouncementForm();
          }
        }
      );
    }
  }
  // get mastr data
  getSendToData() {
    this.service.GetSendToMasterData().subscribe(
      (response: any) => {
        if (response.Success) {
          this.SendtoData = response.AssociationDistributionGroup.filter((s) => s.Name === "HomeOwner");
          this.FromtoData = response.EmailConfigurations;
        }
      }
    );
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'id',
      textField: 'Name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: false
    };
  }
  getAssociation() {
    this.service.getAssociation().subscribe(
      (response: any) => {
        if (response.success) {
          this.associationData = response.AssociationList;
          this.associationDdlAutocompleteList = response.AssociationList;
          // this.selectedAssociation = this.associationData.find(x => x.id === this.associationId.toLowerCase());
        }
      }
    );
  }


  /*auto complete*/
  /**Auto complete Display Function**/
  displayFnAutoCompleteAssociation(association) {
    if (association != null && association.AssociationName != null) {
      return association.AssociationName;
    } else association;
  }

  /**Auto complete filter on change**/
  onInputChangedAssociation(searchStr: string): void {
    this.associationDdlAutocompleteList = [];
    this.associationDdlAutocompleteList = this.associationData.filter(option =>
      option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
  }
  /*Reset mat auto compelte*/
  ngAfterViewInit() {
    if (this.announcementAssociationtrigger !== undefined) {
      this.announcementAssociationtrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.addAnnouncementForm.controls.association.setValue('');
            this.announcementAssociationtrigger.closePanel();
            this.associationDdlAutocompleteList = this.associationData;
          }
        });
    }
  }
  //for clear association drop down
  onFocusOut(searchStr) {
    if (this.announcementAssociationtrigger !== undefined) {
      this.announcementAssociationtrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.associationDdlAutocompleteList = this.associationData;
            this.addAnnouncementForm.controls.association.setValue('');
            this.announcementAssociationtrigger.closePanel();
          }
        });
      this.associationDdlAutocompleteList = this.associationData.filter(option =>
        option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
      if (this.associationDdlAutocompleteList.length === 0) {
        this.associationDdlAutocompleteList = this.associationData;
        this.addAnnouncementForm.controls.association.setValue('');
      }
    }
  }
  // check Email Status
  checkEmailStatus() {
    if (this.addAnnouncementForm.controls.from.value && this.addAnnouncementForm.controls.from.valid) {
      this.service.getEmailStatus(this.addAnnouncementForm.controls.from.value).subscribe(
        (response: any) => {
          if (response.Success) {
          }
        }
      );
    }
  }
  addWelcomeDialog() {

    this.welcomedialogRef = this._matDialog.open(WelcomeDialogComponent, {
      width: '930px',
      disableClose: false
    });
    this.welcomedialogRef.afterClosed()
      .subscribe(response => {
        if (response) {
          //this.isStartTour = true;
        }
      });
  }
  // get date range
  // getRange(event) {
  //   console.log('Date Range', event);
  // }

  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.getRange(event);
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.getRange(event);
    }
  }


  getRange(event) {
    this.isDateFilterResponceLoad = true;
    this.isAssociationDataLoad = false;
    var date = new Date();
    this.newfirstDay = event ? event[0] : this.firstDay;
    this.newlastDay = event ? event[1] : this.lastDay;
    if (event) {
      this.newfirstDay = event[0];
      this.newlastDay = event[1];
      this.currentMonth = this.months[this.newfirstDay.getMonth()];
      this.currentYear = this.newfirstDay.getFullYear();
      this.tocurrentMonth = this.months[this.newlastDay.getMonth()];
      this.tocurrentYear = this.newlastDay.getFullYear();
    }
    else {
      this.newfirstDay = new Date(date.getFullYear(), date.getMonth(), 1);
      this.newlastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
      this.currentMonth = this.months[this.newfirstDay.getMonth()];
      this.currentYear = this.newfirstDay.getFullYear();
      this.tocurrentMonth = "";
      this.tocurrentYear = "";
    }

    this.service.getDashboardData(this.associationId, this.userId, this.userRole, this.newfirstDay, this.newlastDay, 3).subscribe(
      (response: any) => {
        this.isAssociationDataLoad = true;
        this.isDateFilterResponceLoad = false;
        if (response.Success) {
          this.associationDashBoard = response.GetSocialLanding.DashBoard;
          if (response.GetSocialLanding.DashBoard.BoardTaskCount) {
            this.boardTaskTtal = response.GetSocialLanding.DashBoard.BoardTaskCount.TotalBoardTask;
            let New = response.GetSocialLanding.DashBoard.BoardTaskCount.NewBoardtask;
            let Solved = response.GetSocialLanding.DashBoard.BoardTaskCount.CompletedBoardTask;
            let Cancle = response.GetSocialLanding.DashBoard.BoardTaskCount.CanceledBoardTask;
            let Pending = response.GetSocialLanding.DashBoard.BoardTaskCount.AwaitingBoardDecisionBoardTask + response.GetSocialLanding.DashBoard.BoardTaskCount.InProgressBoardTask;
            if (New + Solved + Cancle + Pending === 0) {
              this.boardTskCountData[0] = 1;
              this.boardTskCountData[1] = 0;
              this.boardTskCountData[2] = 0;
              this.boardTskCountData[3] = 0;
              this.boardTaskTotal = 0;
            }
            else {
              this.boardTskCountData[0] = response.GetSocialLanding.DashBoard.BoardTaskCount.NewBoardtask;
              this.boardTskCountData[1] = response.GetSocialLanding.DashBoard.BoardTaskCount.CompletedBoardTask;
              this.boardTskCountData[2] = response.GetSocialLanding.DashBoard.BoardTaskCount.CanceledBoardTask;
              this.boardTskCountData[3] = response.GetSocialLanding.DashBoard.BoardTaskCount.AwaitingBoardDecisionBoardTask + response.GetSocialLanding.DashBoard.BoardTaskCount.InProgressBoardTask;
              this.boardTaskTotal = this.boardTskCountData[0] + this.boardTskCountData[1] + this.boardTskCountData[2] + this.boardTskCountData[3];
            }
          }
          if (response.GetSocialLanding.DashBoard.ServiceRequestCount) {
            this.serviceRequestTtal = response.GetSocialLanding.DashBoard.ServiceRequestCount.TotalServiceRequest
            let New = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
            let Solved = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
            let Cancle = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
            let Pending = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
            if (New + Solved + Cancle + Pending === 0) {
              this.serviveRequestCountData[0] = 1;
              this.serviveRequestCountData[1] = 0;
              this.serviveRequestCountData[2] = 0;
              this.serviveRequestCountData[3] = 0;
              this.serviceRequestTotal = 0;
            }
            else {
              this.serviveRequestCountData[0] = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
              this.serviveRequestCountData[1] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
              this.serviveRequestCountData[2] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
              this.serviveRequestCountData[3] = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
              this.serviceRequestTotal = this.serviveRequestCountData[0] + this.serviveRequestCountData[1] + this.serviveRequestCountData[2] + this.serviveRequestCountData[3];
            }
          }
          if (response.GetSocialLanding.DashBoard.ArcCount) {
            this.arcRequestTtal = response.GetSocialLanding.DashBoard.ArcCount.TotalARC;
            let New = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
            let Solved = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
            let Cancle = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
            let Pending = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest + response.GetSocialLanding.DashBoard.ArcCount.DeniedArc + response.GetSocialLanding.DashBoard.ArcCount.ApprovedArc;
            if (New + Solved + Cancle + Pending === 0) {
              this.arcRequestCountData[0] = 1;
              this.arcRequestCountData[1] = 0;
              this.arcRequestCountData[2] = 0;
              this.arcRequestCountData[3] = 0;
              this.arcTotal = 0;
            }
            else {
              this.arcRequestCountData[0] = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
              this.arcRequestCountData[1] = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
              this.arcRequestCountData[2] = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
              this.arcRequestCountData[3] = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest + response.GetSocialLanding.DashBoard.ArcCount.DeniedArc + response.GetSocialLanding.DashBoard.ArcCount.ApprovedArc;
              this.arcTotal = this.arcRequestCountData[0] + this.arcRequestCountData[1] + this.arcRequestCountData[2] + this.arcRequestCountData[3];
            }

          }
          if (response.GetSocialLanding.DashBoard.ViolationCount) {
            this.violationTtal = response.GetSocialLanding.DashBoard.ViolationCount.TotalVoialation;
            let New = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
            let Solved = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
            let Cancle = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
            let Pending = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
            if (New + Solved + Cancle + Pending === 0) {
              this.violationCountData[0] = 1;
              this.violationCountData[1] = 0;
              this.violationCountData[2] = 0;
              this.violationCountData[3] = 0;
              this.violationTotal = 0;
            }
            else {
              this.violationCountData[0] = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
              this.violationCountData[1] = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
              this.violationCountData[2] = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
              this.violationCountData[3] = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
              this.violationTotal = this.violationCountData[0] + this.violationCountData[1] + this.violationCountData[2] + this.violationCountData[3];
            }
          }
        }
        //   this.progressbarService.hide();
        this.associationDashboardCarts();
      }
    );
  }
  geDatafilterByMyDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.getMyDashboardRange(event);
      }
    } else if (event === null && this.bsRangeValueMy.length !== 0) {
      this.bsRangeValueMy = [];
      this.getMyDashboardRange(event);
    }
  }
  getMyDashboardRange(event) {
    this.isDateFilterResponceLoad = true;
    this.isMyDashboardDataLoad = false;
    if (event) {
      var firstDay = event[0];
      var lastDay = event[1];
      this.myCurrentMonth = this.months[firstDay.getMonth()];
      this.myCurrentYear = firstDay.getFullYear();
      this.myToCurrentMonth = this.months[lastDay.getMonth()];
      this.myToCurrentYear = lastDay.getFullYear();
    }
    else {
      var firstDay = this.firstDay;
      var lastDay = this.lastDay;
      this.myCurrentMonth = this.months[firstDay.getMonth()];
      this.myCurrentYear = lastDay.getFullYear();
      this.myToCurrentMonth = "";
      this.myToCurrentYear = "";
    }
    this.service.myDashboardData(this.associationId, this.userId, this.userRole, firstDay, lastDay).subscribe(
      (response: any) => {
        this.isDateFilterResponceLoad = false;
        this.isMyDashboardDataLoad = true;
        if (response.Success) {
          this.isMyDashboardDataLoad = true;
          this.associationDashBoard = response.GetSocialLanding.DashBoard;
          if (response.GetSocialLanding.DashBoard.ServiceRequestCount) {
            this.serviceRequestTtal = response.GetSocialLanding.DashBoard.ServiceRequestCount.TotalServiceRequest
            let New = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
            let Solved = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
            let Cancle = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
            let Pending = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
            if (New + Solved + Cancle + Pending === 0) {
              this.serviveRequestCountData[0] = 1;
              this.serviveRequestCountData[1] = 0;
              this.serviveRequestCountData[2] = 0;
              this.serviveRequestCountData[3] = 0;
              this.serviceRequestTotal = 0;
            }
            else {
              this.serviveRequestCountData[0] = response.GetSocialLanding.DashBoard.ServiceRequestCount.NewServiceRequest;
              this.serviveRequestCountData[1] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CompletedServiceRequest;
              this.serviveRequestCountData[2] = response.GetSocialLanding.DashBoard.ServiceRequestCount.CanceledServiceRequest;
              this.serviveRequestCountData[3] = response.GetSocialLanding.DashBoard.ServiceRequestCount.AwaitingBoardDecisionServiceRequest + response.GetSocialLanding.DashBoard.ServiceRequestCount.InProgressServiceRequest;
              this.serviceRequestTotal = this.serviveRequestCountData[0] + this.serviveRequestCountData[1] + this.serviveRequestCountData[2] + this.serviveRequestCountData[3];
            }
          }
          if (response.GetSocialLanding.DashBoard.ArcCount) {
            this.arcRequestTtal = response.GetSocialLanding.DashBoard.ArcCount.TotalARC;
            let New = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
            let Solved = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
            let Cancle = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
            let Pending = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest;
            if (New + Solved + Cancle + Pending === 0) {
              this.arcRequestCountData[0] = 1;
              this.arcRequestCountData[1] = 0;
              this.arcRequestCountData[2] = 0;
              this.arcRequestCountData[3] = 0;
              this.arcTotal = 0;
            }
            else {
              this.arcRequestCountData[0] = response.GetSocialLanding.DashBoard.ArcCount.SubmittedArc;
              this.arcRequestCountData[1] = response.GetSocialLanding.DashBoard.ArcCount.WorkCompletedArc;
              this.arcRequestCountData[2] = response.GetSocialLanding.DashBoard.ArcCount.CanceledArc;
              this.arcRequestCountData[3] = response.GetSocialLanding.DashBoard.ArcCount.AwaitingBoardDecisionARCRequest;
              this.arcTotal = this.arcRequestCountData[0] + this.arcRequestCountData[1] + this.arcRequestCountData[2] + this.arcRequestCountData[3];
            }

          }
          if (response.GetSocialLanding.DashBoard.ViolationCount) {
            this.violationTtal = response.GetSocialLanding.DashBoard.ViolationCount.TotalVoialation;
            let New = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
            let Solved = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
            let Cancle = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
            let Pending = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
            if (New + Solved + Cancle + Pending === 0) {
              this.violationCountData[0] = 1;
              this.violationCountData[1] = 0;
              this.violationCountData[2] = 0;
              this.violationCountData[3] = 0;
              this.violationTotal = 0;
            }
            else {
              this.violationCountData[0] = response.GetSocialLanding.DashBoard.ViolationCount.OpenedCountViolation;
              this.violationCountData[1] = response.GetSocialLanding.DashBoard.ViolationCount.ResolvedCountViolation;
              this.violationCountData[2] = response.GetSocialLanding.DashBoard.ViolationCount.LetterSentViolation;
              this.violationCountData[3] = response.GetSocialLanding.DashBoard.ViolationCount.ContestedViolation;
              this.violationTotal = this.violationCountData[0] + this.violationCountData[1] + this.violationCountData[2] + this.violationCountData[3];
            }
          }
          this.associationDashboardCarts();
          //   this.progressbarService.hide();
        }
      }
    );
  }
  //For Preview document
  previewDocument(document) {
    this.isDocumentPreview = true;
    this.documentDetails = document;
    this.fileURL = "";
    if (document.FileName.split('.')[1] !== 'pdf') {
      this.fileURL = document.Link;
    }
    else {
      this.commonService.downloadFile(document.Link).subscribe(
        (response) => {
          this.fileURL = URL.createObjectURL(response);
        }
      );
    }
  }
}
