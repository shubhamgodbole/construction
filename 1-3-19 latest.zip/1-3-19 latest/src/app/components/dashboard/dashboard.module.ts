import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatButtonModule, MatButton, MatSidenavModule, MatAutocompleteModule } from '@angular/material';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { DisplayTimeElapsedModule } from 'src/app/shared/modules/display-time-elapsed.module';
import { QuillModule } from 'ngx-quill';
//import { TourModule } from 'src/app/shared/component/tour/tour.module';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { MomentModule } from 'ngx-moment';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    //  RouterModule ,
    MatAutocompleteModule,
    MatButtonModule,
    MatRadioModule,
    ChartsModule,
    ReactiveFormsModule,
    FormsModule,
    SafeModule,
    MatDatetimepickerModule,
    RouterModule.forChild(routes),
    DisplayTimeElapsedModule,
    QuillModule,
    //TourModule,
    HideIfUnauthorizedModule,
    FilterUniqueArrayModule,
    MomentModule,
    NgMultiSelectDropDownModule.forRoot(),
    NgxDaterangepickerMd.forRoot({
      separator: ' - ',
      applyLabel: 'Okay',
    }),
    BsDatepickerModule.forRoot()
  ],
  exports: [RouterModule],
  declarations: [DashboardComponent]
})
export class DashboardModule { }
