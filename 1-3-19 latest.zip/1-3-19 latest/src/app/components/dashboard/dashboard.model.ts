export class AddEvent {
    AssociationId: String
    CreatedByUserId: string
    CreatedByUserName: string
    EventType: string
    EventName: string
    StartDate: string
    EndDate : string
    Location: string
    Category: string
    Attachments : any
}

export class AddPoll {
    AssociationId: String
    CreatedByUserId: string
    CreatedByUserName: string
    Question: string
    PollEndDate: Date
    Options: any
    CreatedOn: Date
    ModifiedOn: Date
}

export class ParentSocialEvent {
    AssociationId: String
    CreatedByUserId: string
    CreatedByUserName: string
    BodyText: string
    Attachments : any
    id : string
    ModifiedOn: Date
}
export class ChildSocialEvent {
    AssociationId: String
    CreatedByUserId: string
    CreatedByUserName: string
    BodyText: string
    Attachments : any
    ModifiedOn: Date
}

export class AddPhotos {
    AssociationId: String
    CreatedByUserId: string
    CreatedByUserName: string
    EventType: string
    Attachments : any
    BodyText: string
    CreatedOn: Date
    ModifiedOn: Date
}


export class AddAnnouncementModel {
    SendTo: any
    Subject: string
    Attachments : any
    BodyText: string
    From:string
    AssociationId:string
    CreatedByUserId: string
    CreatedByUserName: string
    CreatedOn: Date
    ModifiedOn: Date
}

export enum LikeText {
    Like = "Like",
    Unlike = "Unlike"
}