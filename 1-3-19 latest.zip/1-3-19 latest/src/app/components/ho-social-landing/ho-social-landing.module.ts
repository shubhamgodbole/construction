import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule } from '@angular/material';
import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HoSocialLandingComponent } from './ho-social-landing.component';
const routes: Routes = [
  {
    path: '',
    component: HoSocialLandingComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  declarations: [HoSocialLandingComponent]
})
export class HoSocialLandingModule { }
