import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoSocialLandingComponent } from './ho-social-landing.component';

describe('HoSocialLandingComponent', () => {
  let component: HoSocialLandingComponent;
  let fixture: ComponentFixture<HoSocialLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoSocialLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoSocialLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
