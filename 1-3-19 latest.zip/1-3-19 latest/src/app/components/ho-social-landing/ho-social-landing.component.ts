import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ho-social-landing',
  templateUrl: './ho-social-landing.component.html',
  styleUrls: ['./ho-social-landing.component.scss']
})
export class HoSocialLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
