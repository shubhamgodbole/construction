import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssociationLandingComponent } from './association-landing.component';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule } from '@angular/material';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { CookieService } from 'ngx-cookie-service';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
const routes: Routes = [
  {
    path: '',
    component: AssociationLandingComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    NumberOnlyDirectiveModule,
    MatDatetimepickerModule,
    ReactiveFormsModule,
    FormsModule,
    NoDataFoundModule,
    RouterModule.forChild(routes)
  ],  providers: [ CookieService ],

  exports: [RouterModule],
  declarations: [AssociationLandingComponent]
})
export class AssociationLandingModule { }
