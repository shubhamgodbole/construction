import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociationLandingComponent } from './association-landing.component';

describe('AssociationLandingComponent', () => {
  let component: AssociationLandingComponent;
  let fixture: ComponentFixture<AssociationLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociationLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociationLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
