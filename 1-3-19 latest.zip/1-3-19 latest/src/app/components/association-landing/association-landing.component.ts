import { Component, OnInit, ViewChild } from '@angular/core';
import { AssociationLandingService } from 'src/app/services/association-landing.service';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { TypeOfDocument, RoleEnum, NoDataFoundCaseFeatureName } from 'src/app/shared/Enums/commonEnums';
import { MarketPlaceApiService } from 'src/app/services/market-place-api.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { fileData } from './association-landing.model';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { LoginApiService } from 'src/app/services/login-api.service';
import { MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Title } from '@angular/platform-browser';
import { environment } from 'src/environments/environment';
import { CommonConstant } from 'src/app/shared/common/constant.model';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-association-landing',
  templateUrl: './association-landing.component.html',
  styleUrls: ['./association-landing.component.scss']
})
export class AssociationLandingComponent implements OnInit {
  notificationService: NotificationService;

  /*Check login*/
  role: string = "";
  roleEnum = RoleEnum;
  mobNav = false;
  userData: UserData;
  associationId: string;
  userId: string;
  userName: string;
  domain: string;
  documnetType: string;
  associationData: any;
  classifiedAdBuyData: any;
  classifiedAdSaleData: any;
  classifiedAdBuyOldData: any;
  classifiedAdSaleOldData: any;
  homeForSaleData: any;
  homeForSaleDoc: any;
  bannerImageUrl: any = [];
  soldMarketListForm: FormGroup;
  // isComponentLoad: boolean = false;
  fileData: any = [];
  loginBtnName: string = "";
  loginBtnUrl: string = "";
  //For check user is login or not 
  isLogin: boolean;
  //Set Association
  globalAssociationModel: GlobalAssociationModel;

  //dashboardUrl
  dashBoardUrl = AppRouteUrl.mainDashboardRouteUrl;
  loadMoreSaleButton: string = "Load More";
  loadMoreBuyButton: string = "Load More";
  isLoadMoreSale: boolean = false;
  isLoadMoreBuy: boolean = false;
  backButtonTitle: string = '';
  //For Delete
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  isApiResponceCome: boolean = false;
  @ViewChild('formSoldDirective') formSoldDirective: FormGroupDirective;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  constructor(private service: AssociationLandingService,
    private formBuilder: FormBuilder,
    private loginService: LoginApiService,
    private readonly snb: MatSnackBar,
    public commonService: CommonService,
    private titleService: Title,
    private _router: Router,
    private progressbarService: ProgeressBarService,
    private router: Router,
    private globalAssociationService: GlobalAssociationService,
    public marketPlaceService: MarketPlaceApiService,
    private _matDialog: MatDialog,
    private readonly appConfig: AppConfig) {
    this.titleService.setTitle(environment.mainTitle);
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    this.appConfig.isLoggedIn.subscribe(
      (login) => {
        this.isLogin = login;
      }
    );
    //console.log("AssociationLanding userData", this.userData);
    if (this.userData !== null) {
      this.associationId = this.userData.UserAssociations[0].AssociationId;
      this.userId = this.userData.UserProfileId;
      this.domain = this.userData.UserAssociations[0].Domain;
      this.documnetType = TypeOfDocument.AssociationImages;
      this.userName = this.userData.UserName;
      this.role = this.userData.Role;
      if (this.userData.Role === this.roleEnum.PropertyManager) {
        this.backButtonTitle = 'My App';
      }
      else {
        this.backButtonTitle = 'My Dashboard';
      }
      if (this.userId !== null) {
        this.loginBtnName = "Sign Out";
        this.loginBtnUrl = "";
      }
      else {
        this.loginBtnName = "Sign In";
        this.loginBtnUrl = "/login";
      }

      this.globalAssociationService.associationSubject.subscribe(res => {
        this.globalAssociationModel = res;
        this.getAssociationLandingData();
        // if (res !== 1) {        
        //   this.getAssociationLandingData();
        // }
      });
    } else {
      this.loginBtnName = "Sign In";
      this.loginBtnUrl = "/login";
      this.getSignInByAssociationDetails();
      // this.getAdds();
    }
  }


  logout() {
    this.appConfig.removeCurrentUser();
    this.router.navigate([AppRouteUrl.associationLandingRouteUrl]);
  }


  getSignInByAssociationDetails() {
    let resData;
    //  let url = "http://testassociation.devpropvivo.com";
    // url1 = "https://dev.devpropvivo.com";
    // url2 = "https://www.devpropvivo.com"
    let url = window.location.hostname;
    //console.log("url for get Association Details : ", url);
    this.loginService.getSignInByAssociationDetails(url, "Basic").subscribe(res => {
      //this.isComponentLoad = true;
      resData = res;
      //console.log("SignInByAssociationDetails API results : ", res);
      if (resData.IsCorporateLandingPage === true) {
        this.associationData = resData.Association;
        //this.classifiedAdBuyData = resData.ClassifiedAdBuy;
        //this.classifiedAdSaleData = resData.ClassifiedAdSale;
        //this.homeForSaleData = resData.HomeForSale.length > 0 ? resData.HomeForSale[0].HomeForSale : '';
        //this.homeForSaleDoc = resData.HomeForSale.length > 0 ? resData.HomeForSale[0].Documents : '';
        this.bannerImageUrl = resData.BannerImageUrl;
        this.getDetails();
      }
      else {
        this._router.navigate(['/corporate']);
      }
    },
      (err) => {
        console.log(err);
      }
    );
  }

  getDetails() {
    let resData;
    //  let url = "http://testassociation.devpropvivo.com";
    let url = window.location.href;
    this.loginService.getSignInByAssociationDetails(url, "Detail").subscribe(res => {
      resData = res;
      if (resData.IsCorporateLandingPage === true) {
        // this.associationData = resData.Association;
        this.classifiedAdBuyData = resData.ClassifiedAdBuy;
        this.classifiedAdSaleData = resData.ClassifiedAdSale;
        this.homeForSaleData = resData.HomeForSale.length > 0 ? resData.HomeForSale[0].HomeForSale : '';
        this.homeForSaleDoc = resData.HomeForSale.length > 0 ? resData.HomeForSale[0].Documents : '';
        //this.bannerImageUrl = resData.BannerImageUrl;
      }
      else {
        this._router.navigate(['/corporate']);
      }
    },
      (err) => {
        console.log(err);
      }
    );
  }


  // splitHostname() {
  //   //var result = {};
  //   var hostname = "www.devpropvivo.com";
  //   //var hostname = window.location.hostname;
  //   var regexParse = new RegExp('([a-z\-0-9]{2,63})\.([a-z\.]{2,5})$');
  //   var urlParts = regexParse.exec(hostname);
  //   this.result.domain = urlParts[1];
  //   this.result.type = urlParts[2];
  //   this.result.subdomain = hostname.replace(this.result.domain + '.' + this.result.type, '').slice(0, -1);
  //   console.log(this.result);
  //   if (this.result.subdomain !== "www") {
  //     this.getSignInByAssociationDetails();
  //   } else {
  //     this._router.navigate(['/corporate/home']);
  //   }
  // }


  ngOnInit() {
    // this.getAssociationLandingData();
    this.soldMarketListForm = this.formBuilder.group({
      date: ['', Validators.required],
    });
  }
  goToCCRs() {
    if (this.isLogin) {
      if (this.role === RoleEnum.PropertyManager) {
        this.router.navigate([AppRouteUrl.mainDocumentsPMRouteUrl]);
      }
      else {
        this.router.navigate([AppRouteUrl.mainDocumentsRouteUrl]);
      }
    }
    else {
      this.router.navigate([AppRouteUrl.mainDocumentsRouteUrl]);
    }
  }
  goToDashboard() {
    if (this.userData.Role === this.roleEnum.PropertyManager) {
      this.router.navigate([AppRouteUrl.mainRecentUpdatesRouteUrl]);
    } else {
      this.router.navigate([AppRouteUrl.mainDashboardRouteUrl]);
    }
    //this.router.navigate([AppRouteUrl.mainDashboardRouteUrl]);
  }
  goToHome() {
    window.scroll(0, 0);
  }
  // redirect to corporate home
  gotToCorporate() {
    this.router.navigate([AppRouteUrl.corporateHomeRouteUrl]);
  }
  // redirect to corporate why propvivo
  goToWhypropVIVO() {
    this.router.navigate([AppRouteUrl.corporateWhyPropVivoRouteUrl]);
  }
  // redirect to corporate blog
  goToBlog() {
    this.router.navigate([AppRouteUrl.corporateBlogListRouteUrl]);
  }
  // redirect to corporate contact
  goToContact() {
    this.router.navigate([AppRouteUrl.corporateContactUsRouteUrl]);
  }
  goToResaleCertificate() {
    this.router.navigate([AppRouteUrl.corporateResaleCertificateRouteUrl]);
  }
  // redirect to corporate Demand Request
  goToDemandRequest() {
    this.router.navigate([AppRouteUrl.corporateDemandRequestRouteUrl]);
  }
  // redirect to Condo Questionnaire
  goToCondoQuestionnaire() {
    this.router.navigate([AppRouteUrl.corporateCondoQuestionnaireRouteUrl]);
  }
  // get Landing Data
  getAssociationLandingData() {
    this.service.getAssociationLandingData(this.associationId, this.documnetType, this.domain, this.userId).subscribe(
      (response: any) => {
        console.log("getAssociationResponse", response);
        this.isApiResponceCome = true;
        if (response.Success) {
          this.associationData = response.Association;
          this.classifiedAdBuyData = response.ClassifiedAdBuy;
          this.classifiedAdSaleData = response.ClassifiedAdSale;
          this.homeForSaleData = response.HomeForSale.length > 0 ? response.HomeForSale[0].HomeForSale : '';
          this.homeForSaleDoc = response.HomeForSale.length > 0 ? response.HomeForSale[0].Documents : '';
          this.bannerImageUrl = response.BannerImageUrl;
        }
      }
    );
  }
  navToggle() {
    if (this.mobNav)
      this.mobNav = false;
    else
      this.mobNav = true;
  }
  // get classifiedAd Id & redirect on detail page
  detail(classifiedAd: any) {
    let classifiedAdId = classifiedAd.ClassifiedAd.id;

    let uri;
    if (this.isLogin) {
      uri = AppRouteUrl.mainClassifiedAdsDetailRouteUrl;
      this.router.navigate([uri], { queryParams: { id: classifiedAdId } });
    }
    else {
      uri = AppRouteUrl.mainAssociationMarketDetailRouteUrl;
      let domain = classifiedAd.Documents[0] ? classifiedAd.Documents[0].Domain : '';
      this.router.navigate([uri], { queryParams: { id: classifiedAdId, domain: domain } });
    }
  }
  // get classifiedID for sold
  soldId(id) {
    this.soldId = id;
  }
  // sold
  sold() {
    var date = this.soldMarketListForm.controls.date.value;
    if(date) {
    this.service.soldClassifiedAdds(this.soldId, date, this.userId).subscribe(
      (response: any) => {
        if (response.Success) {
          this.classifiedAdBuyData = response.ClassifiedAdBuy;
          this.classifiedAdSaleData = response.ClassifiedAdSale;
          console.log('ClassifiedAd was sold');
          document.getElementById('close-model').click();
          this.closeSoldModel();
        }
      });
    }  
  }
  closeSoldModel() {
    this.resetSoldForm();
  }
  resetSoldForm() {
    this.soldMarketListForm.reset();
    this.formSoldDirective.resetForm();
  }
  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = valueObject.Title;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }
  // delte
  delete(id) {
    //if (confirm("Are you sure to delete ?")) {
      this.service.deleteClassifiedAdds(id, this.userId).subscribe(
        (response: any) => {
          if (response.Success === true) {
            this.classifiedAdBuyData = response.ClassifiedAdBuy;
            this.classifiedAdSaleData = response.ClassifiedAdSale;
            console.log('ClassifiedAd was deleted');
          }
          else {
            console.log('Some Error');
          }
        }
      );
   // }
  }
  goToList() {
    if (this.isLogin) {
      this.router.navigate([AppRouteUrl.mainClassifiedAdsRouteUrl]);
    }
    else {
      this.router.navigate([AppRouteUrl.associationMarketListRouteUrl]);
    }
  }
  // uplad images
  onUploadChange(evt: any) {
    this.fileData = [];
    if (evt.target.files && evt.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        var fileDataForMeetingMinute = {
          InputStream: event.target.result,
          Name: evt.target.files[0].name,
          MediaType: evt.target.files[0].name.substring(evt.target.files[0].name.indexOf(".")),
          FileSize: evt.target.files[0].size.toString(),
          CreatedByUserId: this.userId,
          CreatedByUserName: this.userName
        };
        this.fileData.push(fileDataForMeetingMinute);
        this.uploadImages();
      }
      reader.readAsDataURL(evt.target.files[0]);
    }
  }

  uploadImages() {
    let modeldata = this.uploadImagesModel();
    this.service.uploadData(this.domain, this.associationId, this.fileData, this.documnetType).subscribe(
      (response: any) => {
        if (response.Success === true) {
          this.bannerImageUrl = response.BannerImageUrl;
          console.log('Images uploaded', response.BannerImageUrl);
        }
        else {
          console.log('Some Error');
        }
      }
    );
  }
  uploadImagesModel() {
    let model: fileData = {
      Domain: this.domain,
      AssociationId: this.associationId,
      AssociationImages: this.fileData,
      DocumentType: this.documnetType
    }
    return model;
  }
}
