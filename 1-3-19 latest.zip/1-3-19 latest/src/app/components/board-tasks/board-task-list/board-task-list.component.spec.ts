import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BoardTaskListComponent } from './board-task-list.component';

describe('BoardTaskListComponent', () => {
  let component: BoardTaskListComponent;
  let fixture: ComponentFixture<BoardTaskListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BoardTaskListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoardTaskListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
