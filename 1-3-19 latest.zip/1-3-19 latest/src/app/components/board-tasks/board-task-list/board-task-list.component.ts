import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { BoardTaskApiService } from 'src/app/services/board-task-api.service';
import { BoardTaskStatus, DisplayPriority, CaseSubCategory, BoardTaskModel, DisplayColumns, AudienceType } from '../board-task.model';
import { fromEvent, Subscription } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { TypeOfDocument, CustomerTypeEnum, CaseTypeEnum, SubCaseTypeEnum, CaseOriginatingType, IsAuthorized, StatusReason, NoDataFoundCaseFeatureName, ImageNameEnums, RoleEnum, FeatureName, SourceType, TriggerType, MasterPaginationEnum, Pagination, DocumentFeatureName, requestSubTypeCount, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { AppConfig } from 'src/app/app.config';
import { UserData, EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Guid } from 'guid-typescript';
import { MatSnackBar, MatPaginator } from '@angular/material';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { AssignedPartyType } from '../../arc/arc-model';
import { CommonService } from 'src/app/services/common.service';
import { FilterListValues, FeatureNameLocalStorage } from 'src/app/shared/common/models';
import { AcceptFilesConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-board-task-list',
  templateUrl: './board-task-list.component.html',
  styleUrls: ['./board-task-list.component.scss']
})
export class BoardTaskListComponent implements OnInit {
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  notificationService: NotificationService;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  //isApiResponceCome: boolean = false;
  isShowList: boolean = false;
  filter = false;
  sidebar = false;
  userData: UserData;
  associationId: string;
  role: string;
  companyCode: string;
  customerType = CustomerTypeEnum.Association;
  caseType = CaseTypeEnum.BoardMembers;
  subCaseType = SubCaseTypeEnum.BoardTask;
  domain: string;
  typeOfDocument = TypeOfDocument.CaseDocuments;
  associationName: string;
  firstName: string;
  lastName: string;
  userId: string;
  userName: string;

  //for filter by date
  dateTo: any;
  dateFrom: any;
  bsRangeValue: Date[] = [];


  //For filter by key word
  filterByKeyWords: string = "";
  @ViewChild('searchData') searchData: any;

  //For Query string;
  querySubcription: Subscription;


  resData: any;
  boardTaskList: any;
  statusTypeCount: any;
  filterBoardTaskList: any;
  caseCategoryDdl: any;
  selectedCaseCategory: string = "All";
  priorityDdl: any;
  selectedPriority: string = "All";
  boardTaskStatusEnum = BoardTaskStatus;
  status = "All";

  /*For add Edit Form */
  caseSubCategoryDdlList = new Array<CaseSubCategory>();
  frmCreateBoardTask: FormGroup;
  caseSubCategoryDdl: any;
  isSubmitBtnDisabled: boolean = false;
  isEditMode: boolean = false;
  fileData = [];
  resDataCreate: any;
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  /**End For Manage Columns*/
  @ViewChild('dueDate') dueDate;

  @Output() searchChangeEmitter = new EventEmitter();

  //For Send Notification
  featureName: any;
  featureId: any;

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  /*For server side paginaion */
  allCount: any;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;

  //for save data of filter in localstorage 
  localStorageFromDate;
  localStorageToDate;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  isApiResponceCome = false;
  constructor(private boardTaskApiService: BoardTaskApiService,
    private readonly snb: MatSnackBar,
    private emailNotification: EmailNotificationService,
    private readonly formBuilder: FormBuilder,
    public commonService: CommonService,
    private progressbarService: ProgeressBarService,
    private _router: Router,
    private route: ActivatedRoute,
    private readonly appConfig: AppConfig) {
    this.createBoardTaskForm();
    this.getCaseCategoryDdl();
    this.priorityDdl = DisplayPriority.PriorityList;
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    this.role = this.userData.Role;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.firstName = this.userName.split(' ')[0];
    this.lastName = this.userName.split(' ')[1];
    this.notificationService = new NotificationService(snb);
    //get list count
    this.getListCount();
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Board_Task) {
          this.featureName = feature.Name;
          this.featureId = feature.FeatureId;
        }
      }
    );

  }

  /**End For Manage Columns*/
  ngOnInit() {
    this.setMasterOfPagination();
    if (this.role === RoleEnum.PropertyManager) {
      this._router.navigate([AppRouteUrl.mainBoardTasksPMRouteUrl]);
    }
    //to open add dialog
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let isAdd = params["isAdd"];
      if (isAdd === "true") {
        this.sidebar = true;
      }
    });
    //for save data of filter in localstorage 
    this.getLocalStorageData();

    /**For Manage Columns*/
    this.seletedColumns = DisplayColumns.AllColumnsList;
    this.displayColumnsDdl = DisplayColumns.AllSelectedColumnsList;
    this.defaultColumnsList = DisplayColumns.DefaultColumnsList;
    /**End For Manage Columns*/
    //Filter By Key word
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.getData();
      });
  }

  statusChange(s) {
    this.status = s;
    /**For Manage Columns*/
    if (this.boardTaskStatusEnum.InProgress === s) {
      this.seletedColumns = DisplayColumns.InProgressColumnsList;
      this.displayColumnsDdl = DisplayColumns.InProgressSelectedColumnsList;
    } else if (this.boardTaskStatusEnum.All === s) {
      this.seletedColumns = DisplayColumns.AllColumnsList;
      this.displayColumnsDdl = DisplayColumns.AllSelectedColumnsList;
    } else if (this.boardTaskStatusEnum.AwaitingBoardDecision === s) {
      this.seletedColumns = DisplayColumns.AwatingDecisionColumnsList;
      this.displayColumnsDdl = DisplayColumns.AwatingDecisionSelectedColumnsList;
    } else if (this.boardTaskStatusEnum.Cancelled === s) {
      this.seletedColumns = DisplayColumns.CancelledColumnsList;
      this.displayColumnsDdl = DisplayColumns.CancelledSelectedColumnsList;
    } else if (this.boardTaskStatusEnum.Completed === s) {
      this.seletedColumns = DisplayColumns.CompletedColumnsList;
      this.displayColumnsDdl = DisplayColumns.CompletedSelectedColumnsList;
    } else if (this.boardTaskStatusEnum.New === s) {
      this.seletedColumns = DisplayColumns.NewColumnsList;
      this.displayColumnsDdl = DisplayColumns.NewSelectedColumnsList;
    }
    /**End For Manage Columns*/
    this.setPaginationVariables();
    this.getData();
    //get list count
    this.getListCount();
  }

  onClickChangeStatus(s) {
    if (this.status === s) {
      return;
    } else {
      this.statusChange(s);
    }
  }

  //for save data of filter in localstorage 
  getLocalStorageData() {
    var data: FilterListValues = this.commonService.getFilterDataFromLocalStorge();
    if (data !== null && data !== undefined) {
      if (data.FeatureName === FeatureNameLocalStorage.BoardTaskBM) {
        this.status = data.Status;
        this.selectedCaseCategory = data.Category;
        this.selectedPriority = data.Priority;
        this.filterByKeyWords = data.SearchKey;
        this.dateFrom = data.DateFrom !== null && data.DateFrom !== undefined && data.DateFrom !== '' ? new Date(data.DateFrom).toUTCString() : '';
        this.dateTo = data.DateTo !== null && data.DateTo !== undefined && data.DateTo !== '' ? new Date(data.DateTo).toUTCString() : '';
        this.filter = data.Filter;

        if (this.dateFrom !== "" && this.dateFrom !== null && this.dateFrom !== undefined && this.dateTo !== "" && this.dateTo !== null && this.dateTo !== undefined) {
          this.bsRangeValue = [new Date(data.DateFrom), new Date(data.DateTo)];
        } else {
          this.bsRangeValue = [];
        }
      }
    } else {
      this.status = this.boardTaskStatusEnum.All;
    }
    this.statusChange(this.status);
  }
  //for save data of filter in localstorage 
  filterDataLocalstorage() {
    var filtersModel: FilterListValues = {
      SearchKey: this.filterByKeyWords,
      DateTo: this.localStorageToDate,
      DateFrom: this.localStorageFromDate,
      Category: this.selectedCaseCategory,
      Priority: this.selectedPriority,
      AssignTo: "",
      Status: this.status,
      ViolationFieldType: "",
      Filter: this.filter,
      FeatureName: FeatureNameLocalStorage.BoardTaskBM
    }
    return filtersModel;
  }
  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }


  filterToggle() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }


  sidebarToggle() {
    if (this.sidebar)
      this.sidebar = false;
    else
      this.sidebar = true;
    this.resetBoardTaskForm();
  }

  getData() {
    this.isShowList = false;
    let resFilterByKeyWords = this.filterByKeyWords;
    let resStatus = this.status === "All" ? "" : this.status;
    let resCaseCategory = this.selectedCaseCategory === "All" ? "" : this.selectedCaseCategory;
    let resPriority = this.selectedPriority === "All" ? "" : this.selectedPriority;
    this.progressbarService.show();
    this.boardTaskApiService.getFilteredBoardTaskBM(this.associationId, this.role, resStatus, resPriority, resCaseCategory, resFilterByKeyWords, this.dateTo, this.dateFrom, this.pageSkip, this.pageTake).subscribe(res => {
      this.isApiResponceCome = true;
      this.resData = res;
      this.isShowList = true;
      this.progressbarService.hide();
      this.boardTaskList = this.resData.caseRequestListResults[0].boardTaskRequestList;
      this.allCount = this.resData.caseRequestListResults[0].ResultCount;
      if (this.boardTaskList !== null) {
        this.setPaginationData(this.boardTaskList);
        this.SetDetailsOfNextPreviousOnDetailsPage();
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  //Get Count of list
  getListCount() {
    var model = this.commonService.getListModel(this.associationId, this.userId, this.role);
    let resData
    this.commonService.getListcount(model, DocumentFeatureName.BoardTask, requestSubTypeCount.Count).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success) {
        this.statusTypeCount = resData.caseRequestListResults[0].StatusTypeCount;
      } else {
        this.statusTypeCount = resData.caseRequestListResults[0].StatusTypeCount;
      }
    });
  }

  //for filter by date
  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.localStorageFromDate = event[0];
        this.dateTo = new Date(event[1]).toUTCString();
        this.localStorageToDate = event[1];
        this.getData();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getData();
    }
  }


  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('BTList');
    var temp: any = [];
    this.boardTaskList.forEach(element => {
      temp.push({
        id: element.id,
        caseid: element.CaseId,
        status: element.BoardTaskStatus
      });
    });
    localStorage.setItem('BTList', JSON.stringify(temp));
  }

  getCaseCategoryDdl() {
    this.boardTaskApiService.getCaseCategoryDdl(this.customerType, this.caseType).subscribe(res => {
      this.resData = res;
      this.caseCategoryDdl = this.resData.CaseType.CaseCategory;
      if (this.caseCategoryDdl.length > 0) {
        for (let i = 0; i < this.caseCategoryDdl.length; i++) {
          let model: CaseSubCategory = new CaseSubCategory();
          model.caseCategoryName = this.caseCategoryDdl[i].Name;
          model.caseSubCategoryNames = this.caseCategoryDdl[i].CaseSubCategories;
          this.caseSubCategoryDdlList.push(model);
        }
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  onChangeCaseCategory(event) {
    let caseSubcat = this.caseSubCategoryDdlList.find(x => x.caseCategoryName === event.value);
    this.caseSubCategoryDdl = caseSubcat.caseSubCategoryNames;
  }


  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
    console.log(this.fileData);
  }

  // remove uploaded Documents
  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }

  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  clearFilter() {
    if (this.selectedCaseCategory === "All" && this.filterByKeyWords === "" && this.selectedPriority === "All" && (this.bsRangeValue === null || this.bsRangeValue === [] || this.bsRangeValue.length === 0)) {
      return
    }
    this.selectedCaseCategory = "All";
    this.filterByKeyWords = "";
    this.selectedPriority = "All";
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    //for save data of filter in localstorage 
    this.localStorageFromDate = "";
    this.localStorageToDate = "";

    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.getData();
  }

  createBoardTaskForm() {
    this.frmCreateBoardTask = this.formBuilder.group({
      caseId: [''],
      title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      caseCategory: ['', Validators.required],
      caseSubCategory: ['', Validators.required],
      dueDate: ['', Validators.required],
      priority: ['', Validators.required],
      comment: ['', [Validators.required, Validators.minLength(1), ValidationService.noWhiteSpace]]
    });
  }
  createBoardTaskFormModel() {

    const model: BoardTaskModel = {
      Domain: this.domain,
      TypeOfDocument: this.typeOfDocument,
      Document: this.fileData,
      RequestId: "",
      Case:
      {
        id: this.frmCreateBoardTask.controls.caseId.value,
        AssociationId: this.associationId,
        Title: this.frmCreateBoardTask.controls.title.value,
        AssociationName: this.associationName,
        CompanyCode: this.companyCode,
        CaseType: this.caseType,
        SubCaseType: this.subCaseType,
        CaseCategory: this.frmCreateBoardTask.controls.caseCategory.value,
        CaseSubCategory: this.frmCreateBoardTask.controls.caseSubCategory.value,
        Comments: this.frmCreateBoardTask.controls.comment.value,
        CustomerType: this.customerType,
        CasePriority: this.frmCreateBoardTask.controls.priority.value,
        DueDate: new Date(this.frmCreateBoardTask.controls.dueDate.value).toUTCString(),
        FirstName: this.firstName,
        LastName: this.lastName,
        CaseOriginatingType: CaseOriginatingType.Website,
        IsAuthorized: IsAuthorized.Yes,
        StatusReason: StatusReason.New,
        Phone: '',
        AssignedTo: '',
        AssignedPartyType: AssignedPartyType.PROPVIVO,
        CaseDocuments: null,
        CreatedByUserId: this.userId,
        CreatedByUserName: this.userName,
        ModifiedByUserId: '',
        ModifiedByUserName: ''
      }
    }
    return model;

  }
  onSubmit() {
    if (this.frmCreateBoardTask.valid) {
      this.isSubmitBtnDisabled = true;
      let model = this.createBoardTaskFormModel();      
      this.boardTaskApiService.createBoardTask(model).subscribe(res => {
        this.isSubmitBtnDisabled = false;
        this.resDataCreate = res;        
        if (this.resDataCreate.caseRequestListResults[0].Success === true) {
          this.notificationService.showNotification("Board Task saved successfully");
          this.sidebar = false;
          this.getListCount();
          this.getData();         
          this.resetBoardTaskForm();
          this.emailNotification.sendNotifications(this.featureId, this.resDataCreate.caseRequestListResults[0].RequestId, this.userId, this.userData.UserAssociations[0].PMCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Board_Task, TriggerType.Create,
            AudienceType.BoardMember).subscribe(res => {
              console.log(res);
            });
          // this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Create, AudienceType.BoardMember);
        }
        else if (this.resDataCreate.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }
  resetBoardTaskForm() {
    this.frmCreateBoardTask.reset();
    this.formDirective.resetForm();
    this.isEditMode = false;
    this.isSubmitBtnDisabled = false;
    this.fileData = [];
  }

  getBoardTaskDetails(detailId, caseId, boardCastStatus) {
    console.log(detailId + "==== " + caseId + "==== " + boardCastStatus + this.domain);
    if (detailId !== "" && detailId !== null && boardCastStatus !== "" && boardCastStatus !== null && caseId !== "" && caseId !== null) {
      this.boardTaskApiService.boardTaskDetailId = detailId;
      this.boardTaskApiService.caseId = caseId;
      this.boardTaskApiService.domain = this.domain;
      this.boardTaskApiService.boardTaskStatus = this.status;      
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": detailId
        }
      };
      //set localstorage data
      this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
      this._router.navigate([AppRouteUrl.mainBoardTasksDeatilBMRouteUrl], navigationExtras);
    }
  }

  /*:Check Current Date*/
  getToday(): string {
    return new Date().toISOString().split('T')[0]
  }

  // For Notification on CURD
  createNotificationModel(featureId, requestId, triggerType, audienceType) {
    var notificationModel = new Array<EmailNotificationModel>();
    notificationModel = [{
      FeatureId: featureId,
      FeatureName: FeatureName.Board_Task,
      CreatedBy: this.userId,
      SourceType: SourceType.Web,
      TriggerType: triggerType,
      PMCompanyAssociationMappingId: this.userData.UserAssociations[0].PMCompanyAssociationMappingId,
      AudienceType: audienceType,
      Url: "",
      RequestId: requestId,
      CustomAttribute: {
        Request: FeatureName.Board_Task,
        RequestSubType: audienceType
      }
    }];
    return notificationModel;
  }

  sendNotification(featureId, requestId, triggerType, audienceType) {
    let emailNotificationModel = this.createNotificationModel(featureId, requestId, triggerType, audienceType);
    this.emailNotification.sendNotification(emailNotificationModel).subscribe(
      (emailresponse: any) => {
        if (emailresponse.Success) {
          //this.notificationService.showNotification('Notification Send SuccessFully');
        }
      }
    );
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(boardTaskList) {
    this.TotalRecord = this.allCount;
    this.FilterArray = boardTaskList;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = boardTaskList.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageTake = clickObj.pageSize;
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getData();
    // var pageStartIndex = (clickObj.pageIndex * clickObj.pageSize) + 1;
    // var pageEndIndex = (clickObj.pageIndex * clickObj.pageSize) + clickObj.pageSize;
    // this.FilterArray = this.boardTaskList.slice(pageStartIndex - 1, pageEndIndex);
    var elmnt: any = document.getElementById("contentTable");
    if (elmnt !== null) {
      elmnt.scrollTo(0, 0);
    }
  }

  ngOnDestroy(): void {
    this.querySubcription.unsubscribe();
  }

}
