import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatTooltipModule, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatPaginatorModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BoardTaskListComponent } from './board-task-list/board-task-list.component';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { BoardTaskDetailComponent } from './board-task-detail/board-task-detail.component';
import { Routes, RouterModule } from '@angular/router';
import { RatingModule } from 'src/app/shared/component/rating/rating.module';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';
import { SpaceNotAllowModule } from 'src/app/shared/directives/space-not-allow/space-not-allow.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
const routes: Routes = [
  {
    path: '',
    component: BoardTaskListComponent
  },
  {
    path: 'board-task-detail',
    component: BoardTaskDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    MatInputModule,
    SafeModule,
    FilterUniqueArrayModule,
    RatingModule,
    NoCaseNoteFoundModule,
    MatListModule,
    MatSelectModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatRadioModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatPaginatorModule,
    NumberOnlyDirectiveModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes),
    BsDatepickerModule.forRoot(),
    HideIfUnauthorizedModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [BoardTaskListComponent, BoardTaskDetailComponent]
})
export class BoardTaskModule { }
