
export enum BoardTaskStatus {
    All = "All",
    New = "New",
    InProgress = "InProgress",
    AwaitingBoardDecision = "AwaitingBoardDecision",
    Completed = "Completed",
    Cancelled = "Canceled"
}

export enum NoteType {
    BoardMember = "BoardMember",
    CommitteeMember = "CommitteeMember",
    Homeowner = "Homeowner",
    General = "General",
    PropertyManager = "PropertyManager",

}

export enum CaseFeatureType {
    ServiceRequest = "ServiceRequest",
    BoardTask = "BoardTask",
    Violation = "Violation",
    ARCRequest = "ARCRequest",
    Motion = "Motion",
    Contest = "Contest"
}
export enum AudienceType {
    HomeOwner = "HomeOwner",
    PropertyManager = "PropertyManager",
    Vendor = "Vendor",
    Guest = "Guest",
    BoardMember = "BoardMember",
    CommitteeMember = "CommitteeMember",
    ARCCommitteeMember = "ARCCommitteeMember",
    Violator = "Violator",
}
export class DisplayPriority {
    public static PriorityList = [
        { value: "High", text: "High" },
        { value: "Medium", text: "Medium" },
        { value: "Low", text: "Low" }
    ]
}


export class DisplayColumns {
    public static ColumnsList = [
        { value: "Status", text: "Status" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "CompletedOn", text: "Completed On" },
        { value: "Priority", text: "Priority" },
        // { value: "Reason", text: "Reason" },
        { value: "Rating", text: "Rating" },
        // { value: "Comments", text: "Comments" },
        // { value: "Action", text: "Action" }
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Category", text: "Category" },
        { value: "CreatedOn", text: "Created On" },
        { value: "DueDate", text: "Due Date" }
    ]

    public static AllSelectedColumnsList = [
        { value: "Status", text: "Status" },
        { value: "Priority", text: "Priority" },
    ]

    public static NewSelectedColumnsList = [
        { value: "Priority", text: "Priority" }
    ]

    public static InProgressSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "Priority", text: "Priority" },
        // { value: "Comments", text: "Comments" },
    ]

    public static AwatingDecisionSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "Priority", text: "Priority" },
        // { value: "Action", text: "Action" },
        // { value: "Comments", text: "Comments" },
    ]

    public static CancelledSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
        // { value: "Reason", text: "Reason" },
        { value: "Priority", text: "Priority" },
    ]

    public static CompletedSelectedColumnsList = [
        { value: "CompletedOn", text: "Completed On" },
        { value: "Rating", text: "Rating" }
    ]

    public static AllColumnsList = [
        "Title", "Category", "Created On", "Due Date", "Status", "Priority"
        //{ value: "Priority", text: "Priority" }
    ]

    public static NewColumnsList = [
        "Title", "Category", "Created On", "Due Date", "Priority"
        //{ value: "Priority", text: "Priority" }
    ]

    public static InProgressColumnsList = [
        "Title", "Category", "Created On", "Due Date", "Last Updated On", "Priority", "Comments"
    ]

    public static AwatingDecisionColumnsList = [
        "Title", "Category", "Created On", "Due Date", "Last Updated On", "Priority", "Comments", "Action"
    ]

    public static CompletedColumnsList = [
        "Title", "Category", "Created On", "Due Date", "Completed On", "Rating"
        // { value: "CompletedOn", text: "Completed On" },
        // { value: "Rating", text: "Rating" }     
    ]

    public static CancelledColumnsList = [
        "Title", "Category", "Created On", "Due Date", "Last Updated On", "Reason", "Priority"
        // { value: "LastUpdatedOn", text: "Last Updated On" },
        // { value: "Reason", text: "Reason" }
    ]

}




export class PmDisplayColumns {
    public static ColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Association", text: "Association" },
        { value: "Category", text: "Category" },
        { value: "CreatedOn", text: "Created On" },
        { value: "DueDate", text: "Due Date" },
        { value: "Status", text: "Status" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "Updated By", text: "Updated By" },
        { value: "CompletedOn", text: "Completed On" },
        { value: "CanceledOn", text: "Canceled On" },
        { value: "AssignTo", text: "Assign To" },
        { value: "PendingTime", text: "Pending Time" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "CompletionTime", text: "Completion Time" },
        { value: "Priority", text: "Priority" },
        { value: "Rating", text: "Rating" },
        // { value: "Comments", text: "Comments" },

    ]

    public static DefaultColumnsList = [
        //"Title", "Category", "Created On", "Due Date"
        { value: "Title", text: "Title" },
        { value: "Association", text: "Association" },
        { value: "Category", text: "Category" },
        { value: "CreatedOn", text: "Created On" }
    ]

    public static AllSelectedColumnsList = [
        { value: "Status", text: "Status" },
        { value: "Priority", text: "Priority" }//,
        // { value: "AssignTo", text: "Assign To" }
    ]

    public static NewSelectedColumnsList = [
        { value: "DueDate", text: "Due Date" },
        // { value: "AssignTo", text: "Assign To" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "Priority", text: "Priority" },
        // { value: "Comments", text: "Comments" },
    ]

    public static InProgressSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "Updated By", text: "Updated By" },
        { value: "DueDate", text: "Due Date" },
        // { value: "AssignTo", text: "Assign To" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        //{ value: "Comments", text: "Comments" },
        { value: "Priority", text: "Priority" }
    ]

    public static CompletedSelectedColumnsList = [
        { value: "DueDate", text: "Due Date" },
        { value: "CompletedOn", text: "Completed On" },
        { value: "Updated By", text: "Updated By" },

        // { value: "AssignTo", text: "Assign To" },
       // { value: "CompletionTime", text: "Completion Time" },
        { value: "Rating", text: "Rating" }
    ]

    public static CancelledSelectedColumnsList = [
        //{ value: "AssignTo", text: "Assign To" },
        { value: "CancelledOn", text: "Canceled On" },
        { value: "Updated By", text: "Updated By" }
    ]

    public static AwatingDecisionSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "Updated By", text: "Updated By" },
        //{ value: "PendingTime", text: "Pending Time" },
        { value: "Priority", text: "Priority" },
        { value: "DueDate", text: "Due Date" }//,
        // { value: "AssignTo", text: "Assign To" },
        // { value: "Comments", text: "Comments" },
    ]

    public static AllColumnsList = [
        "Title", "Association", "Category", "Created On", "Due Date", "Status", "Assign To", "Priority"
        //{ value: "Priority", text: "Priority" }
    ]

    public static NewColumnsList = [
        "Title", "Association", "Category", "Created On", "Due Date", "Assign To", "Time Elapsed", "Priority", "Comments"
        // { value: "Title", text: "Title" },
        // { value: "Association", text: "Association" },
        // { value: "Category", text: "Category" },
        // { value: "CreatedOn", text: "Created On" },
        // { value: "DueDate", text: "Due Date" },
        // { value: "AssignTo", text: "Assign To" },
        // { value: "TimeElapsed", text: "Time Elapsed" },
        // { value: "Priority", text: "Priority" },
        // { value: "Comments", text: "Comments" },
    ]

    public static InProgressColumnsList = [
        "Title", "Association", "Category", "Created On", "Last Updated On", "Updated By", "Due Date", "Assign To", "Time Elapsed", "Priority", "Comments"
        // { value: "LastUpdatedOn", text: "Last Updated On" },
        // { value: "Priority", text: "Priority" },
        // { value: "Comments", text: "Comments" }       
    ]

    public static AwatingDecisionColumnsList = [
        "Title", "Association", "Category", "Created On", "Last Updated On", "Updated By","Due Date", "Assign To", "Pending Time", "Priority", "Comments"
    ]

    public static CompletedColumnsList = [
        "Title", "Association", "Category", "Created On", "Due Date", "Completed On", "Updated By", "Assign To", "Completion Time", "Rating"
    ]

    public static CancelledColumnsList = [
        "Title", "Category", "Created On", "Canceled On", "Updated By","Assign To"
    ]

}



export class CaseSubCategory {
    caseCategoryName: string;
    caseSubCategoryNames: CaseSubCategoryName[];
}
export class CaseSubCategoryName {
    caseSubCategory: string;
}
export class BoardTaskModel {
    Domain: string;
    TypeOfDocument: string;
    RequestId: string;
    Document: any[];
    Case: RequestBoardTaskModel;
}
export class RequestBoardTaskModel {
    id: string;
    Title: string;
    AssociationId: string;
    AssociationName: string;
    CompanyCode: string;
    CaseType: string;
    SubCaseType: string;
    CaseCategory: string;
    CaseSubCategory: string;
    Comments: string;
    CustomerType: string;
    DueDate: string;
    CasePriority: string;
    LastName: string;
    FirstName: String;
    CaseOriginatingType: string;
    IsAuthorized: string;
    StatusReason: string;
    Phone: string;
    AssignedTo: string;
    AssignedPartyType: string;
    CaseDocuments: string[];
    CreatedByUserId: string;
    CreatedByUserName: string;
    ModifiedByUserId: string;
    ModifiedByUserName: string
}

export class CaseNoteModel {
    AssociationId: string;
    Domain: string;
    RequestId:string;
    TypeOfDocument: string;
    Document: any[];
    CaseNotes: RequestCaseNoteModel;
}

export class EscalteModel {
    RequestId: string;
    CaseNotes: RequestCaseNoteModel;
}

export class RequestCaseNoteModel {
    CaseNoteId: string;
    Note: string;
    CreatedByUserId: string;
    CaseId: string;
    NotesType: string;
    CreatedByUserName: string;
    CaseFeatureType: string;
    StatusReason: string;
    ProfilePath: string;
    RoleType: string;
    IsVotingRequired: boolean;
    ActivityType: string;
    IsAssignedToBoard: boolean;
  
}

export class UpdateBoardTaskStatus {
    RequestId: string;
    StatusType: string;
    //CaseId: string;
    CaseNotes: RequestCaseNoteModel;
}



export class MotionModel {
    MotionId: string;
    CaseId: string;
    AssociationId: string;
    AssociationName: string;
    CreatedByUserId: string;
    CreatedByUserName: string;
    Description: string;
    CaseFeatureType: string;
    ProfilePath: string;
}


// export class MotionVoteModel
// {
//     CaseId:string;
//     RequestId:string;
//     AssociationId:string;
//     Votes:VotesModel;
// }

export class VoteModel {
    Vote: boolean;
    CreatedByUserId: string;
    CreatedByUserName: string;
    Remarks: string;
    ProfilePath: string;
}


