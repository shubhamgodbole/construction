import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from "@angular/router";
import { BoardTaskApiService } from 'src/app/services/board-task-api.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { CaseNoteModel, NoteType, CaseFeatureType, UpdateBoardTaskStatus, BoardTaskStatus, MotionModel, VoteModel, AudienceType } from '../board-task.model';
import { TypeOfDocument, IsAuthorized, CaseOriginatingType, RoleEnum, ImageNameEnums, StatusReason, FeatureName, DownloadfeatureName, DocumentFeatureName, SourceType, TriggerType, CallType, ActivityType, PlaceHolderText, VoteStatus, FeaturePermissions, EmailAudience } from 'src/app/shared/Enums/commonEnums';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { MatDialogRef, MatDialog, MatSnackBar } from '@angular/material';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { CommonService } from 'src/app/services/common.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Subscription } from 'rxjs';
import { RateAndReviewDialogComponent } from 'src/app/shared/component/rate-and-review-dialog/rate-and-review-dialog.component';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';
import { Guid } from 'guid-typescript';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonConstant, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import * as _ from 'lodash';


@Component({
  selector: 'app-board-task-detail',
  templateUrl: './board-task-detail.component.html',
  styleUrls: ['./board-task-detail.component.scss']
})
export class BoardTaskDetailComponent implements OnInit {

  propVivoName = CommonConstant.PropVivo;


  previousUrl: string;
  //Rate and Review Diaload
  confirmDialogRateAndReviewRef: MatDialogRef<RateAndReviewDialogComponent>;
  dialogRef: any;
  isRateButtonShow: boolean = false;
  isCommentAndReopen: boolean = true;

  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;


  notificationService: NotificationService;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  //Confirm Dialog
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  //For Query string;
  querySubcription: Subscription;
  userData: UserData;
  typeOfDocument = TypeOfDocument.CaseDocuments;
  isAuthorized = IsAuthorized;
  caseOriginatingType = CaseOriginatingType;
  associationName: string;
  associationId: string;
  currRole: string = "";
  createdByUserName: string;
  profilePath: string;
  createdByUserId: string;
  domain: string;
  boardTaskStatus: string = "";
  isApiResponseCome: boolean = false;
  boardTaskStatusEnum = BoardTaskStatus;
  roleEnum = RoleEnum;
  escalteCaseNoteList: any = null;
  esclateVoteCount: number = 0;
  esclateVoterList: any[];
  isVote: boolean;

  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;
  isEditCaseNoteButtonDisabled: boolean = false;
  //Enum
  noteType = NoteType;
  VoteStatusEnum = VoteStatus;
  userName: string;

  // view more 
  shoNDocs: number = 3;
  viewDocs: boolean;
  viwAllDocBtnMsg: string = "View All Attachments";

  readMoreBtn: boolean;
  readMoreDescBtnMsg: string = "Read More";
  desLimit: number = 160;


  //Read More motion
  readMoreMotionBtn: boolean;
  readMoreMotionBtnMsg: string = "Read More";
  motionLimit: number = 160;
  motionList: any = null;
  motionMsg: string;
  motionIcon: string;
  voteReceiveMsg: string;
  isMotionVote: boolean;
  desMotionLimit: number = 160;
  motionVoteCount: number = 0;

  role: string;
  fileData = [];
  /*PM Case Note Form*/
  frmCreatePmCaseNote: FormGroup;
  fileDataPMCase = [];
  isSubmitBtnDisabledPmCaseNote: boolean = false;
  @ViewChild('formPmDirective') formPmDirective: FormGroupDirective;

  /*BM Case Note Form*/
  frmCreateBmCaseNote: FormGroup;
  fileDataBMCase = [];
  isSubmitBtnDisabledBmCaseNote: boolean = false;
  @ViewChild('formBmDirective') formBmDirective: FormGroupDirective;

  /*Board Cast Status Form*/
  frmCancel: FormGroup;
  isSubmitBtnDisabledCancel: boolean = false;
  audienceType = AudienceType;
  @ViewChild('formDirectiveCancel') formDirectiveCancel: FormGroupDirective;

  /*Motion Form*/
  isDisplayMotionDiv: boolean = false;
  frmCreateMotion: FormGroup;
  isSubmitBtnDisabledMotion: boolean = false;
  resDataCreateMotion: any;
  @ViewChild('formDirectiveMotion') formDirectiveMotion: FormGroupDirective;

  /*Reopen Form*/
  frmCreateReopen: FormGroup;
  isSubmitBtnDisabledReopen: boolean = false;
  resDataCreateReopen: any;
  @ViewChild('formDirectiveReopen') formDirectiveReopen: FormGroupDirective;

  /*Completed Form*/
  frmCreateComplete: FormGroup;
  isSubmitBtnDisabledComplete: boolean = false;
  resDataCreateComplete: any;
  @ViewChild('formDirectiveComplete') formDirectiveComplete: FormGroupDirective;

  /*ReviewAndRating Form*/
  frmCreateReviewAndRating: FormGroup;
  isSubmitBtnDisabledReviewAndRating: boolean = false;
  resDataCreateReviewAndRating: any;
  rate = 0;
  @ViewChild('formDirectiveReviewAndRating') formDirectiveReviewAndRating: FormGroupDirective;
  //rateData:number =0;
  countRating: number = 0;
  resData: any;
  boardTaskDetailList: any;
  documentList: any[];
  caseNoteList: any[];
  boardMemberCaseNoteList: any;

  /**Motion vote */
  resDataCreateMotionVote: any;
  isDisplayVoteList: boolean = false;
  isDisplayEscalatedVoteList: boolean = false;
  isDisplayEscalatVoteList: boolean = false;
  esclateResult: string;
  decisionReason = [];

  MobActoin = false;
  MobDetail = false;
  MobChat = false;
  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentDetails: boolean = false;

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;


  //For Send Notification
  featureName: any;
  featureId: any;
  pmCompanyAssociationMappingId: string;

  //replyTo
  selectedReplyTo: string;
  selectedConversionType: string = "All";
  callTypeEnum = CallType;
  activityTypeEnum = ActivityType;
  caseNotes: any;
  allCaseNotes: any;
  //Enums
  noteTypeEnums = NoteType;
  statusReasonEnum = StatusReason;
  //static msg class
  placeHolderText = PlaceHolderText;

  selectedActivityType: string;
  reasonType: string;

  //Motion
  isMotionCreated: boolean;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  constructor(private _router: Router,
    private ngZone: NgZone,
    private activatedRoute: ActivatedRoute,
    private readonly formBuilder: FormBuilder,
    private boardTaskApiService: BoardTaskApiService,
    private progressbarService: ProgeressBarService,
    public commonService: CommonService,
    private emailNotification: EmailNotificationService,
    private readonly snb: MatSnackBar,
    private route: ActivatedRoute,
    private _matDialog: MatDialog,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.currRole = this.userData.Role;
    this.createdByUserId = this.userData.UserProfileId;
    this.createdByUserName = this.userData.UserName;
    this.profilePath = this.userData.UserProfileBlobPath;
    console.log("this.userData.UserProfileBlobPath", this.userData.UserProfileBlobPath);
    this.domain = this.userData.UserAssociations[0].Domain;
    this.role = this.userData.Role;
    this.userName = this.userData.UserName;

    //Notification
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Escalate) {
          this.featureName = feature.Name
          this.featureId = feature.FeatureId
        }
      });
    this.createCaseNoteForm();
    this.createBoardTaskStatusForm();
    this.createMotionForm();
    this.createReopenForm();
    this.createCompleteForm();
    //this.createReviewAndRatingForm();
    ;
    this.notificationService = new NotificationService(snb);
  }

  MobActionToggle() {
    if (this.MobActoin)
      this.MobActoin = false;
    else
      this.MobActoin = true;
  }

  MobShowDetail() {
    if (this.MobDetail)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  MobShowChat() {
    if (this.MobChat)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.boardTaskApiService.boardTaskDetailId = id;
        this.boardTaskApiService.domain = this.domain;
        this.getData();
      }
      else {
        this._router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
  }

  getData() {
    this.progressbarService.show();
    this.boardTaskApiService.getBoardTaskDetails(this.boardTaskApiService.boardTaskDetailId, this.boardTaskApiService.domain).subscribe(res => {
      this.resData = res;
      this.progressbarService.hide();
      console.log("===============", res);
      if (this.resData.RequestDetail.Success === true) {
        this.isApiResponseCome = true;
        this.boardTaskDetailList = this.resData.RequestDetail.BoardTask;
        if (this.resData.RequestDetail.BoardTask !== null) {
          this.isShowNextAndPreviewsButton();
          this.setBoardTaskDetails();
        } else {
          console.log("Details Not found");
          this._router.navigate([AppRouteUrl.errorRouteUrl]);
        }
        this.documentList = this.resData.RequestDetail.Document;

        if (this.boardTaskStatus === this.boardTaskStatusEnum.Completed && (this.boardTaskDetailList.Ratings === undefined || this.boardTaskDetailList.Ratings === null || this.boardTaskDetailList.Ratings.length === 0)) {
          this.isRateButtonShow = true;
          this.addRateReview();
        }
        else if (this.boardTaskStatus === this.boardTaskStatusEnum.Completed && this.boardTaskDetailList.Ratings !== null && this.boardTaskDetailList.Ratings.length > 0) {
          var userRate = this.boardTaskDetailList.Ratings.find(a => a.CreatedByUserId === this.createdByUserId);
          if (userRate != null) {
            this.isRateButtonShow = false;
          } else {
            this.isRateButtonShow = true;
            this.addRateReview();
          }
        }
        this.motionList = this.resData.RequestDetail.Motion;
        if (this.motionList !== null) {
          // Add motion in to case note
          if (this.motionList.length > 0) {
            this.motionList.map(m => {
              var motion = this.commonService.convertMotionToCaseNote(m);
              this.resData.RequestDetail.CaseNoteDetails.unshift(motion);
            });
          }
        }
        if (this.resData.RequestDetail.CaseNoteDetails !== null) {
          if (this.resData.RequestDetail.CaseNoteDetails.length > 0) {
            this.setCaseNoteData(this.resData.RequestDetail.CaseNoteDetails);
          }
          else {
            this.resetCaseNotesVariables();
          }
        }
        else {
          this.resetCaseNotesVariables();
        }

      } else if (this.resData.Errors.length === 0) {
        this.isApiResponseCome = true;
        if (this.resData.RequestDetail.BoardTask === null) {
          console.log("Details Not found");
          this._router.navigate([AppRouteUrl.errorRouteUrl]);
        }
      }
      else {
        this.notificationService.showNotification("Details Not Found");
        this._router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }
  isShowNextAndPreviewsButton() {
    let BTlocalStorageData = JSON.parse(localStorage.getItem('BTList'));
    if (BTlocalStorageData === null || BTlocalStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.boardTaskApiService.boardTaskDetailId;
      var btAr = JSON.parse(localStorage.getItem('BTList'));
      this.totalPages = btAr.length - 1;
      var el = btAr.find(a => { return a.id === current });
      var currentEl = btAr.indexOf(el);
      this.currentPage = currentEl;
    }
  }


  /*Case Note Add Module*/
  createCaseNoteForm() {
    this.frmCreateBmCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
    this.frmCreatePmCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        if (this.selectedReplyTo === NoteType.BoardMember) {
          this.fileDataBMCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.PropertyManager) {
          this.fileDataPMCase = this.fileData;
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }
  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
    if (this.selectedReplyTo === NoteType.BoardMember) {
      this.fileDataBMCase = this.fileDataBMCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.PropertyManager) {
      this.fileDataPMCase = this.fileDataPMCase.filter(a => a.imageId !== imageId);
    }
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  onSubmitBmCaseNote() {
    if (this.frmCreateBmCaseNote.valid) {
      this.isSubmitBtnDisabledBmCaseNote = true;
      let model = this.createBoardTaskFormModel(NoteType.BoardMember, this.frmCreateBmCaseNote, this.fileDataBMCase);
      console.log("CaseNoteBoardTaskmodel", model);
      let resDataCreate;
      this.boardTaskApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledBmCaseNote = false;
        resDataCreate = res;
        if (resDataCreate.caseRequestListResults[0].Success === true) {
          if (this.fileDataBMCase.length > 0) {
            this.getData();
          } else {
            this.setCaseNoteData(resDataCreate.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetCaseNoteForm();
        }
        else if (resDataCreate.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  onSubmitPmCaseNote() {
    if (this.frmCreatePmCaseNote.valid) {
      this.isSubmitBtnDisabledPmCaseNote = true;
      let model = this.createBoardTaskFormModel(NoteType.PropertyManager, this.frmCreatePmCaseNote, this.fileDataPMCase);
      console.log("CaseNoteBoardTaskmodel", model);
      let resDataCreate;
      this.boardTaskApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledPmCaseNote = false;
        resDataCreate = res;
        if (resDataCreate.caseRequestListResults[0].Success === true) {
          if (this.fileDataPMCase.length > 0) {
            this.getData();
          } else {
            this.setCaseNoteData(resDataCreate.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetCaseNoteForm();
        }
        else if (resDataCreate.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  createBoardTaskFormModel(noteType, caseFrm, caseNotefileData) {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: this.typeOfDocument,
      Document: caseNotefileData,
      Domain: this.boardTaskApiService.domain,
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      CaseNotes:
      {
        CaseNoteId: caseFrm.controls.caseNoteId.value,
        Note: caseFrm.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: noteType,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetCaseNoteForm() {
    if (this.selectedReplyTo === NoteType.BoardMember) {
      this.frmCreateBmCaseNote.reset();
      if (this.formBmDirective !== undefined) {
        this.formBmDirective.resetForm();
      }
      this.isSubmitBtnDisabledBmCaseNote = false;
      this.fileDataBMCase = [];
    }
    else {
      this.frmCreatePmCaseNote.reset();
      if (this.formPmDirective !== undefined) {
        this.formPmDirective.resetForm();
      }
      this.fileDataPMCase = [];
    }

    this.selectedReplyTo = "";
  }

  /*Update status of board task*/

  createBoardTaskStatusForm() {
    this.frmCancel = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitCancel() {
    if (this.frmCancel.valid) {
      this.isSubmitBtnDisabledCancel = true;
      let model = this.createBoardTaskStatusFormModel();
      let resDataCreateBoardTaskStatus;
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledCancel = false;
        resDataCreateBoardTaskStatus = res;
        if (resDataCreateBoardTaskStatus.caseRequestListResults[0].Success === true) {
          this.notificationService.showNotification("Board task status updated successfully");
          this.getData();
          this.resetStatusCancelForm();
          this.emailNotification.sendNotifications(this.featureId, resDataCreateBoardTaskStatus.caseRequestListResults[0].RequestId, this.createdByUserId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Board_Task, TriggerType.Update_Cancelled,
            AudienceType.BoardMember).subscribe(res => {
              console.log(res);
            });
        }
        else if (resDataCreateBoardTaskStatus.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Board task not status updated");
        }
      });
    }
  }

  createBoardTaskStatusFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.Cancelled,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCancel.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: null, //NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: StatusReason.Cancelled,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetStatusCancelForm() {
    this.frmCancel.reset();
    this.formDirectiveCancel.resetForm();
    this.reasonType = '';
  }

  /*Create motion of board task */
  createMotionForm() {
    this.frmCreateMotion = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitMotion() {
    if (this.frmCreateMotion.valid) {
      this.isSubmitBtnDisabledMotion = true;
      let model = this.createMotionFormModel();
      this.boardTaskApiService.createMotion(this.boardTaskApiService.boardTaskDetailId, model).subscribe(res => {
        this.isSubmitBtnDisabledMotion = false;
        this.resDataCreateMotion = res;
        if (this.resDataCreateMotion.caseRequestListResults[0].Success === true) {
          this.getData();
          this.resetMotionForm();
          this.emailNotification.sendNotifications(this.featureId, this.resDataCreateMotion.caseRequestListResults[0].RequestId, this.createdByUserId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Board_Task, TriggerType.Update,
            AudienceType.BoardMember).subscribe(res => {
              console.log(res);
            });
        }
        else if (this.resDataCreateMotion.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createMotionFormModel() {
    const model: MotionModel = {
      MotionId: '',
      CaseId: this.boardTaskApiService.caseId,
      AssociationId: this.associationId,
      CaseFeatureType: CaseFeatureType.BoardTask,
      CreatedByUserId: this.createdByUserId,
      CreatedByUserName: this.createdByUserName,
      AssociationName: this.associationName,
      Description: this.frmCreateMotion.controls.comments.value,
      ProfilePath: this.profilePath
    }
    return model;
  }


  resetMotionForm() {
    this.frmCreateMotion.reset();
    this.formDirectiveMotion.resetForm();
    this.isDisplayMotionDiv = false;
    document.getElementById('closeModelCreateMotion').click();
  }

  showMotionDiv() {
    this.resetMotionForm();
    this.selectedReplyTo = '';
    this.isDisplayMotionDiv = true;
  }


  /**Create Motion Vote */
  createMotionVote(voteStatus, id) {
    let model = this.createMotionVoteModel(voteStatus);
    this.progressbarService.show();
    this.boardTaskApiService.createMotionVote(this.boardTaskApiService.caseId, id, this.associationId, model).subscribe(res => {
      this.progressbarService.hide();
      this.resDataCreateMotionVote = res;
      if (this.resDataCreateMotionVote.caseRequestListResults[0].Success === true) {
        this.motionList = this.resDataCreateMotionVote.caseRequestListResults[0].Motion;
        if (this.motionList !== null) {
          this.getData();
          // if (this.motionList.VoteStatus !== undefined && this.motionList.VoteStatus !== null) {
          //   if (this.motionList.Votes !== null) {
          //     this.motionVoteCount = this.motionList.Votes.length;
          //   }
          // } else {
          //   this.getData();
          // }
        }
      }
      else if (this.resDataCreateMotionVote.caseRequestListResults[0].Success === false) {
        console.log("error");
      }
    });
  }

  createMotionVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: VoteModel = {
      Vote: vote,
      CreatedByUserId: this.createdByUserId,
      CreatedByUserName: this.createdByUserName,
      ProfilePath: this.profilePath,
      Remarks: ''
    }
    return model;
  }

  /*Display list of vote*/
  displayVoteListToggle() {
    this.isDisplayVoteList
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }
  displayEscalatedVoteListToggle() {
    if (this.isDisplayEscalatedVoteList)
      this.isDisplayEscalatedVoteList = false;
    else
      this.isDisplayEscalatedVoteList = true;
  }
  /*Display list of vote*/
  displayEscalatVoteListToggle() {
    if (this.isDisplayEscalatVoteList)
      this.isDisplayEscalatVoteList = false;
    else
      this.isDisplayEscalatVoteList = true;
  }

  /*Create Reopen of board task */
  createReopenForm() {
    this.frmCreateReopen = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitReopen() {
    if (this.frmCreateReopen.valid) {
      this.isSubmitBtnDisabledReopen = true;
      let model = this.createReopenFormModel();
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledReopen = false;
        this.resDataCreateReopen = res;
        if (this.resDataCreateReopen.caseRequestListResults[0].Success === true) {
          this.getData();
          this.resetReopenForm();
        }
        else if (this.resDataCreateReopen.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createReopenFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.InProgress,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateReopen.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: null,// NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: StatusReason.Reopen,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }


  resetReopenForm() {
    this.frmCreateReopen.reset();
    this.formDirectiveReopen.resetForm();
    this.reasonType = '';
    //document.getElementById('closeModelReopen').click();
  }



  /*Create Complete of board task */
  createCompleteForm() {
    this.frmCreateComplete = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitComplete() {
    if (this.frmCreateComplete.valid) {
      this.isSubmitBtnDisabledComplete = true;
      let model = this.createCompleteFormModel();
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledComplete = false;
        this.resDataCreateComplete = res;
        if (this.resDataCreateComplete.caseRequestListResults[0].Success === true) {
          this.getData();
          this.resetCompleteForm();
        }
        else if (this.resDataCreateComplete.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createCompleteFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.Completed,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateComplete.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: null, //NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: StatusReason.Completed,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }


  resetCompleteForm() {
    this.frmCreateComplete.reset();
    this.formDirectiveComplete.resetForm();
    document.getElementById('closeModelComplete').click();
  }

  /*Delete case note*/
  delete(id) {
    let resData;
    this.commonService.deleteCaseNote(id, this.boardTaskApiService.caseId, this.associationId, this.boardTaskApiService.domain).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
            this.setCaseNoteData(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          else {
            this.resetCaseNotesVariables();
          }
        }
        else {
          this.resetCaseNotesVariables();
        }
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })

  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }


  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
  }

  updateCaseNote(noteType) {
    if (this.editComments === "") {
      this.isEditValidation = true;
      return;
    }
    this.isEditCaseNoteButtonDisabled = true;
    this.isEditValidation = false;
    let model = this.editCaseNoteModel(noteType);
    this.commonService.updateCaseNote(model).subscribe(res => {
      let resData;
      this.isEditCaseNoteButtonDisabled = false;
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.resetEditCaseNote();
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
            //this.caseNoteList = resData.caseRequestListResults[0].CaseNoteDetails;
            this.setCaseNoteData(resData.caseRequestListResults[0].CaseNoteDetails);
          } else {
            this.resetCaseNotesVariables();
          }
        }
        console.log("Case note updated successfully.");
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        this.notificationService.showNotification("Not update");
      }
    });
  }

  editCaseNoteModel(noteType) {
    const model: CaseNoteEditModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      Domain: this.boardTaskApiService.domain,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: noteType,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        RoleType: this.role,
      }
    }
    return model;
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
  }

  // //For Vote
  createEsclateVote(voteStatus, caseNoteId) {
    this.progressbarService.show();
    let resData;
    let model = this.createEsclateVoteModel(voteStatus);
    this.boardTaskApiService.createEsclateVote(this.boardTaskApiService.caseId, caseNoteId, this.boardTaskApiService.boardTaskDetailId, this.associationId, model).subscribe(res => {
      resData = res;
      console.log("resData", resData);
      this.progressbarService.hide();
      if (resData.Success === true) {
        this.escalteCaseNoteList = resData.CaseActivity;
        this.esclateResult = this.escalteCaseNoteList.VoteStatus;
        this.esclateVoteCount = this.escalteCaseNoteList.Votes.length;
        this.caseNotes = this.caseNotes.map((a) => {
          if (a.CaseNotes.id === this.escalteCaseNoteList.id) {
            a.CaseNotes = this.escalteCaseNoteList;
          }
          return a;
        });
        console.log(this.caseNotes);
        if (this.esclateVoteCount > 0) {
          this.esclateVoterList = this.escalteCaseNoteList.Votes;
          let voteByUser = this.escalteCaseNoteList.Votes.find(v => v.CreatedByUserId === this.createdByUserId);
          if (voteByUser) {
            this.isVote = voteByUser.Vote;
          }
        }

        this.boardTaskDetailList = resData.boardTaskRequestDetail;
        this.setBoardTaskDetails();
      }
      else if (resData.Success === false) {
        console.log("error");
      }
    });
  }

  createEsclateVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: VoteModel = {
      Vote: vote,
      CreatedByUserId: this.createdByUserId,
      CreatedByUserName: this.createdByUserName,
      ProfilePath: this.profilePath,
      Remarks: ''
    }
    return model;
  }


  // view more description
  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.desLimit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.readMoreDescBtnMsg = "Read Less";
      this.desLimit = this.boardTaskDetailList.Description.length;

    }
  }

  // view more Motions
  viewMoreMotions() {
    if (this.readMoreMotionBtn) {
      this.readMoreMotionBtn = false;
      this.readMoreMotionBtnMsg = "Read More";
      this.motionLimit = 160;
    }
    else {
      this.readMoreMotionBtn = true;
      this.readMoreMotionBtnMsg = "Read Less";
      this.motionLimit = this.motionList.Description.length;

    }
  }

  //view more documents
  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.documentList.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }



  //Rate and review dialoag using mat dialog
  addRateReview() {
    this.dialogRef = this._matDialog.open(RateAndReviewDialogComponent, {
      // panelClass: 'add-question-set-dialog'
    });

    this.dialogRef.afterClosed()
      .subscribe(response => {
        if (!response) {
        }
        console.log(response);
        const actionType: string = response[0];
        const formData: FormGroup = response[1];
        switch (actionType) {
          case 'submit':
            let model = {
              Comment: formData.controls.comments.value,
              Ratings: formData.controls.rateCount.value,
              CreatedByUserId: this.createdByUserId,
              CreatedByUserName: this.createdByUserName,
              ProfilePath: this.profilePath
            };
            console.log(model);
            this.boardTaskApiService.addRateOnBoardTask(this.boardTaskApiService.boardTaskDetailId, this.boardTaskApiService.domain, model).subscribe(res => {
              this.isSubmitBtnDisabledReviewAndRating = false;
              this.resDataCreateReviewAndRating = res;
              if (this.resDataCreateReviewAndRating.caseRequestListResults[0].Success === true) {
                this.getData();
              }
              else if (this.resDataCreateReviewAndRating.caseRequestListResults[0].Success === false) {
                console.log("error");
              }
            });
            break;
          /**
           * Delete
           */
          case 'cancel':
            break;
        }
      });
  }

  setCaseNoteData(caseNoteDetail) {
    this.allCaseNotes = [];
    console.log(caseNoteDetail);
    if (caseNoteDetail !== null) {

      var assignToBoardBeforeVote = caseNoteDetail.find(note => (note.CaseNotes.IsVotingRequired === true && note.CaseNotes.VoteStatus === null));
      if (assignToBoardBeforeVote !== null && (assignToBoardBeforeVote !== undefined)) {
        this.allCaseNotes.push(assignToBoardBeforeVote);
      }

      this.allCaseNotes = caseNoteDetail.filter(note => note.CaseNotes.NotesType !== NoteType.PropertyManager && note.CaseNotes.RoleType !== RoleEnum.PropertyManager);
      console.log("allCaseNotes", this.allCaseNotes);

      var activity = caseNoteDetail.filter(note => ((note.CaseNotes.ActivityType === ActivityType.Email && note.CaseNotes.EmailAudience !== EmailAudience.None) || note.CaseNotes.ActivityType === ActivityType.Phone && (note.CaseNotes.IsVotingRequired === false || note.CaseNotes.IsVotingRequired === null)));

      if (activity.length > 0) {
        this.allCaseNotes = this.allCaseNotes.concat(activity);
      }
      var assignToBoardAfterVote = caseNoteDetail.filter(note => (note.CaseNotes.ActivityType === ActivityType.AssignToBoard && note.CaseNotes.VoteStatus !== null));
      if (assignToBoardAfterVote.length > 0) {
        this.allCaseNotes = this.allCaseNotes.concat(assignToBoardAfterVote);
      }
      var assignToBoardData = caseNoteDetail.filter(note => (note.CaseNotes.ActivityType === ActivityType.AssignToBoard && note.CaseNotes.IsVotingRequired === false || ((note.CaseNotes.ActivityType === this.activityTypeEnum.Phone && note.CaseNotes.IsVotingRequired === true))));
      if (assignToBoardData.length > 0) {
        this.allCaseNotes = this.allCaseNotes.concat(assignToBoardData);
      }
      var reasons = caseNoteDetail.filter(note => note.CaseNotes.StatusReason !== null && note.CaseNotes.StatusReason !== '');
      if (reasons.length > 0) {
        this.allCaseNotes = this.allCaseNotes.concat(reasons);
      }
      var bmCaseNote = caseNoteDetail.filter(note => note.CaseNotes.NotesType === NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager || note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.BoardMember);
      if (bmCaseNote.length > 0) {
        this.allCaseNotes = this.allCaseNotes.concat(bmCaseNote);
      }

      this.allCaseNotes = _.sortBy(this.allCaseNotes, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();


      // get motion with final status
      var motionCaseNoteWithStatus = caseNoteDetail.filter(m => {
        return m.CaseNotes.VoteStatus !== null && m.CaseNotes.DocumentType === 'Motion';
      });

      //concat motion
      if (motionCaseNoteWithStatus.length > 0) {
        this.allCaseNotes = motionCaseNoteWithStatus.concat(this.allCaseNotes);
      }

      // sort data with motion data
      this.allCaseNotes = _.sortBy(this.allCaseNotes, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();


      //get before data
      var caseNoteBeforeVote = caseNoteDetail.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null || note.CaseNotes.DocumentType === "Motion" && note.CaseNotes.VoteStatus === null));

      if (caseNoteBeforeVote.length > 0) {
        caseNoteBeforeVote = _.sortBy(caseNoteBeforeVote, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();
        this.allCaseNotes = caseNoteBeforeVote.concat(this.allCaseNotes);
      }

      this.changeConversion();

      let escalteCaseNote = caseNoteDetail.find(x => x.CaseNotes.IsAssignedToBoard === true);
      console.log("escalteCaseNote", escalteCaseNote);
      if (escalteCaseNote != undefined && escalteCaseNote !== null) {
        // this.esclateResult = escalteCaseNote.VoteStatus;
        this.escalteCaseNoteList = escalteCaseNote.CaseNotes;
        if (this.escalteCaseNoteList.Votes !== null) {
          if (this.escalteCaseNoteList.Votes.length !== 0) {
            this.esclateVoterList = escalteCaseNote.CaseNotes.Votes;
            this.esclateVoteCount = escalteCaseNote.CaseNotes.Votes.length;
            let voteByUser = escalteCaseNote.CaseNotes.Votes.find(v => v.CreatedByUserId === this.createdByUserId);
            if (voteByUser) {
              this.isVote = voteByUser.Vote;
            }
          }
        }
      }
    }
  }

  checkIsMotionVote(motionCaseNoteWithNotStatus) {
    if (motionCaseNoteWithNotStatus !== null && motionCaseNoteWithNotStatus !== undefined) {
      this.isMotionCreated = true;
      if (motionCaseNoteWithNotStatus.CaseNotes.Votes.length > 0) {
        let voteByUser = motionCaseNoteWithNotStatus.CaseNotes.Votes.find(v => v.CreatedByUserId === this.createdByUserId);
        if (voteByUser) {
          //this.isMotionVote = voteByUser.Vote;
          return voteByUser.Vote;
        }
      }
    }
  }


  downloadDocument(filename) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.BoardTask,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Document not found");
        }
      });
  }




  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.FilePath, DocumentFeatureName.BoardTask, DownloadfeatureName.Download).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Preview not found");
      }
    });
  }


  //**Next AND Preview */
  PreviousCase() {
    var current = this.boardTaskApiService.boardTaskDetailId;
    var btAr = JSON.parse(localStorage.getItem('BTList'));
    this.totalPages = btAr.length - 1;
    var el = btAr.find(a => { return a.id === current });
    var currentEl = btAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = btAr[currentEl - 1].id;
      this.boardTaskApiService.boardTaskDetailId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getData();
    }
  }

  NextCase() {
    var current = this.boardTaskApiService.boardTaskDetailId;
    var btAr = JSON.parse(localStorage.getItem('BTList'));
    this.totalPages = btAr.length - 1;
    var el = btAr.find(a => { return a.id === current });
    var currentEl = btAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < btAr.length) {
      let prevIndex = btAr[currentEl + 1].id;
      this.boardTaskApiService.boardTaskDetailId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getData();
    }
  }

  toGoBack() {
    let page = localStorage.getItem("previousPage");
    if (page === AppRouteUrl.mainMotionsRouteUrl) {
      this._router.navigate([AppRouteUrl.mainMotionsRouteUrl]);
    } else {
      this._router.navigate([AppRouteUrl.mainBoardTasksBMRouteUrl]);
    }
  }

  resetCaseNotesVariables() {
    this.caseNotes = [];
    this.caseNoteList = [];
    this.boardMemberCaseNoteList = [];
    this.decisionReason = [];
    this.escalteCaseNoteList = null;
  }

  ngOnDestroy(): void {
    // Unsubscribe from localStorage
    localStorage.removeItem('BTList');
    this.querySubcription.unsubscribe();
  }

  //New methods Reply to 
  //change reply to 
  changeReplyTo() {
    this.isDisplayMotionDiv = false;
    this.fileData = [];
  }

  //change conversion
  changeConversion() {
    if (this.selectedConversionType === "All") {
      this.caseNotes = this.allCaseNotes;
    } else if (this.selectedConversionType === NoteType.BoardMember) {
      this.caseNotes = this.allCaseNotes.filter(note => (note.CaseNotes.NotesType == NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.BoardMember));
    } else if (this.selectedConversionType === NoteType.PropertyManager) {
      this.caseNotes = this.allCaseNotes.filter(note => (note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.BoardMember && note.CaseNotes.IsAssignedToBoard === false) || (note.CaseNotes.NotesType == NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager && note.CaseNotes.IsAssignedToBoard === false));
    } else if (this.selectedConversionType === this.activityTypeEnum.Phone) {
      this.caseNotes = this.allCaseNotes.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Phone && note.CaseNotes.IsVotingRequired !== true);
    } else if (this.selectedConversionType === this.activityTypeEnum.Email) {
      this.caseNotes = this.allCaseNotes.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Email && note.CaseNotes.EmailAudience !== EmailAudience.None);
    } else if (this.selectedConversionType === this.activityTypeEnum.AssignToBoard) {
      this.caseNotes = this.allCaseNotes.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.AssignToBoard);
    }
  }

  setMotionValue() {
    var passVotes;
    var failVotes;
    if (this.motionList !== null && this.motionList !== undefined) {
      if (this.motionList.Votes !== null && this.motionList.Votes !== undefined) {
        this.motionVoteCount = this.motionList.Votes.length;
        passVotes = this.motionList.Votes.filter(v => v.Vote === true).length;
        failVotes = this.motionList.Votes.filter(v => v.Vote === false).length;
      }
      if (this.motionList.VoteStatus === null || this.motionList.VoteStatus === undefined) {   
        this.motionIcon = CommonConstant.MotionMovedIcon;
        if (this.motionList.Votes.length > 1)
          this.voteReceiveMsg = this.motionVoteCount + " Votes Received"
        else
          this.voteReceiveMsg = this.motionVoteCount + " Vote Received"
        // this.motionIcon = CommonConstant.MotionMovedIcon;
        // this.voteReceiveMsg = this.motionVoteCount + " Votes Received"
      }
      if (this.motionList.VoteStatus !== null && this.motionList.VoteStatus === this.VoteStatusEnum.Approved) {
        this.motionMsg = CommonConstant.MotionPassed;
        this.motionIcon = CommonConstant.MotionPassedIcon;
        this.voteReceiveMsg = "(" + passVotes + "-" + failVotes + ")"
      }
      if (this.motionList.VoteStatus !== null && this.motionList.VoteStatus === this.VoteStatusEnum.Denied) {
        this.motionMsg = CommonConstant.MotionFailed;
        this.motionIcon = CommonConstant.MotionFailedIcon;
        this.voteReceiveMsg = "(" + passVotes + "-" + failVotes + ")"
      }
    }
  }

  onClickReason(reasonType) {
    this.reasonType = reasonType;
    this.selectedActivityType = '';
    this.selectedReplyTo = '';
  }


  setBoardTaskDetails() {
    this.boardTaskStatus = this.boardTaskDetailList.BoardTaskStatus;
    if (this.boardTaskDetailList.IsComment === true) {
      this.isCommentAndReopen = false;
    }
    this.boardTaskApiService.caseId = this.boardTaskDetailList.CaseId;
  }


}

