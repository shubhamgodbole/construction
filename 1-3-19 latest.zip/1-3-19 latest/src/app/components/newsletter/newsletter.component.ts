import { Component, OnInit, ViewChild } from '@angular/core';
import { NewsletterApiService } from 'src/app/services/newsletter-api.service';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { NewsletterModel } from './newsletter.model';
import { AppConfig } from 'src/app/app.config';
import { UserData, EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { TypeOfDocument, RoleEnum, ImageNameEnums, DownloadfeatureName, FeatureName, NoDataFoundCaseFeatureName, SourceType, TriggerType, AudienceType, DocumentFeatureName, MasterPaginationEnum, Pagination, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { DisplayMonth, CommonConstant } from 'src/app/shared/common/constant.model';
import { MatDialogRef, MatDialog, MatSnackBar, MatPaginator } from '@angular/material';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { EmailNotificationService } from 'src/app/services/email-notification.service';

@Component({
  selector: 'app-newsletter',
  templateUrl: './newsletter.component.html',
  styleUrls: ['./newsletter.component.scss']
})
export class NewsletterComponent implements OnInit {

  //ImageNameEnums
  imageNameEnums = ImageNameEnums;

  //Preview the document
  fileURL: any;
  documentDetails: any;
  isDocumentDetails: boolean = false;


  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;


  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  notificationService: NotificationService;
  //Confirm Dialog
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  isApiResponseCome: boolean = false;
  domain: string;
  associationId: string;
  associationName: string;
  userName: string;
  role: string = "";
  userId: string;
  frmCreateNewletter: FormGroup;
  isEditMode: boolean = false;
  adddocument = false;
  newsletterList: any;
  monthNameDdl: any;
  resData: any;
  resDataCreate: any;
  fileFullName: any;
  url: string = "";
  pdfImageUrl: string;
  fileName: string;
  pdfvalidation: boolean = false;

  //For Filter data
  selectedMonthName: string = "All";
  filterNewsletterList: any;
  userData: UserData;
  isSubmitBtnDisabled: boolean = false;
  //base64textString = [];
  inputStreamString = "";
  isDeletePermision: boolean = false;
  isCreatePermision: boolean = false;
  isStatusShow: boolean = false;

  @ViewChild('formDirective') formDirective: FormGroupDirective;

  @ViewChild('displayfrom') displayfrom;
  open() {
    this.displayfrom.open();
  }

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;

  //For Send Notification
  featureName: any;
  featureId: any;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  //Set Association
  globalAssociationModel: GlobalAssociationModel;

  /*For server side paginaion */
  allCount: any;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;

  
  isApiResponceCome = false;

  constructor(private readonly formBuilder: FormBuilder,
    private _router: Router,
    public commonService: CommonService,
    private emailNotification: EmailNotificationService,
    private globalAssociationService: GlobalAssociationService,
    private _matDialog: MatDialog,
    private progressbarService: ProgeressBarService,
    private readonly snb: MatSnackBar,
    private newsletterApiService: NewsletterApiService, private readonly appConfig: AppConfig) {
    this.monthNameDdl = DisplayMonth.monthList;
    this.pdfImageUrl = "../../../../assets/images/" + this.imageNameEnums.pdfName;
    this.userData = this.appConfig.getCurrentUser();
    this.userData = appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.role = this.userData.Role;
    this.userData.Role !== RoleEnum.Member ? this.isStatusShow = true : this.isStatusShow = false
    this.notificationService = new NotificationService(snb);

    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Newsletter) {
          // feature.CanDelete ? this.isDeletePermision = true : this.isDeletePermision = false;
          //feature.CanCreate ? this.isCreatePermision = true : this.isCreatePermision = false;
          this.featureName = feature.Name;
          this.featureId = feature.FeatureId;
        }
      }
    );
    //this.getData();
  }

  ngOnInit() {
    this.setMasterOfPagination();
    if (this.role === RoleEnum.PropertyManager) {
      this._router.navigate([AppRouteUrl.mainPMNewslettersRouteUrl]);
    }
    this.createForm();
    // this.globalAssociationService.associationSubject.subscribe(res => {
    //   this.globalAssociationModel = res;
    //   if (res !== 1) {
    this.getData();
    //   }
    // });
  }

  getData() {

    let resDoumentCategory = this.selectedMonthName === "All" ? "" : this.selectedMonthName;
    this.progressbarService.show();
    this.newsletterApiService.getNewsletterDocument(this.associationId, this.domain, TypeOfDocument.NewsLetterDocuments, resDoumentCategory, this.role,
      this.pageSkip, this.pageTake).subscribe(res => {
        this.isApiResponceCome = true;
        this.isApiResponseCome = true;
        this.progressbarService.hide();
        this.resData = res;

        // if (this.role !== "" || this.role !== null && this.role !== undefined) {
        //   if (this.role === RoleEnum.Member) {
        //     let documents = this.resData.DocumentDetails.Documents;
        //     this.newsletterList = documents.filter(x => x.IsPublished);
        //     this.filterNewsletterList = documents.filter(x => x.IsPublished);
        //   } else {
        //     this.newsletterList = this.resData.DocumentDetails.Documents;
        //     this.filterNewsletterList = this.resData.DocumentDetails.Documents;

        //   }
        // } else {
        //   this.newsletterList = this.resData.DocumentDetails.Documents;
        //   this.filterNewsletterList = this.resData.DocumentDetails.Documents;
        // }

        this.newsletterList = this.resData.DocumentDetails.Documents;
        this.filterNewsletterList = this.resData.DocumentDetails.Documents;

        if (this.newsletterList !== null) {
          //For Pagination
          this.allCount = this.resData.DocumentCount;
          this.setPaginationData(this.filterNewsletterList)
          this.SetDetailsOfNextPreviousOnDetailsPage();
        }
      },
        (err) => {
          console.log(err);
        }
      )
  }

  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('NewsletterList');
    var temp: any = [];
    this.newsletterList.forEach(element => {
      temp.push({
        filePath: element.FilePath,
        documentId: element.id
      });
    });
    localStorage.setItem('NewsletterList', JSON.stringify(temp));
  }

  deleteNewsletter(documentId) {
    this.newsletterApiService.deleteNewsletter(documentId).subscribe(res => {
      this.resData = res;
      if (this.resData.Success === true) {
        this.selectedMonthName = "All";
        this.notificationService.showNotification("Newsletter deleted successfully");
        this.getData();
        this.sendNotification(this.featureId, documentId, TriggerType.Delete, AudienceType.BoardMember);
      }
    },
      (err) => {
        console.log(err);
      })
  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = valueObject.DocumentTitle;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteNewsletter(valueObject.id);
      }
    });
  }



  filterGetData() {
    // let filterNewsletter = this.filterNewsletterList;
    // if (this.selectedMonthName === "All") {
    //   this.newsletterList = filterNewsletter;
    // } else {
    //   this.newsletterList = filterNewsletter.filter(x => x.MonthName === this.selectedMonthName);
    // }

    //For Pagination
    this.setPaginationVariables();
    this.getData();
    //this.setPaginationData(this.newsletterList);
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }

  //For Pagination
  setPaginationData(documentLists) {
    this.TotalRecord = this.allCount;
    this.FilterArray = documentLists;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = documentLists.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageTake = clickObj.pageSize;
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getData();
    // var pageStartIndex = (clickObj.pageIndex * clickObj.pageSize) + 1;
    // var pageEndIndex = (clickObj.pageIndex * clickObj.pageSize) + clickObj.pageSize;
    // this.FilterArray = this.newsletterList.slice(pageStartIndex - 1, pageEndIndex);
    var elmnt: any = document.getElementById("contentTable");
    if (elmnt !== null) {
      elmnt.scrollTo(0, 0);
    }
  }

  onUploadChange(evt: any) {
    const file = evt.target.files[0];
    if (file !== undefined) {
      this.fileFullName = file;
      this.fileName = this.fileFullName.name;
      const reader = new FileReader();
      reader.onload = this.handleReaderLoaded.bind(this);
      reader.readAsBinaryString(file);
    }
    else {
      this.url = "";
      this.fileName = "";
      this.pdfvalidation = true;
    }
  }
  removeFile() {
    this.url = "";
    this.fileName = "";
    this.pdfvalidation = true;
  }
  handleReaderLoaded(e) {
    this.inputStreamString = 'data:image/png;base64,' + btoa(e.target.result);
    if (this.fileFullName.name.toLowerCase().substring(this.fileFullName.name.indexOf(".")) === ".pdf") {
      this.url = this.pdfImageUrl;
      this.pdfvalidation = false;
    }
    else {
      this.url = "";
      this.fileName = "";
      this.pdfvalidation = true;
    }
  }

  onSubmit(formDirective: FormGroupDirective) {
    if (this.isEditMode) {
      if (this.fileFullName === undefined || this.fileFullName === null || this.fileFullName === "") {
        this.pdfvalidation = true;
        return;
      }
    } else {
      if (this.fileFullName === undefined || this.fileFullName === null || this.fileFullName === ""
        || this.inputStreamString === undefined || this.inputStreamString === null || this.inputStreamString === "") {
        this.pdfvalidation = true;
        return;
      }
    }
    if (this.pdfvalidation === false) {
      if (this.frmCreateNewletter.valid) {
        this.isSubmitBtnDisabled = true;
        let model = this.createFormModel();
        if (this.isEditMode) {
          this.editData(model, formDirective);
        } else {
          this.saveData(model, formDirective);
        }
      }
    }

  }
  editData(model: any, formDirective: FormGroupDirective) {
    this.newsletterApiService.editNewsletter(model).subscribe(res => {
      this.isSubmitBtnDisabled = false;
      this.resDataCreate = res;
      if (this.resDataCreate.Success === true) {
        this.notificationService.showNotification("Newsletter updated successfully");
        this.selectedMonthName = "All"
        this.adddocument = false;
        this.getData();
        this.resetForm();
        this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Update, AudienceType.BoardMember);
      }
      else if (this.resDataCreate.Success === false) {
        this.notificationService.showNotification("Not Save");
      }
    });
  }

  saveData(model: any, formDirective: FormGroupDirective) {
    this.newsletterApiService.createNewsletter(model).subscribe(res => {
      this.isSubmitBtnDisabled = false;
      this.resDataCreate = res;
      if (this.resDataCreate.Success === true) {
        this.notificationService.showNotification("Newsletter saved successfully");
        this.selectedMonthName = "All";
        this.adddocument = false;
        this.getData();
        this.resetForm();
        this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Create, AudienceType.BoardMember);
        // this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Upload, AudienceType.BoardMember);
        // this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Publish, AudienceType.BoardMember);
      }
      else if (this.resDataCreate.Success === false) {
        this.notificationService.showNotification("Not Save");
      }
    });
  }

  createFormModel() {
    let isPublished;
    let currentDate = new Date();
    const publishDate = new Date(this.frmCreateNewletter.controls.publishDate.value);
    if (publishDate <= currentDate) {
      isPublished = true;
    } else {
      isPublished = false;
    }

    let inputStream = "";
    let name = "";
    let mediaType = "";
    if (this.inputStreamString !== "") {
      inputStream = this.inputStreamString;
      name = this.fileFullName.name.toLowerCase();
      mediaType = this.fileFullName.name.toLowerCase().substring(this.fileFullName.name.indexOf("."));
    }
    const model: NewsletterModel = {
      Domain: this.domain,
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.NewsLetterDocuments,
      RequestDocuments:
        [{
          documentId: this.frmCreateNewletter.controls.documentId.value,
          documentCategoryId: '',
          documentTitle: this.frmCreateNewletter.controls.newletterTitle.value,
          monthName: this.frmCreateNewletter.controls.monthName.value,
          associationDocumentCategoryId: '',
          publishDate: publishDate.toUTCString(),
          isPublished: isPublished,
          documentCategoryName: '',
          inputStream: inputStream,
          name: name,
          mediaType: mediaType,
          CreatedByUserId: this.userId,
          CreatedByUserName: this.userName,
          Years: '',
          AssociationName: this.associationName
        }]
    }
    return model;
  }

  adddocumentToggle() {
    if (this.adddocument)
      this.adddocument = false;
    else
      this.adddocument = true;
    this.resetForm();
  }

  createForm() {
    this.frmCreateNewletter = this.formBuilder.group({
      documentId: [''],
      newletterTitle: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      monthName: ['', Validators.required],
      publishDate: ['', Validators.required],
      attachment: ['']
    });
  }

  resetForm() {
    this.url = "";
    this.pdfvalidation = false;
    this.frmCreateNewletter.reset();
    this.formDirective.resetForm();
    this.fileFullName = "";
    this.fileName = "";
    this.isEditMode = false;
    this.isSubmitBtnDisabled = false;
    this.inputStreamString = "";
    //  this.selectedMonthName = "All";
  }

  editRow(newsletter: any) {
    this.isEditMode = true;
    this.adddocument = true;
    if (newsletter.FilePath !== "" && newsletter.FilePath !== null) {
      this.url = this.pdfImageUrl;
      this.fileName = newsletter.DocumentName;
      this.pdfvalidation = false;
      this.fileFullName = newsletter.FilePath;
    }
    this.frmCreateNewletter.controls.documentId.setValue(newsletter.id);
    this.frmCreateNewletter.controls.newletterTitle.setValue(newsletter.DocumentTitle);
    this.frmCreateNewletter.controls.publishDate.setValue(newsletter.PublishDate);
    this.frmCreateNewletter.controls.monthName.setValue(newsletter.MonthName);
  }

  // For Download Document
  downloadDocument(documentDetails) {
    let resData;
    this.commonService.getDownloadDocumentUrl(documentDetails.Domain, documentDetails.FilePath, DocumentFeatureName.Documents,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (documentDetails.FilePath)
                downloadLink.setAttribute('download', documentDetails.FilePath);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Can not download it");
        }
      });
  }


  //For Preview document
  previewDocument(docDetails) {
    this.isDocumentDetails = true;
    this.documentDetails = docDetails;
    this.isShowNextAndPreviewsButton();
    let resData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(docDetails.Domain, docDetails.FilePath, DocumentFeatureName.Documents,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Preview not Found");
        }
      });
  }


  PreviousDocument() {
    var current = this.documentDetails;
    var btAr = JSON.parse(localStorage.getItem('NewsletterList'));
    this.totalPages = btAr.length - 1;
    var el = btAr.find(a => { return a.documentId === current.id });
    var currentEl = btAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevFile = btAr[currentEl - 1].documentId;
      this.newsletterList.forEach((element: any) => {
        if (element.id === prevFile) {
          this.documentDetails = element;
          this.previewDocument(this.documentDetails);
        }
      });
    }
  }

  NextDocument() {
    var current = this.documentDetails;
    var btAr = JSON.parse(localStorage.getItem('NewsletterList'));
    this.totalPages = btAr.length - 1;
    var el = btAr.find(a => { return a.documentId === current.id });
    var currentEl = btAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < btAr.length) {
      let nextFile = btAr[currentEl + 1].documentId;
      this.newsletterList.forEach((element: any) => {
        if (element.id === nextFile) {
          this.documentDetails = element;
          this.previewDocument(this.documentDetails);
        }
      });
    }
  }


  isShowNextAndPreviewsButton() {
    let BTlocalStorageData = JSON.parse(localStorage.getItem('NewsletterList'));
    if (BTlocalStorageData === null || BTlocalStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.documentDetails;
      var btAr = JSON.parse(localStorage.getItem('NewsletterList'));
      this.totalPages = btAr.length - 1;
      var el = btAr.find(a => { return a.documentId === current.id });
      var currentEl = btAr.indexOf(el);
      this.currentPage = currentEl;
    }
  }

  // For Notification on CURD
  createNotificationModel(featureId, requestId, triggerType, audienceType) {
    var notificationModel = new Array<EmailNotificationModel>();
    notificationModel = [{
      FeatureId: featureId,
      FeatureName: FeatureName.Newsletter,
      CreatedBy: this.userId,
      SourceType: SourceType.Web,
      TriggerType: triggerType,
      PMCompanyAssociationMappingId: this.userData.UserAssociations[0].PMCompanyAssociationMappingId,
      AudienceType: audienceType,
      Url: "",
      RequestId: requestId,
      CustomAttribute: {
        Request: FeatureName.Newsletter,
        RequestSubType: audienceType
      }
    }];
    return notificationModel;
  }

  sendNotification(featureId, requestId, triggerType, audienceType) {
    //let emailNotificationModel = this.createNotificationModel("",response.RequestId);
    let emailNotificationModel = this.createNotificationModel(featureId, requestId, triggerType, audienceType);
    this.emailNotification.sendNotification(emailNotificationModel).subscribe(
      (emailresponse: any) => {
        if (emailresponse.Success) {
          //this.notificationService.showNotification('Notification Send SuccessFully');
        }
      }
    );
  }

  ngOnDestroy() {
    localStorage.removeItem('NewsletterList');
  }
}
