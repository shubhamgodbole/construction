
export class NewsletterModel{
    Domain :string;
    AssociationId:string;
    TypeOfDocument
    RequestDocuments :RequestNewsletterModel[];
}
export class RequestNewsletterModel{
    mediaType:string;
    monthName:string;
    name:string;
    documentId:string;
    inputStream: string;
    isPublished:boolean ;
    publishDate:string;
    documentTitle:string;
    documentCategoryId:string;
    associationDocumentCategoryId:string;
    documentCategoryName:string;
    CreatedByUserId:string;
    CreatedByUserName:string;
    Years:string;
    AssociationName:string;

}