import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewsletterRoutingModule } from './newsletter-routing.module';
import { MatInputModule, MatSelectModule, MatCheckboxModule, MatTooltipModule, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatPaginatorModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NewsletterComponent } from './newsletter.component';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';

@NgModule({
  imports: [
    NewsletterRoutingModule,
    CommonModule,
    SafeModule,
    NoDataFoundModule,
    MatInputModule,
    MatSelectModule,
    ReactiveFormsModule,
    FormsModule,
    MatPaginatorModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    HideIfUnauthorizedModule
  ],
  declarations: [NewsletterComponent ]
})
export class NewsletterModule { }
