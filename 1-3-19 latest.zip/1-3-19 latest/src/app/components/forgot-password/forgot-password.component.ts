import { Component, OnInit, ViewChild } from '@angular/core';
import { LoginApiService } from '../../services/login-api.service';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { FeatureName, SourceType, TriggerType, AudienceType } from 'src/app/shared/Enums/commonEnums';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar, MatDialog, MatDialogRef } from '@angular/material';
import { Title } from '@angular/platform-browser';
import { environment } from 'src/environments/environment';
import { CommonConstant } from 'src/app/shared/common/constant.model';
import { ThankYouComponent } from 'src/app/shared/component/thank-you/thank-you.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  
  email:any;
  forgotPasseordForm: FormGroup;
  notificationService: NotificationService;
  isButtonDisable: boolean = false;
  invalidEmailMsg: string = '';
  showInvalidMsg: boolean = false;
  thanksDialogRef: MatDialogRef<ThankYouComponent>;

  @ViewChild('formDirective') formDirective: FormGroupDirective;
  constructor(private service: LoginApiService,private formBuilder: FormBuilder,private readonly snb: MatSnackBar,
    private titleService: Title, private _matDialog: MatDialog, private router: Router,
    private emailNotification : EmailNotificationService) {
      this.notificationService = new NotificationService(snb); 
      this.titleService.setTitle(environment.mainTitle);
    }

  ngOnInit() {
    this.forgotPasseordForm = this.formBuilder.group({
      email: ['', [Validators.required,Validators.email]],
    });
  }


  forgotPassword() {
    if(this.forgotPasseordForm.invalid){
      return
    }
    this.invalidEmailMsg = '';
    this.showInvalidMsg = false;
    let event = this.forgotPasseordForm.controls.email.value;
    if (event) {
      this.isButtonDisable = true;
      this.service.forgotPassword(event).subscribe((response :any)=> {
        console.log(response);
        this.isButtonDisable = false;
        if(response.Success)
        {
          let message = { header: 'Thank You!', content: CommonConstant.forgetPasswordThankYouMsg, type: '' }
          this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
            width: '500px',
            disableClose: false
          });
          this.thanksDialogRef.componentInstance.data = message;
          this.thanksDialogRef.afterClosed().subscribe(result => {
            this.router.navigate(['/login']);
          });
          this.sendNotification('',response.RequestId,response.Token);
          this.resetForm();
        }
        else {
          this.showInvalidMsg = true;
          this.invalidEmailMsg = CommonConstant.InvalidEmail;
        }
      }, error => {

      })
    }

  }
  resetForm() {
    this.forgotPasseordForm.reset();
    this.formDirective.resetForm();
  }
  createNotificationModel(featureId,requestId,token) {
    
    var notificationModel = new Array<EmailNotificationModel>();
    notificationModel = [{
      FeatureId: featureId,
      FeatureName:FeatureName.ResetPassword,
      CreatedBy:"",
      SourceType:SourceType.Web,
      TriggerType:TriggerType.Create,
      PMCompanyAssociationMappingId:"",
      AudienceType:AudienceType.HomeOwner,
      Url:token,
      RequestId:requestId,
      CustomAttribute: {
        Request:FeatureName.ResetPassword,
      	RequestSubType:TriggerType.Create

      }
   }];
   return notificationModel;
  }

  sendNotification(featureId,requestId,token) {
    //let emailNotificationModel = this.createNotificationModel("",response.RequestId);
    let emailNotificationModel = this.createNotificationModel(featureId,requestId,token);
            this.emailNotification.sendNotification(emailNotificationModel).subscribe(
              (emailresponse:any) =>{
                if (emailresponse.Success) {
                  //this.notificationService.showNotification('Notification Send SuccessFully');
                 }
              }
            );
  }
}
