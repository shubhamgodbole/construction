import { Component, OnInit, ViewChild } from '@angular/core';
import { ViolationApiService } from 'src/app/services/violation-api.service';
import { FormBuilder } from '@angular/forms';
import { Router, NavigationExtras } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ViolationStatus, BmDisplayColumns } from '../violation.model';
import { fromEvent } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { TypeOfDocument, CaseTypeEnum, CustomerTypeEnum, SubCaseTypeEnum, NoDataFoundCaseFeatureName, MasterPaginationEnum, Pagination, DocumentFeatureName, requestSubTypeCount, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { MatPaginator } from '@angular/material';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { CommonService } from 'src/app/services/common.service';
import { FilterListValues, FeatureNameLocalStorage } from 'src/app/shared/common/models';

@Component({
  selector: 'app-bm-violation-list',
  templateUrl: './bm-violation-list.component.html',
  styleUrls: ['./bm-violation-list.component.scss']
})
export class BmViolationListComponent implements OnInit {
  userData: UserData;
  associationId: string;
  role: string;
  customerType = CustomerTypeEnum.Association;
  caseType = CaseTypeEnum.Homeowners;
  subCaseType = SubCaseTypeEnum.Violation;


  domain: string;
  typeOfDocument = TypeOfDocument.CaseDocuments;
  associationName: string;
  userId: string;
  /**Filter's Variables */
  //For filter by key word
  filterByKeyWords: string = "";
  @ViewChild('searchData') searchData: any;

  //for date filter
  dateTo: any;
  dateFrom: any;
  bsRangeValue: Date[] = [];

  violationList: any;
  violationStatusCount: any;
  filter = false;
  violationStatusEnum = ViolationStatus;
  status = "All";

  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  /**End For Manage Columns*/

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  isShowList: boolean = false;
  //for save data in localstorage
  localStorageFromDate;
  localStorageToDate;


  //For server side pagination
  allCount: any;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  isApiResponceCome = false;
  constructor(private violationApiService: ViolationApiService,
    private _router: Router,
    private readonly appConfig: AppConfig,
    public commonService: CommonService,
    private progressBarService: ProgeressBarService) {
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.role = this.userData.Role;
    this.userId = this.userData.UserProfileId;
    //get list count
    this.getListCount();
  }

  ngOnInit() {
    this.setMasterOfPagination();

    this.seletedColumns = BmDisplayColumns.AllColumnsList;
    this.displayColumnsDdl = BmDisplayColumns.AllSelectedColumnsList;
    this.defaultColumnsList = BmDisplayColumns.DefaultColumnsList;
    //get local storage filter data
    this.getLocalStorageData();
    //Filter By Key word
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.getData();
      });
    this.getData();
  }
  getLocalStorageData() {
    //get local storage filter data
    var data: FilterListValues = this.commonService.getFilterDataFromLocalStorge();
    if (data !== null && data !== undefined) {
      if (data.FeatureName === FeatureNameLocalStorage.ViolationBm) {
        this.status = data.Status;
        // this.selectedCaseCategory = data.Category;
        //this.selectedPriority = data.Priority;
        this.filterByKeyWords = data.SearchKey;
        this.dateFrom = data.DateFrom !== null && data.DateFrom !== undefined && data.DateFrom !== '' ? new Date(data.DateFrom).toUTCString() : '';
        this.dateTo = data.DateTo !== null && data.DateTo !== undefined && data.DateTo !== '' ? new Date(data.DateTo).toUTCString() : '';
        this.filter = data.Filter;

        if (this.dateFrom !== "" && this.dateFrom !== null && this.dateFrom !== undefined && this.dateTo !== "" && this.dateTo !== null && this.dateTo !== undefined) {
          this.bsRangeValue = [new Date(data.DateFrom), new Date(data.DateTo)];
        } else {
          this.bsRangeValue = [];
        }
      }
    }
    this.statusChange(this.status);
  }
  filterDataLocalstorage() {
    var filtersModel: FilterListValues = {
      SearchKey: this.filterByKeyWords,
      DateFrom: this.dateFrom,
      DateTo: this.dateTo,
      Category: "",
      Priority: "",
      AssignTo: "",
      Status: this.status,
      ViolationFieldType: "",
      Filter: this.filter,
      FeatureName: FeatureNameLocalStorage.ViolationBm
    }
    return filtersModel;
  }
  addClass() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  statusChange(s) {
    this.status = s;
    /**For Manage Columns*/
    if (this.violationStatusEnum.All === s) {
      this.seletedColumns = BmDisplayColumns.AllColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.AllSelectedColumnsList;
    } else if (this.violationStatusEnum.Opened === s) {
      this.seletedColumns = BmDisplayColumns.OpenColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.OpenSelectedColumnsList;
    } else if (this.violationStatusEnum.Contested === s) {
      this.seletedColumns = BmDisplayColumns.ContestedColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.ContestedSelectedColumnsList;
    } else if (this.violationStatusEnum.AwaitingDecision === s) {
      this.seletedColumns = BmDisplayColumns.AwaitingBoardDecisionColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.AwaitingBoardDecisionSelectedColumnsList;
    } else if (this.violationStatusEnum.LetterSent === s) {
      this.seletedColumns = BmDisplayColumns.LetterSentColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.LetterSentSelectedColumnsList;
    } else if (this.violationStatusEnum.ViolationResolved === s) {
      this.seletedColumns = BmDisplayColumns.ResolvedColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.ResolvedSelectedColumnsList;
    }
    /**End For Manage Columns*/
    this.setPaginationVariables();
    this.getData();
    //get list count
    this.getListCount();
  }

  getData() {
    let resData;
    this.isShowList = false;
    let resFilterByKeyWords = this.filterByKeyWords;
    let resStatus = this.status === "All" ? "" : this.status;
    this.progressBarService.show();
    this.violationApiService.getBmViolation(this.associationId, this.userId, resStatus, resFilterByKeyWords, this.dateTo, this.dateFrom, this.pageSkip, this.pageTake).subscribe(res => {
      resData = res;
      this.isApiResponceCome = true;
      this.progressBarService.hide();
      this.isShowList = true;
      console.log(res);
      if (resData.Success === true) {        
        this.violationList = resData.violationListResult.violationList;
        this.allCount = resData.violationListResult.ResultCount;
        console.log("this.allCount ",this.allCount );
        if (this.violationList !== null) {
          this.setPaginationData(this.violationList);
          this.SetDetailsOfNextPreviousOnDetailsPage();
        }
      }
      else {
        console.log("No data found");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  //for filter by date
  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.localStorageFromDate = event[0];
        this.dateTo = new Date(event[1]).toUTCString();
        this.localStorageToDate = event[1];
        this.getData();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getData();
    }
  }


  clearFilter() {
    this.filterByKeyWords = "";
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.getData();
  }

  getBmViolationDetails(detailId, caseId, status) {
    console.log("detailId :" + detailId + "caseId : " + caseId + "status : " + status);
    if (detailId !== "" && detailId !== null && status !== null) {
      this.violationApiService.violationDetailId = detailId;
      this.violationApiService.caseId = caseId;
      this.violationApiService.violationStatus = status;
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": detailId
        }
      };
      this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
      this._router.navigate([AppRouteUrl.mainViolationsDeatilBMRouteUrl], navigationExtras);
    }
  }

  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }

  //For Pagination
  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  setPaginationData(violationList) {
    this.TotalRecord = this.allCount;
    this.FilterArray = violationList;
    // this.TotalRecord = violationList.length;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = violationList.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize
    this.pageTake = clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getData();
    // var pageStartIndex = (clickObj.pageIndex * clickObj.pageSize) + 1;
    // var pageEndIndex = (clickObj.pageIndex * clickObj.pageSize) + clickObj.pageSize;
    // this.FilterArray = this.violationList.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Next Previous
  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('ViolationBM');
    var temp: any = [];
    this.violationList.forEach(element => {
      temp.push({
        id: element.id,
        caseid: element.CaseId,
        status: element.ViolationStatus
      });
    });
    localStorage.setItem('ViolationBM', JSON.stringify(temp));
  }

  //Get Address for list page
  getAssociationAddressForList(request) {
    var associationUnit = {
      AssociationUnitAddress1: request.ViolatedByAddress1,
      AssociationUnitAddress2: request.ViolatedByAddress2,
      AssociationUnitCity: request.ViolatedByCity,
      AssociationUnitState: request.ViolatedByState,
      AssociationUnitZip: request.ViolatedByZip
    }
    return this.commonService.getAssociationAddressForList(associationUnit);
  }

  //Get Count of list
  getListCount() {
    var model = this.commonService.getListModel(this.associationId, this.userId, this.role);
    let resData
    this.commonService.getListcount(model, DocumentFeatureName.Violation, requestSubTypeCount.Count).subscribe(res => {
      resData = res;
      if (resData.violationListResult.Success) {
        this.violationStatusCount = resData.violationListResult.StatusTypeCount;
      } else {
        this.violationStatusCount =  resData.violationListResult.StatusTypeCount;
      }
    });
  }

}

