import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ViolationApiService } from 'src/app/services/violation-api.service';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { CaseNoteModel, ViolationStatus, ContestVoteRequestModel, MotionModel } from '../violation.model';
import { TypeOfDocument, NoteType, CaseFeatureType, CaseOriginatingType, IsAuthorized, ImageNameEnums, DocumentFeatureName, DownloadfeatureName, CallType, ActivityType, StatusReason, VoteStatus, RoleEnum, PlaceHolderText, FeatureName, FeaturePermissions, EmailAudience } from 'src/app/shared/Enums/commonEnums';
import { MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Subscription } from 'rxjs';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { CommonService } from 'src/app/services/common.service';
import { Guid } from 'guid-typescript';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { CommonConstant } from 'src/app/shared/common/constant.model';
import { VoteModel } from '../../service-request/service-request.model';

@Component({
  selector: 'app-bm-violation-detail',
  templateUrl: './bm-violation-detail.component.html',
  styleUrls: ['./bm-violation-detail.component.scss']
})
export class BmViolationDetailComponent implements OnInit {
  propVivoName = CommonConstant.PropVivo;
  notificationService: NotificationService;
  userData: UserData;
  role: string;
  violationStatus: string = "";
  isApiResponseCome: boolean = false;
  bmViolationDetailList: any;
  unitAddress: string;
  limit: any = 160;
  documentList: any;

  userId: string;
  userName: string;
  associationId: string;
  associationName: string;
  domain: string;
  allCaseNoteList: any;
  decisionReason: any;
  boardMemberCaseNoteList: any;
  homeOwnerCaseNoteList: any;

  //view more document
  shoNDocs: any = 3;
  viewDocs: boolean = false;
  viwAllDocBtnMsg: string = "View All Attachments";

  //Confirm Dialog
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;

  /*Case Note Form For Board Member*/
  frmCreateBmCaseNote: FormGroup;
  fileData = [];
  isSubmitBtnDisabledBmCaseNote: boolean = false;
  resDataCreateBmCaseNote: any;
  @ViewChild('formDirectiveBmCaseNote') formDirectiveBmCaseNote: FormGroupDirective;
  fileDataBMCase = [];
  /*Case Note Form*/
  frmCreateHoCaseNote: FormGroup;
  isSubmitBtnDisabledHoCaseNote: boolean = false;
  resDataCreateHoCaseNote: any;
  @ViewChild('formDirectiveHoCaseNote') formDirectiveHoCaseNote: FormGroupDirective;
  fileDataHoCase = [];

  /*Case Note Form*/
  frmCreateIcCaseNote: FormGroup;
  isSubmitBtnDisabledIcCaseNote: boolean = false;
  @ViewChild('formDirectiveIcCaseNote') formDirectiveIcCaseNote: FormGroupDirective;
  fileDataICCase = [];
  querySubcription: Subscription;

  violationStatusEnum = ViolationStatus;

  //read more description
  readMoreDescBtnMsg: string = "Read More";
  readMoreBtn: boolean = false;
  //Enums
  isAuthorized = IsAuthorized;
  caseOriginatingType = CaseOriginatingType;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  //for Preview
  isDocumentDetails: boolean
  documentDetails
  fileURL

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;
  requestId: string;

  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;
  isEditBtnDisable: boolean;


  //for esclate vote
  pendingDecision: any;
  esclateVoteCount: number;
  isVote: boolean;
  esclateVoterList: any[];
  esclateResult: string;
  isDisplayEsclateVoteList: boolean = false;
  isDisplayEsclateVoteList1: boolean = false;



  //contest
  contest: any;
  contestLimit: number = 160;
  readMoreContestBtnMsg: string;
  profilePath: string;
  isContestVote: boolean;
  isDisplayVoteList: boolean = false;

  //replyTo
  selectedReplyTo: string;
  selectedConversionType: string = "All";
  callTypeEnum = CallType;
  activityTypeEnum = ActivityType;
  //static msg class
  placeHolderText = PlaceHolderText;
  //Enums
  noteTypeEnums = NoteType;
  statusReasonEnum = StatusReason;
  VoteStatusEnum = VoteStatus;
  roleTypeEnum = RoleEnum;
  caseNotes: any;
  allCaseNotes: any;
  motionLimit: number = 160;

  motionList: any = null;
  isMotionCreated: boolean;
  isMotionVote: boolean;
  motionVoteCount: number;
  /*Motion Form*/
  isDisplayMotionDiv: boolean = false;
  frmCreateMotion: FormGroup;
  isSubmitBtnDisabledMotion: boolean = false;
  resDataCreateMotion: any;
  @ViewChild('formDirectiveMotion') formDirectiveMotion: FormGroupDirective;
  @ViewChild('formDirective') formDirective: FormGroupDirective;
  isEditMode: boolean = false;
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  constructor(private violationApiService: ViolationApiService,
    private ngZone: NgZone,
    private _matDialog: MatDialog,
    private readonly formBuilder: FormBuilder,
    private readonly snb: MatSnackBar,
    private progressBarService: ProgeressBarService,
    public commonService: CommonService,
    private _location: Location,
    private route: ActivatedRoute,
    private _router: Router, private readonly appConfig: AppConfig) {
    this.createCaseNoteForm();
    this.createMotionForm();
    this.userData = this.appConfig.getCurrentUser();
    this.role = this.userData.Role;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.profilePath = this.userData.UserProfileBlobPath;
    this.notificationService = new NotificationService(snb);
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.requestId = id;
        this.violationApiService.violationDetailId = id;
        this.getData();
      }
      else {
        this._router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
  }
  getDiscription(form) {
    if (form === 'frmCreateHoCaseNote') {
      if (this.frmCreateHoCaseNote.controls.comments.value === ' ' || this.frmCreateHoCaseNote.controls.comments.value === '\n') {
        this.frmCreateHoCaseNote.controls.comments.setValue('');
      }
    }
    else if (form === 'frmCreateBmCaseNote') {
      if (this.frmCreateBmCaseNote.controls.comments.value === ' ' || this.frmCreateBmCaseNote.controls.comments.value === '\n') {
        this.frmCreateBmCaseNote.controls.comments.setValue('');
      }
    }
    else if (form === 'frmCreateIcCaseNote') {
      if (this.frmCreateIcCaseNote.controls.comments.value === ' ' || this.frmCreateIcCaseNote.controls.comments.value === '\n') {
        this.frmCreateIcCaseNote.controls.comments.setValue('');
      }
    }
    else if (form === 'frmCreateMotion') {
      if (this.frmCreateMotion.controls.comments.value === ' ' || this.frmCreateMotion.controls.comments.value === '\n') {
        this.frmCreateMotion.controls.comments.setValue('');
      }
    }
  }
  getData() {
    this.isDocumentDetails = false;
    this.progressBarService.show();
    let resData;
    this.contest = null;
    this.violationApiService.getViolationDetails(this.requestId, this.domain).subscribe(res => {
      this.progressBarService.hide();
      resData = res;
      this.isApiResponseCome = true;
      console.log(res);
      if (resData.Success === true) {
        this.bmViolationDetailList = resData.violationDetailResult.Violations;
        this.motionList = resData.Motion;
        this.documentList = resData.violationDetailResult.Document;
        if (resData.Contest !== null && resData.Contest !== undefined && resData.Contest !== '') {
          this.contest = resData.Contest;
        }
        this.setValue(resData.violationDetailResult.CaseNoteDetails);
        if (this.contest !== null) {
          if (this.contest.Votes !== null) {
            let voteByUser = this.contest.Votes.find(v => v.CreatedByUserId === this.userId);
            if (voteByUser) {
              this.isContestVote = voteByUser.Vote;
            }
          }
        }
        if (this.bmViolationDetailList !== null) {
          this.violationStatus = this.bmViolationDetailList.ViolationStatus;
          var associationUnit = {
            AssociationUnitNumber: this.bmViolationDetailList.ViolatedByUnitNumber,
            AssociationUnitAddress1: this.bmViolationDetailList.ViolatedByAddress1,
            AssociationUnitAddress2: this.bmViolationDetailList.ViolatedByAddress2,
            AssociationUnitCity: this.bmViolationDetailList.ViolatedByCity,
            AssociationUnitState: this.bmViolationDetailList.ViolatedByState,
            AssociationUnitZip: this.bmViolationDetailList.ViolatedByZip
          }
          this.unitAddress = this.commonService.getFullAssociationAddress(associationUnit);
          this.isShowNextAndPreviewsButton();
        }
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }


  setValue(caseNoteDetails) {

    this.allCaseNoteList = caseNoteDetails.filter(note => note.CaseNotes.NotesType !== NoteType.PropertyManager && note.CaseNotes.RoleType !== RoleEnum.PropertyManager);

    var activity = caseNoteDetails.filter(note => ((note.CaseNotes.ActivityType === ActivityType.Email && note.CaseNotes.EmailAudience !== EmailAudience.None) || note.CaseNotes.ActivityType === ActivityType.Phone && (note.CaseNotes.IsVotingRequired === false || note.CaseNotes.IsVotingRequired === null)));

    if (activity.length > 0) {
      this.allCaseNoteList = this.allCaseNoteList.concat(activity);
    }
    var assignToBoardAfterVote = caseNoteDetails.filter(note => (note.CaseNotes.ActivityType === ActivityType.AssignToBoard && note.CaseNotes.VoteStatus !== null));
    if (assignToBoardAfterVote.length > 0) {
      this.allCaseNoteList = this.allCaseNoteList.concat(assignToBoardAfterVote);
    }
    var assignToBoardData = caseNoteDetails.filter(note => (note.CaseNotes.ActivityType === ActivityType.AssignToBoard && note.CaseNotes.IsVotingRequired === false || ((note.CaseNotes.ActivityType === this.activityTypeEnum.Phone && note.CaseNotes.IsVotingRequired === false))));
    if (assignToBoardData.length > 0) {
      this.allCaseNoteList = this.allCaseNoteList.concat(assignToBoardData);
    }
    var reasons = caseNoteDetails.filter(note => note.CaseNotes.StatusReason !== null && note.CaseNotes.StatusReason !== '');
    if (reasons.length > 0) {
      this.allCaseNoteList = this.allCaseNoteList.concat(reasons);
    }
    var bmCaseNote = caseNoteDetails.filter(note => note.CaseNotes.NotesType === NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager || note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.BoardMember);
    if (bmCaseNote.length > 0) {
      this.allCaseNoteList = this.allCaseNoteList.concat(bmCaseNote);
    }

    this.allCaseNoteList.sort(function (a, b) {
      return +new Date(a.CreatedOrModifiedOn) - +new Date(b.CreatedOrModifiedOn);
    });

    // Add motion in to case note
    if (this.motionList.length > 0) {
      this.motionList.map(m => {
        var motion = this.commonService.convertMotionToCaseNote(m);
        caseNoteDetails.push(motion);
      });
    }
    // get motion with final status
    var motionCaseNoteWithStatus = caseNoteDetails.filter(m => {
      return m.CaseNotes.VoteStatus !== null && m.CaseNotes.DocumentType === 'Motion';
    });

    // get motion with not final status
    var motionCaseNoteWithNotStatus = caseNoteDetails.find(m => {
      return m.CaseNotes.VoteStatus === null && m.CaseNotes.DocumentType === 'Motion';
    });
    if (motionCaseNoteWithNotStatus !== null && motionCaseNoteWithNotStatus !== undefined) {
      this.isMotionCreated = true;
      if (motionCaseNoteWithNotStatus.CaseNotes.Votes.length > 0) {
        let voteByUser = motionCaseNoteWithNotStatus.CaseNotes.Votes.find(v => v.CreatedByUserId === this.userId);
        if (voteByUser) {
          this.isMotionVote = voteByUser.Vote;
        }
      }
    }

    //concat motion
    if (motionCaseNoteWithStatus.length > 0) {
      this.allCaseNoteList = this.allCaseNoteList.concat(motionCaseNoteWithStatus);
    }

    // // sort data with motion data
    this.allCaseNoteList.sort(function (a, b) {
      return +new Date(a.CreatedOrModifiedOn) - +new Date(b.CreatedOrModifiedOn);
    });


    //get before data
    var caseNoteBeforeVote = caseNoteDetails.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null || note.CaseNotes.DocumentType === "Motion" && note.CaseNotes.VoteStatus === null));

    if (caseNoteBeforeVote.length > 0) {
      caseNoteBeforeVote.sort(function (a, b) {
        return new Date(b.CreatedOrModifiedOn).getTime() - new Date(a.CreatedOrModifiedOn).getTime()
      });
      this.allCaseNoteList = caseNoteBeforeVote.concat(this.allCaseNoteList);
    }
    this.changeConversion();
    let pendingAction = caseNoteDetails.find(note => note.CaseNotes.IsAssignedToBoard == true || (note.CaseNotes.ActivityType === ActivityType.Phone && note.CaseNotes.IsVotingRequired === true));
    if (pendingAction !== null && pendingAction !== undefined) {
      this.pendingDecision = pendingAction.CaseNotes;
      if (this.pendingDecision.Votes !== null) {
        if (this.pendingDecision.Votes.length > 0) {
          this.esclateVoteCount = this.pendingDecision.Votes.length;
          this.esclateVoterList = this.pendingDecision.Votes;
          let voteByUser = this.pendingDecision.Votes.find(v => v.CreatedByUserId === this.userId);
          if (voteByUser) {
            this.isVote = voteByUser.Vote;
          }
        }
      }
    }
  }

  removeListValue() {
    this.allCaseNoteList = [];
    this.decisionReason = []
    this.boardMemberCaseNoteList = []
    this.homeOwnerCaseNoteList = []
  }

  /*Case Note Add Module*/

  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
     // var data = [];
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        if (this.selectedReplyTo === NoteType.Homeowner) {
          this.fileDataHoCase =  this.fileData;
        } else if (this.selectedReplyTo === NoteType.BoardMember) {
          this.fileDataBMCase =  this.fileData;
        } else if (this.selectedReplyTo === NoteType.PropertyManager) {
          this.fileDataICCase =  this.fileData;
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  removeImage(imageId) {
    if (this.selectedReplyTo === NoteType.Homeowner) {
      this.fileDataHoCase = this.fileDataHoCase.filter(a => a.imageId !== imageId);;
    } else if (this.selectedReplyTo === NoteType.BoardMember) {
      this.fileDataBMCase = this.fileDataBMCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.PropertyManager) {
      this.fileDataICCase = this.fileDataICCase.filter(a => a.imageId !== imageId);
    }
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  createCaseBmNoteFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataBMCase,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: this.frmCreateBmCaseNote.controls.caseNoteId.value,
        Note: this.frmCreateBmCaseNote.controls.comments.value,
        CaseId: this.bmViolationDetailList.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.BoardMember,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.Violation,
        RoleType: this.role
      }
    }
    return model;
  }

  createCaseHoNoteFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataHoCase,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: this.frmCreateHoCaseNote.controls.caseNoteId.value,
        Note: this.frmCreateHoCaseNote.controls.comments.value,
        CaseId: this.bmViolationDetailList.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.Homeowner,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.Violation,
        RoleType: this.role
      }
    }
    return model;
  }
  createCasePmNoteFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataICCase,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: this.frmCreateIcCaseNote.controls.caseNoteId.value,
        Note: this.frmCreateIcCaseNote.controls.comments.value,
        CaseId: this.bmViolationDetailList.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.PropertyManager,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.Violation,
        RoleType: this.role
      }
    }
    return model;
  }

  resetCaseNoteForm(noteType) {
    if (noteType === NoteType.BoardMember) {
      this.frmCreateBmCaseNote.reset();
      this.formDirectiveBmCaseNote.resetForm();
      this.isSubmitBtnDisabledBmCaseNote = false;
    }
    else if (noteType === NoteType.PropertyManager) {
      this.frmCreateIcCaseNote.reset();
      this.formDirectiveIcCaseNote.resetForm();
      this.isSubmitBtnDisabledIcCaseNote = false;
    }
    else {
      this.frmCreateHoCaseNote.reset();
      this.formDirectiveHoCaseNote.resetForm();
      this.isSubmitBtnDisabledHoCaseNote = false;
    }
    this.fileData = [];
    this.fileDataBMCase = [];
    this.fileDataHoCase = [];
    this.fileDataICCase = [];
    this.selectedReplyTo = "";
  }


  createCaseNoteForm() {
    /*BM Case Note */
    this.frmCreateBmCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
    /*HO Case Note */
    this.frmCreateHoCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
    /*IC Case Note */
    this.frmCreateIcCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitBmCaseNote() {
    let resData;
    if (this.frmCreateBmCaseNote.valid) {
      this.isSubmitBtnDisabledBmCaseNote = true;
      let model = this.createCaseBmNoteFormModel();
      this.violationApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledBmCaseNote = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          if (this.fileData.length > 0)
            this.getData();
          else {
            if (resData.caseRequestListResults !== null) {
              this.setValue(resData.caseRequestListResults[0].CaseNoteDetails);
            } else {
              this.removeListValue();
            }
          }
          this.resetCaseNoteForm(NoteType.BoardMember);
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  onSubmitHoCaseNote() {
    let resData;
    if (this.frmCreateHoCaseNote.valid) {
      this.isSubmitBtnDisabledHoCaseNote = true;
      let model = this.createCaseHoNoteFormModel();
      this.violationApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledBmCaseNote = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          if (this.fileData.length > 0)
            this.getData();
          else {
            if (resData.caseRequestListResults !== null) {
              this.setValue(resData.caseRequestListResults[0].CaseNoteDetails);
            } else {
              this.removeListValue();
            }
          }
          this.resetCaseNoteForm(NoteType.Homeowner);
        }
        else  {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }
  onSubmitIcCaseNote() {
    let resData;
    if (this.frmCreateIcCaseNote.valid) {
      this.isSubmitBtnDisabledIcCaseNote = true;
      let model = this.createCasePmNoteFormModel();
      this.violationApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledIcCaseNote = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          if (this.fileData.length > 0)
            this.getData();
          else {
            if (resData.CaseNoteDetails !== null) {
              this.setValue(resData.caseRequestListResults[0].CaseNoteDetails);
            } else {
              this.removeListValue();
            }
          }
          this.resetCaseNoteForm(NoteType.PropertyManager);
        }
        else  {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }
  toGoBack() {
    let page = localStorage.getItem("previousPage");
    if (page === AppRouteUrl.mainHoaMembersDetailRouteUrl) {
      this._location.back();
    } else {
      this._router.navigate([AppRouteUrl.mainViolationsBMRouteUrl]);
    }
    //this._router.navigate([AppRouteUrl.mainViolationsBMRouteUrl]);
  }

  //read more description
  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.limit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.readMoreDescBtnMsg = "Read Less";
      this.limit = this.bmViolationDetailList.Description.length;
    }
  }

  //download 
  downloadDocument(filename) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.Violation,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Document not found");
        }
      });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.FilePath,
      DocumentFeatureName.Violation, DownloadfeatureName.Download).subscribe(res => {
        resDoumentData = res;
        console.log('res ', res);
        if (resDoumentData.Success === true) {
          if (this.documentDetails.MediaType !== '.pdf') {
            this.fileURL = resDoumentData.DocumentPath;
          }
          else {
            this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
              (response) => {
                this.fileURL = URL.createObjectURL(response);
              }
            );
          }
        }
        else if (resDoumentData.Success === false) {
          this.notificationService.showNotification("Not get image");
        }
      });
  }

  //**Next AND Preview */
  PreviousCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('ViolationBM'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = ar[currentEl - 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getData();
    }
  }

  NextCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('ViolationBM'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < ar.length) {
      let prevIndex = ar[currentEl + 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getData();
    }
  }

  isShowNextAndPreviewsButton() {
    let localStorageData = JSON.parse(localStorage.getItem('ViolationBM'));
    if (localStorageData === null || localStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.requestId;
      var ar = JSON.parse(localStorage.getItem('ViolationBM'));
      this.totalPages = ar.length - 1;
      var el = ar.find(a => { return a.id === current });
      var currentEl = ar.indexOf(el);
      this.currentPage = currentEl;
    }
  }

  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.documentList.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }

  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
    this.isEditMode = true;
  }
  onchageCaseNot() {
    if (this.editComments === "") {
      this.isEditValidation = true;
      this.isEditBtnDisable = true;
    }
    else {
      this.isEditValidation = false;
      this.isEditBtnDisable = false;
    }
  }
  updateCaseNote(noteType) {
    // if (this.editComments === "") {
    //   this.isEditValidation = true;
    //   return;
    // }
    this.progressBarService.show();
    this.isEditValidation = false;
    this.isEditBtnDisable = true;
    this.isEditMode = false;
    let model = this.editCaseNoteModel(noteType);
    this.violationApiService.updateCaseNote(model).subscribe(res => {
      let resData;
      resData = res;
      this.progressBarService.hide();
      this.isEditBtnDisable = false;
      if (resData.Success === true) {
        this.resetEditCaseNote();
        this.setValue(resData.violationCaseNoteDetails);
        console.log("Case note updated successfully.");
      }
      else if (resData.Success === false) {
        this.notificationService.showNotification("Not update");
      }
    });
  }

  editCaseNoteModel(noteType) {
    const model: CaseNoteEditModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.bmViolationDetailList.id,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.bmViolationDetailList.CaseId,
        CreatedByUserId: this.userId,
        NotesType: noteType,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        RoleType: this.role

      }
    }
    return model;
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }
  /*Delete case note*/
  delete(id) {
    let resData;
    this.progressBarService.show();
    this.violationApiService.deleteCaseNote(id, this.bmViolationDetailList.CaseId, this.associationId, this.domain).subscribe(res => {
      resData = res;
      this.progressBarService.hide();
      if (resData.Success === true) {
        if (resData.violationCaseNoteDetails != null) {
          if (resData.violationCaseNoteDetails.length > 0) {
            this.setValue(resData.violationCaseNoteDetails);
          }
          else {
            this.removeListValue();
          }
        }
        else {
          this.removeListValue();
        }
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })

  }

  /**Create Contest Vote */
  createContestVote(voteStatus) {
    let model = this.createContestVoteModel(voteStatus);
    let resData;
    this.violationApiService.createContestVote(model).subscribe(res => {
      resData = res;
      console.log(res);

      if (resData.Success === true) {
        this.contest = resData.Contest;
        if (this.contest !== null) {
          if (this.contest.Votes !== null) {
            let voteByUser = this.contest.Votes.find(v => v.CreatedByUserId === this.userId);
            if (voteByUser) {
              this.isContestVote = voteByUser.Vote;
            }
            this.bmViolationDetailList = resData.Violations;
            if (this.bmViolationDetailList !== null) {
              this.violationStatus = this.bmViolationDetailList.ViolationStatus;
            }
            //this.getServiceRequestDetail();
          }
        }
      }
      else if (resData.Success === false) {
        console.log("error");
      }
    });
  }

  createContestVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: ContestVoteRequestModel = {
      CaseId: this.bmViolationDetailList.CaseId,
      AssociationId: this.associationId,
      Votes: {
        Vote: vote,
        CreatedByUserId: this.userId,
        CreatedByUserName: this.userName,
        ProfilePath: this.profilePath,
      },
      RequestId: this.bmViolationDetailList.id,
    }
    return model;
  }

  viewMoreContestDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreContestBtnMsg = "Read More";
      this.contestLimit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.readMoreContestBtnMsg = "Read Less";
      this.contestLimit = this.contest.Description.length;

    }
  }


  /*Display list of vote*/
  displayVoteListToggle() {
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }

  /*Display list of vote*/
  displayEsclateVoteListToggle() {
    if (this.isDisplayEsclateVoteList)
      this.isDisplayEsclateVoteList = false;
    else
      this.isDisplayEsclateVoteList = true;
  }

  /*Display list of vote*/
  displayVoteEscalateListToggle() {
    if (this.isDisplayEsclateVoteList1)
      this.isDisplayEsclateVoteList1 = false;
    else
      this.isDisplayEsclateVoteList1 = true;
  }


  //For Esclate Vote
  //  createEsclateVote(voteStatus) {
  //   let resData;
  //   let model = this.createEsclateVoteModel(voteStatus);
  //   this.violationApiService.createEsclateVote(this.bmViolationDetailList.CaseId, this.bmViolationDetailList.id, this.associationId, model).subscribe(res => {
  //     resData = res;
  //     if (resData.Success === true) {
  //       this.pendingDecision = resData.Esclate;
  //       this.bmViolationDetailList = resData.Violations;
  //     }
  //     else if (resData.Success === false) {
  //       console.log("error");
  //     }
  //   });
  // }
//For Vote
createEsclateVote(voteStatus, caseNoteId) {
 // this.progressbarService.show();
  let model = this.createEsclateVoteModel(voteStatus);
  this.violationApiService.createEsclateVote(this.bmViolationDetailList.CaseId, caseNoteId,this.bmViolationDetailList.id, this.associationId, model).subscribe(
    (response: any) => {
     // this.progressbarService.hide();
      if (response.Success) {
        this.pendingDecision = response.Esclate;
        this.esclateVoteCount = this.pendingDecision.Votes.length;
        this.esclateResult = this.pendingDecision.VoteStatus;
        this.bmViolationDetailList = response.Violations;
        this.getData();
        this.caseNotes = this.caseNotes.map((a) => {
          if (a.CaseNotes.id === this.pendingDecision.id) {
            a.CaseNotes = this.pendingDecision;
          }
          return a;
        });
        if (this.esclateVoteCount > 0) {
          this.esclateVoterList = this.pendingDecision.Votes;
          let voteByUser = this.pendingDecision.Votes.find(v => v.CreatedByUserId === this.userId);
          if (voteByUser) {
            this.isVote = voteByUser.Vote;
          }
        }
      }
    }
  );
}
  createEsclateVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: VoteModel = {
      Vote: vote,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      ProfilePath: this.profilePath,
      Remarks: ''
    }
    return model;
  }
  /*Create motion of Service Request */
  createMotionForm() {
    this.frmCreateMotion = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitMotion() {
    let resData;
    if (this.frmCreateMotion.valid) {
      this.isSubmitBtnDisabledMotion = true;
      let model = this.createMotionFormModel();
      this.resetMotionForm();
      this.violationApiService.createMotion(model, this.bmViolationDetailList.id).subscribe(res => {
        this.isSubmitBtnDisabledMotion = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          //this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.Motion, TriggerType.Create,
          //  AudienceType.BoardMember);
          this.getData();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createMotionFormModel() {
    const model: MotionModel = {
      MotionId: '',
      CaseId: this.bmViolationDetailList.CaseId,
      AssociationId: this.associationId,
      CaseFeatureType: CaseFeatureType.Violation,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      AssociationName: this.associationName,
      Description: this.frmCreateMotion.controls.comments.value,
      ProfilePath: this.profilePath
    }
    return model;
  }


  resetMotionForm() {
    this.frmCreateMotion.reset();
    if (this.formDirectiveMotion !== undefined) {
      this.formDirectiveMotion.resetForm();
    }
    this.isDisplayMotionDiv = false;
  }

  showMotionDiv() {
    this.resetMotionForm();
    this.selectedReplyTo = '';
    this.isDisplayMotionDiv = true;
  }

  /**Create Motion Vote */
  createMotionVote(voteStatus, id) {
    let model = this.createMotionVoteModel(voteStatus);
    let resData;
    this.progressBarService.show();
    this.violationApiService.createMotionVote(this.bmViolationDetailList.CaseId, id, this.associationId, model).subscribe(res => {
      this.progressBarService.hide();
      resData = res;
      console.log(res);
      if (resData.Success === true) {
        var motion = resData.Motions;
        var caseMotion: any = this.commonService.convertMotionToCaseNote(motion);
        var count = motion.Votes.length;
        this.caseNotes = this.caseNotes.map((a) => {
          if (a.CaseNotes.id === caseMotion.CaseNotes.id) {
            a.CaseNotes = caseMotion.CaseNotes;
          }
          return a;
        });
        if (count > 0) {
          var voterList = caseMotion.CaseNotes.Votes;
          let voteByUser = caseMotion.CaseNotes.Votes.find(v => v.CreatedByUserId === this.userId);
          if (voteByUser) {
            this.isMotionVote = voteByUser.Vote;
          }
        }
      }
      else {
        console.log("error");
      }
    });
  }

  createMotionVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: VoteModel = {
      Vote: vote,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      ProfilePath: this.profilePath,
      Remarks: ''
    }
    return model;
  }


  ngOnDestroy(): void {
    // Unsubscribe from localStorage
    localStorage.removeItem('ViolationBM');
    this.querySubcription.unsubscribe();
  }

  changeReplyTo() {
    this.isDisplayMotionDiv = false;
    this.frmCreateBmCaseNote.reset();
    this.frmCreateIcCaseNote.reset();
    this.frmCreateHoCaseNote.reset();
    this.fileDataBMCase = [];
    this.fileDataHoCase = [];
    this.fileDataICCase = [];
    this.fileData=[];
    let ele = document.getElementById('pv-detail');
    ele.scrollTo(0, 0);
  }

  //change conversion
  changeConversion() {
    if (this.selectedConversionType === "All") {
      this.caseNotes = this.allCaseNoteList;
    } else if (this.selectedConversionType === NoteType.Homeowner) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType == NoteType.Homeowner));
    } else if (this.selectedConversionType === NoteType.BoardMember) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType == NoteType.BoardMember);
    } else if (this.selectedConversionType === NoteType.PropertyManager) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.BoardMember && note.CaseNotes.IsAssignedToBoard === false) || (note.CaseNotes.NotesType == NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager && note.CaseNotes.IsAssignedToBoard === false));
    } else if (this.selectedConversionType === this.activityTypeEnum.Phone) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Phone && note.CaseNotes.IsVotingRequired !== true);
    } else if (this.selectedConversionType === this.activityTypeEnum.Email) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Email && note.CaseNotes.EmailAudience !== EmailAudience.None);
    } else if (this.selectedConversionType === this.activityTypeEnum.AssignToBoard) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.AssignToBoard || (note.CaseNotes.ActivityType === this.activityTypeEnum.Phone && note.CaseNotes.IsVotingRequired === true));
    }
  }
}
