import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatCheckboxModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatPaginatorModule, MatAutocompleteModule, MatTooltipModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HoViolationListComponent } from './ho-violation-list/ho-violation-list.component';
import { HoViolationDetailComponent } from './ho-violation-detail/ho-violation-detail.component';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { NoDataFoundComponent } from 'src/app/shared/component/no-data-found/no-data-found.component';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';

const routes: Routes = [
  {
    path: '',
    component: HoViolationListComponent
  },
  {
    path: AppRouteUrl.violationsDeatilHORouteUrl,
    component: HoViolationDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatCheckboxModule,
    NumberOnlyDirectiveModule,
    NoDataFoundModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatTooltipModule,
    SafeModule,
    NoCaseNoteFoundModule,
    MatButtonToggleModule,
    MatPaginatorModule,
    FormsModule,
    RouterModule.forChild(routes),
    BsDatepickerModule.forRoot(),
    HideIfUnauthorizedModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [RouterModule],
  declarations: [HoViolationListComponent, HoViolationDetailComponent]
})
export class HoViolationModule { }
