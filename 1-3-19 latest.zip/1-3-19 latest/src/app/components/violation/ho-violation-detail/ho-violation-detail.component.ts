import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { ViolationApiService } from 'src/app/services/violation-api.service';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { NoteType, TypeOfDocument, CaseFeatureType, ImageNameEnums, IsAuthorized, CaseOriginatingType, DownloadfeatureName, DocumentFeatureName, StatusReason, VoteStatus, RoleEnum, CallType, ActivityType, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { CaseNoteModel, ViolationStatus, ContestRequestModel } from '../violation.model';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Subscription } from 'rxjs';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { CommonService } from 'src/app/services/common.service';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { CommonConstant, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { Guid } from 'guid-typescript';

@Component({
  selector: 'app-ho-violation-detail',
  templateUrl: './ho-violation-detail.component.html',
  styleUrls: ['./ho-violation-detail.component.scss']
})
export class HoViolationDetailComponent implements OnInit {
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  notificationService: NotificationService;
  userData: UserData;
  role: string;
  violationStatus: string = "";
  isApiResponseCome: boolean = false;
  hoViolationDetailList: any;
  documentList: any;
  caseNoteList: any;
  decisionReason: any;
  userId: string;
  userName: string;
  profilePath: string;
  associationId: string;
  associationName: string;
  unitAddress: string;
  reportedByAddress: string;

  domain: string;
  /*Case Note Form*/
  frmCreateCaseNote: FormGroup;
  fileData = [];
  isSubmitBtnDisabledCaseNote: boolean = false;
  resDataCreateCaseNote: any;
  @ViewChild('formDirectiveCaseNote') formDirectiveCaseNote: FormGroupDirective;
  querySubcription: Subscription;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  //read more description
  readMoreDescBtnMsg: string = "Read More";
  readMoreBtn: boolean = false;
  limit: number = 160;

  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;
  isEditBtnDisable: boolean;

  //Confirm Dialog
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;

  //Enums
  isAuthorized = IsAuthorized;
  caseOriginatingType = CaseOriginatingType;
  violationStatusEnum = ViolationStatus;

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;
  requestId: string;

  //for Preview
  isDocumentDetails: boolean
  documentDetails
  fileURL

  statusReasonEnum = StatusReason;
  VoteStatusEnum = VoteStatus;
  roleTypeEnum = RoleEnum;
  callTypeEnum = CallType;
  activityTypeEnum = ActivityType;
  //display CaseNote
  homeOwnerCaseNoteList: any = [];
  allCaseNoteList: any = [];

  //view more document
  shoNDocs: any = 3;
  viewDocs: boolean = false;
  viwAllDocBtnMsg: string = "View All Attachments";

  /*Contest Form*/
  frmCreateContest: FormGroup;
  isSubmitBtnDisabledContest: boolean = false;
  @ViewChild('formDirectiveContest') formDirectiveContest: FormGroupDirective;
  contest: any;
  isContestVote: boolean = false;
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  constructor(private violationApiService: ViolationApiService,
    private ngZone: NgZone,
    private readonly formBuilder: FormBuilder,
    private readonly snb: MatSnackBar,
    public commonService: CommonService,
    private _matDialog: MatDialog,
    private route: ActivatedRoute,
    private progressBarService: ProgeressBarService,
    private _router: Router, private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.role = this.userData.Role;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.createCaseNoteForm();
    this.notificationService = new NotificationService(snb);
    this.profilePath = this.userData.UserProfileBlobPath;
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.requestId = id;
        this.violationApiService.violationDetailId = id;
        this.getData();
      }
      else {
        this._router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });

    this.createContestForm();
  }
  //assign to board text 
  assignToBoardText(caseNote) {
    if (caseNote) {
      if (caseNote.IsAssignedToBoard) {
        if (caseNote.Votes.length > 0 && caseNote.VoteStatus !== null) {
          return CommonConstant.BoardDecision
        } else if (caseNote.VoteStatus === null) {
          return CommonConstant.DecisionRequired
        }
      }
    }
  }

  getData() {
    let resData;
    this.progressBarService.show();
    this.isDocumentDetails = false;
    this.contest = null;
    this.violationApiService.getViolationDetails(this.requestId, this.domain).subscribe(res => {
      resData = res;
      this.isApiResponseCome = true;
      console.log('res ', res);
      this.progressBarService.hide();
      if (resData.Success === true) {
        this.hoViolationDetailList = resData.violationDetailResult.Violations;
        this.documentList = resData.violationDetailResult.Document;
        this.setValue(resData.violationDetailResult.CaseNoteDetails);
        if (resData.Contest !== null && resData.Contest !== undefined && resData.Contest !== '') {
          this.contest = resData.Contest;
        }
        if (this.contest !== null) {
          if (this.contest.Votes !== null) {
            let voteByUser = this.contest.Votes.find(v => v.CreatedByUserId === this.userId);
            if (voteByUser) {
              this.isContestVote = voteByUser.Vote;
            }
          }
        }
        if (this.hoViolationDetailList !== null) {
          this.violationStatus = this.hoViolationDetailList.ViolationStatus;
          var associationUnit = {
            AssociationUnitNumber: this.hoViolationDetailList.ViolatedByUnitNumber,
            AssociationUnitAddress1: this.hoViolationDetailList.ViolatedByAddress1,
            AssociationUnitAddress2: this.hoViolationDetailList.ViolatedByAddress2,
            AssociationUnitCity: this.hoViolationDetailList.ViolatedByCity,
            AssociationUnitState: this.hoViolationDetailList.ViolatedByState,
            AssociationUnitZip: this.hoViolationDetailList.ViolatedByZip
          }
          this.unitAddress = this.commonService.getFullAssociationAddress(associationUnit);
          var reportedByAddress = {
            AssociationUnitNumber: this.hoViolationDetailList.ReportedByUnitNumber,
            AssociationUnitAddress1: this.hoViolationDetailList.ReportedByUnitAddress1,
            AssociationUnitAddress2: this.hoViolationDetailList.ReportedByUnitAddress2,
            AssociationUnitCity: this.hoViolationDetailList.ReportedByUnitCity,
            AssociationUnitState: this.hoViolationDetailList.ReportedByUnitState,
            AssociationUnitZip: this.hoViolationDetailList.ReportedByUnitZip
          }
          this.reportedByAddress
            = this.commonService.getFullAssociationAddress(reportedByAddress);
          this.isShowNextAndPreviewsButton();
        }
      }
      else {
        this.notificationService.showNotification("Details Not Found");
        this._router.navigate([AppRouteUrl.mainViolationsHORouteUrl]);
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  setValue(caseNoteDetails) {
    this.homeOwnerCaseNoteList = caseNoteDetails.filter(note => note.CaseNotes.NotesType == NoteType.Homeowner);
    this.allCaseNoteList = this.homeOwnerCaseNoteList;
    this.decisionReason = caseNoteDetails.filter(note => note.CaseNotes.StatusReason !== null);
    if (this.decisionReason !== null && this.decisionReason !== undefined && this.decisionReason.length > 0) {
      this.allCaseNoteList = this.allCaseNoteList.concat(this.decisionReason);
    }
  }

  removeListValue() {
    this.homeOwnerCaseNoteList = [];
    this.allCaseNoteList = [];
    this.decisionReason = [];
  }

  /*Case Note Add Module*/
  createCaseNoteForm() {
    this.frmCreateCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  onSubmitCaseNote() {
    let resData;
    if (this.frmCreateCaseNote.valid) {
      this.isSubmitBtnDisabledCaseNote = true;
      let model = this.createCaseNoteFormModel();
      this.violationApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledCaseNote = false;
        resData = res;
        if (resData.Success === true) {
          if (this.fileData.length > 0)
            this.getData();
          else {
            if (resData.violationCaseNoteDetails !== null) {
              this.setValue(resData.violationCaseNoteDetails);
            } else {
              this.removeListValue();
            }
          }
          this.resetCaseNoteForm();
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  createCaseNoteFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: this.frmCreateCaseNote.controls.caseNoteId.value,
        Note: this.frmCreateCaseNote.controls.comments.value,
        CaseId: this.hoViolationDetailList.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.Homeowner,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.Violation,
        RoleType: this.role
      }
    }
    return model;
  }

  resetCaseNoteForm() {
    this.frmCreateCaseNote.reset();
    this.formDirectiveCaseNote.resetForm();
    this.isSubmitBtnDisabledCaseNote = false;
    this.fileData = [];
  }

  toGoBack() {
    this._router.navigate([AppRouteUrl.mainViolationsHORouteUrl]);
  }

  //read more description
  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.limit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.limit = this.hoViolationDetailList.Description.length;
      this.readMoreDescBtnMsg = "Read Less";
    }
  }

  //download 
  downloadDocument(filename) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.Violation,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Document not found");
        }
      });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.FilePath,
      DocumentFeatureName.Violation, DownloadfeatureName.Download).subscribe(res => {
        resDoumentData = res;
        console.log('res ', res);
        if (resDoumentData.Success === true) {
          if (this.documentDetails.MediaType !== '.pdf') {
            this.fileURL = resDoumentData.DocumentPath;
          }
          else {
            this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
              (response) => {
                this.fileURL = URL.createObjectURL(response);
              }
            );
          }
        }
        else if (resDoumentData.Success === false) {
          this.notificationService.showNotification("Not get image");
        }
      });
  }

  //**Next AND Preview */
  PreviousCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('ViolationHO'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = ar[currentEl - 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getData();
    }
  }

  NextCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('ViolationHO'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < ar.length) {
      let prevIndex = ar[currentEl + 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getData();
    }
  }

  isShowNextAndPreviewsButton() {
    let localStorageData = JSON.parse(localStorage.getItem('ViolationHO'));
    if (localStorageData === null || localStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.requestId;
      var ar = JSON.parse(localStorage.getItem('ViolationHO'));
      this.totalPages = ar.length - 1;
      var el = ar.find(a => { return a.id === current });
      var currentEl = ar.indexOf(el);
      this.currentPage = currentEl;
    }
  }

  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.documentList.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }

  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
  }

  updateCaseNote(noteType) {
    if (this.editComments === "") {
      this.isEditValidation = true;
      return;
    }
    this.isEditValidation = false;
    this.isEditBtnDisable = true;
    let model = this.editCaseNoteModel(noteType);
    this.violationApiService.updateCaseNote(model).subscribe(res => {
      let resData;
      resData = res;
      this.isEditBtnDisable = false;
      if (resData.Success === true) {
        this.resetEditCaseNote();
        this.setValue(resData.violationCaseNoteDetails);
        console.log("Case note updated successfully.");
      }
      else if (resData.Success === false) {
        this.notificationService.showNotification("Not update");
      }
    });
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
  }

  editCaseNoteModel(noteType) {
    const model: CaseNoteEditModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.hoViolationDetailList.id,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.hoViolationDetailList.CaseId,
        CreatedByUserId: this.userId,
        NotesType: noteType,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        RoleType: this.role

      }
    }
    return model;
  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }
  /*Delete case note*/
  delete(id) {
    let resData;
    this.violationApiService.deleteCaseNote(id, this.hoViolationDetailList.CaseId, this.associationId, this.domain).subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        if (resData.violationCaseNoteDetails != null) {
          if (resData.violationCaseNoteDetails.length > 0) {
            this.setValue(resData.violationCaseNoteDetails);
          }
          else {
            this.updateValue();
          }
        }
        else {
          this.updateValue();
        }
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })

  }

  updateValue() {
    this.allCaseNoteList = [];
    this.decisionReason = []
    this.homeOwnerCaseNoteList = []
  }

  /*Create Contest  */
  createContestForm() {
    this.frmCreateContest = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitContest() {
    let resData;
    if (this.frmCreateContest.valid) {
      this.isSubmitBtnDisabledContest = true;
      let model = this.createContestFormModel();
      this.violationApiService.createContest(model).subscribe(res => {
        this.isSubmitBtnDisabledContest = false;
        resData = res;
        if (resData.Success === true) {
          this.contest = resData.Contest;
          this.getData();
        }
        else if (resData.Success === false) {
          console.log("error");
        }
        this.resetContestForm();
      });
    }
  }

  createContestFormModel() {
    const model: ContestRequestModel = {
      Contest: {
        CaseId: this.hoViolationDetailList.CaseId,
        AssociationId: this.associationId,
        CaseFeatureType: CaseFeatureType.Contest,
        CreatedByUserId: this.userId,
        CreatedByUserName: this.userName,
        AssociationName: this.associationName,
        Description: this.frmCreateContest.controls.comments.value,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        SourceType: ""
      },
      RequestId: this.hoViolationDetailList.id,
    }
    return model;
  }



  checkIsContest() {
    var isEdit = (new Date().getTime() <= new Date(new Date(this.hoViolationDetailList.CreatedOn).setTime(new Date(this.hoViolationDetailList.CreatedOn).getTime() + (1 * 60 * 60 * 1000))).getTime());
    return isEdit;
  }



  resetContestForm() {
    this.frmCreateContest.reset();
    this.formDirectiveContest.resetForm();
    document.getElementById('closeModelCreateContest').click();
  }



  ngOnDestroy(): void {
    // Unsubscribe from localStorage
    localStorage.removeItem('ViolationHO');
    this.querySubcription.unsubscribe();
  }
}
