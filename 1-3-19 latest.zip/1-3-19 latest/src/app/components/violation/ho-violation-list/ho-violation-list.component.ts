import { Component, OnInit, ViewChild, DebugNode } from '@angular/core';
import { ViolationApiService } from 'src/app/services/violation-api.service';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ViolationStatus, DisplayViolationType, HoBYMeDisplayColumns, HoAgainstMeDisplayColumns, ViolationCase, Violation, FineStatus } from '../violation.model';
import { fromEvent, Subscription } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { CustomerTypeEnum, CaseTypeEnum, SubCaseTypeEnum, TypeOfDocument, NoDataFoundCaseFeatureName, ImageNameEnums, IsAuthorized, CaseOriginatingType, StatusReason, CasePriority, AudienceType, FeatureName, SourceType, TriggerType, MasterPaginationEnum, Pagination, DocumentFeatureName, requestSubTypeCount, RoleEnum, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { MatPaginator, MatAutocompleteTrigger, MatSnackBar } from '@angular/material';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CommonService } from 'src/app/services/common.service';
import { DropdownModelAssociationUnit, FilterListValues, FeatureNameLocalStorage } from 'src/app/shared/common/models';
import { Guid } from 'guid-typescript';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { debug } from 'util';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-ho-violation-list',
  templateUrl: './ho-violation-list.component.html',
  styleUrls: ['./ho-violation-list.component.scss']
})
export class HoViolationListComponent implements OnInit {
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  isShowList: boolean = false;
  // isApiResponseCome: boolean = false;
  userData: UserData;
  associationId: string;
  userName: string;
  associationUnitId: string;
  role: string;
  customerType = CustomerTypeEnum.Association;
  caseType = CaseTypeEnum.Homeowners;
  subCaseType = SubCaseTypeEnum.Violation
  domain: string;
  typeOfDocument = TypeOfDocument.CaseDocuments;
  associationName: string;
  userId: string;
  selectedViolationType = DisplayViolationType.violationTypeByMe;
  displayViolationType = DisplayViolationType;
  violationTypeDdl: any;
  /**Filter's Variables */
  //For filter by key word
  filterByKeyWords: string = "";
  @ViewChild('searchData') searchData: any;

  //for date filter
  dateTo: any;
  dateFrom: any;
  bsRangeValue: Date[] = [];


  // for Notification
  pmCompanyAssociationMappingId: string;
  featureId: string;


  violationList: any;
  violationStatusCount: any;
  filter = false;
  sidebar = false;

  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  violationStatusEnum = ViolationStatus;
  status: any = this.violationStatusEnum.All;

  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  displayColumnsDdlAgainstMe: any;
  seletedColumnsAgainstMe: any[];
  defaultColumnsListAgainstMe: any[];
  /**End For Manage Columns*/

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  //Create Violation
  frmCreateViolation: FormGroup;
  @ViewChild('violationFormDirective') violationFormDirective: FormGroupDirective;
  @ViewChild('violationDate') violationDate;
  isSubmitBtnDisabled: boolean;
  fileData = [];
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  //association unit drop down autocomplate
  associationUnitDdl: any[] = [];
  associationAutoCompleteUnitDdl: any[];
  /*Reset mat auto compelte*/
  @ViewChild('associationUnitAutoComplete', { read: MatAutocompleteTrigger })
  associationUnitTrigger: MatAutocompleteTrigger;
  notificationService: NotificationService;

  //For Query string;
  querySubcription: Subscription;

  companyCode: string;
  //for save data in localstorage
  localStorageFromDate;
  localStorageToDate;
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;


  //For server side pagination
  allCount: any;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;

  isApiResponceCome = false;

  constructor(private violationApiService: ViolationApiService,
    private readonly formBuilder: FormBuilder,
    private route: ActivatedRoute,
    public commonService: CommonService,
    private readonly snb: MatSnackBar,
    private progressbarService: ProgeressBarService,
    private emailNotification: EmailNotificationService,
    private _router: Router,
    private readonly appConfig: AppConfig) {
    this.violationTypeDdl = DisplayViolationType.ViolationTypeList;
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.userName = this.userData.UserName;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.associationUnitId = this.userData.UserUnits[0].UnitId;
    this.role = this.userData.Role;
    this.userId = this.userData.UserProfileId;
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    this.notificationService = new NotificationService(snb);
    //Notification
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Violations) {
          this.featureId = feature.FeatureId
        }
      });
  }


  ngOnInit() {
    this.setMasterOfPagination();
    /**For Manage Columns*/
    this.seletedColumns = HoBYMeDisplayColumns.AllColumnsList;
    this.seletedColumnsAgainstMe = HoAgainstMeDisplayColumns.AllColumnsList;
    this.displayColumnsDdl = HoBYMeDisplayColumns.AllSelectedColumnsList;
    this.displayColumnsDdlAgainstMe = HoAgainstMeDisplayColumns.AllSelectedColumnList;
    this.defaultColumnsList = HoBYMeDisplayColumns.DefaultColumnsList;
    this.displayColumnsDdlAgainstMe = HoAgainstMeDisplayColumns.AllSelectedColumnList;
    this.defaultColumnsListAgainstMe = HoAgainstMeDisplayColumns.DefaultColumnsList;
    /**End For Manage Columns*/

    //to open add dialog
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let isAdd = params["isAdd"];
      if (isAdd === "true") {
        this.sidebar = true;
      }
    });
    //get local storage filter data
    this.getLocalStorageData();
    //Filter By Key word
    this.createViolationForm();
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.getData();
      })
    this.getAssociationUnit();
  }

  changeVialationType() {
    this.filterDataLocalstorage();
    this.status = ViolationStatus.All;
    this.getData();
  }

  getLocalStorageData() {
    //get local storage filter data
    var data: FilterListValues = this.commonService.getFilterDataFromLocalStorge();
    if (data !== null && data !== undefined) {
      if (data.FeatureName === FeatureNameLocalStorage.ViolationHo) {
        this.status = data.Status;
        this.selectedViolationType = data.Category;
        //this.selectedPriority = data.Priority;
        this.filterByKeyWords = data.SearchKey;
        this.dateFrom = data.DateFrom !== null && data.DateFrom !== undefined && data.DateFrom !== '' ? new Date(data.DateFrom).toUTCString() : '';
        this.dateTo = data.DateTo !== null && data.DateTo !== undefined && data.DateTo !== '' ? new Date(data.DateTo).toUTCString() : '';
        this.filter = data.Filter;
        this.selectedViolationType = data.ViolationFieldType;
        if (this.dateFrom !== "" && this.dateFrom !== null && this.dateFrom !== undefined && this.dateTo !== "" && this.dateTo !== null && this.dateTo !== undefined) {
          this.bsRangeValue = [new Date(data.DateFrom), new Date(data.DateTo)];
        } else {
          this.bsRangeValue = [];
        }
      } else {
        this.status = this.violationStatusEnum.All;
      }
    } else {
      this.status = this.violationStatusEnum.All;
    }
    this.statusChange(this.status);
  }
  filterDataLocalstorage() {
    var filtersModel: FilterListValues = {
      SearchKey: this.filterByKeyWords,
      DateFrom: this.dateFrom,
      DateTo: this.dateTo,
      Category: this.selectedViolationType,
      Priority: "",
      AssignTo: "",
      Status: this.status,
      ViolationFieldType: this.selectedViolationType,
      Filter: this.filter,
      FeatureName: FeatureNameLocalStorage.ViolationHo
    }
    return filtersModel;
  }

  addClass() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  sidebarToggle() {
    if (this.sidebar)
      this.sidebar = false;
    else
      this.sidebar = true;
  }

  statusChange(s) {
    this.status = s;
    /**For Manage Columns*/
    if (this.violationStatusEnum.All === s) {
      this.seletedColumns = HoBYMeDisplayColumns.AllColumnsList;
      this.displayColumnsDdl = HoBYMeDisplayColumns.AllSelectedColumnsList;
    } else if (this.violationStatusEnum.Opened === s) {
      this.seletedColumns = HoBYMeDisplayColumns.OpenColumnsList;
      this.displayColumnsDdl = HoBYMeDisplayColumns.OpenSelectedColumnsList;
    } else if (this.violationStatusEnum.LetterSent === s) {
      this.seletedColumns = HoBYMeDisplayColumns.LetterSentColumnsList;
      this.displayColumnsDdl = HoBYMeDisplayColumns.LetterSentSelectedColumnsList;
    } else if (this.violationStatusEnum.ViolationResolved === s) {
      this.seletedColumns = HoBYMeDisplayColumns.ResolvedColumnsList;
      this.displayColumnsDdl = HoBYMeDisplayColumns.ResolvedSelectedColumnsList;
    }
    /**End For Manage Columns*/
    
    this.setPaginationVariables();   
    this.getData();
    this.getListCount();
    //get list count
  }

  statusChangeAgainstMe(s) {
    this.status = s;
    /**For Manage Columns*/
    if (this.violationStatusEnum.All === s) {
      this.seletedColumnsAgainstMe = HoAgainstMeDisplayColumns.AllColumnsList;
      this.displayColumnsDdlAgainstMe = HoAgainstMeDisplayColumns.AllSelectedColumnList;
    } else if (this.violationStatusEnum.Opened === s) {
      this.seletedColumnsAgainstMe = HoAgainstMeDisplayColumns.OpenColumnsList;
      this.displayColumnsDdlAgainstMe = HoAgainstMeDisplayColumns.OpenSelectedColumnList;
    } else if (this.violationStatusEnum.Contested === s) {
      this.seletedColumnsAgainstMe = HoAgainstMeDisplayColumns.ContestedColumnsList;
      this.displayColumnsDdlAgainstMe = HoAgainstMeDisplayColumns.ContestedSelectedColumnList;
    } else if (this.violationStatusEnum.ViolationResolved === s) {
      this.seletedColumnsAgainstMe = HoAgainstMeDisplayColumns.ResolvedColumnsList;
      this.displayColumnsDdlAgainstMe = HoAgainstMeDisplayColumns.ResolvedSelectedColumnList;
    }
    /**End For Manage Columns*/
    //get list count
    this.setPaginationVariables();    
    this.getData();
    this.getListCount();
  }

  getData() {
    let resData;
    let resViolationType = this.selectedViolationType;
    let resFilterByKeyWords = this.filterByKeyWords;
    let resStatus = this.status === "All" ? "" : this.status;
    this.violationList = [];
    this.TotalRecord = 0;
    this.violationStatusCount = null;
    this.progressbarService.show();
    this.isShowList = false;
    this.violationApiService.getHoViolation(this.associationId, this.userId, resStatus, resViolationType, resFilterByKeyWords, this.dateTo, this.dateFrom, this.pageSkip, this.pageTake).subscribe(res => {
      resData = res;
      this.isApiResponceCome = true;
      this.isShowList = true;
      this.progressbarService.hide();
      if (resData.Success === true) {
        this.violationList = resData.violationListResult.violationList;
        this.allCount = resData.violationListResult.ResultCount;
        if (this.violationList !== null) {
          this.setPaginationData(this.violationList);
          this.SetDetailsOfNextPreviousOnDetailsPage();
        }
      }
      else {
        console.log("No data found");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  //for filter by date
  geDatafilterByDateRange(event) {
    
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.localStorageFromDate = event[0];
        this.dateTo = new Date(event[1]).toUTCString();
        this.localStorageToDate = event[1];
        this.getData();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getData();
    }
  }


  clearFilter() {
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    this.filterByKeyWords = "";
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.getData();
  }

  getHoViolationDetails(detailId, caseId, status) {
    console.log("detailId :" + detailId + "caseId : " + caseId + "status : " + status);
    if (detailId !== "" && detailId !== null && status !== null) {
      this.violationApiService.violationDetailId = detailId;
      this.violationApiService.caseId = caseId;
      this.violationApiService.violationStatus = status;
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": detailId
        }
      };
      this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
      this._router.navigate([AppRouteUrl.mainViolationsDeatilHORouteUrl], navigationExtras);
    }

  }

  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Pagination
  setPaginationData(violationList) {
    this.TotalRecord = this.allCount;
    this.FilterArray = violationList;
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize
    this.pageTake = clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getData();
    this.getListCount();
  }

  //For Next Previous
  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('ViolationHO');
    var temp: any = [];
    this.violationList.forEach(element => {
      temp.push({
        id: element.id,
        caseid: element.CaseId,
        status: element.ViolationStatus
      });
    });
    localStorage.setItem('ViolationHO', JSON.stringify(temp));
  }

  createViolationForm() {
    this.frmCreateViolation = this.formBuilder.group({
      associationUnit: [''],
      title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      violationDate: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(1), ValidationService.noWhiteSpace]],
    });
    //this.getAllAssociationUnit();
  }

  //For Attachments
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
    console.log(this.fileData);
  }
  // remove uploaded Documents
  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }

  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  onSubmit() {
    if (!this.frmCreateViolation.valid) {
      return;
    }
    console.log(this.frmCreateViolation.value);
    this.isSubmitBtnDisabled = true;
    let CaseRequest = {
      Case: this.createRequestModel(),
      Violation: this.createCaseUnitModel(),
      TypeOfDocument: this.typeOfDocument,
      AssociationId: this.associationId,
      Domain: this.domain,
      Document: this.fileData,
    };
    this.isSubmitBtnDisabled = true;
    this.violationApiService.createViolation(CaseRequest).subscribe(
      (response: any) => {
        this.isSubmitBtnDisabled = false;
        if (response.Success == true) {
          this.reset();
          this.emailNotification.sendNotifications(this.featureId, response.RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Violations,
            TriggerType.Create,
            AudienceType.HomeOwner);
          this.getData();
          this.notificationService.showNotification("Violation saved Successfully");
        }
      });
  }

  // reset form
  reset() {
    this.frmCreateViolation.reset();
    this.violationFormDirective.resetForm();
    this.sidebar = false;
    this.fileData = [];
  }

  // Request Model
  createRequestModel() {
    let model: ViolationCase = {
      id: '',
      Title: this.frmCreateViolation.controls.title.value,
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      CaseType: this.caseType,
      CustomerTypeId: '',
      SubCaseType: this.subCaseType,
      CaseCategory: CaseTypeEnum.Violations,
      CaseSubCategory: CaseTypeEnum.Violations,
      CasePriority: CasePriority.Medium,
      Description: this.frmCreateViolation.controls.description.value,
      CustomerType: this.customerType,
      AssociationUnitId: this.userData.UserUnits !== null ? this.userData.UserUnits[0].UnitId : '',
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      CaseOriginatingType: CaseOriginatingType.Website,
      IsAuthorized: IsAuthorized.Yes,
      StatusReason: StatusReason.InProgress,
      UserProfileId: this.userId,
      CompanyCode: this.companyCode,
      CaseDocuments: null
    }
    return model;
  }
  // Case Unit Model
  createCaseUnitModel() {
    let model1: Violation = {
      id: "",
      ViolatedOn: new Date(this.frmCreateViolation.controls.violationDate.value).toISOString(),
      ViolatedByUnitNumber: this.frmCreateViolation.controls.associationUnit.value.CreatedByUnitNumber,
      ViolatedByAddress1: this.frmCreateViolation.controls.associationUnit.value.CreatedByUnitAddress1,
      ViolatedByAddress2: this.frmCreateViolation.controls.associationUnit.value.CreatedByUnitAddress2,
      ViolatedByCity: this.frmCreateViolation.controls.associationUnit.value.CreatedByUnitCity,
      ViolatedByState: this.frmCreateViolation.controls.associationUnit.value.CreatedByUnitState,
      ViolatedByZip: this.frmCreateViolation.controls.associationUnit.value.CreatedByUnitZip,
      ViolatedByAssociationUnitId: this.frmCreateViolation.controls.associationUnit.value.CreatedByUnitId,
      FineStatus: FineStatus.TobeDetermined,
      ViolationStatus: ViolationStatus.Opened,
      FineAmount: null,
      ReportedByUnitId: this.userData.UserUnits !== null ? this.userData.UserUnits[0].UnitId : '',
      ReportedByUserId: this.userId,
      ReportedByUserName: this.userName
    }
    return model1
  }



  //for clear association drop down
  //get associationUnit 
  getAssociationUnit() {
    let resData;
    this.violationApiService.getAssociationUnit(this.userId, this.associationId).subscribe(res => {
      resData = res;
      console.log('violation ', res);
      if (resData.Success === true) {
        if (resData.AssociationUnits !== null && resData.AssociationUnits !== undefined && resData.AssociationUnits.length > 0) {
          this.associationAutoCompleteUnitDdl = resData.AssociationUnits;
          this.associationAutoCompleteUnitDdl.map(associationUnit => {
            let unitAddress = this.commonService.getFullAssociationAddress(associationUnit);
            if (unitAddress !== null && unitAddress !== undefined) {
              let dropdownModelAssociationUnit = new DropdownModelAssociationUnit();
              dropdownModelAssociationUnit.CreatedByUnitAddress1 = associationUnit.AssociationUnitAddress1;
              dropdownModelAssociationUnit.CreatedByUnitAddress2 = associationUnit.AssociationUnitAddress2;
              dropdownModelAssociationUnit.CreatedByUnitCity = associationUnit.AssociationUnitCity;
              dropdownModelAssociationUnit.CreatedByUnitState = associationUnit.AssociationUnitState;
              dropdownModelAssociationUnit.CreatedByUnitId = associationUnit.id;
              dropdownModelAssociationUnit.CreatedByUnitZip = associationUnit.AssociationUnitZip;
              dropdownModelAssociationUnit.CreatedByUnitNumber = associationUnit.AssociationUnitNumber;
              dropdownModelAssociationUnit.Text = unitAddress;
              this.associationUnitDdl.push(dropdownModelAssociationUnit);
            }
          });
          this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
        }
      }
      else {
        console.log("No data found");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }


  /**Auto complete association Unit Display Function**/
  displayFnAutoCompleteUnit(associationUnit) {
    if (associationUnit != null) {
      return associationUnit.Text;
    } else return associationUnit;
  }

  /**Auto complete association Unit filter change**/
  onInputUnitChanged(searchStr: string): void {
    this.associationAutoCompleteUnitDdl = [];
    this.associationAutoCompleteUnitDdl = this.associationUnitDdl.filter(option =>
      option.Text.toLowerCase().includes(searchStr.toLowerCase()));
  }
  //for clear association Unit drop down
  onFocusOutUnit(searchStr) {
    if (this.associationUnitTrigger !== undefined) {
      this.associationUnitTrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
            this.frmCreateViolation.controls.associationUnit.setValue('');
            this.associationUnitTrigger.closePanel();
          }
        });
      this.associationAutoCompleteUnitDdl = this.associationUnitDdl.filter(option =>
        option.Text.toLowerCase().includes(searchStr.toLowerCase()));
      if (this.associationAutoCompleteUnitDdl.length === 0) {
        this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
        this.frmCreateViolation.controls.associationUnit.setValue('');
      }
    }
  }

  /*:Check Current Date*/
  getToday(): string {
    return new Date().toISOString().split('T')[0]
  }

  ngOnDestroy(): void {
    this.querySubcription.unsubscribe();
  }

  //Get Address for list page
  getAssociationAddressForList(request) {
    var associationUnit = {
      AssociationUnitAddress1: request.ViolatedByAddress1,
      AssociationUnitAddress2: request.ViolatedByAddress2,
      AssociationUnitCity: request.ViolatedByCity,
      AssociationUnitState: request.ViolatedByState,
      AssociationUnitZip: request.ViolatedByZip
    }
    return this.commonService.getAssociationAddressForList(associationUnit);
  }

  //Get Count of list
  getListCount() {    
    var model = this.commonService.getListModel(this.associationId, this.userId, RoleEnum.Member);
    let resData
    this.commonService.getListcount(model, DocumentFeatureName.Violation, requestSubTypeCount.Count).subscribe(res => {
      resData = res;
      console.log("resData HO violation", resData);
      if (resData.violationListResult.Success) {
        this.violationStatusCount = resData.violationListResult.StatusTypeCount;
      } else {
          this.violationStatusCount = resData.violationListResult.StatusTypeCount;
      }
    });
  }

}
