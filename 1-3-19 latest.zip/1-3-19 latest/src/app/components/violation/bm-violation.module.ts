import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatCheckboxModule, MatPaginatorModule, MatTooltipModule, MatButtonModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BmViolationListComponent } from './bm-violation-list/bm-violation-list.component';
import { BmViolationDetailComponent } from './bm-violation-detail/bm-violation-detail.component';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { NoCaseNoteFoundComponent } from 'src/app/shared/component/no-case-note-found/no-case-note-found.component';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';

const routes: Routes = [
  {
    path: '',
    component: BmViolationListComponent
  },
  {
    path: 'bm-violation-detail',
    component: BmViolationDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    NumberOnlyDirectiveModule,
    MatListModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatRadioModule,
    MatButtonModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    NoDataFoundModule,
    NoCaseNoteFoundModule,
    MatPaginatorModule,
    FormsModule,
    SafeModule,
    RouterModule.forChild(routes),
    BsDatepickerModule.forRoot(),
    HideIfUnauthorizedModule,
    FilterUniqueArrayModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [RouterModule],
  declarations: [BmViolationListComponent, BmViolationDetailComponent]
})
export class BmViolationModule { }
