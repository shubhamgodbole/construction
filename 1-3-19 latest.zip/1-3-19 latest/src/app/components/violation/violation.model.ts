export enum ViolationStatus {
    All = "All",
    Opened = "Opened",
    LetterSent = "LetterSent",
    ViolationResolved = "ViolationResolved",
    Cancelled = "Canceled",
    Contested = "Contested",
    AwaitingDecision = "AwaitingDecision"
}

export class CaseNoteModel {
    AssociationId: string;
    Domain: string;
    TypeOfDocument: string;
    Document: any[];
    CaseNotes: RequestCaseNoteModel;
}
export class RequestCaseNoteModel {
    CaseNoteId: string;
    Note: string;
    CreatedByUserId: string;
    CaseId: string;
    NotesType: string;
    CreatedByUserName: string;
    CaseFeatureType: string;
    RoleType: string;
}

export class ContestVoteRequestModel {
    CaseId: string;
    AssociationId: string;
    Votes: ContestVote;
    RequestId: string;
}

export class ContestVote {
    Vote: boolean;
    CreatedByUserId: string;
    CreatedByUserName: string;
    ProfilePath: string;
}



export class DisplayViolationType {
    public static ViolationTypeList = [
        { value: "ByMe", text: "By Me" },
        { value: "AgainstMe", text: "Against Me" }
    ];
    public static violationTypeByMe: string = "ByMe";
    public static violationTypeAgainstMe: string = "AgainstMe";
}

//Case Model for Violation
export class ViolationCase {
    id: string;
    AssociationId: string;
    AssociationName: string;
    AssociationUnitId: string;
    CaseOriginatingType: string;
    CaseType: string;
    SubCaseType: string;
    CasePriority: string;
    CustomerType: string;
    CaseCategory: string;
    CaseSubCategory: string;
    CustomerTypeId: string;
    Description: string;
    IsAuthorized: string;
    StatusReason: string;
    Title: string;
    UserProfileId: string;
    CreatedByUserId: string;
    CreatedByUserName: string;
    CompanyCode: string;
    CaseDocuments : string[];
};
export class Violation {
    id: string;
    ViolatedOn: string;
    ViolatedByUnitNumber: string;
    ViolatedByAddress1: string;
    ViolatedByAddress2: string;
    ViolatedByCity: string;
    ViolatedByState: string;
    ViolatedByZip: string;
    ViolatedByAssociationUnitId: string;
    FineStatus: string;
    ViolationStatus: string;
    FineAmount: string;
    ReportedByUnitId: string;
    ReportedByUserId: string;
    ReportedByUserName: string;
}

export class ContestRequestModel {
    Contest: Contest;
    RequestId: string;
}

export class Contest {
    CaseId: string;
    AssociationId: string;
    CaseFeatureType: string;
    CreatedByUserId: string;
    CreatedByUserName: string;
    AssociationName: string;
    Description: string;
    ProfilePath: string;
    RoleType: string;
    SourceType: string;
}

export enum SourceType {
    Email = "Email",
    Phone = "Phone"
}

export enum FineStatus {
    NoFine = "NoFine",
    FinePosted = "FinePosted",
    FineReceived = "FineReceived",
    FineWaived = "FineWaived",
    TobeDetermined = "TobeDetermined"
}

//Manage column for ho BYME
export class HoBYMeDisplayColumns {
    public static ColumnsList = [
        { value: "Status", text: "Status" },
        { value: "LetterSentOn", text: "Letter Sent On" },
        { value: "ResolvedOn", text: "Resolved On" },
        // { value: "Comments", text: "Comments" },
        { value: "ViolationDate", text: "Violation Date" },
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "VoilatorBy", text: "Voilator By" },
        { value: "CreatedOn", text: "Created On" },
    ]

    public static AllSelectedColumnsList = [
        { value: "ViolationDate", text: "Violation Date" },
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
    ]

    public static OpenSelectedColumnsList = [
        { value: "ViolationDate", text: "Violation Date" },
        // { value: "Comments", text: "Comments" },
    ]

    public static ResolvedSelectedColumnsList = [
        { value: "ResolvedOn", text: "Resolved On" },
    ]

    public static LetterSentSelectedColumnsList = [
        { value: "LetterSentOn", text: "Letter Sent On" },
    ]

    public static AllColumnsList = [
        "Title", "Voilator By", "Created On", "Violation Date", "Status", "Comments"
    ]

    public static OpenColumnsList = [
        "Title", "Voilator By", "Created On", "Violation Date", "Comments"
    ]

    public static ResolvedColumnsList = [
        "Title", "Voilator By", "Created On", "Resolved On"
    ]

    public static LetterSentColumnsList = [
        "Title", "Voilator By", "Created On", "Letter Sent On"
    ]
}


//Manage column for ho Against me
export class HoAgainstMeDisplayColumns {
    public static ColumnsList = [
        { value: "Status", text: "Status" },
        { value: "Attachments", text: "Attachments" },
        { value: "Contest", text: "Contest" },
        { value: "ResolvedOn", text: "Resolved On" },
        { value: "ContestedOn", text: "Contested On" }
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Occurrance", text: "Occurrance" },
        { value: "CreatedOn", text: "Created On" },
        { value: "Fine", text: "Fine" },
        { value: "Fine Status", text: "Fine Status" },
    ]

    public static AllSelectedColumnList = [
        { value: "Status", text: "Status" },
        { value: "Contest", text: "Contest" }
    ]

    public static OpenSelectedColumnList = [
        { value: "Attachments", text: "Attachments" },
        { value: "Contest", text: "Contest" }
    ]

    public static ResolvedSelectedColumnList = [
        { value: "ResolvedOn", text: "Resolved On" },
    ]

    public static ContestedSelectedColumnList = [
        { value: "ContestedOn", text: "Contested On" },
        { value: "ContestStatus", text: "Contest Status" }
    ]

    public static AllColumnsList = [
        "Title", "Occurrance", "Created On", "Fine", "Fine Status", "Status", "Contest"
    ]

    public static OpenColumnsList = [
        "Title", "Occurrance", "Created On", "Fine", "Fine Status", "Attachments", "Contest"
    ]

    public static ResolvedColumnsList = [
        "Title", "Occurrance", "Created On", "Fine", "Fine Status", "Resolved On"
    ]

    public static ContestedColumnsList = [
        "Title", "Occurrance", "Created On", "Fine", "Fine Status", "Contested On", "Contest Status"
    ]
}


//Manage column for BM
export class BmDisplayColumns {
    public static ColumnsList = [
        { value: "ReportedBy", text: "Reported By" },
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
        { value: "Actions", text: "Actions" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "ContestedOn", text: "Contested On" },
        { value: "PendingAction", text: "Pending Action" },
        { value: "Attachments", text: "Attachments" },
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "LotNumber", text: "Lot No." },
        { value: "VoilatorAddress", text: "Voilator Address" },
        { value: "CreatedOn", text: "Created On" },
        { value: "Fine", text: "Fine" },
        { value: "Fine Status", text: "Fine Status" },
        { value: "Occurrance", text: "Occurrance" },
    ]

    public static AllSelectedColumnsList = [
        { value: "ReportedBy", text: "Reported By" },
        { value: "Status", text: "Status" },
    ]

    public static OpenSelectedColumnsList = [
        { value: "ReportedBy", text: "Reported By" },
        // { value: "Comments", text: "Comments" },
    ]

    public static AwaitingBoardDecisionSelectedColumnsList = [
        { value: "Pending Action", text: "Pending Action" },
        { value: "ReportedBy", text: "Reported By" },
        // { value: "Comments", text: "Comments" },
    ]

    public static ResolvedSelectedColumnsList = [
        { value: "ReportedBy", text: "Reported By" },
        { value: "LastUpdatedOn", text: "Last Updated On"}
    ]

    public static  LetterSentSelectedColumnsList = [
        { value: "Attachment", text: "Attachment" }
    ]

    public static ContestedSelectedColumnsList = [
        { value: "Contested On", text: "Contested On" },
        { value: "Pending Action", text: "Pending Action"}
    ]

    public static AllColumnsList = [
        "Title", "Reported By", "Lot No.", "Voilator Address", "Created On", "Status", "Occurance", "Fine", "Fine Status"
    ]

    public static OpenColumnsList = [
        "Title", "Reported By", "Lot No.", "Voilator Address", "Created On", "Occurance", "Fine", "Fine Status", "Comments"
    ]

    public static AwaitingBoardDecisionColumnsList = [
        "Title", "Reported By", "Lot No.", "Voilator Address", "Created On", "Occurance", "Fine", "Fine Status", "Comments","Pending Action"
    ]

    public static ResolvedColumnsList = [
        "Title", "Reported By", "Lot No.", "Voilator Address", "Created On", "Last Updated On", "Occurance", "Fine", "Fine Status"
    ]

    public static ContestedColumnsList = [
        "Title", "Lot No.", "Voilator Address", "Created On", "Contested On", "Occurance", "Fine", "Fine Status", "Pending Action"
    ]

    public static LetterSentColumnsList = [
        "Title", "Lot No.", "Voilator Address", "Created On", "Occurance", "Fine", "Fine Status", "Attachment"
    ]
}


//Manage column for PM
export class DisplayColumnsPM {
    public static ColumnsList = [
        { value: "Status", text: "Status" },
        { value: "Occurance", text: "Occurance" },
        { value: "Fine", text: "Fine" },
        { value: "FineStatus", text: "Fine Status" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        // { value: "Comments", text: "Comments" },
        { value: "ContestReason", text: "Contest Reason" },
        { value: "ResolvedOn", text: "Resolved On" },
        { value: "ResolvedTime", text: "Resolved Time" },
        { value: "Attachments", text: "Attachments" }
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Association", text: "Association" },
        { value: "ReportedBy", text: "Reported By" },
        { value: "LotNo", text: "Lot No." },
        { value: "VoilatorAddress", text: "Voilator Address" },
        { value: "Created On", text: "Created On" },
        { value: "Assign To", text: "Assign To" },
    ]

    public static AllSelectedColumnsList = [
        { value: "Status", text: "Status" },
        { value: "Occurance", text: "Occurance" },
        { value: "Fine", text: "Fine" },
        { value: "FineStatus", text: "Fine Status" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "Assign To", text: "Assign To" },
    ]

    public static OpenSelectedColumnsList = [
        { value: "Occurance", text: "Occurance" },
        { value: "Fine", text: "Fine" },
        { value: "FineStatus", text: "Fine Status" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "Assign To", text: "Assign To" },

        // { value: "Comments", text: "Comments" }
    ]

    public static AwaitingBoardDecisionSelectedColumnsList = [
        { value: "Occurance", text: "Occurance" },
        { value: "Fine", text: "Fine" },
        { value: "FineStatus", text: "Fine Status" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "Assign To", text: "Assign To" },
        // { value: "Comments", text: "Comments" }
    ]

    public static ResolvedSelectedColumnsList = [
        { value: "ResolvedOn", text: "Resolved On" },
      //  { value: "ResolvedTime", text: "Resolved Time" },
        { value: "Assign To", text: "Assign To" }
    ]

    public static ContestedSelectedColumnsList = [
        { value: "Occurance", text: "Occurance" },
        { value: "Fine", text: "Fine" },
        { value: "FineStatus", text: "Fine Status" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "ContestReason", text: "Contest Reason" },
        { value: "Assign To", text: "Assign To" }
        // { value: "Comments", text: "Comments" }
    ]

    public static LetterSentSelectedColumnsList = [
        { value: "Occurance", text: "Occurance" },
        { value: "Fine", text: "Fine" },
        { value: "LetterSentOn", text: "LetterSentOn" },
        { value: "Attachments", text: "Attachments" }
    ]


    public static AllColumnsList = [
        "Title", "Association", "Reported By", "Lot No.", "Voilator Address", "Assign To",
        "Created On", "Status", "Occurance", "Fine", "Fine Status", "Time Elapsed"
    ]

    public static OpenColumnsList = [
        "Title", "Association", "Reported By", "Lot No.", "Voilator Address",
        "Created On", "Assign To", "Occurance", "Fine", "Fine Status", "Time Elapsed", "Comments"
    ]

    public static AwaitingBoardDecisionColumnsList = [
        "Title", "Association", "Reported By", "Lot No.", "Voilator Address",
        "Created On", "Assign To", "Occurance", "Fine", "Fine Status", "Time Elapsed", "Comments"]

    public static ResolvedColumnsList = [
        "Title", "Association", "Reported By", "Lot No.", "Voilator Address",
        "Created On", "Assign To", " Resolved On", "Resolved Time"
    ]

    public static ContestedColumnsList = [
        "Title", "Association", "Reported By", "Lot No.", "Voilator Address",
        "Created On", "Assign To", "Occurance", "Fine", "Fine Status", "Time Elapsed", "Contest Reason", "Comments"]

    public static LetterSentColumnsList = [
        "Title", "Association", "Reported By", "Lot No.", "Voilator Address",
        "Created On", "Occurance", "Fine", "Letter Sent On", "Attachments"]
}

export class CallModel {
    RequestId: string;
    CaseNotes: {
        CallType: string;
        CallNumber: string;
        CallerName: string;
        IsShowCallConversation: boolean;
        IsVotingRequired: boolean;
        CallDuration: string;
        PhoneCallRecord: string;
        CaseNoteId: string;
        Note: string;
        CreatedByUserId: string;
        CaseId: string;
        NotesType: string;
        CreatedByUserName: string;
        CaseFeatureType: string;
        ProfilePath: string;
        RoleType: string;
        StatusReason: string;
        ActivityType: string;
    }
}

export class EmailModel {
    RequestId: string;
    AssociationId: string;
    TypeOfDocument: string;
    Document: any;
    Domain: string;
    CaseNotes: {
        To: string;
        CC: string;
        BCC: string;
        Message: string;
        Subject: string;
        CaseNoteId: string;
        Note: string;
        CreatedByUserId: string;
        CaseId: string;
        NotesType: string;
        CreatedByUserName: string;
        CaseFeatureType: string;
        ProfilePath: string;
        RoleType: string;
        StatusReason: string;
        ActivityType: string;
        EmailAudience: string;
    }
}


// Assign to model
export class AssignToModel {
    RequestId: string;
    CaseId: string;
    Case: {
        AssignedTo: string;
        ModifiedByUserId: string;
        ModifiedByUserName: string;
    }
}

export class MotionModel {
    MotionId: string;
    CaseId: string;
    AssociationId: string;
    AssociationName: string;
    CreatedByUserId: string;
    CreatedByUserName: string;
    Description: string;
    CaseFeatureType: string;
    ProfilePath: string;
}


