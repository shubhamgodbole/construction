import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss']
})
export class ErrorComponent implements OnInit {
  constructor(private _location: Location ) {

  }
  toGoBack() {
    if (window.location.pathname === AppRouteUrl.errorRouteUrl) {
      window.history.go(-2);
    }else{
      this._location.back();
    }
  }
  ngOnInit() {
  }

}
