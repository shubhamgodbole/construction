import { Component, OnInit, ChangeDetectionStrategy, ViewChild, TemplateRef } from '@angular/core';
import { startOfDay, endOfDay, subDays, addDays, endOfMonth, isSameDay, isSameMonth, addHours } from 'date-fns';
import { Subject } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CalendarEvent, CalendarEventAction, CalendarEventTimesChangedEvent, CalendarView } from 'angular-calendar';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar } from '@angular/material';
import { CalendarService } from 'src/app/services/calendar.service';
import { EventType } from './calendar.model';
import { Router } from '@angular/router';
import { RoleEnum, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-calendar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})
export class CalendarComponent implements OnInit {

  @ViewChild('modalContent')
  modalContent: TemplateRef<any>;
  @ViewChild('modalContentView')
  modalContentView: TemplateRef<any>;
  view: CalendarView = CalendarView.Month;
  CalendarView = CalendarView;
  viewDate: Date = new Date();
  updateEventData: any;
  modalData: {
    action: string;
    event: CalendarEvent;
  };
  actions: CalendarEventAction[] = [
    {
      label: '<i class="fa fa-fw fa-pencil" data-toggle="modal" data-target="#CreateEventModals"></i>',
      onClick: ({ event }: { event }): void => {
        this.handleEvent('Edited', event);
        this.updateEventData = event;
        this.editEventForm.controls.eventName.setValue(event.title);
        this.editEventForm.controls.eventType.setValue(event.type);
        this.editEventForm.controls.location.setValue(event.location);
        this.editEventForm.controls.detail.setValue(event.detail);
        this.editEventForm.controls.startDate.setValue(event.start);
        this.editEventForm.controls.endDate.setValue(event.end);
        this.editEventForm.controls.member.setValue(event.member);
        this.editEventForm.controls.color.setValue(event.color.primary);
      }
    },
    // {
    //   label: '<i class="fa fa-fw fa-times" ></i>',
    //   onClick: ({ event }: { event: CalendarEvent }): void => {
    //     this.events = this.events.filter(iEvent => iEvent !== event);
    //     if (confirm("Are you sure to delete ?")) {
    //      // this.handleEvent('Deleted', event);
    //     }
    //   }
    // }
  ];
  refresh: Subject<any> = new Subject();
  evt = [
    {
      startDate: '01/17/2019',
      endDate: '01/19/2019',
      title: 'A1'
    },
    {
      startDate: '01/18/2019',
      endDate: '01/19/2019',
      title: 'A2'
    },
    {
      startDate: '01/25/2019',
      endDate: '02/25/2019',
      title: 'A3'
    },
    {
      startDate: '02/2/2019',
      endDate: '02/19/2019',
      title: 'A4'
    },
    {
      startDate: '03/17/2019',
      endDate: '03/19/2019',
      title: 'A5'
    },
  ];
  events: any = [];
  activeDayIsOpen: boolean = false;
  // user clame
  notificationService: NotificationService;
  userData: UserData;
  associationId: string;
  associationName: string;
  domain: string;
  userId: string;
  userName: string;
  userRole: string;
  userProfile: string;

  // multiselect dropdown
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  isComponentLoad: boolean = false;
  // add Event
  addEventForm: FormGroup;
  @ViewChild('addEventDirective') addEventDirective: FormGroupDirective;
  // Edit Event
  editEventForm: FormGroup;
  @ViewChild('editEventDirective') editEventDirective: FormGroupDirective;
  minDate: Date = new Date();
  maxDate: Date;
  editminDate: Date;
  editmaxDate: Date;
  eventType: any = EventType.Types;
  isMemberDataNull: boolean = false;
  currentEvent:any;
  isAddEventButton: boolean = false;
  isEditEventButton: boolean = false;
  roleEnum:any = RoleEnum;
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  constructor(private modal: NgbModal, private formBuilder: FormBuilder, private readonly appConfig: AppConfig,
    private readonly snb: MatSnackBar,
    private router : Router,
    public commonService: CommonService,
    private service: CalendarService) {
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userRole = this.userData.Role;
  }

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
   
    if (isSameMonth(date, this.viewDate)) {
      this.viewDate = date;
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
    }
  }

  eventTimesChanged({
    event,
    newStart,
    newEnd
  }: CalendarEventTimesChangedEvent): void {
    event.start = newStart;
    event.end = newEnd;
    this.handleEvent('Dropped or resized', event);
    this.refresh.next();
  }

  handleEvent(action: string, event: any): void {
  
    if(action === "Clicked") {
      if(event.type === this.eventType[2].value) {
       // this.router.navigate(['']);
      }
      this.modalData = { event, action };
      this.modal.open(this.modalContentView);
    }
    else {
      this.modalData = { event, action };
      this.modal.open(this.modalContent);
    }
  }
  changeSDate() {
    this.minDate = this.addEventForm.controls.startDate.value;
  }
  changeEDate() {
    this.maxDate = this.addEventForm.controls.endDate.value;
  }
  ngOnInit() {
    this.addEventForm = this.formBuilder.group({
      eventType: ['', [Validators.required,Validators.maxLength(50), ValidationService.noWhiteSpace]],
      eventName: ['', [Validators.required, Validators.maxLength(50), ValidationService.noWhiteSpace]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      location: ['', [Validators.required, Validators.maxLength(50), ValidationService.noWhiteSpace]],
      // eventNotification: ['', [Validators.required]],
      detail: ['', [Validators.required, Validators.maxLength(1000), ValidationService.noWhiteSpace]],
      member: ['', [Validators.required]],
      color: [''],
    });
    this.editEventForm = this.formBuilder.group({
      eventType: ['', [Validators.required,Validators.maxLength(50), ValidationService.noWhiteSpace]],
      eventName: ['', [Validators.required, Validators.maxLength(50), ValidationService.noWhiteSpace]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      location: ['', [Validators.required, Validators.maxLength(50), ValidationService.noWhiteSpace]],
      // eventNotification: ['', [Validators.required]],
      detail: ['', [Validators.required, Validators.maxLength(1000), ValidationService.noWhiteSpace]],
      member: ['', [Validators.required]],
      color: [''],
    });
    this.setEventData();
  
    this.selectedItems = [
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'UserProfileId',
      textField: 'UserName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
    this.getMemberData();
  }
  onItemSelect(item: any) {
    // console.log(item);
    this.isMemberDataNull =false;
  }
  onSelectAll(items: any) {
    // console.log(items);
    this.isMemberDataNull =false;
  }
  nextMonth() {
    //  console.log(this.viewDate);
    this.setEventData();
  }
  previousMonth() {
    //  console.log(this.viewDate);
    this.setEventData();
  }
  getMemberData() {
    this.service.getMembers(this.associationId).subscribe(
      (response:any) => {
        if(response.Success) {
          this.dropdownList = response.UserProfiles;
        }
      }
    );
  }
  setEventData() {

    var date = this.viewDate;
    //date.setMonth(4);
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    this.service.getEventList(this.associationId, firstDay, lastDay).subscribe(
      (response: any) => {
        if (response.Success) {
          this.events = [];
          console.log(response.EventsList);
          response.EventsList.forEach((e) => {
            var act;
            var colors: any ;
            var showForHo : boolean = true;
            // set action
            if(e.EventType !== this.eventType[2].value && e.CreatedByUserId === this.userId) {
              act = this.actions;
            }
            else {
              act = '';
            }
            // set color
            if(e.EventTagColor !== null) {
              colors = {
                red: {
                  primary: e.EventTagColor
                },
              }
            }
            else {
              colors = {
                yellow: {
                  primary: '#e3bc08',
                  secondary: '#FDF1BA'
                }
              }
            } 
            // check user role is member & MeetingAudienceType true (board only) then hide event from ho
            if(this.userRole === this.roleEnum.Member && e.EventType === this.eventType[2].value && (e.MeetingAudienceType === null || e.MeetingAudienceType === true)) {
              showForHo =false;
            }
           else {
              this.events.push({
                id: e.id,
                associationId: e.AssociationId,
                title: e.EventName,
                start: new Date(e.EventStartTime),
                end: new Date(e.EventEndTime),
                type: e.EventType,
                location: e.Location,
                detail: e.Description,
                category: e.EventCategory,
                member: e.InvitedMembers,
                color: e.EventType === this.eventType[2].value ? colors.yellow : colors.red,
                actions: act,
                MeetingAudienceType : e.MeetingAudienceType
              });
            }
           
          });
          this.isComponentLoad = true;
          setTimeout(() => {
            //this.setEventData();
            console.log('evt',this.events);
            document.getElementById('comp_load').click();
          }, 100);
        }
      }
    );
    //  this.evt.forEach((e)=>{
    //   this.events.push({
    //     start: new Date(e.startDate),
    //     end: new Date(e.endDate),
    //     title: e.title,
    //     color: colors.blue,
    //     actions: this.actions
    //   });
    // });
  }
  // Add Event Model
  addEventModel() {
    let model = {
      AssociationId: this.associationId,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      EventName: this.addEventForm.controls.eventName.value,
      EventStartTime: this.addEventForm.controls.startDate.value,
      EventEndTime: this.addEventForm.controls.endDate.value,
      Location: this.addEventForm.controls.location.value,
      Description: this.addEventForm.controls.detail.value,
      EventType: this.addEventForm.controls.eventType.value,
      InvitedMembers: this.addEventForm.controls.member.value,
      EventTagColor:this.addEventForm.controls.color.value ? this.addEventForm.controls.color.value : '#000000',
      // notification: this.addEventForm.controls.eventNotification.value,
      EventCategory: "Association",
      CreatedOn: new Date(),
    }
    return model;
  }
  addNewEvent() {
    let model = this.addEventModel();
    if(model.InvitedMembers === null || model.InvitedMembers.length === 0) {
      this.isMemberDataNull =true;
    }
    if (this.addEventForm.valid) {
      this.isAddEventButton =true;
      this.service.addEvent(this.domain, model).subscribe(
        (response:any) => {
          if (response.Success) {
          this.resetEventForm();
          this.notificationService.showNotification('Event is created successfully');
          this.setEventData();
          }
        }
      );
      // console.log(model);
    }
    else {
        console.log('invalidForm');
    }
  }
  // Reset Add Event Form
  resetEventForm() {
    this.addEventForm.reset();
    this.addEventDirective.resetForm();
    document.getElementById('CreateEventModal').click();
    this.isMemberDataNull =false;
    this.isAddEventButton =false;
    this.minDate = null;
    this.maxDate = null;
  }
  updateEventModel() {
    let model = {
      id: this.updateEventData.id,
      AssociationId: this.updateEventData.associationId,
      EventName: this.editEventForm.controls.eventName.value,
      EventStartTime: this.editEventForm.controls.startDate.value,
      EventEndTime: this.editEventForm.controls.endDate.value,
      Location: this.editEventForm.controls.location.value,
      Description: this.editEventForm.controls.detail.value,
      EventType: this.editEventForm.controls.eventType.value,
      InvitedMembers: this.editEventForm.controls.member.value,
      EventTagColor:this.editEventForm.controls.color.value,
      // notification: this.editEventForm.controls.eventNotification.value,
      EventCategory: "Association",
    }
    return model;
  }
  updateEvent() {
    let model = this.updateEventModel();
    if(model.InvitedMembers === null || model.InvitedMembers.length === 0) {
      this.isMemberDataNull =true;
    }
    if (this.editEventForm.valid) {
      this.isEditEventButton =true;
      this.service.updateEvent(this.domain, model).subscribe(
        (response:any) => {
          if (response.Success) {
            this.resetEditEventForm();
            this.notificationService.showNotification('Event is update successfully');
            this.setEventData();
          }
        }
      );
       // console.log(model);
    }
    else {
      console.log('invalidForm');
    }
  }
  // Reset Add Event Form
  resetEditEventForm() {
    //this.editEventForm.reset();
   // this.editEventDirective.resetForm();
    document.getElementById('editEventModal').click();
    this.isMemberDataNull =false;
    this.isEditEventButton =false;
  
  }
}
