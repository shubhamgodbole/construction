import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatChipsModule, MatIconModule, MatAutocompleteModule, MatTooltipModule } from '@angular/material';
import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CalendarComponent } from './calendar.component';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';

const routes: Routes = [
  {
    path: '',
    component: CalendarComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatDatepickerModule,
    MatDatetimepickerModule,
    NumberOnlyDirectiveModule,
    ReactiveFormsModule,
    FormsModule,
    MatSelectModule,
    MatChipsModule,
    MatIconModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatRadioModule,
    NgMultiSelectDropDownModule.forRoot(),
    RouterModule.forChild(routes),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory
    }),
    HideIfUnauthorizedModule,
  ],
  declarations: [CalendarComponent]
})
export class AssociationCalendarModule { }
