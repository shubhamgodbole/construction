
export class EventType {
    public static Types = [
        { value: "Birthday", text: "Birthday" },
        { value: "Meetup", text: "Meetup" },
        { value: "Meeting", text: "Meeting" }
        
    ]
}