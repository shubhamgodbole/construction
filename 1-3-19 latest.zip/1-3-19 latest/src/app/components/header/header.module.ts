import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header.component';
import { MatIconModule, MatInputModule, MatSelectModule, MatCheckboxModule, MatFormFieldModule, MatButtonModule, MatMenuModule, MatSidenavModule, MatTooltipModule, MatProgressSpinnerModule } from '@angular/material';
import { RouterModule } from '@angular/router';
import { GlobalAssociationModule } from 'src/app/shared/component/global-association/global-association.module';
import { CookieService } from 'ngx-cookie-service';
import { TourModule } from 'src/app/shared/component/tour/tour.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DisplayTimeElapsedModule } from 'src/app/shared/modules/display-time-elapsed.module';
import { HighlightModule } from 'src/app/shared/pipes/highlight/highlight.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';

@NgModule({
  imports: [
    CommonModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,    
    RouterModule,
    MatButtonModule,
    MatTooltipModule,
    GlobalAssociationModule,
    MatFormFieldModule,
    MatMenuModule,
    DisplayTimeElapsedModule,
    FormsModule,
    TourModule,
    MatSidenavModule,
    HighlightModule,
    MatProgressSpinnerModule,
    HideIfUnauthorizedModule,
    ReactiveFormsModule,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [HeaderComponent],
  exports: [HeaderComponent],
  providers: [ CookieService ],
})
export class HeaderModule { }
