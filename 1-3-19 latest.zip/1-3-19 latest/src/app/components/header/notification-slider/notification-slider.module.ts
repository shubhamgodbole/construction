import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationSliderComponent } from './notification-slider.component';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatPaginatorModule, MatTooltipModule, MatCheckboxModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    NoCaseNoteFoundModule,
    NoDataFoundModule,
    SafeModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatPaginatorModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    FormsModule,
  ],
  exports: [NotificationSliderComponent],
  declarations: [NotificationSliderComponent]
})
export class NotificationSliderModule { }
