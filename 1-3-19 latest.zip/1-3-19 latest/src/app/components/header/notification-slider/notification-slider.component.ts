import { Component, OnInit } from '@angular/core';
import { FeatureName, RoleEnum, CaseFeatureType } from 'src/app/shared/Enums/commonEnums';
import { NavigationExtras, Router } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { AppConfig } from 'src/app/app.config';
import { CommonService } from 'src/app/services/common.service';
import { MemberHistoryService } from 'src/app/services/member-history.service';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { NotificationSliderService } from 'src/app/services/notification-slider.service';
import { MatSnackBar } from '@angular/material';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';

@Component({
  selector: 'app-notification-slider',
  templateUrl: './notification-slider.component.html',
  styleUrls: ['./notification-slider.component.scss']
})
export class NotificationSliderComponent implements OnInit {

  
  //notification slider
  Notification = false;
  pmCompanyAssociationMappingId: string;
  notificationList: any = [];
  associationNotification: any = [];
  myNotification: any = [];
  caseFeatureTypeEnum = CaseFeatureType;
  featureNameEnum = FeatureName;
  userId
  role
  userData
  NotifyFilter

  constructor(private readonly appConfig: AppConfig,
    public commonService: CommonService,
    private memberHistoryService: MemberHistoryService,
    private globalAssociationService: GlobalAssociationService,
    private notificationSliderService: NotificationSliderService,
    private readonly snb: MatSnackBar,
    private router: Router,
    private hoaDirectoryApiService: HoaDirectoryApiService) {
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData !== null) {
     
      this.userId = this.userData.UserProfileId;
      this.role = this.userData.Role;
     
    }
  }
  ngOnInit() {
  }

   //notification slider toggle
   NotificationToggle() {
    if (this.Notification) {
      this.Notification = false;
    }
    else {
      this.Notification = true;
    }
  }

  // get all Notification 
  getAllNotificaton() {
    this.notificationList = [];
    let pmCompanyAssociationMappingId;
    if (this.role === RoleEnum.PropertyManager) {
      //pmCompanyAssociationMappingId = this.globalAssociationModel.PMCompanyAssociationMappingId;
    } else {
      pmCompanyAssociationMappingId = this.pmCompanyAssociationMappingId;
    }
    let resData;
    this.notificationSliderService.getNotifications(pmCompanyAssociationMappingId).subscribe(res => {
      console.log('NotificationDetails ', res);
      resData = res;
      if (resData.Success) {
        this.notificationList = resData.ProcessedNotifications.filter(n => {
          if (n.FeatureName !== null) {
            return n;
          }
        });

        this.notificationList.sort((val1, val2) => {
          return new Date(val2.SentDate).getTime() - new Date(val1.SentDate).getTime()
        });

        this.getMyNotification();
        this.getAssociationNotification();
      }
    });
  }

  goToAllNotificationList() {
    this.router.navigate([AppRouteUrl.mainNotificationRouteUrl]);
    this.NotificationToggle();
  }

  changeStatus(s) {
    this.getAssociationNotification();
    if (s === CaseFeatureType.ServiceRequest) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Service_Request || n.FeatureName === FeatureName.ServiceRequest
      });
    } else if (s === CaseFeatureType.Meeting) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Meetings
      });
    } else if (s === CaseFeatureType.Motion) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Motion
      });
    } else if (s === CaseFeatureType.ARCRequest) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.ARCRequests || n.FeatureName === FeatureName.ARC
      });
    }
    else if (s === CaseFeatureType.Violation) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Violations
      });
    } else if (s === CaseFeatureType.BoardTask) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Board_Task
      });
    }
  }

  // statusChangeMyNotification(s) {
  //   this.getMyNotification();
  //   if (s === CaseFeatureType.ServiceRequest) {
  //     this.myNotification = this.myNotification.filter(n => {
  //       return n.FeatureName === FeatureName.Service_Request || n.FeatureName === FeatureName.ServiceRequest
  //     });
  //   } else if (s === CaseFeatureType.Meeting) {
  //     this.myNotification = this.myNotification.filter(n => {
  //       return n.FeatureName === FeatureName.Meetings
  //     });
  //   } else if (s === CaseFeatureType.Motion) {
  //     this.myNotification = this.myNotification.filter(n => {
  //       return n.FeatureName === FeatureName.Motion
  //     });
  //   } else if (s === CaseFeatureType.ARCRequest) {
  //     this.myNotification = this.myNotification.filter(n => {
  //       return n.FeatureName === FeatureName.ARCRequests || n.FeatureName === FeatureName.ARC
  //     });
  //   }
  //   else if (s === CaseFeatureType.Violation) {
  //     this.myNotification = this.myNotification.filter(n => {
  //       return n.FeatureName === FeatureName.Violations
  //     });
  //   } else if (s === CaseFeatureType.BoardTask) {
  //     this.myNotification = this.myNotification.filter(n => {
  //       return n.FeatureName === FeatureName.Board_Task
  //     });
  //   }
  // }

  getAssociationNotification() {
    this.associationNotification = this.notificationList.filter(n => {
      return n.UserProfileId !== this.userId;
    });
  }

  getMyNotification() {
    this.myNotification = this.notificationList.filter(n => {
      return n.UserProfileId === this.userId;
    });
  }

  goToDetailPage(notification) {
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": notification.NotificationAction.ActionParams[0].Parameter
      }
    };
    if (this.role === RoleEnum.PropertyManager) {
      if (notification.FeatureName === FeatureName.Service_Request || notification.FeatureName === FeatureName.ServiceRequest) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Violations) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Board_Task) {
        this.router.navigate([AppRouteUrl.mainBoardTasksDeatilPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.ARC || notification.FeatureName === FeatureName.ARCRequests) {
        this.router.navigate([AppRouteUrl.mainArcDetailPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Meetings) {
        this.router.navigate([AppRouteUrl.mainMeetingPMRouteUrl], navigationExtras)
      }
    }
    if (this.role === RoleEnum.BoardMember) {
      if (notification.FeatureName === FeatureName.Service_Request || notification.FeatureName === FeatureName.ServiceRequest) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Violations) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Board_Task) {
        this.router.navigate([AppRouteUrl.mainBoardTasksDeatilBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.ARC || notification.FeatureName === FeatureName.ARCRequests) {
        this.router.navigate([AppRouteUrl.mainArcDetailBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Meetings) {
        this.router.navigate([AppRouteUrl.mainMeetingRouteUrl], navigationExtras)
      }
    }
    if (this.role === RoleEnum.Member) {
      if (notification.FeatureName === FeatureName.Service_Request || notification.FeatureName === FeatureName.ServiceRequest) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailHORouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Violations) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.ARC || notification.FeatureName === FeatureName.ARCRequests) {
        this.router.navigate([AppRouteUrl.mainArcDetailHORouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Meetings) {
        this.router.navigate([AppRouteUrl.mainMeetingRouteUrl], navigationExtras)
      }
    }
    this.Notification = false;
  }

  NotifyFilterToggle() {
    this.NotifyFilter=true
  }

}
