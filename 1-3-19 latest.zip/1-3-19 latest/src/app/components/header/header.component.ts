import { Component, OnInit, ViewChild, AfterViewInit, ElementRef, ViewChildren } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { Router, NavigationExtras } from '@angular/router';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';
import { RoleEnum, CaseTypeEnum, CaseFeatureType, FeatureName, FeaturePermissions, FeedbackCategory, notoficationStatus } from 'src/app/shared/Enums/commonEnums';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonService } from 'src/app/services/common.service';
import { map, debounceTime } from 'rxjs/operators';
import { MemberHistoryService } from 'src/app/services/member-history.service';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { NotificationSliderService } from 'src/app/services/notification-slider.service';
import { fromEvent } from 'rxjs';
import { MatSnackBar } from '@angular/material';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { FeedbackService } from 'src/app/services/feedback.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  notificationService: NotificationService;
  nav = false;
  headcreate = false;
  viewprofilelink = false;
  userData: UserData;
  userProfileUrl: string;
  caseTypeEnum = CaseTypeEnum;

  menu = new Array<any>();
  parentMainMenu = new Array<any>();
  userId: string;
  userName: string;
  companyCode: string;
  associationId: string;
  associationUnitId: string;
  associationName: string;
  roleType = RoleEnum;
  role: string;
  NotifyFilter = false;

  mainUrl = AppRouteUrl.headerMainRouteUrl;

  //global search
  searchUserList = new Array<SearchUserList>()
  displayList: any = [];
  //For filter by key word
  filterByKeyWords: string = "";
  //@ViewChild('searchData') searchData: any;
  isSearchShow: boolean = false;
  globalAssociationModel: GlobalAssociationModel;
  private searchData: ElementRef;

  @ViewChild('searchData') set content(content: ElementRef) {
     this.searchData = content;
  }
  //notification slider
  Notification = false;
  pmCompanyAssociationMappingId: string;
  notificationList: any = [];
  isassociationNotificationLoad : boolean = false;
  isMyNotificationLoad: boolean = false;
  associationNotification: any = [];
  myNotification: any = [];
  caseFeatureTypeEnum = CaseFeatureType;
  featureNameEnum = FeatureName;
  totalUnreadNotification: any;
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  totalNotification: any;
  // feed back
  addFeedbackForm: FormGroup;
  isFeedbackButton: boolean = true;
  @ViewChild('addFeedbackDirective') addFeedbackDirective: FormGroupDirective;
  feedbackCategory : FeedbackCategory;
  feedBackCat:any;
  Comments:any;

  status : any =notoficationStatus;

  constructor(private readonly appConfig: AppConfig,
    private arcService: ArcRequestApiService,
    public commonService: CommonService,
    private memberHistoryService: MemberHistoryService,
    private globalAssociationService: GlobalAssociationService,
    private notificationSliderService: NotificationSliderService,
    private readonly snb: MatSnackBar,
    private router: Router,
    private formBuilder: FormBuilder,
    private feedBackService: FeedbackService,
    private hoaDirectoryApiService: HoaDirectoryApiService) {
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData !== null) {
      console.log('status : ',this.status.Canceled);
      this.commonService.userProfileUrlSubject.subscribe(res => {
        let randomNumber = new Date().getTime();
        this.userProfileUrl = "";
        if (res !== "") {
          console.log(res);
          this.userProfileUrl = res + '?p=' + randomNumber;
        } else {
          this.userProfileUrl = this.userData.UserProfileBlobPath;
        }
      });
      this.userId = this.userData.UserProfileId;
      this.role = this.userData.Role;
      this.userName = this.userData.UserName;
      this.associationId = this.userData.UserAssociations.length > 0 ? this.userData.UserAssociations[0].AssociationId : '';
      this.associationUnitId = this.userData.UserUnits.length > 0 ? this.userData.UserUnits[0].UnitId : '';
      this.associationName = this.userData.UserAssociations.length > 0 ? this.userData.UserAssociations[0].Name : '';
      this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
      this.companyCode = this.userData.UserAssociations[0].CompanyCode;
      this.createMenu();
    }
  }

  getUserProfile(val) {
    var associationId = "";
    if (this.role === RoleEnum.PropertyManager) {
      associationId = this.globalAssociationModel.AssociationId;
    } else {
      associationId = this.associationId;
    }
    let resData;
    this.searchUserList = new Array<SearchUserList>();
    this.memberHistoryService.getUserProfiles(associationId,val).subscribe(res => {
      resData = res;
      console.log("userprofile",res);
      if (resData.Success) {
        var userList = resData.UserProfiles;
        userList.map(u => {
          let userDetail = {
            Address: this.getAddress(u),
            AssociationId: u.AssociationId,
            AssociationName: u.AssociationName,
            Email: u.Email,
            PhoneNo: u.PhoneNo,
            ProfileImagePath: u.ProfileImagePath,
            RoleName: u.RoleName,
            UnitId: u.UnitId,
            UserName: u.UserName,
            UserProfileId: u.UserProfileId
          }
          this.searchUserList.push(userDetail);
        });
        this.filterByKeyWords = val;     
        this.createList();
        console.log("UserList",userList);
      }
    });
  }

  getAddress(u) {
    if (u.Addresses !== null) {
      var address = {
        AssociationUnitNumber: "",
        AssociationUnitAddress1: u.Addresses.Address1,
        AssociationUnitAddress2: u.Addresses.Address2,
        AssociationUnitCity: u.Addresses.City,
        AssociationUnitState: u.Addresses.State,
        AssociationUnitZip: u.Addresses.ZIP
      }
      return this.commonService.getFullAssociationAddress(address);
    }
    else {
      return "";
    }

  }

  createList() {
    var searchStr = this.filterByKeyWords.toLowerCase();
    this.displayList = [];
    this.displayList = this.searchUserList.map(a => {
      var userName = a.UserName !== null ? a.UserName : "";
      var email = a.Email !== null ? a.Email : "";
      var phone = a.PhoneNo !== null ? a.PhoneNo : "";
      var address = a.Address !== null ? a.Address : "";
      if (userName.toLowerCase().search(searchStr) >= 0 || email.toLowerCase().search(searchStr) >= 0 || phone.toLowerCase().search(searchStr) >= 0 || address.toLowerCase().search(searchStr) >= 0) {
        return a;
      }
    });
    this.displayList = this.displayList.filter(a => {
      return a !== undefined;
    })
    if (this.displayList.length > 0) {
      this.isSearchShow = true;
    }
  }

  goToHistory(data) {
    console.log('data ', data);
    if (this.role === RoleEnum.PropertyManager) {
      window.open(document.location.origin + AppRouteUrl.mainMemberHistoryRouteUrl + "?userId=" + data.UserProfileId + "&unitId=" + data.UnitId + "&associationId=" + data.AssociationId);
    }
    this.isSearchShow = false;
  }


  NotifyFilterToggle() {
    if (this.NotifyFilter) {
      this.NotifyFilter = false;
    }
    else {
      this.NotifyFilter = true;
    }
  }

  createMenu() {
    this.menu = new Array<any>();
    this.parentMainMenu = new Array<any>();
    if (this.userData) {
      this.parentMainMenu = this.userData.FeatureMenuPermissions.filter(m => (m.FeatureParentId === null || m.FeatureParentId === '') && m.IsMenuItem === true && m.CanRead === true);
      this.parentMainMenu.forEach(element => {
        var childMenu = this.userData.FeatureMenuPermissions.filter(el => el.FeatureParentId == element.FeatureId && el.IsMenuItem === true && el.CanRead === true);
        const menuData = {
          parent: element,
          child: childMenu
        }
        this.menu.push(menuData);
      });

      this.isARCMember();
    }
  }



  ngOnInit() {
    this.globalAssociationService.associationSubject.subscribe(res => {
      this.globalAssociationModel = res;
      //global search
      if (res !== 1) {
        //this.getUserProfile();
        this.totalNotifications();
      }
    });
   // this.getAllFeedbacks();
  }

  ngAfterViewInit() {
     //Filter By Key word
     if(this.searchData !== undefined){
      fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        if(val !== '') {
          this.getUserProfile(val);      
        }
        else {
          this.isSearchShow = false;
        }
      });
     }
    
  }
  getFeedbackComment() {
    if (this.Comments === ' ' || this.Comments === '\n') {
      this.Comments = '';
    }
    else {
      if(this.Comments.length > 0) {
        this.isFeedbackButton = false;
      }
      else {
        this.isFeedbackButton = true;
      }
    }
  }
  addFeedback() {
    let model = {
        CompanyCode: this.companyCode,
        CreatedByUserId: this.userId,
        CreatedByUserName: this.userName,
        Comments: this.Comments,
        FeedbackCategory: this.feedBackCat === 'top' ? FeedbackCategory.Top : this.feedBackCat === 'average' ? FeedbackCategory.Average : FeedbackCategory.Poor
    }
    this.feedBackService.addFeedback(model).subscribe(
      (response: any) => {
        console.log('feedback response',response);
        if(response.Success) {
          document.getElementById('close_modal').click();
         this.resetFeedback();
        }
      }
    );
    console.log('FeedBack Model',model);
  }
  getAllFeedbacks() {
    this.feedBackService.getAllFeedback().subscribe(
      (response) => {
        console.log('Feedback List',response);
      }
    );
  }
  resetFeedback() {
    this.Comments = null;
    this.feedBackCat = null;
    this.isFeedbackButton = false;
  }
  headcreateToggle() {
    if (this.headcreate)
      this.headcreate = false;
    else
      this.headcreate = true;
  }

  myprofileToggle() {
    if (this.viewprofilelink)
      this.viewprofilelink = false;
    else
      this.viewprofilelink = true;
  }

  logout() {
    this.appConfig.removeCurrentUser();
    this.router.navigate([AppRouteUrl.associationLandingRouteUrl]);
  }

  myProfileDetails() {
    if ((this.userId !== null && this.userId !== "" && this.userId !== undefined) && (this.associationUnitId !== null && this.associationUnitId !== "" && this.associationUnitId !== undefined)) {
      this.hoaDirectoryApiService.userId = this.userId;
      this.hoaDirectoryApiService.associationUnitId = this.associationUnitId;
      this.hoaDirectoryApiService.isMyProfileComesFromHeader = true;
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": this.userId,
          "auid": this.associationUnitId
        }
      };
      this.router.navigate([AppRouteUrl.mainMyProfileRouteUrl], navigationExtras);
    }
    else {
      this.notificationService.showNotification("User details not found");
    }
  }

  isARCMember() {
    const userData: UserData = this.appConfig.getCurrentUser();
    let resData;
    if (userData !== undefined && userData !== null) {
      this.arcService.isUserArcCommitteeMemberGet(userData.UserProfileId, userData.UserAssociations[0].AssociationId).subscribe(res => {
        resData = res;
        this.arcService.isCommitteeMember = resData.Success;
      });
    }
  }


  onGlobalCreate(caseType) {
    if (this.role !== RoleEnum.PropertyManager) {
      if (caseType === CaseTypeEnum.ServiceRequest) {
        window.open(document.location.origin + AppRouteUrl.mainServiceRequestHORouteUrl + "?isAdd=true");
      }
      if (caseType === CaseTypeEnum.Violations) {
        window.open(document.location.origin + AppRouteUrl.mainViolationsHORouteUrl + "?isAdd=true");
      }
      if (caseType === CaseTypeEnum.ARC) {
        window.open(document.location.origin + AppRouteUrl.mainCreateArcRouteUrl + "?isAdd=true");
      }
      if (caseType === CaseTypeEnum.BoardTasks) {
        window.open(document.location.origin + AppRouteUrl.mainBoardTasksBMRouteUrl + "?isAdd=true");
      }
    }

    if (this.role === RoleEnum.PropertyManager) {
      if (caseType === CaseTypeEnum.ServiceRequest) {
        window.open(document.location.origin + AppRouteUrl.mainServiceRequestPMRouteUrl + "?isAdd=true");
      }
      if (caseType === CaseTypeEnum.Violations) {
        window.open(document.location.origin + AppRouteUrl.mainViolationsPMRouteUrl + "?isAdd=true");
      }
      if (caseType === CaseTypeEnum.BoardTasks) {
        window.open(document.location.origin + AppRouteUrl.mainBoardTasksPMRouteUrl + "?isAdd=true");
      }
      if (caseType === CaseTypeEnum.ARC) {
        window.open(document.location.origin + AppRouteUrl.mainCreateArcPMRouteUrl + "?isAdd=true");
      }
    }
  }

  //notification slider toggle
  NotificationToggle() {
    if (this.Notification) {
      this.Notification = false;
    }
    else {
      //this.getAllNotificaton();
      this.getAssociationNotification();
      this.getMyNotification();
      this.Notification = true;
      var ele=document.getElementById('notification_sidebar');
      ele.scrollTo(0,0);
    }
  }
  // get totoal notifications
  totalNotifications() {
    this.notificationSliderService.getTotlaNotifications(this.userId,this.pmCompanyAssociationMappingId).subscribe(
      (response:any) => {
        if(response.Success) {
          console.log('total',response);
          this.totalNotification = response;
          this.role === RoleEnum.Member ? this.totalUnreadNotification = response.MyCount: this.totalUnreadNotification = response.AllCount;
        }
      }
    );
  }
  // get all Notification 
  getAllNotificaton() {
    this.notificationList = [];
    let pmCompanyAssociationMappingId;
    if (this.role === RoleEnum.PropertyManager) {
      pmCompanyAssociationMappingId = this.globalAssociationModel.PMCompanyAssociationMappingId;
    } else {
      pmCompanyAssociationMappingId = this.pmCompanyAssociationMappingId;
    }
    let resData;
    this.notificationSliderService.getNotifications(pmCompanyAssociationMappingId).subscribe(res => {
      console.log('NotificationDetails ', res);
      resData = res;
      if (resData.Success) {
        this.isassociationNotificationLoad = true;
        this.notificationList = resData.ProcessedNotifications.filter(n => {
          if (n.FeatureName !== null) {
            return n;
          }
        });

        this.notificationList.sort((val1, val2) => {
          return new Date(val2.SentDate).getTime() - new Date(val1.SentDate).getTime()
        });
        if(this.role === RoleEnum.Member) {
          this.getMyNotification();
        }
        else{
          this.getAssociationNotification();
        }
      }
    });
  }

  goToAllNotificationList(currentTab) {

    this.notificationSliderService.currentTab.next(currentTab)// = currentTab;
    console.log('tab',currentTab,'sTab',this.notificationSliderService.currentTab);
    this.router.navigate([AppRouteUrl.mainNotificationRouteUrl]);
    this.NotificationToggle();
  }

  changeStatus(s) {
    this.getAssociationNotification();
    if (s === CaseFeatureType.ServiceRequest) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Service_Request || n.FeatureName === FeatureName.ServiceRequest
      });
    } else if (s === CaseFeatureType.Meeting) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Meetings
      });
    } else if (s === CaseFeatureType.Motion) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Motion
      });
    } else if (s === CaseFeatureType.ARCRequest) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.ARCRequests || n.FeatureName === FeatureName.ARC
      });
    }
    else if (s === CaseFeatureType.Violation) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Violations
      });
    } else if (s === CaseFeatureType.BoardTask) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Board_Task
      });
    }
  }

  statusChangeMyNotification(s) {
    this.getMyNotification();
    if (s === CaseFeatureType.ServiceRequest) {
      this.myNotification = this.myNotification.filter(n => {
        return n.FeatureName === FeatureName.Service_Request || n.FeatureName === FeatureName.ServiceRequest
      });
    } else if (s === CaseFeatureType.Meeting) {
      this.myNotification = this.myNotification.filter(n => {
        return n.FeatureName === FeatureName.Meetings
      });
    } else if (s === CaseFeatureType.Motion) {
      this.myNotification = this.myNotification.filter(n => {
        return n.FeatureName === FeatureName.Motion
      });
    } else if (s === CaseFeatureType.ARCRequest) {
      this.myNotification = this.myNotification.filter(n => {
        return n.FeatureName === FeatureName.ARCRequests || n.FeatureName === FeatureName.ARC
      });
    }
    else if (s === CaseFeatureType.Violation) {
      this.myNotification = this.myNotification.filter(n => {
        return n.FeatureName === FeatureName.Violations
      });
    } else if (s === CaseFeatureType.BoardTask) {
      this.myNotification = this.myNotification.filter(n => {
        return n.FeatureName === FeatureName.Board_Task
      });
    }
  }

  getAssociationNotification() {
    // this.associationNotification = this.notificationList.filter(n => {
    //   return n.UserProfileId !== this.userId;
    // });
    let pmCompanyAssociationMappingId;
    if (this.role === RoleEnum.PropertyManager) {
      pmCompanyAssociationMappingId = this.globalAssociationModel.PMCompanyAssociationMappingId;
    } else {
      pmCompanyAssociationMappingId = this.pmCompanyAssociationMappingId;
    }
    let resData;
    this.notificationSliderService.getAssociationNotifications(pmCompanyAssociationMappingId).subscribe(
      (response : any) => {
        console.log('Association Notification ', response);
      resData = response;
      if (resData.Success) {
        this.isassociationNotificationLoad = true;
        this.associationNotification = resData.ProcessedNotifications.filter(n => {
          if (n.FeatureName !== null) {
            return n;
          }
        });

        this.associationNotification.sort((val1, val2) => {
          return new Date(val2.SentDate).getTime() - new Date(val1.SentDate).getTime()
        });
      }
      }
    );
    
  }

  getMyNotification() {
    // this.myNotification = this.notificationList.filter(n => {
    //   return n.UserProfileId === this.userId;
    // });
    let pmCompanyAssociationMappingId;
    if (this.role === RoleEnum.PropertyManager) {
      pmCompanyAssociationMappingId = this.globalAssociationModel.PMCompanyAssociationMappingId;
    } else {
      pmCompanyAssociationMappingId = this.pmCompanyAssociationMappingId;
    }
    let resData;
    this.notificationSliderService.getMyNotifications(pmCompanyAssociationMappingId,this.userId).subscribe(
      (response : any) => {
        console.log('My Notification ', response);
      resData = response;
      if (resData.Success) {
        this.isMyNotificationLoad = true;
        this.myNotification = resData.ProcessedNotifications.filter(n => {
          if (n.FeatureName !== null) {
            return n;
          }
        });

        this.myNotification.sort((val1, val2) => {
          return new Date(val2.SentDate).getTime() - new Date(val1.SentDate).getTime()
        });
      }
      }
    );
  }

  goToDetailPage(notification) {
    this.notificationSliderService.wasSeenNotifications(notification.id).subscribe(
      (response:any)=> {
        if(response.Success) {
          this.totalNotifications();
        }
       console.log('wasSeen',response);
     });
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": notification.NotificationAction.ActionParams[0].Parameter
      }
    };
    if (this.role === RoleEnum.PropertyManager) {
      if (notification.FeatureName === FeatureName.Service_Request || notification.FeatureName === FeatureName.ServiceRequest) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Violations) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Board_Task) {
        this.router.navigate([AppRouteUrl.mainBoardTasksDeatilPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.ARC || notification.FeatureName === FeatureName.ARCRequests) {
        this.router.navigate([AppRouteUrl.mainArcDetailPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Meetings) {
        this.router.navigate([AppRouteUrl.mainMeetingPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.SocialAnnouncement) {
        this.router.navigate([AppRouteUrl.mainAnnouncementsDetailRouteUrl], navigationExtras)
      } 
    }
    if (this.role === RoleEnum.BoardMember) {
      if (notification.FeatureName === FeatureName.Service_Request || notification.FeatureName === FeatureName.ServiceRequest) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Violations) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Board_Task) {
        this.router.navigate([AppRouteUrl.mainBoardTasksDeatilBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.ARC || notification.FeatureName === FeatureName.ARCRequests) {
        this.router.navigate([AppRouteUrl.mainArcDetailBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Meetings) {
        this.router.navigate([AppRouteUrl.mainMeetingRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.SocialAnnouncement) {
        this.router.navigate([AppRouteUrl.mainAnnouncementsDetailRouteUrl], navigationExtras)
      } 
    }
    if (this.role === RoleEnum.Member) {
      if (notification.FeatureName === FeatureName.Service_Request || notification.FeatureName === FeatureName.ServiceRequest) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailHORouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Violations) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.ARC || notification.FeatureName === FeatureName.ARCRequests) {
        this.router.navigate([AppRouteUrl.mainArcDetailHORouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Meetings) {
        this.router.navigate([AppRouteUrl.mainMeetingRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.SocialAnnouncement) {
        this.router.navigate([AppRouteUrl.mainAnnouncementsDetailRouteUrl], navigationExtras)
      } 
    }
    this.Notification = false;
  }
  cancle(id,type) {
    this.notificationSliderService.cancelNotifications(id).subscribe(
     (response:any)=> {
      if(response.Success)
        if(type === 'my') {
          console.log('my');
          this.getMyNotification();
        }
        else {
          console.log('Association');
          this.getAssociationNotification();
        }
      
    });
  }
}


export class SearchUserList {
  Address: string;
  AssociationId: string;
  Email: string;
  PhoneNo: string;
  ProfileImagePath: string;
  RoleName: string;
  UnitId: string;
  UserName: string;
  UserProfileId: string;
}