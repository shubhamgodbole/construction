import { Component, OnInit, ViewChild } from '@angular/core';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';
import { BasicDetailsModel } from '../../my-profile/my-profile.model';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { Subscription } from 'rxjs';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar, MatPaginator } from '@angular/material';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { NoDataFoundCaseFeatureName, RoleEnum, MasterPaginationEnum, Pagination, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Location } from '@angular/common';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { DisplayLoadMore } from '../../manage-payment/manage-payment.model';
import { CommonService } from 'src/app/services/common.service';
import { ActiveFeatureRequestEnum } from '../directory.model';

@Component({
  selector: 'app-hoa-detail',
  templateUrl: './hoa-detail.component.html',
  styleUrls: ['./hoa-detail.component.scss']
})
export class HoaDetailComponent implements OnInit {
  //For no data found
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  notificationService: NotificationService;
  isApiResponceCome: boolean = false;
  //For get Query String.
  querySubcription: Subscription;
  hoaDetailList: any;
  unitEmergencyContactsList: any;
  vehiclesList: any;
  petsList: any;
  tenantsList: any;
  associationUnitId: string;
  accountNumber: string;
  unitNumber: string;
  basicDetails: BasicDetailsModel;
  serviceList: any;
  violationList: any;
  arcRequestList: any;
  isCommitteMemberForARC: boolean = false;
  //Get data From localstroge
  userData: UserData;
  domain: string;
  role: string;
  associationId: string;
  //payment
  paymentSheetList = [];
  companyCode: string;
  /*For maintain which tab is active in featureRequest*/
  activeFeatureRequestEnum = ActiveFeatureRequestEnum;
  featureRequest: string = ActiveFeatureRequestEnum.ServiceRequest
  /*For Payment */
  nextRecordCount: string = DisplayLoadMore.nextRecordCount;


  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  
  constructor(
    private _router: Router,
    public serviceRequest: ServiceRequestService,
    private paymentsApiService: PaymentsApiService,
    public commonService: CommonService,
    private route: ActivatedRoute, private readonly snb: MatSnackBar,
    private hoaDirectoryApiService: HoaDirectoryApiService, private _location: Location,
    private progressbarService: ProgeressBarService,
    private readonly appConfig: AppConfig) {
    this.userData = appConfig.getCurrentUser();
    this.role = this.userData.Role;
    //this.associationId = this.userData.UserAssociations[0].AssociationId;
    //this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    this.notificationService = new NotificationService(snb);
    this.domain = this.userData.UserAssociations[0].Domain;
  }

  ngOnInit() {
    this.setMasterOfPagination();
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let associationUnitId = params["auid"];
      let associationId = params["aid"];
      if (associationUnitId && associationId) {
        this.hoaDirectoryApiService.userId = "";
        this.hoaDirectoryApiService.associationUnitId = associationUnitId;
        this.associationId = associationId;
        this.getData();
      }
      else {
        console.log("details Not found.")
        this._router.navigate([AppRouteUrl.mainHoaMembersRouteUrl]);
      }
    });
  }

  getData() {
    this.progressbarService.show();
    let resData;
    this.hoaDirectoryApiService.getHoaDetails(this.hoaDirectoryApiService.userId, this.hoaDirectoryApiService.associationUnitId, this.associationId).subscribe(res => {
      this.progressbarService.hide();     
      resData = res;
      console.log("Detail of HOA res", res);
      this.isApiResponceCome = true;
      if (resData.Success === true) {
        let activeFeatureRequest = localStorage.getItem("activeFeatureRequest");
        if (activeFeatureRequest) {
          this.featureRequest = activeFeatureRequest;
        } else {
          this.featureRequest = ActiveFeatureRequestEnum.ServiceRequest;
        }
        this.associationUnitId = this.hoaDirectoryApiService.associationUnitId;

        this.serviceList = resData.HOADetail.serviceRequestList;
        this.violationList = resData.HOADetail.violationList;
        this.arcRequestList = resData.HOADetail.arcRequestList;
        console.log("this.featureRequest", this.featureRequest);
        if (this.featureRequest === ActiveFeatureRequestEnum.ServiceRequest && this.serviceList !== null) {
          this.setPaginationData(this.serviceList);
        } else if (this.featureRequest === ActiveFeatureRequestEnum.ARC && this.arcRequestList !== null) {
          this.setPaginationData(this.arcRequestList);
        } else if (this.featureRequest === ActiveFeatureRequestEnum.Violation && this.violationList !== null) {
          this.setPaginationData(this.violationList);
        }
        this.hoaDetailList = resData.HOADetail.UserProfileDetailWithAddress;
        if (this.hoaDetailList !== null) {
          this.vehiclesList = this.hoaDetailList.UnitVehicles;
          this.petsList = this.hoaDetailList.UnitPets;
          this.tenantsList = this.hoaDetailList.UnitTenants;
          this.accountNumber = this.hoaDetailList.UnitRole.UnitRoleProfiles[0].AccountNumber;
          this.unitNumber = this.hoaDetailList.AssociationUnit.AssociationUnitNumber;
          this.unitEmergencyContactsList = this.hoaDetailList.UnitEmergencyContacts;
          this.isCommitteMemberForARC = this.hoaDetailList.isCommitteMember;
          this.getBasicDetails();
        }
        this.getPayMentDetail();

      } else {
        this.notificationService.showNotification("Details Not Found");
        this._router.navigate([AppRouteUrl.mainHoaMembersRouteUrl]);
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  getBasicDetails() {
    let propertyAddress = this.getFullPropertyAddress();
    let mailAddress = this.getFullMailingAddress();
    let basicDetail: BasicDetailsModel = {
      dateOfBirth: this.hoaDetailList.UserProfile.BirthDate,
      emailAddress: this.hoaDetailList.UserProfile.EmailAddress,
      gender: this.hoaDetailList.UserProfile.Gender,
      homePhoneNumber: this.hoaDetailList.UserProfile.HomePhone,
      mailingAddress: mailAddress,
      mobileNumber: this.hoaDetailList.UserProfile.Mobile,
      propertyAddress: propertyAddress,
      workPhoneNumber: this.hoaDetailList.UserProfile.WorkPhone1,
    }
    this.basicDetails = basicDetail;
  }

  getFullPropertyAddress(): string {
    let propertyAddress = "";
    let fullPropertyAddress = this.hoaDetailList.AssociationUnit;
    if (fullPropertyAddress !== null) {
      if (fullPropertyAddress.AssociationUnitAddress1 !== null) {
        propertyAddress = fullPropertyAddress.AssociationUnitAddress1 + ",";
      }
      if (fullPropertyAddress.AssociationUnitAddress2 !== null) {
        propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitAddress2;
      }
      if (fullPropertyAddress.AssociationUnitCity !== null) {
        propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitCity;
      }
      if (fullPropertyAddress.AssociationUnitState !== null) {
        propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitState + ",";
      }
      // if (fullPropertyAddress.AssociationUnitCounty !== null) {
      //   propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitCounty;
      // }
      if (fullPropertyAddress.AssociationUnitZip !== null) {
        propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitZip;
      }
    }
    return propertyAddress;
  }

  getFullMailingAddress(): string {
    let fullMailingAddress = this.hoaDetailList.Address;
    let mailAddress = "";
    if (fullMailingAddress !== null) {
      if (fullMailingAddress.Address1 !== null) {
        mailAddress = fullMailingAddress.Address1 + ",";
      }
      if (fullMailingAddress.Address2 !== null) {
        mailAddress = mailAddress + fullMailingAddress.Address2;
      }
      if (fullMailingAddress.City !== null) {
        mailAddress = mailAddress + " " + fullMailingAddress.City;
      }
      if (fullMailingAddress.State !== null) {
        mailAddress = mailAddress + " " + fullMailingAddress.State + ",";
      }
      if (fullMailingAddress.County !== null) {
        mailAddress = mailAddress + fullMailingAddress.County;
      }
      if (fullMailingAddress.ZIP !== null) {
        mailAddress = mailAddress + " " + fullMailingAddress.ZIP;
      }
    }

    return mailAddress;
  }


  // Go to detail page of the Service Request.
  getServiceRequest(requestId: any) {
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": requestId
      }
    };
    this.commonService.setDataInLocalStorge(AppRouteUrl.mainHoaMembersDetailRouteUrl);
    if (this.role === RoleEnum.PropertyManager) {
      this._router.navigate([AppRouteUrl.mainServiceRequestDetailPMRouteUrl], navigationExtras);
    } else {
      this._router.navigate([AppRouteUrl.mainServiceRequestDetailBMRouteUrl], navigationExtras);
    }
  }

  // Go to detail page of the ARC Request.
  getARCRequest(requestId: any) {
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": requestId
      }
    };
    this.commonService.setDataInLocalStorge(AppRouteUrl.mainHoaMembersDetailRouteUrl);
    if (this.isCommitteMemberForARC === true) {
      this._router.navigate([AppRouteUrl.mainArcDetailCMRouteUrl], navigationExtras);
    } else if (this.role === RoleEnum.PropertyManager) {
      this._router.navigate([AppRouteUrl.mainArcDetailPMRouteUrl], navigationExtras);
    } else {
      this._router.navigate([AppRouteUrl.mainArcDetailBMRouteUrl], navigationExtras);
    }
  }

  // Go to detail page of the ARC Request.
  getViolationRequest(requestId: any) {
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": requestId
      }
    };
    this.commonService.setDataInLocalStorge(AppRouteUrl.mainHoaMembersDetailRouteUrl);
    if (this.role === RoleEnum.PropertyManager) {
      this._router.navigate([AppRouteUrl.mainViolationsDeatilBMRouteUrl], navigationExtras);
    } else {
      this._router.navigate([AppRouteUrl.mainViolationsDeatilBMRouteUrl], navigationExtras);
    }
  }

  getPayMentDetail() {
    let associations = this.userData.UserAssociations;
    let companyCode = associations.find(x => x.AssociationId === this.associationId).CompanyCode;
    let paymentReport = {
      "Count": DisplayLoadMore.count,
      "LastCount": DisplayLoadMore.lastCount,
      "AccountNum": this.accountNumber,
      "NextRecordCount": this.nextRecordCount,
      "Association": companyCode
    };
    let resData;

    this.progressbarService.show();
    this.paymentsApiService.getPaymentSheet(paymentReport).subscribe(res => {
      this.progressbarService.hide();
      console.log("res", res);
      resData = res;
      if (resData.PaymentReport !== null && resData.PaymentReport !== undefined) {
        if (resData.PaymentReport.PaymentHeaderList !== null && resData.PaymentReport.PaymentHeaderList !== undefined) {
          this.paymentSheetList = resData.PaymentReport.PaymentHeaderList[0].PaymentDetailsList;
          this.accountNumber = resData.PaymentReport.PaymentHeaderList[0].AccountNum;
          console.log("this.paymentSheetList", this.paymentSheetList);
        }
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  loadMorePaymentSheet() {
    let count = this.nextRecordCount;
    let nextCount = +count + 10;
    this.nextRecordCount = nextCount.toString();
    this.getPayMentDetail();
  }

  setDataOfFeatureRequest(activeRequest) {
    this.featureRequest = activeRequest;
    this.setMasterOfPagination();
    if (this.featureRequest === ActiveFeatureRequestEnum.ServiceRequest) {
      this.setPaginationData(this.serviceList);
    } else if (this.featureRequest === ActiveFeatureRequestEnum.ARC) {
      this.setPaginationData(this.arcRequestList);
    } else if (this.featureRequest === ActiveFeatureRequestEnum.Violation) {
      this.setPaginationData(this.violationList);
    }
    this.commonService.setDataInLocalStorgeOfFeatureRequest(this.featureRequest);

  }

  toGoBack() {
    this._location.back();
  }

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }

  //For Pagination
  setPaginationData(list) {
    this.TotalRecord = list.length;
    var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    this.FilterArray = list.slice(pageStartIndex - 1, pageEndIndex);
    console.log("FilterArray service request", this.FilterArray);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {

    var pageStartIndex = (clickObj.pageIndex * clickObj.pageSize) + 1;
    var pageEndIndex = (clickObj.pageIndex * clickObj.pageSize) + clickObj.pageSize;

    if (this.featureRequest === ActiveFeatureRequestEnum.ServiceRequest) {
      this.FilterArray = this.serviceList.slice(pageStartIndex - 1, pageEndIndex);
      var elmnt: any = document.getElementById("srcontentTable");
      if (elmnt !== null) {
        elmnt.scrollTo(0, 0);
      }
    } else if (this.featureRequest === ActiveFeatureRequestEnum.ARC) {
      this.FilterArray = this.arcRequestList.slice(pageStartIndex - 1, pageEndIndex);
      var elmnt: any = document.getElementById("arccontentTable");
      if (elmnt !== null) {
        elmnt.scrollTo(0, 0);
      }
    } else if (this.featureRequest === ActiveFeatureRequestEnum.Violation) {
      this.FilterArray = this.violationList.slice(pageStartIndex - 1, pageEndIndex);
      var elmnt: any = document.getElementById("viocontentTable");
      if (elmnt !== null) {
        elmnt.scrollTo(0, 0);
      }
    }


  }

}
