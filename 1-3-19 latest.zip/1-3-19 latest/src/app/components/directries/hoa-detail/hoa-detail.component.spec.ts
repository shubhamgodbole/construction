import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoaDetailComponent } from './hoa-detail.component';

describe('HoaDetailComponent', () => {
  let component: HoaDetailComponent;
  let fixture: ComponentFixture<HoaDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoaDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoaDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
