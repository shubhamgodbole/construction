import { Component, OnInit, ViewChild } from '@angular/core';
import { BoardMemberDirectoryApiService } from 'src/app/services/board-member-directory-api.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective, FormArray, FormControl } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import { BoardMember, BoardMemberPosition } from './board-member-directory-model';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { MatAutocompleteTrigger, MatSnackBar } from '@angular/material';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { RoleEnum, NoDataFoundCaseFeatureName, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { Router } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-board-member-directory',
  templateUrl: './board-member-directory.component.html',
  styleUrls: ['./board-member-directory.component.scss']
})
export class BoardMemberDirectoryComponent implements OnInit {
  notificationService: NotificationService;
  id: string;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  apiResponceErrorMsg: string = "";
  resData: any;
  boardMembersList: any = [];
  userList: any;
  filteredUsers: any;
  editMode: boolean = false;
  associationBoardTitles: any;
  userName: string;
  boardMember;
  userData: UserData;
  associationId: string;
  associationName: string;
  userId: string;
  domain: string;
  /**Add Board Member */
  frmBoardMember: FormGroup;
  addboardmember: boolean = false;
  btnDisable: boolean = false;
  addRes: any;
  btStartDate: Date;
  btEndDate: Date;
  @ViewChild('btend') btend;
  @ViewChild('btstart') btstart;
  @ViewChild('ptstart') ptstart;
  @ViewChild('ptend') ptend;
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  /*Edit Board member validation*/
  frmEditBoardMember: FormGroup;
  editboardmember: boolean = false;
  editBoardMemberName: string = "";
  editRes: any;
  btnEditDisable: boolean = false;
  btEditStartDate: string;
  btEditEndDate: string;
  today = new Date();
  @ViewChild('btEditend') btEditend;
  @ViewChild('formEditDirective') formEditDirective: FormGroupDirective;

  /*Reset mat auto compelte*/
  @ViewChild('homeOwnerAutoComplete', { read: MatAutocompleteTrigger })
  homeOwnertrigger: MatAutocompleteTrigger;

  isUpdatePermision: boolean = false;
  isCreatePermision: boolean = false;
  minSdate: string = null;
  boardMemberPositionList: any = [];
  isCustomTitleShow: boolean = false;
  positionList: any = [];
  positionStartDte: Date;
  cPosition: any;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  isApiResponceCome = false;

  constructor(private service: BoardMemberDirectoryApiService,
    private readonly snb: MatSnackBar,
    private emailNotification: EmailNotificationService,
    public commonService: CommonService,
    private router: Router,
    private readonly formBuilder: FormBuilder,
    private readonly appConfig: AppConfig) {
    this.userData = appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.notificationService = new NotificationService(snb);
    // this.userData.FeatureMenuPermissions.forEach(
    //   (feature) => {
    //     if (feature.Name === 'Board Members') {
    //       feature.CanUpdate ? this.isUpdatePermision = true : this.isUpdatePermision = false;
    //       feature.CanCreate ? this.isCreatePermision = true : this.isCreatePermision = false;
    //     }
    //   });

    if (this.userData.Role === RoleEnum.PropertyManager) {
      this.router.navigate([AppRouteUrl.pmBoardMemberRouteUrl]);
    }
    this.getMasterData();
  }

  /*Reset mat auto compelte*/
  ngAfterViewInit() {
    this.homeOwnertrigger.panelClosingActions
      .subscribe(e => {
        if (!(e && e.source)) {
          this.userList = this.userList;
          this.frmBoardMember.controls.homeOwner.setValue('');
          this.homeOwnertrigger.closePanel();
        }
      });
  }

  private _filterUsers(value: string) {
    const filterValue = value;
    return this.userList.filter(user => user.UserName.toLowerCase().indexOf(filterValue) === 0);
  }

  ngOnInit() {
    this.getBoardMemberDirectory();
    this.createForm();
    this.editForm();
  }

  displayFn(user) {
    return user ? user.UserName : null;
  }
  changeSDate() {
    this.btStartDate = this.frmBoardMember.controls.boardTermStartDate.value;
  }
  changeEditSDate() {
    this.btEditStartDate = this.frmEditBoardMember.controls.boardTermStartDate.value;
    let editStDate: any = new Date(this.btEditStartDate);
    let editEndDate: any = new Date(this.btEditEndDate);
    if (editStDate > editEndDate) {
      this.frmEditBoardMember.controls.boardTermEndDate.setValue('');
    }
    this.resetPosition();
  }

  changeEDate() {
    this.btEndDate = this.frmBoardMember.controls.boardTermEndDate.value;
    let stDate = this.frmBoardMember.controls.boardTermStartDate.value;
    if (stDate > this.btEndDate) {
      this.frmBoardMember.controls.boardTermStartDate.reset('');
    }
  }
  changeEditEDate() {
    this.btEditEndDate = this.frmEditBoardMember.controls.boardTermEndDate.value;
    this.minSdate = this.frmEditBoardMember.controls.boardTermEndDate.value;
    this.resetPosition();
  }
  changePositionSDate(pos) {
    this.cPosition = null;
    this.positionStartDte = null;
    let formPositions;
    if (this.frmBoardMember.controls.positions.value) {
      formPositions = this.frmBoardMember.controls.positions.value;
      for (let i = 0; i < formPositions.length; i++) {
        if (i === pos) {
          this.cPosition = pos;
          this.positionStartDte = new Date(formPositions[i].positionStartDate);
        }
      }
    }
    if (this.frmEditBoardMember.controls.positions.value) {
      formPositions = this.frmEditBoardMember.controls.positions.value;

      for (let i = 0; i < formPositions.length; i++) {
        if (i === pos) {
          this.cPosition = pos;
          this.positionStartDte = new Date(formPositions[i].positionStartDate);
        }

      }
    }
  }
  resetPosition() {
    let editStDate: any = new Date(this.btEditStartDate);
    let editEndDate: any = new Date(this.btEditEndDate);

    const formPositions = this.frmEditBoardMember.controls.positions.value;
    for (let i = 0; i < formPositions.length; i++) {

      let positionStartDte = new Date(formPositions[i].positionStartDate);
      let positionEndDte = new Date(formPositions[i].positionEndDate);
      if (editStDate > positionStartDte) {

        //  console.log('posSdate',(<FormArray>this.frmEditBoardMember.controls.positions).controls[i].value.positionStartDate);
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.positionStartDate.reset();

      }
      if (editEndDate > positionEndDte) {

        // console.log('posSdate',(<FormArray>this.frmEditBoardMember.controls.positions).controls[i].value.positionEndDate);
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.positionEndDate.reset();

      }
    }
  }
  createForm() {
    this.frmBoardMember = this.formBuilder.group({
      descriptions: ['', [Validators.maxLength(2000)]],
      boardTermStartDate: ['', Validators.required],
      boardTermEndDate: ['', Validators.required],
      homeOwner: ['', Validators.required],
      positions: this.formBuilder.array([]),
    });
  }

  // use for show and hide model
  addboardmemberToggle() {
    if (this.addboardmember) {
      this.addboardmember = false;
    }
    else {
      this.addboardmember = true;
    }
    this.removeAllPositionControl();
    this.addPosition();
  }


  //use for remove position control
  removeAllPositionControl() {
    for (let i = 0; i < this.boardMemberPositions.length; i++) {
      console.log('assd ', i);
      //this.removePosition(i);
      this.boardMemberPositions.removeAt(i);
    }
    console.log(this.boardMemberPositions);
  }


  getCurrrentPosition(PositionStartDate, PositionEndDate) {
    // console.log("PositionStartDate",PositionStartDate);
    // console.log("PositionEndDate",PositionEndDate);
    // console.log(this.today.getTime());
    // console.log(new Date(PositionStartDate).getTime() >= this.today.getTime());
    // console.log(new Date(PositionEndDate).getTime() <= this.today.getTime());
    // console.log("condi", new Date(PositionStartDate).getTime() >= this.today.getTime() || new Date(PositionEndDate).getTime() <= this.today.getTime());

    // if (new Date(PositionStartDate).getTime() >= this.today.getTime() || new Date(PositionEndDate).getTime() <= this.today.getTime()) {
    //   return true;
    // }
    // else {
    //   return false;
    // }
    if (PositionStartDate !== null && PositionEndDate !== null) {
      if (new Date(PositionStartDate).getTime() <= this.today.getTime() && new Date(PositionEndDate).getTime() >= this.today.getTime()) {
        return true;
      }
      else {
        return false;
      }
    } else if (PositionEndDate === null && PositionStartDate !== null) {
      if (new Date(PositionStartDate).getTime() <= this.today.getTime()) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
  //Get List of board member
  getBoardMemberDirectory() {
    this.service.getBoardMembers(this.associationId).subscribe(
      (response) => {        
        let positionlst;
        this.resData = response;      
        this.boardMembersList = [];
        this.boardMembersList = this.resData.BoardMembersList;
        this.isApiResponceCome = true;
        this.resData.BoardMembersList.forEach((member) => {
          positionlst = member.BoardMemberPositions.filter(a => a.PositionEndDate >= new Date());
        });
        console.log(positionlst);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  // use for get master data that is use for bind data in form
  getMasterData() {
    this.service.getMasterData(this.associationId).subscribe(
      (response) => {
        console.log("response",response);
        this.resData = response;
        this.userList = this.resData.BoardMemberMasters.UserProfiles;
        this.associationBoardTitles = this.resData.BoardMemberMasters.AssociationBoardTitles;
        this.getAssociationTitle();
        this.filteredUsers = this.frmBoardMember.controls.homeOwner.valueChanges
          .pipe(
            startWith(''),
            map((data) => data ? this._filterUsers(data) : this.userList.slice())
          );
      },
      (error) => {
        console.log(error);
      }
    );
  }

  //Use for get association title
  getAssociationTitle() {
    this.associationBoardTitles.map(
      (a) => {
        if (a.BoardTitle === 'Other')
          a.BoardTitle = a.CustomBoardTitleName;
        else
          a.BoardTitle = a.BoardTitle;
        return a;
      });
  }

  // Call after click on add or Edit button
  onSubmit() {
    if (!this.frmBoardMember.valid) {
      console.log('fail');
      return;
    }
    const boardMemberModel = this.createModel();
    this.btnDisable = true;
    // if (this.editMode)
    //   this.editBoardMember(boardMemberModel);
    // else
    this.addBoardMember(boardMemberModel);
    // }
  }

  //use for Create Board Member model
  createModel() {
    let boardMemberPositions = new Array<BoardMemberPosition>();
    const formPositions = this.frmBoardMember.controls.positions.value;
    for (let i = 0; i < formPositions.length; i++) {
      let boardPosition: BoardMemberPosition = new BoardMemberPosition();
      boardPosition.PositionTitleName = formPositions[i].positionTitle.BoardTitle;
      boardPosition.CustomBoardTitleName = formPositions[i].CustomBoardTitleName;
      boardPosition.PositionTitleId = formPositions[i].positionTitle.AssociationBoardTitleId;
      boardPosition.PositionEndDate = formPositions[i].positionEndDate !== '' ? new Date(formPositions[i].positionEndDate).toUTCString() : '';
      boardPosition.PositionStartDate = new Date(formPositions[i].positionStartDate).toUTCString();
      boardPosition.BoardMemberPositionId = formPositions[i].positionTitle.BoardMemberPositionId;
      boardMemberPositions.push(boardPosition);
    }

    const model: BoardMember = {
      id: this.editMode ? this.boardMember.id : '',
      BoardMemberCoverImagepath: '',
      BoardMemberProfileImagepath: '',
      Description: this.frmBoardMember.controls.descriptions.value,
      BoardMemberUserProfileId: this.editMode ? this.boardMember.BoardMemberUserProfileId : this.frmBoardMember.value.homeOwner.UserProfileId.toString(),
      BoardMemberName: this.editMode ? this.boardMember.BoardMemberName : this.frmBoardMember.value.homeOwner.UserName,
      BoardMemberStartDate: new Date(this.frmBoardMember.value.boardTermStartDate).toUTCString(),
      BoardMemberEndDate: new Date(this.frmBoardMember.value.boardTermEndDate).toUTCString(),
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      CreatedOn: new Date().toUTCString(),
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      BoardMemberPositions: boardMemberPositions,
      ModifiedByUserId: "",
      ModifiedByUserName: ""
    }
    return model;
  }

  // use for add board member
  addBoardMember(boardMemberModel: BoardMember) {
    this.service.addBoardMember(boardMemberModel, this.domain).subscribe(
      (res) => {
        this.btnDisable = false;
        this.addRes = res;
        if (this.addRes.Success === true) {
          this.notificationService.showNotification("Board member saved successfully");
          this.addboardmember = false;
          this.resetForm();
          this.getMasterData();
          this.getBoardMemberDirectory();
        }
        if (this.addRes.Success === false && this.addRes.Message !== "") {
          this.apiResponceErrorMsg = this.addRes.Message;
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }

  resetForm() {
    this.frmBoardMember.reset();
    this.formDirective.resetForm();
    this.addboardmember = false;
    this.btEndDate = null;
    this.btStartDate = null;
    this.btnDisable = false;
    this.removeAllPositionControl();
    this.isCustomTitleShow = false;
    this.positionList = [];
  }

  get boardMemberPositions() {
    return this.frmBoardMember.get('positions') as FormArray;
  }

  addPosition() {
    this.boardMemberPositions.push(this.formBuilder.group({
      positionTitle: ['', Validators.required],
      positionStartDate: ['', Validators.required],
      positionEndDate: [''],
      CustomBoardTitleName: ['']
    }));
  }

  removePosition(index) {
    this.boardMemberPositions.removeAt(index);
  }

  /**Edit Form */
  editForm() {
    this.frmEditBoardMember = this.formBuilder.group({
      descriptions: ['', Validators.maxLength(2000)],
      boardTermStartDate: ['', Validators.required],
      boardTermEndDate: ['', Validators.required],
      homeOwner: [''],
      positions: this.formBuilder.array([])
    });
  }

  resetEditForm() {
    this.frmEditBoardMember.reset();
    this.formEditDirective.resetForm();
    this.editboardmember = false;
    this.btnEditDisable = false;
    this.btEditEndDate = null;
    this.btEditStartDate = null;
    this.minSdate = null;
    this.isCustomTitleShow = false;
    this.positionList = [];
    this.removeAllEditPositionControl();
  }

  onEditSubmit() {
    // if (!this.frmEditBoardMember.valid) {
    //   return;
    // }
    const boardMemberModel = this.createEditModel();
    this.editBoardMember(boardMemberModel);
  }

  // use for bind data for edit
  boardMemberEdit(boardMember) {
    this.removeAllEditPositionControl();
    this.editboardmember = true;
    this.boardMember = boardMember;
    this.editBoardMemberName = boardMember.BoardMemberName;
    this.btEditEndDate = boardMember.BoardMemberEndDate
    this.btEditStartDate = boardMember.BoardMemberStartDate// new Date(boardMember.BoardMemberStartDate).toString().split('T')[0];
    this.frmEditBoardMember.controls.boardTermEndDate.setValue(boardMember.BoardMemberEndDate);
    this.frmEditBoardMember.controls.boardTermStartDate.setValue(boardMember.BoardMemberStartDate);
    this.frmEditBoardMember.controls.descriptions.setValue(boardMember.Description);
    let countPosition = boardMember.BoardMemberPositions.length;
    if (countPosition > 0) {
      for (let i = 0; i < countPosition; i++) {
        this.editPosition(boardMember.BoardMemberPositions[i]);
      }
    }
  }

  editPosition(model: any) {
    const position = this.associationBoardTitles.find(a => a.AssociationBoardTitleId.toLowerCase() == model.PositionTitleId.toLowerCase());
    this.editBoardMemberPositions.push(this.formBuilder.group({
      positionStartDate: [model.PositionStartDate, Validators.required],
      positionEndDate: [model.PositionEndDate],
      positionTitle: [position, Validators.required],
      CustomBoardTitleName: [''],
      boardMemberPositionId: [model.BoardMemberPositionId],
    }));
  }

  get editBoardMemberPositions() {
    return this.frmEditBoardMember.get('positions') as FormArray;
  }

  addPositionForEdit() {
    this.editBoardMemberPositions.push(this.formBuilder.group({
      positionTitle: ['', Validators.required],
      positionStartDate: ['', Validators.required],
      positionEndDate: [''],
      CustomBoardTitleName: ['']
    }));
  }

  removePositionForEdit(index) {
    this.editBoardMemberPositions.removeAt(index);
  }

  //use for remove position control
  removeAllEditPositionControl() {
    if (this.editBoardMemberPositions.length > 0) {
      for (let i = 0; i < this.editBoardMemberPositions.length; i++) {
        this.editBoardMemberPositions.removeAt(i);
      }
    }
  }

  //use for edit board member
  editBoardMember(boardMemberModel: BoardMember) {
    if (!this.frmEditBoardMember.valid) {
      console.log(this.frmEditBoardMember);
      return;
    }
    console.log(boardMemberModel);
    let isValid: boolean = true;
    const formEditPositions = this.frmEditBoardMember.controls.positions.value;
    for (let i = 0; i < formEditPositions.length; i++) {
      if (formEditPositions[i].positionTitle.BoardTitle === 'other' && formEditPositions[i].CustomBoardTitleName === '') {
        isValid = false;
      }
    }
    this.btnEditDisable = true;
    if (isValid) {
      this.service.editBoardMember(boardMemberModel).subscribe(
        (res) => {
          this.editRes = res;
          //  this.btnEditDisable = false;
          if (this.editRes.Success === true) {
            this.notificationService.showNotification("Board member updated successfully");
            this.resetEditForm();
            this.getMasterData();
            this.getBoardMemberDirectory();
          }
        }, (error) => {
          console.log(error);
        }
      );
    }
  }

  //use for Create Board Member model
  createEditModel() {
    let editBoardMemberPositions = new Array<BoardMemberPosition>();
    const formEditPositions = this.frmEditBoardMember.controls.positions.value;
    for (let i = 0; i < formEditPositions.length; i++) {
      let boardPosition: BoardMemberPosition = new BoardMemberPosition();
      boardPosition.PositionTitleName = formEditPositions[i].positionTitle.BoardTitle;
      boardPosition.CustomBoardTitleName = formEditPositions[i].CustomBoardTitleName;
      boardPosition.PositionTitleId = formEditPositions[i].positionTitle.AssociationBoardTitleId;
      boardPosition.PositionEndDate = formEditPositions[i].positionEndDate ? new Date(formEditPositions[i].positionEndDate).toUTCString() : null;
      boardPosition.PositionStartDate = new Date(formEditPositions[i].positionStartDate).toUTCString();
      boardPosition.BoardMemberPositionId = formEditPositions[i].boardMemberPositionId;
      editBoardMemberPositions.push(boardPosition);
    }

    const model: BoardMember = {
      id: this.boardMember.id,
      BoardMemberCoverImagepath: '',
      BoardMemberProfileImagepath: '',
      Description: this.frmEditBoardMember.controls.descriptions.value,
      BoardMemberUserProfileId: this.boardMember.BoardMemberUserProfileId,
      BoardMemberName: this.boardMember.BoardMemberName,
      BoardMemberStartDate: new Date(this.frmEditBoardMember.value.boardTermStartDate).toUTCString(),
      BoardMemberEndDate: new Date(this.frmEditBoardMember.value.boardTermEndDate).toUTCString(),
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      CreatedOn: new Date().toUTCString(),
      CreatedByUserId: "",
      CreatedByUserName: "",
      BoardMemberPositions: editBoardMemberPositions,
      ModifiedByUserId: this.userId,
      ModifiedByUserName: this.userName,
    }
    console.log("model", model);
    return model;

  }

  changepositionTitle(event, position) {
    this.id = event.value.id;
    if (event.value.BoardTitle === 'other') {
      this.isCustomTitleShow = true;
      this.positionList.push({ 'ID': event.value.id });
      const formPositions = this.frmBoardMember.controls.positions.value;
      for (let i = 0; i < formPositions.length; i++) {
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.setValidators([Validators.required, Validators.maxLength(20)]);
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.updateValueAndValidity();
      }
      const formEditPositions = this.frmEditBoardMember.controls.positions.value;
      for (let i = 0; i < formEditPositions.length; i++) {
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.setValidators([Validators.required, Validators.maxLength(20)]);
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.updateValueAndValidity();
      }
    }
    else {
      this.isCustomTitleShow = false;
      this.positionList.pop({ 'ID': event.value.id });
      const formPositions = this.frmBoardMember.controls.positions.value;
      for (let i = 0; i < formPositions.length; i++) {
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.clearValidators();
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.setValue('');
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.updateValueAndValidity();
      }
      const formEditPositions = this.frmEditBoardMember.controls.positions.value;
      for (let i = 0; i < formEditPositions.length; i++) {
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.clearValidators();
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.setValue('');
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.updateValueAndValidity();
      }
    }
  }
}

