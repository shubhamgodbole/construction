export class BoardMember {
    id: string
    BoardMemberUserProfileId: string
    AssociationId: string
    AssociationName: string
    BoardMemberName: string
    Description: string
    BoardMemberProfileImagepath: string
    BoardMemberCoverImagepath: string
    BoardMemberStartDate: string
    BoardMemberEndDate: string
    CreatedOn: string
    CreatedByUserId: string
    CreatedByUserName: string
    BoardMemberPositions: BoardMemberPosition[];
    ModifiedByUserId :string
    ModifiedByUserName:string
}

export class BoardMemberPosition {
    BoardMemberPositionId: string
    PositionStartDate: string
    PositionEndDate: string
    PositionTitleId: string
    PositionTitleName: string
    CustomBoardTitleName: string
    BoardMemberPositionSequence: number
}