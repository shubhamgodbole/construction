import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatAutocompleteModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HoHoaDirectoryComponent } from './ho-hoa-directory/ho-hoa-directory.component';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';

const routes: Routes = [
  {
    path: '',
    component: HoHoaDirectoryComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatBottomSheetModule,
    NumberOnlyDirectiveModule,
    MatButtonModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule
  ],
  exports: [RouterModule],
  declarations: [HoHoaDirectoryComponent]
})
export class HoHoaDirectoryModule { }
