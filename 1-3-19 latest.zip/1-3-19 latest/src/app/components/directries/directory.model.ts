export const UnitRole = {
  unitRoleOwner: "Owner",
  unitRoleRenter: "Renter",
  unitRoleAll: "All"
};

export enum ActiveFeatureRequestEnum {
  ServiceRequest = "ServiceRequest",
  Violation = "Violation",
  ARC = "ARC",
  PaymentHistory = "PaymentHistory",
  LetterSent = "LetterSent",
  PersonalInformation = "PersonalInformation",


}