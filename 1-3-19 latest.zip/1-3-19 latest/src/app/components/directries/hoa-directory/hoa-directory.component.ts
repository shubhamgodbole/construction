import { Component, OnInit, HostListener } from '@angular/core';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';
import { Router, NavigationExtras } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar } from '@angular/material';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { RoleEnum, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { UnitRole } from '../directory.model';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonService } from 'src/app/services/common.service';


@Component({
  selector: 'app-hoa-directory',
  templateUrl: './hoa-directory.component.html',
  styleUrls: ['./hoa-directory.component.scss']
})
export class HoaDirectoryComponent implements OnInit {
  notificationService: NotificationService;
  associationId: string;
  status = UnitRole.unitRoleAll;
  resData: any;
  hOADirectoryList: any;
  filterHOADirectoryList: any;
  totalUnit: number;
  totalUnitForOwner: number;
  totalUnitForRenter: number;
  userData: UserData;
  userId: string;
  currRole: string;
  roleEnum = RoleEnum;

  //For Globle Association
  associationDdl: any;
  selectedAssociation: any;

  globalAssociationModel: GlobalAssociationModel;


  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  /**For Load more */
  counter = 25;
  isAllLoaded: boolean = false;

  constructor(
    private _router: Router, private readonly snb: MatSnackBar,
    private globalAssociationService: GlobalAssociationService,
    public commonService: CommonService,
    private progressbarService: ProgeressBarService,
    private hoaDirectoryApiService: HoaDirectoryApiService, private readonly appConfig: AppConfig) {
    this.notificationService = new NotificationService(snb);
    this.userData = appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.currRole = this.userData.Role;
    this.userId = this.userData.UserProfileId;
  }

  /**For Load more */
  @HostListener("window:scroll", [])

  onWindowScroll() {
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight;
    if (Math.ceil(pos) == max) {
      //this.loadMore();
    }
  }
  loadMore = () => {
    if (this.hOADirectoryList !== undefined) {
      if (this.counter <= this.hOADirectoryList.length && !this.isAllLoaded) {
        this.progressbarService.show();
        setTimeout(() => {
          if (this.counter === this.hOADirectoryList.length) {
            this.isAllLoaded = true;
          }
          else {
            this.counter = this.counter + 10;
            this.counter = this.counter > this.hOADirectoryList.length ? this.hOADirectoryList.length : this.counter;
            window.scrollTo(0, document.body.scrollHeight);
          }
          this.progressbarService.hide();
        }, 2000);

      }
    }
  }
  /**End For Load more */

  ngOnInit() {
    if (this.currRole === RoleEnum.Member) {
      this._router.navigate([AppRouteUrl.mainHoHoaMembersRouteUrl]);
    }

    this.globalAssociationService.associationSubject.subscribe(res => {
      this.globalAssociationModel = res;
      if (res !== 1) {
        this.status = UnitRole.unitRoleAll
        this.getData();
      }
    });

    //Hide For now in html
    // else if (this.currRole === RoleEnum.PropertyManager) {
    //   if (this.hoaDirectoryApiService.associationId !== null && this.hoaDirectoryApiService.associationId !== undefined) {
    //     this.associationId = this.hoaDirectoryApiService.associationId;
    //   }
    //   this.getAssociationDdl();
    // } else {
    //   this.getData();
    // }
  }

  //Hide For now in html
  filterByAssociation(association) {
    if (association.value === "All") {
      this.associationId = "";
    } else {
      this.associationId = association.value.id;
      console.log("this.associationId", this.associationId);
    }
    this.getData();
  }


  getAssociationDdl() {
    this.hoaDirectoryApiService.getAssociation().subscribe(res => {
      this.resData = res;
      if (this.resData.Success === true) {
        this.associationDdl = this.resData.AssociationList;
      }
      //Hide For now in html
      // if (this.currRole === RoleEnum.PropertyManager) {
      //   if ((this.associationDdl !== null || this.associationDdl !== undefined) && this.hoaDirectoryApiService.associationId !== "" && this.hoaDirectoryApiService.associationId !== undefined && this.hoaDirectoryApiService.associationId !== null)
      //     this.selectedAssociation = this.associationDdl.find(x => x.id.toLowerCase() === this.associationId);
      //   else {
      //     //Set By default all association.
      //     this.selectedAssociation = "All";
      //     if (this.selectedAssociation === "All") {
      //       this.associationId = "";
      //     }
      //   }
      // } else {
      //   //Set By default all association.
      //   this.selectedAssociation = "All";
      //   if (this.selectedAssociation === "All") {
      //     this.associationId = "";
      //   }
      // }
      // this.getData();
    },
      (err) => {
        console.log(err);
      }
    )
  }

  statusChange(s) {
    let filterHOADirectoryList = this.filterHOADirectoryList;
    if (s === UnitRole.unitRoleOwner) {
      this.hOADirectoryList = filterHOADirectoryList.filter(x => x.UserUnitRole === UnitRole.unitRoleOwner);
    }
    if (s === UnitRole.unitRoleRenter) {
      this.hOADirectoryList = filterHOADirectoryList.filter(x => x.UserUnitRole === UnitRole.unitRoleRenter);
    }
    if (s === UnitRole.unitRoleAll) {
      this.hOADirectoryList = filterHOADirectoryList;
    }
    this.status = s;
  }

  getData() {
    this.progressbarService.show();
    this.hoaDirectoryApiService.getHoaDirectory(this.globalAssociationModel.AssociationId).subscribe(res => {
      this.progressbarService.hide();
      this.resData = res;
      if (this.resData.Errors.length !== 0) {
        this.notificationService.showNotification("Details not found");
        this.hOADirectoryList = [];
        this.filterHOADirectoryList = [];
        this.totalUnit = 0;
        this.totalUnitForRenter = 0;
        this.totalUnitForOwner = 0;
      }
      else {
        this.hOADirectoryList = this.resData.HOADirectory;
        console.log("this.hOADirectoryList", this.hOADirectoryList);
        this.filterHOADirectoryList = this.resData.HOADirectory;
        this.totalUnit = this.hOADirectoryList.length;
        let countOwner = 0, countRenter = 0;
        for (let i of this.hOADirectoryList) {
          if (i.UserUnitRole === UnitRole.unitRoleOwner) {
            countOwner++;
          }
          if (i.UserUnitRole === UnitRole.unitRoleRenter) {
            countRenter++;
          }
        }
        this.totalUnitForOwner = countOwner;
        this.totalUnitForRenter = countRenter;
      }

    },
      (err) => {
        console.log(err);
      }
    );
  }
  myProfileDetails(associationUnitId: string, userId: string) {
    if ((userId !== null && userId !== "" && userId !== undefined) && (associationUnitId !== null && associationUnitId !== "" && associationUnitId !== undefined)) {
      this.hoaDirectoryApiService.userId = userId;
      this.hoaDirectoryApiService.associationUnitId = associationUnitId;
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": userId,
          "auid": associationUnitId
        }
      };
      if (this.userId === userId && this.currRole === RoleEnum.BoardMember) {
        this._router.navigate([AppRouteUrl.mainMyProfileRouteUrl], navigationExtras);
      } else if (this.currRole === RoleEnum.PropertyManager) {
        this.hoaDirectoryApiService.associationId = this.globalAssociationModel.AssociationId; //this.associationId;
        this._router.navigate([AppRouteUrl.mainPmUserProfileRouteUrl], navigationExtras);
      }
      else {
        this._router.navigate([AppRouteUrl.mainMyProfileRouteUrl], navigationExtras);
      }
    }
    else {
      this.notificationService.showNotification("User details not found");
    }
  }
  //Old method
  myHoaDetails(associationUnitId: string, userId: string) {
    if ((userId !== null && userId !== "" && userId !== undefined) && (associationUnitId !== null && associationUnitId !== "" && associationUnitId !== undefined)) {
      this.hoaDirectoryApiService.userId = userId;
      this.hoaDirectoryApiService.associationUnitId = associationUnitId;
      this.hoaDirectoryApiService.associationId = this.globalAssociationModel.AssociationId; //this.associationId;
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": userId,
          "auid": associationUnitId
        }
      };
      this._router.navigate([AppRouteUrl.mainHoaMembersDetailRouteUrl], navigationExtras);
    }
    else {
      this.notificationService.showNotification("Hoa details not found");
    }
  }
  //New method
  myHoaDetailsByAssociationUnitId(associationUnitId: string, associationId: string) {
    if (associationUnitId !== null && associationUnitId !== "" && associationUnitId !== undefined) {
      //this.hoaDirectoryApiService.userId = userId;
      this.hoaDirectoryApiService.associationUnitId = associationUnitId;
      this.hoaDirectoryApiService.associationId = associationId; //this.associationId;
      //this._router.navigate(["/hoa-detail"]);
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "auid": associationUnitId,
          "aid": associationId
        }
      };
      this._router.navigate([AppRouteUrl.mainHoaMembersDetailRouteUrl], navigationExtras);
    }
    else {
      this.notificationService.showNotification("Hoa details not found");
    }
  }


}
