import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatAutocompleteModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatTooltipModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BoardMemberDirectoryComponent } from './board-member-directory/board-member-directory.component';
import { CommonModule } from '@angular/common';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { AllowOnlyDateModule } from 'src/app/shared/directives/allow-only-date/allow-only-date.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';

const routes: Routes = [
  {
    path: '',
    component: BoardMemberDirectoryComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatBottomSheetModule,
    MatButtonModule,
    NumberOnlyDirectiveModule,
    AllowOnlyDateModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    NoDataFoundModule,
    FormsModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule,
    MatTooltipModule,
  ],
  declarations: [BoardMemberDirectoryComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class BoardMemberDirectoryModule { }
