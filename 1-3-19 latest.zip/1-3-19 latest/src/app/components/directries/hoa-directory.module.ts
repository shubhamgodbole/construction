import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatAutocompleteModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatTooltipModule, MatPaginatorModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HoaDirectoryComponent } from './hoa-directory/hoa-directory.component';
import { HoaDetailComponent } from './hoa-detail/hoa-detail.component';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';

const routes: Routes = [
  {
    path: '',
    component: HoaDirectoryComponent
  },
  {
    path: 'hoa-detail',
    component: HoaDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    NoDataFoundModule,
    MatRadioModule,
    NumberOnlyDirectiveModule,
    MatTooltipModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatPaginatorModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule
  ],
  exports: [RouterModule],
  declarations: [HoaDirectoryComponent, HoaDetailComponent]
})
export class HoaDirectoryModule { }
