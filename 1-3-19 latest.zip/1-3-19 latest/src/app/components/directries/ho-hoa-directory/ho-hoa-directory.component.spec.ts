import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoHoaDirectoryComponent } from './ho-hoa-directory.component';

describe('HoHoaDirectoryComponent', () => {
  let component: HoHoaDirectoryComponent;
  let fixture: ComponentFixture<HoHoaDirectoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoHoaDirectoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoHoaDirectoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
