import { Component, OnInit, HostListener } from '@angular/core';
import { UnitRole } from '../directory.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { Router, NavigationExtras } from '@angular/router';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';
import { AppConfig } from 'src/app/app.config';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar } from '@angular/material';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { FeatureName, FeaturePermissions, RoleEnum } from 'src/app/shared/Enums/commonEnums';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-ho-hoa-directory',
  templateUrl: './ho-hoa-directory.component.html',
  styleUrls: ['./ho-hoa-directory.component.scss']
})
export class HoHoaDirectoryComponent implements OnInit {
  notificationService: NotificationService;

  associationId: string;
  status = UnitRole.unitRoleAll;
  resData: any;
  hOADirectoryList: any;
  filterHOADirectoryList: any;
  totalUnit: number;
  totalUnitForOwner: number;
  totalUnitForRenter: number;
  userData: UserData;
  currRole: string;
  userId: string = "";


  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  /**For Load more */
  counter = 25;
  isAllLoaded: boolean = false;

  constructor(
    private _router: Router,
    private progressbarService: ProgeressBarService,
    private readonly snb: MatSnackBar,
    public commonService: CommonService,
    private hoaDirectoryApiService: HoaDirectoryApiService, private readonly appConfig: AppConfig) {
    this.notificationService = new NotificationService(snb);
    this.userData = appConfig.getCurrentUser();
    this.currRole = this.userData.Role;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.userId = this.userData.UserProfileId;
  }

  /**For Load more */
  @HostListener("window:scroll", [])

  onWindowScroll() {
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight;
    if (Math.ceil(pos) == max) {
      //this.loadMore();
    }
  }
  loadMore = () => {
    if (this.hOADirectoryList !== undefined) {
      if (this.counter <= this.hOADirectoryList.length && !this.isAllLoaded) {
        this.progressbarService.show();
        setTimeout(() => {
          if (this.counter === this.hOADirectoryList.length) {
            this.isAllLoaded = true;
          }
          else {
            this.counter = this.counter + 10;
            this.counter = this.counter > this.hOADirectoryList.length ? this.hOADirectoryList.length : this.counter;
            window.scrollTo(0, document.body.scrollHeight);
          }
          this.progressbarService.hide();
        }, 2000);

      }
    }
  }
  /**End For Load more */

  ngOnInit() {
    if (this.currRole === RoleEnum.BoardMember) {
      this._router.navigate([AppRouteUrl.mainHoaMembersRouteUrl]);
    }
    this.getData();
  }

  statusChange(s) {
    let filterHOADirectoryList = this.filterHOADirectoryList;
    if (s === UnitRole.unitRoleOwner) {
      this.hOADirectoryList = filterHOADirectoryList.filter(x => x.UserUnitRole === UnitRole.unitRoleOwner);
    }
    if (s === UnitRole.unitRoleRenter) {
      this.hOADirectoryList = filterHOADirectoryList.filter(x => x.UserUnitRole === UnitRole.unitRoleRenter);
    }
    if (s === UnitRole.unitRoleAll) {
      this.hOADirectoryList = filterHOADirectoryList;
    }
    this.status = s;
  }

  getData() {
    this.progressbarService.show();
    this.hoaDirectoryApiService.getHoaDirectory(this.associationId).subscribe(res => {
      this.resData = res;
      this.progressbarService.hide();
      if (this.resData.Errors.length !== 0)
        this.notificationService.showNotification("Details not found");
      else {
        this.hOADirectoryList = this.resData.HOADirectory;
        this.filterHOADirectoryList = this.resData.HOADirectory;
        this.totalUnit = this.hOADirectoryList.length;
        let countOwner = 0, countRenter = 0;
        for (let i of this.hOADirectoryList) {
          if (i.UserUnitRole === UnitRole.unitRoleOwner) {
            countOwner++;
          }
          if (i.UserUnitRole === UnitRole.unitRoleRenter) {
            countRenter++;
          }
        }
        this.totalUnitForOwner = countOwner;
        this.totalUnitForRenter = countRenter;
      }
    },
      (err) => {
        console.log(err);
      }
    );
  }
  myProfileDetails(associationUnitId: string, userId: string) {
    if ((userId !== null && userId !== "" && userId !== undefined) && (associationUnitId !== null && associationUnitId !== "" && associationUnitId !== undefined)) {
      this.hoaDirectoryApiService.userId = userId;
      this.hoaDirectoryApiService.associationUnitId = associationUnitId;
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": userId,
          "auid": associationUnitId
        }
      };
      if (this.userId === userId) {
        this._router.navigate([AppRouteUrl.mainMyProfileRouteUrl], navigationExtras);
      } else {
        this._router.navigate([AppRouteUrl.mainUserProfileRouteUrl], navigationExtras);
      }
      //this._router.navigate(["/my-profile"]);
    }
    else {
      this.notificationService.showNotification("User Details not found");

    }
  }
}
