import { Component, OnInit } from '@angular/core';
import { BasicDetailsModel, DisplayGender } from '../my-profile/my-profile.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { Subscription, Subject } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatSnackBar } from '@angular/material';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';
import { CommonService } from 'src/app/services/common.service';
import { AppConfig } from 'src/app/app.config';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Location } from '@angular/common';
import { FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {
  isApiResponceCome: boolean = false;
  notificationService: NotificationService;
  resData: any;
  //For get Query String.
  querySubcription: Subscription;
  /*For get list variables*/
  userProfileList: any;
  tenantsList: any;
  unitEmergencyContactsList: any;
  vehiclesList: any;
  petsList: any;
  userProfileDetails: any;

  associationUnitId: string;
  accountNumber: string;
  coverImagePath: string;
  profileImagePath: string;
  basicDetails: BasicDetailsModel;
  userData: UserData;
  genderDdl: any;
  hoaHOUrl = AppRouteUrl.mainHoHoaMembersRouteUrl;
  // Private
  private unsubscribeAll: Subject<any>;


  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;


  constructor(private _router: Router,
    private route: ActivatedRoute,
    private _matDialog: MatDialog,
    private progressbarService: ProgeressBarService,
    private readonly snb: MatSnackBar,
    private _location: Location,
    private hoaDirectoryApiService: HoaDirectoryApiService,
    public commonService: CommonService,
    private readonly appConfig: AppConfig) {
    this.notificationService = new NotificationService(snb);
    this.unsubscribeAll = new Subject();
    this.genderDdl = DisplayGender.GenderList;
    this.userData = this.appConfig.getCurrentUser();
  }

  ngOnInit() {

    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      let associationUnitId = params["auid"];
      if (id) {
        this.hoaDirectoryApiService.userId = id;
        this.hoaDirectoryApiService.associationUnitId = associationUnitId;
        this.getData();
      }
      else {
        console.log("details Not found.")
        this._router.navigate([AppRouteUrl.mainHoHoaMembersRouteUrl]);
      }
    });
  }

  getData() {
    this.progressbarService.show();
    this.hoaDirectoryApiService.getMyprofile(this.hoaDirectoryApiService.userId, this.hoaDirectoryApiService.associationUnitId).subscribe(res => {
      this.resData = res;
      this.isApiResponceCome = true;
      this.progressbarService.hide();
      console.log(res);
      if (this.resData.Errors > 0) {
        console.log("Api Error is comming");
      } else {
        if (this.resData.Success) {
          this.userProfileList = this.resData.UserProfileDetailWithAddress;
          this.associationUnitId = this.hoaDirectoryApiService.associationUnitId;
          if (this.userProfileList !== null && this.userProfileList !== undefined) {
            this.userProfileDetails = this.userProfileList.UserProfileDetail;
            this.unitEmergencyContactsList = this.userProfileList.UnitEmergencyContacts;
            this.vehiclesList = this.userProfileList.UnitVehicles;
            this.petsList = this.userProfileList.UnitPets;
            this.tenantsList = this.userProfileList.UnitTenants;
            this.accountNumber = this.userProfileList.UnitRole.UnitRoleProfiles[0].AccountNumber;
            this.coverImagePath = this.userProfileList.UserProfile.CoverImagePath;
            this.profileImagePath = this.userProfileList.UserProfile.ProfileImagePath;
            this.getBasicDetails();
          }
        } else {
          this.notificationService.showNotification("Details not found");
        }
      }

    },
      (err) => {
        console.log(err);
      }
    )
  }

  getBasicDetails() {
    let propertyAddress = this.getFullPropertyAddress();
    let mailAddress = this.getFullMailingAddress();
    let basicDetail: BasicDetailsModel = {
      dateOfBirth: this.userProfileList.UserProfile.BirthDate,
      emailAddress: this.userProfileList.UserProfile.EmailAddress,
      gender: this.userProfileList.UserProfile.Gender,
      homePhoneNumber: this.userProfileList.UserProfile.HomePhone,
      mailingAddress: mailAddress,
      mobileNumber: this.userProfileList.UserProfile.Mobile,
      propertyAddress: propertyAddress,
      workPhoneNumber: this.userProfileList.UserProfile.WorkPhone1,
    }
    this.basicDetails = basicDetail;
  }

  getFullPropertyAddress(): string {
    let propertyAddress = "";
    let fullPropertyAddress = this.userProfileList.AssociationUnit;
    if (fullPropertyAddress !== null) {
      if (fullPropertyAddress.AssociationUnitAddress1 !== null) {
        propertyAddress = fullPropertyAddress.AssociationUnitAddress1 + ",";
      }
      if (fullPropertyAddress.AssociationUnitAddress2 !== null) {
        propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitAddress2;
      }
      if (fullPropertyAddress.AssociationUnitCity !== null) {
        propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitCity;
      }
      if (fullPropertyAddress.AssociationUnitState !== null) {
        propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitState + ",";
      }
      // if (fullPropertyAddress.AssociationUnitCounty !== null) {
      //   propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitCounty;
      // }
      if (fullPropertyAddress.AssociationUnitZip !== null) {
        propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitZip;
      }
    }
    return propertyAddress;
  }

  getFullMailingAddress(): string {
    let fullMailingAddress = this.userProfileList.Address;
    let mailAddress = "";
    if (fullMailingAddress !== null) {
      if (fullMailingAddress.Address1 !== null) {
        mailAddress = fullMailingAddress.Address1 + ",";
      }
      if (fullMailingAddress.Address2 !== null) {
        mailAddress = mailAddress + fullMailingAddress.Address2;
      }
      if (fullMailingAddress.City !== null) {
        mailAddress = mailAddress + " " + fullMailingAddress.City;
      }
      if (fullMailingAddress.State !== null) {
        mailAddress = mailAddress + " " + fullMailingAddress.State + ",";
      }
      // if (fullMailingAddress.County !== null) {
      //   mailAddress = mailAddress + fullMailingAddress.County;
      // }
      if (fullMailingAddress.ZIP !== null) {
        mailAddress = mailAddress + " " + fullMailingAddress.ZIP;
      }
      return mailAddress;
    }
  }

  toGoBack() {
    this._location.back();
  }
}
