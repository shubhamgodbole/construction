import { Component, OnInit, ViewChild } from '@angular/core';
import { LoginApiService } from 'src/app/services/login-api.service';
import { FormBuilder, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { MatStepper, MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { Case, RequestActivationCode } from './sign-up-model';
import { Router } from '@angular/router';
import { ValidationService, ConfirmPasswordValidator } from 'src/app/shared/services/validation.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { CaseTypeEnum, CasePriority, FeatureName, TriggerType, SourceType } from 'src/app/shared/Enums/commonEnums';
import { DisplayPriority, CommonConstant } from 'src/app/shared/common/constant.model';
import { CaseOriginatingType } from '../arc/arc-model';
import { CommonService } from 'src/app/services/common.service';
import { ThankYouComponent } from 'src/app/shared/component/thank-you/thank-you.component';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { AudienceType } from '../board-tasks/board-task.model';
import { Title } from '@angular/platform-browser';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {
  hide = true;
  private unsubscribeAll: Subject<any>;
  notificationService: NotificationService;
  //Confirm Dialog
  //For Delete
  thanksDialogRef: MatDialogRef<ThankYouComponent>;
  resData: any;
  isLinear: boolean = true;
  activationCodeForm: FormGroup;
  secondFormGroup: FormGroup;
  isSelect: boolean = false;
  displayNoActivationCodeForm: boolean = false;
  resitrationInfo = null;
  isIncorectInfo = true;
  incorrectInformationForm: FormGroup;
  incorrectInformationForm1: FormGroup;
  loginForm: FormGroup;
  loginDisable: boolean = false;
  radioIncorrect: string = "continue";
  isActivationCode: boolean = true;
  activationCodeValidate: boolean = false;
  requestActivationForm: FormGroup;
  associationList: any;
  customerTypeForm: FormGroup;
  invalidActivationCode: boolean = false;
  errorMsg: boolean = false;
  isPass: string = "true";
  customerTypes: any;
  isDisabledRequest: boolean = false;
  incorrectInfoBtnDisabled: boolean = false;

  @ViewChild('incorrectInformationFormDirective') incorrectInformationFormDirective: FormGroupDirective;

  @ViewChild('stepper') stepper: MatStepper;


  invalidCodeMessage: string = '';
  incorrectInfo: boolean = false;
  disbaleNextBtn: boolean = false;
  isLoginVisible: boolean = false;
  apiResponseInvalidEmailMsg: string = '';

  @ViewChild('formDirective') formDirective: FormGroupDirective;
  @ViewChild('loginFormDirective') loginFormDirective: FormGroupDirective;
  @ViewChild('formDirective1') formDirective1: FormGroupDirective;

  //msg for password
  invalidPassword = CommonConstant.InvalidPassword;
  invalidConfirmPassword = CommonConstant.InvalidConfirmPassword;

  constructor(private formBuilder: FormBuilder,
    private readonly snb: MatSnackBar,
    private service: LoginApiService,
    private titleService: Title,
    private _matDialog: MatDialog,
    private emailNotification: EmailNotificationService,
    private router: Router) {
    this.unsubscribeAll = new Subject();
    this.notificationService = new NotificationService(snb);
    this.titleService.setTitle(environment.mainTitle);
  }

  ngOnInit() {
    this.createForm();
    this.getMasterData();
  }



  validateActivationCode(stepper: MatStepper) {
    this.invalidCodeMessage = '';
    if (!this.activationCodeForm.controls.activationCode.valid) {
      return;
    }
    this.disbaleNextBtn = true;
    this.service.validateActivationCade(this.activationCodeForm.controls.activationCode.value).subscribe(response => {
      this.resData = response;
      this.disbaleNextBtn = false;
      if (this.resData.Success) {
        this.resitrationInfo = this.resData.UserRegistrationDetails;
        this.activationCodeValidate = true;
        this.invalidCodeMessage = '';
        setTimeout(() => {
          this.goForward(stepper);
        }, 20);
      }
      else {
        this.invalidCodeMessage = "Invalid Activation Code";
      }
    }, error => {

    })
  }

  goForward(stepper: MatStepper) {
    stepper.next();
  }

  createForm() {
    this.activationCodeForm = this.formBuilder.group({
      activationCode: ['', [Validators.required, ValidationService.noWhiteSpace]],
      isActivationCode: ['true'],
      activationCodeValid: ['', [Validators.required]]
    });

    this.customerTypeForm = this.formBuilder.group({
      customerType: ['', Validators.required]
    });

    this.incorrectInformationForm = this.formBuilder.group({
      incorrectRadio: ['', Validators.required],
      email: ['', [Validators.required, ValidationService.emailValidator, Validators.maxLength(30)]],
      comment: ['', [Validators.required, Validators.maxLength(1000), ValidationService.noWhiteSpace]]
    });

    this.incorrectInformationForm1 = this.formBuilder.group({
      incorrectInformationValid: ['', Validators.required]
    });

    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, ValidationService.emailValidator, Validators.maxLength(30)]],
      newPassword: ['', [Validators.required, ValidationService.passwordValidator]],
      confirmPassword: ['', [Validators.required, ConfirmPasswordValidator]]
    });

    // Update the validity of the 'passwordConfirm' field
    // when the 'password' field changes
    this.loginForm.get('newPassword').valueChanges
      .pipe(takeUntil(this.unsubscribeAll))
      .subscribe(() => {
        this.loginForm.get('confirmPassword').updateValueAndValidity();
      });

    this.requestActivationForm = this.formBuilder.group({
      association: ['', [Validators.required, Validators.maxLength(100), ValidationService.noWhiteSpace]],
      firstName: ['', [Validators.required, Validators.maxLength(30), ValidationService.noWhiteSpace]],
      lastName: ['', [Validators.required, Validators.maxLength(30), ValidationService.noWhiteSpace]],
      city: ['', [Validators.required, Validators.maxLength(30), ValidationService.noWhiteSpace]],
      state: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      zipCode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10), ValidationService.noWhiteSpace]],
      address1: ['', [Validators.required, Validators.maxLength(100), ValidationService.noWhiteSpace]],
      address2: ['', [Validators.maxLength(100), Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      email: ['', [Validators.required, ValidationService.emailValidator, Validators.maxLength(30), ValidationService.noWhiteSpace]],
      mobile: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13), ValidationService.noWhiteSpace]]
    });

  }

  setMobileNumber(event) {
    let ctrlValue = this.requestActivationForm.controls.mobile.value;
    if (this.requestActivationForm.controls.mobile.value.length < 10) { }
    else {
      let newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.requestActivationForm.controls.mobile.setValue(newCtrlValue);
    }
    if (event.inputType === 'deleteContentBackward') {
      var format = "()-";
      if (ctrlValue.match(format)) {
        let val = this.requestActivationForm.controls.mobile.value.replace(/[^0-9 ]/g, "");
        this.requestActivationForm.controls.mobile.setValue(val);
      }
      //this.homeWonerForm.controls.phone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
    }
  }

  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }

  changeSteeper(hasCode) {

    if (hasCode.value === "true")
      this.isActivationCode = true;
    else
      this.isActivationCode = false;
  }

  onBackToRequestActivation() {
    this.isActivationCode = true;
    this.activationCodeForm.controls.isActivationCode.setValue('true');
  }

  changeDiv(isIncorectInfo) {
    setTimeout(() => {
      window.scrollTo(0, document.body.scrollHeight);
    }, 10);
    if (isIncorectInfo.value === "true") {
      this.isIncorectInfo = true;
      this.isLoginVisible = true;
      this.incorrectInformationForm.controls.email.setValue('');
      this.incorrectInformationForm.controls.comment.setValue('');
      this.incorrectInformationFormDirective.resetForm();
      this.incorrectInformationForm.controls.incorrectRadio.setValue('true');
    }
    else {
      this.isIncorectInfo = false;
      this.isLoginVisible = false;
    }
  }

  customerType: string
  customerTypeFormValidate() {
    if (!this.customerTypeForm.valid) {
      return
    }
    this.customerType = this.customerTypeForm.controls.customerType.value.Name
  }

  incorrectInfoRequest() {
    if (!this.incorrectInformationForm.valid) {
      return;
    }
    let res;
    let model = this.createIncorrectInfoModel();
    this.incorrectInfoBtnDisabled = false;
    this.service.requestIncorectInfo(model).subscribe(response => {
      res = response;
      this.incorrectInfoBtnDisabled = true;
      if (res.Success) {
        let message = { header: 'Thank You!', content: 'Your request has been sent to our team.', type: 'info' }
        this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
          width: '700px',
          disableClose: false
        });
        this.emailNotification.sendNotifications('', res.RequestId, '', '',
        SourceType.Web, FeatureName.WebsiteAccess, TriggerType.Create,
        AudienceType.HomeOwner).subscribe(res => {
          console.log(res);
        });
        this.thanksDialogRef.componentInstance.data = message;
        this.thanksDialogRef.afterClosed().subscribe(result => {
          this.router.navigate(['/login']);
        });
        this.loginDisable = true;
      }
      else {
        console.log("Invalid Information");
      }
    }, error => {

    })
  }

  requestForActivation() {
    if (!this.requestActivationForm.valid) {
      return
    }
    let res;
    this.displayNoActivationCodeForm = true;
    this.isDisabledRequest = true;
    let model = this.createIncorrectInfoModel();
    this.service.requestIncorectInfo(model).subscribe(response => {
      res = response;
      this.isDisabledRequest = false;
      this.requestResetForm();
      if (res.Success) {
        let message = { header: 'Thank You!', content: 'Your activation code request has been sent to our team..', type: 'activation' }
        this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
          width: '700px',
          disableClose: false
        });
        this.emailNotification.sendNotifications('', res.RequestId, '', '',
        SourceType.Web, FeatureName.WebsiteAccess, TriggerType.Create,
        AudienceType.HomeOwner).subscribe(res => {
          console.log(res);
        });
        this.thanksDialogRef.componentInstance.data = message;
        this.thanksDialogRef.afterClosed().subscribe(result => {
          this.router.navigate(['/login']);
        });
        this.loginDisable = true;
      }
      else {
        this.notificationService.showNotification("Your information is incorrect");
      }
    }, error => {

    })
  }


  createIncorrectInfoModel() {
    const associationName = this.requestActivationForm.controls.association.value !== null ? this.requestActivationForm.controls.association.value : null;
    const associationId = null;
    const resAssociationName = this.resitrationInfo != null ? this.resitrationInfo.AssociationName : null;
    const resAssociationId = this.resitrationInfo != null ? this.resitrationInfo.id : null;
    const unitNumber = this.resitrationInfo != null ? this.resitrationInfo.UnitNumber : null;
    const add1 = this.resitrationInfo != null ? this.resitrationInfo.UnitAddress1 : null;
    const add2 = this.resitrationInfo != null ? this.resitrationInfo.UnitAddress2 : null;
    const city = this.resitrationInfo != null ? this.resitrationInfo.UnitCity : null;
    const state = this.resitrationInfo != null ? this.resitrationInfo.UnitState : null;
    const mobile = this.resitrationInfo != null ? this.resitrationInfo.mobile : null;
    const zip = this.resitrationInfo != null ? this.resitrationInfo.UnitZip : null;
    const _case: Case =
    {
      Title: this.displayNoActivationCodeForm ? 'Request For Activation Code' : "Incorrect User Information",
      Description: this.displayNoActivationCodeForm ? '' : this.incorrectInformationForm.controls.comment.value,
      CustomerType: this.displayNoActivationCodeForm ? this.customerTypeForm.controls.customerType.value.Name : "Association",
      AssociationName: this.displayNoActivationCodeForm ? associationName : resAssociationName,
      AssociationId: this.displayNoActivationCodeForm ? associationId : resAssociationId,
      CaseType: CaseTypeEnum.Homeowners,
      CaseCategory: 'Website Access',
      CaseSubCategory: 'Registration / Access Code',
      CasePriority: CasePriority.High,
      CaseOriginatingType: CaseOriginatingType.Website,
      CreatedByUserId: '',
      SubCaseType: '',
      FirstName: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.firstName.value : '',
      LastName: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.lastName.value : '',
      Email: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.email.value : ''
    }

    const model: RequestActivationCode = {
      AssociationName: this.displayNoActivationCodeForm === true ? associationName : resAssociationName,
      UnitNumber: this.displayNoActivationCodeForm ? null : unitNumber,
      Address1: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.address1.value : add1,
      Address2: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.address2.value : add2,
      City: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.city.value : city,
      State: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.state.value : state,
      Zip: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.zipCode.value : zip,
      Mobile: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.mobile.value : mobile,
      Case: _case,
      Email: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.email.value : this.incorrectInformationForm.controls.email.value,
    }
    return model;
  }

  createLogin() {
    if (!this.loginForm.valid) {
      return;
    }
    if (this.apiResponseInvalidEmailMsg !== '') {
      return;
    }
    let res;
    this.service.registration(this.loginForm.value.email, this.loginForm.value.newPassword, this.loginForm.value.confirmPassword, this.activationCodeForm.controls.activationCode.value).subscribe(response => {
      res = response;
      if (res.Success) {
        let message = { header: 'Congratulations !', content: 'Your Account is ready to go...', type: 'login' }
        this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
          width: '700px',
          disableClose: false
        });
        this.thanksDialogRef.componentInstance.data = message;
        this.thanksDialogRef.afterClosed().subscribe(result => {
          this.router.navigate(['/login']);
        });
        this.loginDisable = true;
        this.emailNotification.sendNotifications('', res.RequestId, '', '',
          SourceType.Web, FeatureName.Registration, TriggerType.Create,
          AudienceType.HomeOwner).subscribe(res => {
            console.log(res);
          });
      }
      else {
        this.resetLoginForm();
        let message = { header: 'Invalid Info !', content: 'Your Information is Invalid', type: 'info' }
        this.loginDisable = true;
        this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
          width: '400px',
          disableClose: false
        });
        this.thanksDialogRef.componentInstance.data = message;
      }
    },
      (err) => {
        console.log(err);
      });
  }

  resetLoginForm() {
    this.loginForm.controls.newPassword.setErrors(null);
    this.loginForm.controls.confirmPassword.setErrors(null);
    this.loginForm.clearValidators();
    this.loginForm.reset();
    this.loginFormDirective.resetForm();
  }

  getMasterData() {
    let res;
    this.service.getMasterData().subscribe(response => {
      res = response;
      if (res.Success) {
        this.associationList = res.GetMasterDataForActivationCode.Association;
        this.customerTypes = res.GetMasterDataForActivationCode.CustomerType;
        this.customerTypes = this.customerTypes.filter(x => x.Name === "Association");
        var c = this.customerTypes.find(x => x.Name === "Association");
        this.customerTypeForm.controls.customerType.setValue(c);
      }
      else
        console.log(res.Errors[0].message);
    },
      (err) => {
        console.log(err);
      });
  }

  requestResetForm() {
    this.requestActivationForm.reset();
    this.formDirective1.resetForm();
  }

  onCancel() {
    this.stepper.reset();
    var c = this.customerTypes.find(x => x.Name == this.customerType);
    this.customerTypeForm.controls.customerType.setValue(c);
  }

  checkEmailAvailability() {
    console.log(this.loginForm.controls.email.value);
    this.service.checkEmailAvailability(this.loginForm.controls.email.value).subscribe((response: any) => {
      console.log('res ', response);
      if (response.Success === false) {
        this.apiResponseInvalidEmailMsg = "Email is already exist"
      } else {
        this.apiResponseInvalidEmailMsg = '';
      }
    });
  }
  isRadio() {
    if (this.incorrectInformationForm.value.incorrectRadio === null || this.incorrectInformationForm.value.incorrectRadio === undefined || this.incorrectInformationForm.value.incorrectRadio === "")
      return true;
    else
      return false;
  }

  disbaleEyeIcon() {
    if (this.loginForm.value.newPassword !== null && this.loginForm.value.newPassword !== undefined && this.loginForm.value.newPassword !== '') {
      this.hide = !this.hide
      return false;
    } else {
      //this.hide = false;
      return true;
    }
  }
}
