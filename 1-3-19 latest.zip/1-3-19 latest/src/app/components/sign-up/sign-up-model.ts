export class RequestActivationCode
{
    AssociationName: string;
    Email: string;
    Mobile: string;
    UnitNumber: string;
    Address1: string;
    Address2: string;
    City: string;
    State: string;
    Zip: string;
    Case: Case;
}

export class Case{
    Title: string;
    Description: string;
    AssociationName: string;
    CustomerType: string;
    CaseType: string;
    CaseCategory: string;
    CaseSubCategory: string;
    AssociationId: string;
    CasePriority: string;
    CaseOriginatingType: string;
    CreatedByUserId: string;
    SubCaseType: string;
    FirstName: string;
    LastName: string;
    Email: string;
}
