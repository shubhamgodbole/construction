import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignUpComponent } from './sign-up.component';
import { SignUpRoutingModule } from './sign-up-routing.module';
import { MatInputModule, MatSelectModule, MatRadioModule, MatStepperModule, MatIconModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule } from '@angular/material';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { OnlyAlphabetsModule } from 'src/app/shared/directives/allow-only-alphabets/only-alphabets.module';

@NgModule({
  imports: [
    CommonModule,
    SignUpRoutingModule,
    MatInputModule,
    NumberOnlyDirectiveModule,
    MatSelectModule,
    MatRadioModule,
    MatStepperModule,
    MatIconModule,
    MatDatetimepickerModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    FormsModule,
    OnlyAlphabetsModule
  ],
  declarations: [SignUpComponent]
})
export class SignUpModule { }
