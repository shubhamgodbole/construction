import { Component, OnInit, ViewChild } from '@angular/core';
import { LoginApiService } from 'src/app/services/login-api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription, Subject } from 'rxjs';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { ValidationService, ConfirmPasswordValidator } from 'src/app/shared/services/validation.service';
import { takeUntil } from 'rxjs/operators';
import { CommonConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.scss']
})
export class UpdatePasswordComponent implements OnInit {

  password: any;
  resData: any;
  querySubcription: Subscription;
  token: any;
  // Private
  private unsubscribeAll: Subject<any>;
  updateSuccess: boolean = false;
  updatePasswordForm: FormGroup;

  hide = true;

  //msg for password
  invalidPassword = CommonConstant.InvalidPassword;
  invalidConfirmPassword = CommonConstant.InvalidConfirmPassword;

  @ViewChild('formDirective') formDirective: FormGroupDirective;
  constructor(private service: LoginApiService, private router: Router, private route: ActivatedRoute, private formBuilder: FormBuilder) {
    this.unsubscribeAll = new Subject();
  }

  ngOnInit() {
    this.updatePasswordForm = this.formBuilder.group({
      newPassword: ['', [Validators.required, ValidationService.passwordValidator]],
      confirmPassword: ['', [Validators.required, ConfirmPasswordValidator]],
    });

    // Update the validity of the 'passwordConfirm' field
    // when the 'password' field changes
    this.updatePasswordForm.get('newPassword').valueChanges
      .pipe(takeUntil(this.unsubscribeAll))
      .subscribe(() => {
        this.updatePasswordForm.get('confirmPassword').updateValueAndValidity();
      });

    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["token"];
      if (id) {
        this.token = id;
      }
      else {
        this.router.navigate(['/error']);
      }
    });
  }

  updatePassword() {
    //this.password=password;
    if (this.updatePasswordForm.valid) {
      let password = this.updatePasswordForm.controls.newPassword.value;
      this.service.updatePassword(password, this.token).subscribe(response => {
        this.resData = response;
        if (this.resData.Success) {
          this.updateSuccess = true;
        }
        // this.router.navigate(['/login']);
      }, error => {

      })
    }

  }

}
