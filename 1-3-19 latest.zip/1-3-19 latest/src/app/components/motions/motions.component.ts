import { Component, OnInit, ViewChild } from '@angular/core';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Router, NavigationExtras } from '@angular/router';
import { UserData } from 'src/app/shared/models/user-data-model';
import { MotionApiService } from 'src/app/services/motion-api.service';
import { RoleEnum, NoDataFoundCaseFeatureName, MasterPaginationEnum, Pagination, SubCaseTypeEnum, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { MatPaginator } from '@angular/material';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { CommonService } from 'src/app/services/common.service';
import { AppConfig } from 'src/app/app.config';

@Component({
  selector: 'app-motions',
  templateUrl: './motions.component.html',
  styleUrls: ['./motions.component.scss']
})
export class MotionsComponent implements OnInit {

  isApiResponseCome: boolean = false;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  /*local storage value*/
  associationId: string;
  userData: UserData;
  role: string = "";

  motionList: any;

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  globalAssociationModel: GlobalAssociationModel;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  isApiResponceCome = false;
  constructor(private progressbarService: ProgeressBarService,
    private globalAssociationService: GlobalAssociationService,
    public commonService: CommonService,
    private readonly appConfig: AppConfig,
    private motionApiService: MotionApiService,
    private _router: Router) {
    this.userData = this.appConfig.getCurrentUser();
    this.role = this.userData.Role;
  }

  ngOnInit() {
    this.globalAssociationService.associationSubject.subscribe(res => {
      this.globalAssociationModel = res;
      if (res !== 1) {
        this.getData();
      }
    });
  }

  getData() {
    let resData;
    this.progressbarService.show();
    this.setMasterOfPagination();
    this.motionApiService.getMotionList(this.globalAssociationModel.AssociationId).subscribe(res => {
      resData = res;
      this.isApiResponceCome = true;
      this.progressbarService.hide();
      this.isApiResponseCome = true;
      if (resData.Success === true) {
        this.motionList = resData.MotionsList;
        console.log(this.motionList);
        if (this.motionList !== null) {
          this.setPaginationData(this.motionList);
        }
      } else {
        console.log("api errors");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(motionList) {
    this.TotalRecord = motionList.length;
    var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    this.FilterArray = motionList.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    var pageStartIndex = (clickObj.pageIndex * clickObj.pageSize) + 1;
    var pageEndIndex = (clickObj.pageIndex * clickObj.pageSize) + clickObj.pageSize;
    this.FilterArray = this.motionList.slice(pageStartIndex - 1, pageEndIndex);
  }

  getMotionDetails(detailId, requestType) {
    console.log("detailId", detailId);
    if (detailId !== "" && detailId !== null && detailId !== undefined) {
      this.motionApiService.detailId = detailId;
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": detailId,
        }
      };
      console.log("requestType", requestType);
      this.commonService.setDataInLocalStorge(AppRouteUrl.mainMotionsRouteUrl);
      if (this.role === RoleEnum.PropertyManager) {
        if (SubCaseTypeEnum.ServiceRequest === requestType) {
          this._router.navigate([AppRouteUrl.mainServiceRequestDetailPMRouteUrl], navigationExtras);
        } else {
          this._router.navigate([AppRouteUrl.mainBoardTasksDeatilPMRouteUrl], navigationExtras);
        }
      } else {
        if (SubCaseTypeEnum.ServiceRequest === requestType) {
          this._router.navigate([AppRouteUrl.mainServiceRequestDetailBMRouteUrl], navigationExtras);
        } else {
          this._router.navigate([AppRouteUrl.mainBoardTasksDeatilBMRouteUrl], navigationExtras);

        }
      }
    }
  }

}

