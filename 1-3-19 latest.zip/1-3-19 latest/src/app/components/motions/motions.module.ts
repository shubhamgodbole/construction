import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MotionsComponent } from './motions.component';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { MatTooltipModule, MatPaginatorModule } from '@angular/material';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
const routes: Routes = [
  {
    path: '',
    component: MotionsComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    MatTooltipModule,
    MatPaginatorModule,
    NoCaseNoteFoundModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [MotionsComponent]
})
export class MotionsModule { }
