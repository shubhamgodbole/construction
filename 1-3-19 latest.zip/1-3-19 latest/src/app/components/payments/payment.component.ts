import { Component, OnInit } from '@angular/core';
import { DisplayMonth } from 'src/app/shared/common/constant.model';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { DropdownModel } from 'src/app/shared/common/models';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { PaymentSubjectModel } from './payments.model';
import { FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  resData: any;
  balanceSheetList: any;
  filterbalanceSheetList: any;
  yearList = new Array<DropdownModel>();
  selectedYear: string = new Date().getFullYear().toString();
  currMonth = new Date().getMonth() + 1;
  selectedMonth: string = this.currMonth.toString();
  monthNameDdl: any;
  filterMonthNameDdl: any;
  //Route Url
  incomeSheetUrl: string = AppRouteUrl.mainIncomeStatementReportRouteUrl;
  balanceSheetUrl: string = AppRouteUrl.mainBalanceSheetReportRouteUrl;
  prePaymentSheetUrl: string = AppRouteUrl.mainPrepaymentReportRouteUrl;
  delinquencyUrl: string = AppRouteUrl.mainDelinquencyReportRouteUrl;
  generalUrl: string = AppRouteUrl.mainGeneralLedgerRouteUrl;
  constructor(private paymentsApiService: PaymentsApiService,
    public commonService: CommonService
  ) {
    this.monthNameDdl = DisplayMonth.monthList;
    this.yearList = this.paymentsApiService.getYearDropDownList();
  }

  ngOnInit() {
    this.setMonthByCurrYear();
    let paymentModel: PaymentSubjectModel = {
      SelectedYear: this.selectedYear,
      SelectedMonth: this.selectedMonth
    };
    this.paymentsApiService.paymentSubject.next(paymentModel);
  }

  getDatabyMonth(monthValue) {
    this.selectedMonth = monthValue;
    let paymentModel: PaymentSubjectModel = {
      SelectedYear: this.selectedYear,
      SelectedMonth: this.selectedMonth
    };
    this.paymentsApiService.paymentSubject.next(paymentModel);
  }

  getDatabyYear() {
    let paymentModel: PaymentSubjectModel = {
      SelectedYear: this.selectedYear,
      SelectedMonth: this.selectedMonth
    };
    this.setMonthByCurrYear();
    this.paymentsApiService.paymentSubject.next(paymentModel);   
  }

  setMonthByCurrYear() {
    if (this.selectedYear === new Date().getFullYear().toString()) {
      this.filterMonthNameDdl = this.monthNameDdl.filter(a => {
        return +a.value <= +this.selectedMonth;
      });
      console.log(this.filterMonthNameDdl);
    } else {
      this.filterMonthNameDdl = this.monthNameDdl;
    }

  }
}

