export class PaymentSubjectModel {
    SelectedMonth: string;
    SelectedYear: string;
}
export class BalanceSheetReportModel {
    accountHeaderModel: AccountHeaderModel[];
}
export class AccountHeaderModel {
    header: string;
    accountSubHeaderModel: AccountSubHeaderModel[];
    total: TotalModel
}
export class AccountSubHeaderModel {
    subHeader: string;
    accountDetailsList: AccountDetailsModel[]
}
export class AccountDetailsModel {
    accountMain: string;
    accountName: string;
    operatingMST: string;
    reserveMST: string;
    totalMST: string
}
export class TotalModel {
    operatingMST: string;
    reserveMST: string;
    totalMST: string
}

const monthInterval = '0';
export class DisplayMonthInterval {
    public static monthInterval: string = monthInterval;
}

export enum CustomerAging {
    Current = "Current",
    SecondMonth = "SecondMonth",
    ThirdMonth = "ThirdMonth",
    Over90 = "Over90",
    BalanceAsOf = "BalanceAsOf"
}
