import { Component, OnInit } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { DropdownModel } from 'src/app/shared/common/models';
import { DisplayMonth } from 'src/app/shared/common/constant.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { PaymentSubjectModel, DisplayMonthInterval } from '../payments.model';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { AppConfig } from 'src/app/app.config';
import { NoDataFoundCaseFeatureName, RoleEnum } from 'src/app/shared/Enums/commonEnums';

@Component({
  selector: 'app-income-sheet',
  templateUrl: './income-sheet.component.html',
  styleUrls: ['./income-sheet.component.scss']
})
export class IncomeSheetComponent implements OnInit {
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  /*localstorage data*/
  userData: UserData;
  companyCode: string;
  role: string = "";

  globalAssociationModel: GlobalAssociationModel;
  paymentSubjectModel: PaymentSubjectModel;

  incomeSheetList: any;
  filterIncomeSheetList: any;

  isApiResponceCome = false;


  constructor(private paymentsApiService: PaymentsApiService,
    private globalAssociationService: GlobalAssociationService,
    private progressbarService: ProgeressBarService,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    this.role = this.userData.Role;

  }

  ngOnInit() {
    if (this.role === RoleEnum.PropertyManager) {
      this.globalAssociationService.associationSubject.subscribe(res => {
        this.globalAssociationModel = res;
        this.paymentsApiService.paymentSubject.subscribe(resPayment => {
          this.paymentSubjectModel = resPayment;
          this.getData();
        });
      });

      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.globalAssociationService.associationSubject.subscribe(res => {
          this.globalAssociationModel = res;
          this.getData();
        });
      });
    } else {
      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.getData();
      });
    }
  }
  getData() {
    let incomeSheetReport = {
      "Year":  this.paymentSubjectModel.SelectedYear, //'2006',//
      "Month":  this.paymentSubjectModel.SelectedMonth, //'12',//
      "MonthInterval": DisplayMonthInterval.monthInterval,
      "Association":  this.role === RoleEnum.PropertyManager ? this.globalAssociationModel.CompanyCode : this.companyCode 
    };
    let resData;
    this.progressbarService.show();
    this.paymentsApiService.getIncomeSheet(incomeSheetReport).subscribe(res => {
      this.progressbarService.hide();    
      this.isApiResponceCome = true;  
      resData = res;
      console.log("IncomeSheetresData", resData);
      if (resData.Errors.length === 0) {
        this.incomeSheetList = resData.IncomeSheetReport.AccountHeaderList;
        this.filterIncomeSheetList = resData.IncomeSheetReport.AccountHeaderList;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }
}
