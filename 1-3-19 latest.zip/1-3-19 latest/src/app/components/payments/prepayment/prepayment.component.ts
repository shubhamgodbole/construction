import { Component, OnInit } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { DisplayMonth } from 'src/app/shared/common/constant.model';
import { DropdownModel } from 'src/app/shared/common/models';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { DisplayMonthInterval, PaymentSubjectModel, CustomerAging } from '../payments.model';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NoDataFoundCaseFeatureName, RoleEnum } from 'src/app/shared/Enums/commonEnums';

@Component({
  selector: 'app-prepayment',
  templateUrl: './prepayment.component.html',
  styleUrls: ['./prepayment.component.scss']
})
export class PrepaymentComponent implements OnInit {
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  /*localstorage data*/
  userData: UserData;
  companyCode: string;
  role: string = "";


  prepaymentSheetList: any;
  filterprepaymentList: any;

  globalAssociationModel: GlobalAssociationModel;
  paymentSubjectModel: PaymentSubjectModel;

  customerAgingEnum = CustomerAging;
  resData: any;  
  isApiResponceCome = false;
  constructor(private paymentsApiService: PaymentsApiService,
    private globalAssociationService: GlobalAssociationService,
    private progressbarService: ProgeressBarService,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.role = this.userData.Role;
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
  }


  ngOnInit() {
    if (this.role === RoleEnum.PropertyManager) {
      this.globalAssociationService.associationSubject.subscribe(res => {
        this.globalAssociationModel = res;
        this.paymentsApiService.paymentSubject.subscribe(resPayment => {
          this.paymentSubjectModel = resPayment;
          this.getData();
        });
      });

      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.globalAssociationService.associationSubject.subscribe(res => {
          this.globalAssociationModel = res;
          this.getData();
        });
      });
    } else {
      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.getData();
      });
    }
  }

  getData() {
    let customerAgingReport = {
      "Year": this.paymentSubjectModel.SelectedYear,
      "Month": this.paymentSubjectModel.SelectedMonth,
      "MonthInterval": DisplayMonthInterval.monthInterval,
      "Association": this.role === RoleEnum.PropertyManager ? this.globalAssociationModel.CompanyCode : this.companyCode 
    };
    let resData;
    this.progressbarService.show();
    this.paymentsApiService.getPrePayment(customerAgingReport).subscribe(res => {
      this.progressbarService.hide();
      this.isApiResponceCome = true;
      console.log("resData prepayment", res);
      this.resData = res;
      if (this.resData.Errors.length === 0) {
        this.prepaymentSheetList = this.resData.CustomerAgingReport.ReportDetailList;
        this.filterprepaymentList = this.resData.CustomerAgingReport.ReportDetailList;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }


}

