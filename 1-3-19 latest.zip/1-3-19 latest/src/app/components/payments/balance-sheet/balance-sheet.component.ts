import { Component, OnInit } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { BalanceSheetReportModel, AccountHeaderModel, AccountSubHeaderModel, AccountDetailsModel, PaymentSubjectModel, DisplayMonthInterval } from '../payments.model';
import { DropdownModel } from 'src/app/shared/common/models';
import { DisplayMonth } from 'src/app/shared/common/constant.model';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NoDataFoundCaseFeatureName, RoleEnum } from 'src/app/shared/Enums/commonEnums';

@Component({
  selector: 'app-balance-sheet',
  templateUrl: './balance-sheet.component.html',
  styleUrls: ['./balance-sheet.component.scss']
})
export class BalanceSheetComponent implements OnInit {
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  /*localstorage data*/
  userData: UserData;
  companyCode: string;
  role: string = "";


  balanceSheetList: any;
  filterbalanceSheetList: any;
  globalAssociationModel: GlobalAssociationModel;
  paymentSubjectModel: PaymentSubjectModel;

  isApiResponceCome = false;
  constructor(private paymentsApiService: PaymentsApiService,
    private globalAssociationService: GlobalAssociationService,
    private progressbarService: ProgeressBarService,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.role = this.userData.Role;
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
  }

  ngOnInit() {
    if (this.role === RoleEnum.PropertyManager) {
      this.globalAssociationService.associationSubject.subscribe(res => {
        this.globalAssociationModel = res;
        this.paymentsApiService.paymentSubject.subscribe(resPayment => {
          this.paymentSubjectModel = resPayment;
          this.getData();
        });
      });

      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.globalAssociationService.associationSubject.subscribe(res => {
          this.globalAssociationModel = res;
          this.getData();
        });
      });
    } else {
      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.getData();
      });
    }
  }

  getData() {
    let balanceSheetReport = {
      "Year": this.paymentSubjectModel.SelectedYear,//'2006',
      "Month": this.paymentSubjectModel.SelectedMonth, //'12',//
      "MonthInterval": DisplayMonthInterval.monthInterval,
      "Association": this.role === RoleEnum.PropertyManager ? this.globalAssociationModel.CompanyCode : this.companyCode //this.companyCode 
    };
    console.log("balanceSheetReport", balanceSheetReport);
    let resData;
    this.progressbarService.show();
    this.paymentsApiService.getBalanceSheet(balanceSheetReport).subscribe(res => {
      this.progressbarService.hide();
      this.isApiResponceCome = true;
      resData = res;
      console.log("resData", resData);
      if (resData.Errors.length === 0) {
        this.balanceSheetList = resData.BalanceSheetReport.AccountHeaderList;
        this.filterbalanceSheetList = resData.BalanceSheetReport.AccountHeaderList;
      } else {
        this.balanceSheetList = [];
        this.filterbalanceSheetList = [];
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }
}
