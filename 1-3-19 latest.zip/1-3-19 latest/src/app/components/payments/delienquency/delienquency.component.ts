import { Component, OnInit } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { DropdownModel } from 'src/app/shared/common/models';
import { AppConfig } from 'src/app/app.config';
import { DisplayMonth } from 'src/app/shared/common/constant.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { PaymentSubjectModel, DisplayMonthInterval, CustomerAging } from '../payments.model';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NoDataFoundCaseFeatureName, RoleEnum } from 'src/app/shared/Enums/commonEnums';

@Component({
  selector: 'app-delienquency',
  templateUrl: './delienquency.component.html',
  styleUrls: ['./delienquency.component.scss']
})
export class DelienquencyComponent implements OnInit {
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  /*localstorage data*/
  userData: UserData;
  companyCode: string;
  role: string = "";

  globalAssociationModel: GlobalAssociationModel;
  paymentSubjectModel: PaymentSubjectModel;

  delienquencySheetList: any;
  filterDelienquencyList: any;
  customerAgingEnum = CustomerAging;
  resData :any;

  isApiResponceCome = false;
  constructor(private paymentsApiService: PaymentsApiService,
    private globalAssociationService: GlobalAssociationService,
    private progressbarService: ProgeressBarService,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    this.role = this.userData.Role;

  }

  ngOnInit() {
    if (this.role === RoleEnum.PropertyManager) {
      this.globalAssociationService.associationSubject.subscribe(res => {
        this.globalAssociationModel = res;
        this.paymentsApiService.paymentSubject.subscribe(resPayment => {
          this.paymentSubjectModel = resPayment;
          this.getData();
        });
      });

      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.globalAssociationService.associationSubject.subscribe(res => {
          this.globalAssociationModel = res;
          this.getData();
        });
      });
    } else {
      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.getData();
      });
    }
  }

  getData() {
    let customerAgingReport = {
      "Year": this.paymentSubjectModel.SelectedYear,
      "Month": this.paymentSubjectModel.SelectedMonth,
      "MonthInterval": DisplayMonthInterval.monthInterval,
      "Association": this.role === RoleEnum.PropertyManager ? this.globalAssociationModel.CompanyCode : this.companyCode 
    };
  
    this.progressbarService.show();
    this.paymentsApiService.getDeliquency(customerAgingReport).subscribe(res => {
      this.progressbarService.hide();
      this.isApiResponceCome = true;
      this.resData = res;
      if (this.resData.Errors.length === 0) {
        this.delienquencySheetList = this.resData.CustomerAgingReport.ReportDetailList;
        this.filterDelienquencyList = this.resData.CustomerAgingReport.ReportDetailList;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }
}
