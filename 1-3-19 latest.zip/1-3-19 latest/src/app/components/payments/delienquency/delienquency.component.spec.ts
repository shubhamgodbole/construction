import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DelienquencyComponent } from './delienquency.component';

describe('DelienquencyComponent', () => {
  let component: DelienquencyComponent;
  let fixture: ComponentFixture<DelienquencyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DelienquencyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DelienquencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
