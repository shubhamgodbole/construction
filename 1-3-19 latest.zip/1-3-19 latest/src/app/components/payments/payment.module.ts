import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MatListModule, MatSelectModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatIconModule, MatInputModule, MatDialogModule, MatStepperModule, MatSliderModule, MatFormFieldModule, MatSlideToggleModule, MatSnackBarModule, MatTableModule, MatRadioModule, MatTooltipModule, MatDatepickerModule } from '@angular/material';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { PaymentComponent } from './payment.component';
import { BalanceSheetComponent } from './balance-sheet/balance-sheet.component';
import { IncomeSheetComponent } from './income-sheet/income-sheet.component';
import { PrepaymentComponent } from './prepayment/prepayment.component';
import { DelienquencyComponent } from './delienquency/delienquency.component';
import { GeneralLedgerComponent } from './general-ledger/general-ledger.component';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
const routes: Routes = [
  {
    path: '',
    component: PaymentComponent,
    children: [
      { path: '', redirectTo: AppRouteUrl.balanceSheetReportRouteUrl },
      { path: AppRouteUrl.balanceSheetReportRouteUrl , component: BalanceSheetComponent },
      { path: AppRouteUrl.incomeStatementReportRouteUrl, component: IncomeSheetComponent },
      { path: AppRouteUrl.prepaymentReportRouteUrl, component: PrepaymentComponent },
      { path: AppRouteUrl.delinquencyReportRouteUrl, component: DelienquencyComponent },
      { path: AppRouteUrl.generalLedgerRouteUrl, component: GeneralLedgerComponent }
    ]
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatListModule,
    MatSelectModule,
    MatBottomSheetModule,
    NoDataFoundModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatDatetimepickerModule,
    MatIconModule,
    MatInputModule,
    MatDialogModule,
    MatStepperModule,
    MatSliderModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatTableModule,
    MatRadioModule,
    MatTooltipModule,
    NumberOnlyDirectiveModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    FormsModule,
    HideIfUnauthorizedModule,
    RouterModule.forChild(routes)
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [PaymentComponent,GeneralLedgerComponent,IncomeSheetComponent, BalanceSheetComponent, PrepaymentComponent, DelienquencyComponent, PaymentComponent ]
})
export class PaymentModule { }
