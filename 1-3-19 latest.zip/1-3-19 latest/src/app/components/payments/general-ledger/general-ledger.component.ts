import { Component, OnInit } from '@angular/core';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { PaymentSubjectModel, DisplayMonthInterval } from '../payments.model';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { AppConfig } from 'src/app/app.config';
import { NoDataFoundCaseFeatureName, RoleEnum } from 'src/app/shared/Enums/commonEnums';

@Component({
  selector: 'app-general-ledger',
  templateUrl: './general-ledger.component.html',
  styleUrls: ['./general-ledger.component.scss']
})
export class GeneralLedgerComponent implements OnInit {
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  /*localstorage data*/
  userData: UserData;
  companyCode: string;
  role: string = "";

  globalAssociationModel: GlobalAssociationModel;
  paymentSubjectModel: PaymentSubjectModel;

  generalLedgerSheetList: any;
  filterGeneralLedgerList: any;

  isApiResponceCome = false;
  constructor(private paymentsApiService: PaymentsApiService,
    private globalAssociationService: GlobalAssociationService,
    private progressbarService: ProgeressBarService,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    this.role = this.userData.Role;

  }

  ngOnInit() {
    if (this.role === RoleEnum.PropertyManager) {
      this.globalAssociationService.associationSubject.subscribe(res => {
        this.globalAssociationModel = res;
        this.paymentsApiService.paymentSubject.subscribe(resPayment => {
          this.paymentSubjectModel = resPayment;
          this.getData();
        });
      });

      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.globalAssociationService.associationSubject.subscribe(res => {
          this.globalAssociationModel = res;
          this.getData();
        });
      });
    } else {
      this.paymentsApiService.paymentSubject.subscribe(resPayment => {
        this.paymentSubjectModel = resPayment;
        this.getData();
      });
    }
  }

  getData() {
    let GenralLedgerReport = {
      "Year": this.paymentSubjectModel.SelectedYear,
      "Month": this.paymentSubjectModel.SelectedMonth,
      "MonthInterval": DisplayMonthInterval.monthInterval,
      "Association":  this.role === RoleEnum.PropertyManager ? this.globalAssociationModel.CompanyCode : this.companyCode 
    };
    let resData;
    this.progressbarService.show();
    this.paymentsApiService.getGeneralLedger(GenralLedgerReport).subscribe(res => {
      this.progressbarService.hide();
      this.isApiResponceCome = true;
      console.log("paymentsres",res);
      resData = res;
      if (resData.Errors.length === 0) {
        this.generalLedgerSheetList = resData.GenralLedgerReport.GenralLedgerList;
        console.log("this.generalLedgerSheetList",this.generalLedgerSheetList);
        this.filterGeneralLedgerList = resData.GenralLedgerReport.GenralLedgerList;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

}
