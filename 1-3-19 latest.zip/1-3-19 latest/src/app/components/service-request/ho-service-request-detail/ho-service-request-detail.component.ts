import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { CaseNoteModel, CaseFeatureType, ServiceRequestStatus, UpdateServiceRequestStatus, MotionModel, RequestMsg } from '../service-request.model';
import { Router, ActivatedRoute } from '@angular/router';

import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { TypeOfDocument, CaseOriginatingType, IsAuthorized, ImageNameEnums, RoleEnum, NoteType, DownloadfeatureName, FeatureName, StatusReason, DocumentFeatureName, AudienceType, SourceType, TriggerType, CallType, ActivityType, PlaceHolderText, VoteStatus, FeaturePermissions, EmailAudience } from 'src/app/shared/Enums/commonEnums';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { RateAndReviewDialogComponent } from 'src/app/shared/component/rate-and-review-dialog/rate-and-review-dialog.component';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonConstant, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { Guid } from 'guid-typescript';
import { AuthService } from 'src/app/services/auth.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-ho-service-request-detail',
  templateUrl: './ho-service-request-detail.component.html',
  styleUrls: ['./ho-service-request-detail.component.scss']
})
export class HoServiceRequestDetailComponent implements OnInit {
  propVivoName = CommonConstant.PropVivo;
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  notificationService: NotificationService;
  //Confirm Dialog
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  //For Query string;
  querySubcription: Subscription;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;

  isAuthorized = IsAuthorized;
  caseOriginatingType = CaseOriginatingType;
  requestId: string;
  serviceRequestData: any;
  documents: any;
  caseNotes: any;
  cancleServiceRequestForm: FormGroup;
  serviceRequestStatusEnum = ServiceRequestStatus;
  fileData = [];
  associationId: string;
  typeOfDocument = TypeOfDocument.CaseDocuments; //"CaseDocuments";
  domain: string = "";
  userId: string = "";
  userName: string = "";
  associationName: string = "";
  //Enums
  noteTypeEnums = NoteType;

  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;
  editBtnDisable: boolean = false;

  isComponentLoad: boolean = false;
  serviceRequestStatus: string = "";
  userData: UserData;
  role: string;
  shoNDocs: any = 3;
  viewDocs: boolean = false;
  viwAllDocBtnMsg: string = "View All Attachments";
  readMoreBtn: boolean = false;
  readMoreDescBtnMsg: string = "Read More";
  desLimit: number = 160;
  addEsclateForm: FormGroup;
  profilePath: string = "";


  //requestMsg enum 
  requestMsgEnum = RequestMsg

  //for chat list
  caseNoteList
  decisionReason
  hocaseNotes
  allChat
  displayDiv: boolean

  /*Case Note Form*/
  frmCreateCaseNote: FormGroup;
  isSubmitBtnDisabled: boolean = false;
  resDataCreate: any;
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;

  /*Cancel Form*/
  frmCancel: FormGroup;
  isSubmitBtnDisabledCancel: boolean = false;
  @ViewChild('formDirectiveCancel') formDirectiveCancel: FormGroupDirective;

  /*Reopen Form*/
  frmCreateReopen: FormGroup;
  isSubmitBtnDisabledReopen: boolean = false;
  resDataCreateReopen: any;
  @ViewChild('formDirectiveReopen') formDirectiveReopen: FormGroupDirective;
  isCommentAndReopen: boolean = true;

  //for Preview
  isDocumentDetails: boolean
  documentDetails;
  fileURL;

  reasonType: string = '';

  statusReasonEnum = StatusReason;
  VoteStatusEnum = VoteStatus;

  /*ReviewAndRating Form*/
  frmCreateReviewAndRating: FormGroup;
  isSubmitBtnDisabledReviewAndRating: boolean = false;
  resDataCreateReviewAndRating: any;
  rate = 0;
  isRateButtonShow: boolean = false;
  @ViewChild('formDirectiveReviewAndRating') formDirectiveReviewAndRating: FormGroupDirective;
  //rateData:number =0;
  countRating: number = 0;
  dialogRef: any;
  /**Motion vote */
  resDataCreateMotionVote: any;
  isDisplayVoteList: boolean = false;
  isDisplayEscalatVoteList: boolean = false;

  MobActoin = false;
  MobDetail = false;
  MobChat = false;

  //For Send Notification
  featureId: string;
  pmCompanyAssociationMappingId: string;
  featureName: string;

  callTypeEnum = CallType;
  activityTypeEnum = ActivityType;

  placeHolderText = PlaceHolderText;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;


  constructor(private service: ServiceRequestService,
    private progressbarService: ProgeressBarService,
    private ngZone: NgZone,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private _location: Location,
    private router: Router,
    private _matDialog: MatDialog,
    private readonly snb: MatSnackBar,
    public commonService: CommonService,
    private emailNotification: EmailNotificationService,
    private authService: AuthService,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.role = this.userData.Role;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.profilePath = this.userData.UserProfileBlobPath;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.notificationService = new NotificationService(snb);
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Service_Request && (feature.UnitId !== null && feature.UnitId !== "")) {
          this.featureName = feature.Name
          this.featureId = feature.FeatureId
        }
      });
  }

  MobActionToggle() {
    if (this.MobActoin)
      this.MobActoin = false;
    else
      this.MobActoin = true;
  }

  MobShowDetail() {
    if (this.MobDetail)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  MobShowChat() {
    if (this.MobChat)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.requestId = id;
        this.service.requestId = id;
        this.service.domain = this.domain;
        this.getServiceRequestDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
    this.createServiceRequestStatusForm();
    this.createReopenForm();
    this.createCaseNoteForm();
  }


  // get Service Request Detail
  getServiceRequestDetail() {
    this.isCommentAndReopen = true;
    this.progressbarService.show();
    this.service.getServiceRequestDetail(this.requestId).subscribe(
      (response: any) => {
        this.progressbarService.hide();
        this.isComponentLoad = true;
        console.log(response);
        if (response.Errors.length > 0) {
          console.log("Details Not Found");
          this.router.navigate([AppRouteUrl.mainServiceRequestHORouteUrl]);
        }
        else {
          if (response.RequestDetail.Success) {
            this.serviceRequestData = response.RequestDetail.ServiceRequest;
            this.documents = response.RequestDetail.Document;
            if (response.RequestDetail.CaseNoteDetails.length > 0) {
              this.setListValue(response.RequestDetail.CaseNoteDetails);
            } else {
              this.removeListValue();
            }
            this.isShowNextAndPreviewsButton();
            if (this.serviceRequestData !== null) {
              this.serviceRequestStatus = this.serviceRequestData.ServiceRequestStatus;
              this.service.caseId = this.serviceRequestData.CaseId;
              if (this.serviceRequestData.Ratings !== null && this.serviceRequestData.Ratings.length > 0) {
                if (this.serviceRequestData.Ratings.length > 0) {
                  this.isCommentAndReopen = false;
                }
              }
            }
            if (this.serviceRequestStatus === this.serviceRequestStatusEnum.Resolved && (this.serviceRequestData.Ratings === undefined || this.serviceRequestData.Ratings === null || this.serviceRequestData.Ratings.length === 0)) {
              this.isRateButtonShow = true;
              this.addRateReview();
            }
            else if (this.serviceRequestStatus === this.serviceRequestStatusEnum.Resolved && this.serviceRequestData.Ratings !== null && this.serviceRequestData.Ratings.length > 0) {
              var userRate = this.serviceRequestData.Ratings.find(a => a.CreatedByUserId === this.userId);
              if (userRate != null) {
                this.isRateButtonShow = false;
              } else {
                this.isRateButtonShow = true;
                this.addRateReview();
              }
            }
          }
        }
      }
    );
  }


  //Rate and review dialoag using mat dialog
  addRateReview() {
    this.dialogRef = this._matDialog.open(RateAndReviewDialogComponent, {
      // panelClass: 'add-question-set-dialog'
    });

    this.dialogRef.afterClosed()
      .subscribe(response => {
        if (!response) {
        }
        console.log(response);
        const actionType: string = response[0];
        const formData: FormGroup = response[1];
        switch (actionType) {
          case 'submit':
            let model = {
              Comment: formData.controls.comments.value,
              Ratings: formData.controls.rateCount.value,
              CreatedByUserId: this.userId,
              CreatedByUserName: this.userName,
              ProfilePath: this.profilePath
            };
            console.log(model);
            this.service.addRateOnServiceRequest(this.service.requestId, this.service.domain, model).subscribe(res => {
              this.isSubmitBtnDisabledReviewAndRating = false;
              this.resDataCreateReviewAndRating = res;
              if (this.resDataCreateReviewAndRating.Success === true) {
                this.getServiceRequestDetail();
              }
              else if (this.resDataCreateReviewAndRating.caseRequestListResults[0].Success === false) {
                console.log("error");
              }
            });
            break;
          /**
           * Delete
           */
          case 'cancel':
            break;
        }
      });
  }


  getUnitAddress() {
    var associationUnit = {
      AssociationUnitNumber: this.serviceRequestData.CreatedByUnitNumber,
      AssociationUnitAddress1: this.serviceRequestData.CreatedByUnitAddress1,
      AssociationUnitAddress2: this.serviceRequestData.CreatedByUnitAddress2,
      AssociationUnitCity: this.serviceRequestData.CreatedByUnitCity,
      AssociationUnitState: this.serviceRequestData.CreatedByUnitState,
      AssociationUnitZip: this.serviceRequestData.CreatedByUnitZip,
    }
    return this.commonService.getFullAssociationAddress(associationUnit);
  }
  //set chatnot value
  setListValue(caseNoteDetails) {
    //this.caseNotes = resData.RequestDetail.CaseNotes;
    this.caseNoteList = caseNoteDetails;
    this.hocaseNotes = this.caseNoteList.filter(note => note.CaseNotes.NotesType == NoteType.Homeowner || note.CaseNotes.StatusReason !== null || note.CaseNotes.ActivityType === ActivityType.Phone || (note.CaseNotes.ActivityType === ActivityType.Email && note.CaseNotes.EmailAudience === EmailAudience.All));
    this.allChat = this.hocaseNotes;
    var assignToBoardAfterVote = caseNoteDetails.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus !== null));
    if (assignToBoardAfterVote.length > 0) {
      assignToBoardAfterVote.map(a => {
        this.allChat.push(a);
      })
    }

    this.allChat = _.sortBy(this.allChat, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();
  
    var caseNoteBeforeVote = caseNoteDetails.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null || note.CaseNotes.DocumentType === "Motion" && note.CaseNotes.VoteStatus === null));
    if (caseNoteBeforeVote.length > 0) {
      caseNoteBeforeVote = _.sortBy(caseNoteBeforeVote, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();
      this.allChat = caseNoteBeforeVote.concat(this.allChat);
    }

  }

  removeListValue() {
    this.caseNoteList = [];
    this.decisionReason = [];
    this.hocaseNotes = [];
    this.allChat = [];
  }
  text = CommonConstant.AwaitingBoardDecision
  //assign to board text 
  assignToBoardText(caseNote) {
    if (caseNote !== null) {
      if (caseNote.IsAssignedToBoard) {
        if (caseNote.Votes.length > 0 && caseNote.VoteStatus !== null) {
          return CommonConstant.BoardDecision
        } else if (caseNote.VoteStatus === null) {
          return CommonConstant.AwaitingBoardDecision
        }
      }
    }
  }



  /*Case Note Add Module*/
  createCaseNoteForm() {
    this.frmCreateCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  onSubmitCaseNote() {
    let resData;
    if (this.frmCreateCaseNote.valid) {
      this.isSubmitBtnDisabled = true;
      let model = this.createCaseFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Service_Request, TriggerType.Update,
            AudienceType.HomeOwner).subscribe(res => {
              console.log(res);
            });
          if (this.fileData.length > 0)
            this.getServiceRequestDetail();
          else {
            if (resData.caseRequestListResults[0].CaseNoteDetails !== null) {
              this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);
            } else {
              this.removeListValue();
            }
          }
          this.resetCaseNoteForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  createCaseFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: this.typeOfDocument,
      Document: this.fileData,
      Domain: this.service.domain,
      RequestId: this.serviceRequestData.id,
      CaseNotes:
      {
        CaseNoteId: this.frmCreateCaseNote.controls.caseNoteId.value,
        Note: this.frmCreateCaseNote.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.Homeowner,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: RoleEnum.Member
      }
    }
    return model;
  }

  resetCaseNoteForm() {
    this.frmCreateCaseNote.reset();
    this.formDirective.resetForm();
    this.isSubmitBtnDisabled = false;
    this.fileData = [];
  }

  /*Update status of service request*/

  createServiceRequestStatusForm() {
    this.frmCancel = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitCancel() {
    let resData;
    if (this.frmCancel.valid) {
      this.isSubmitBtnDisabledCancel = true;
      let model = this.createStatusUpdateFormModel();
      this.service.updatServiceRequestStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledCancel = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Service_Request, TriggerType.Update_Cancelled,
            AudienceType.HomeOwner).subscribe(res => {
              console.log(res);
            });
          this.notificationService.showNotification("Service Request status updated successfully.");
          this.getServiceRequestDetail();
          this.resetStatusCancelForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Service Request not status updated");
        }
      });
    }
  }

  createStatusUpdateFormModel() {
    const model: UpdateServiceRequestStatus = {
      RequestId: this.service.requestId,
      StatusType: ServiceRequestStatus.Cancelled,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCancel.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: null, //NoteType.BoardMember,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: StatusReason.Cancelled,
        ProfilePath: this.profilePath,
        RoleType: RoleEnum.Member
      }
    }
    return model;
  }

  resetStatusCancelForm() {
    this.frmCancel.reset();
    this.formDirectiveCancel.resetForm();
    this.reasonType = "";
  }




  /*Display list of vote*/
  displayVoteListToggle() {
    this.isDisplayVoteList
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }

  /*Display list of vote*/
  displayEscalatVoteListToggle() {
    if (this.isDisplayEscalatVoteList)
      this.isDisplayEscalatVoteList = false;
    else
      this.isDisplayEscalatVoteList = true;
  }

  /*Create Reopen of service request */
  createReopenForm() {
    this.frmCreateReopen = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitReopen() {
    let resData;
    if (this.frmCreateReopen.valid) {
      this.isSubmitBtnDisabledReopen = true;
      let model = this.createReopenFormModel();
      this.service.updatServiceRequestStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledReopen = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Service_Request, TriggerType.Update,
            AudienceType.HomeOwner).subscribe(res => {
              console.log(res);
            });
          this.getServiceRequestDetail();
          this.resetReopenForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createReopenFormModel() {
    const model: UpdateServiceRequestStatus = {
      RequestId: this.service.requestId,
      StatusType: ServiceRequestStatus.InProgress,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateReopen.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: null,// NoteType.BoardMember,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: StatusReason.Reopen,
        ProfilePath: this.profilePath,
        RoleType: RoleEnum.Member,
      }
    }
    return model;
  }


  resetReopenForm() {
    this.frmCreateReopen.reset();
    this.formDirectiveReopen.resetForm();
    this.reasonType = '';
  }



  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.desLimit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.readMoreDescBtnMsg = "Read Less";
      this.desLimit = this.serviceRequestData.Description.length;
    }
  }
  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.documents.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }

  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
  }

  updateCaseNote(noteType) {
    if (this.editComments === "") {
      this.isEditValidation = true;
      return;
    }
    this.isEditValidation = false;
    this.editBtnDisable = true;
    let model = this.editCaseNoteModel(noteType);
    this.commonService.updateCaseNote(model).subscribe(res => {
      let resData;
      this.editBtnDisable = false;
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.resetEditCaseNote();
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
            this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);
          } else {
            this.removeListValue();
          }
        }
        console.log("Case note updated successfully.");
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        this.notificationService.showNotification("Not update");
      }
    });
  }

  editCaseNoteModel(noteType) {
    const model: CaseNoteEditModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.serviceRequestData.id,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.serviceRequestData.CaseId,
        CreatedByUserId: this.userId,
        NotesType: noteType,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        RoleType: RoleEnum.Member
      }
    }
    return model;
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
  }

  /*Delete case note*/
  delete(id) {
    let resData;
    this.commonService.deleteCaseNote(id, this.serviceRequestData.CaseId, this.associationId, this.domain).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
            this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          else {
            this.caseNoteList = [];
            this.hocaseNotes = [];
            this.decisionReason = [];
            this.allChat = [];
          }
        }
        else {
          this.caseNotes = "";
        }
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })
  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }

  //download 
  downloadDocument(filename) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.ServiceRequest,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Document not found");
        }
      });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.FilePath, DocumentFeatureName.ServiceRequest, DownloadfeatureName.Download).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image");
      }
    });
  }

  toGoBack() {
    this.router.navigate([AppRouteUrl.mainServiceRequestHORouteUrl]);
  }

  ngOnDestroy() {
    this.querySubcription.unsubscribe();
    localStorage.removeItem('serviceRequestStatus');
  }


  //**Next AND Preview */
  PreviousCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('SRHO'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = ar[currentEl - 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getServiceRequestDetail();
    }
  }

  NextCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('SRHO'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < ar.length) {
      let prevIndex = ar[currentEl + 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getServiceRequestDetail();
    }
  }

  isShowNextAndPreviewsButton() {
    let localStorageData = JSON.parse(localStorage.getItem('SRHO'));
    if (localStorageData === null || localStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.requestId;
      var ar = JSON.parse(localStorage.getItem('SRHO'));
      this.totalPages = ar.length - 1;
      var el = ar.find(a => { return a.id === current });
      var currentEl = ar.indexOf(el);
      this.currentPage = currentEl;
    }
  }


  onClickReason(reasonType) {
    this.reasonType = reasonType;
  }

  checkIconAssignToBoard(assignTOBoard) {
    if (assignTOBoard !== null && assignTOBoard !== undefined) {
      if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined) {
        return CommonConstant.MotionMovedIcon;
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
        return CommonConstant.MotionPassedIcon;
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
        return CommonConstant.MotionFailedIcon;
      }
    }
  }

  checkTextAssignToBoard(assignTOBoard) {
    if (assignTOBoard !== null && assignTOBoard !== undefined) {
      if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined) {
        return "Decision is Pending"
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
        return VoteStatus.Approved
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
        return VoteStatus.Denied
      }
    }
  }


}
