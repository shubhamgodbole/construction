import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoServiceRequestDetailComponent } from './ho-service-request-detail.component';

describe('HoServiceRequestDetailComponent', () => {
  let component: HoServiceRequestDetailComponent;
  let fixture: ComponentFixture<HoServiceRequestDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoServiceRequestDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoServiceRequestDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
