import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
//import { CaseFeatureType, addMotion, VoteModel, NoteType, ServiceRequestStatus, UpdateServiceStatus } from './bm-service-request.model';
import { CaseNoteModel, CaseFeatureType, addMotion, VoteModel, ServiceRequestStatus, UpdateServiceStatus, MotionModel, RequestMsg } from '../service-request.model';
import { Router, ActivatedRoute } from '@angular/router';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { CommonService } from 'src/app/services/common.service';
import { TypeOfDocument, CaseOriginatingType, IsAuthorized, ImageNameEnums, NoteType, DownloadfeatureName, FeatureName, DocumentFeatureName, StatusReason, VoteStatus, PlaceHolderText, RoleEnum, SourceType, AudienceType, TriggerType, CallType, ActivityType, FeaturePermissions, EmailAudience } from 'src/app/shared/Enums/commonEnums';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { MatDialogRef, MatDialog, MatSnackBar } from '@angular/material';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Subscription } from 'rxjs';
import { Guid } from 'guid-typescript';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonConstant, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-bm-service-request-detail',
  templateUrl: './bm-service-request-detail.component.html',
  styleUrls: ['./bm-service-request-detail.component.scss']
})
export class BmServiceRequestDetailComponent implements OnInit {
  propVivoName = CommonConstant.PropVivo;
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  notificationService: NotificationService;
  //Confirm Dialog
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  //For Query string;
  querySubcription: Subscription;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  requestId;
  serviceRequestData: any;
  isAuthorized = IsAuthorized;
  caseOriginatingType = CaseOriginatingType;
  documents: any;
  //For Case Note
  caseNotes: any;
  allCaseNotes: any;
  boardMemberCaseNoteList: any;
  homeOwnerCaseNoteList: any;
  motion: any = null;
  addMotionForm: FormGroup;
  addCaseForm: FormGroup;
  reopenForm: FormGroup;
  completeForm: FormGroup;
  cancleForm: FormGroup;
  rateForm: FormGroup;
  associationId: string;
  associationName: string;
  //documentType = "Motion";
  domain: string;
  fileData = [];
  serviceRequestStatusEnum = ServiceRequestStatus;
  serviceRequestStatus: string = "";
  isDisplayVoteList: boolean = false;
  isComponentLoad: boolean = false;
  rate = 0;
  userData: UserData;
  role: string;
  roleTypeEnum = RoleEnum;
  //Enums
  noteTypeEnums = NoteType;
  statusReasonEnum = StatusReason;
  VoteStatusEnum = VoteStatus;

  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;

  /*Motion Form*/
  isDisplayMotionDiv: boolean = false;
  frmCreateMotion: FormGroup;
  isSubmitBtnDisabledMotion: boolean = false;
  resDataCreateMotion: any;
  @ViewChild('formDirectiveMotion') formDirectiveMotion: FormGroupDirective;
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  //Read More motion
  readMoreMotionBtn: boolean;
  readMoreMotionBtnMsg: string = "Read More";
  motionLimit: number = 160;

  motionList: any = null;
  isMotionCreated: boolean;
  isMotionVote: boolean;
  motionVoteCount: number;

  shoNDocs: any = 3;
  viewDocs: boolean = false;
  viwAllDocBtnMsg: string = "View All Attachments";
  readMoreBtn: boolean = false;
  readMoreDescBtnMsg: string = "Read More";
  desLimit: number = 160;

  addEsclateForm: FormGroup;
  isDisplayEsclateVoteList: boolean = false;
  userId: string;
  userName: string;
  profilePath: string;
  pendingAction: any;
  esclateVoteCount: any;
  esclateResult: string;
  esclateVoterList: any;
  isVote: boolean;

  //for Preview
  isDocumentDetails: boolean
  documentDetails
  fileURL

  decisionReason

  MobActoin = false;
  MobDetail = false;
  MobChat = false;

  isCommentAndReopen: boolean = true;
  isDisplayEsclateVoteList1: boolean = false;
  disableBtn = false;

  //static msg class
  placeHolderText = PlaceHolderText;

  //requestMsg enum 
  requestMsgEnum = RequestMsg


  /*Case Note Form For Board Member*/
  frmCreateBmCaseNote: FormGroup;
  isSubmitBtnDisabledBmCaseNote: boolean;
  @ViewChild('formDirectiveBmCaseNote') formDirectiveBmCaseNote: FormGroupDirective;
  fileDataBMCase = [];

  /*Case Note Form*/
  frmCreateIcCaseNote: FormGroup;
  isSubmitBtnDisabledIcCaseNote: boolean = false;
  @ViewChild('formDirectiveIcCaseNote') formDirectiveIcCaseNote: FormGroupDirective;
  fileDataICCase = [];


  /*Case Note Form*/
  frmCreateHoCaseNote: FormGroup;
  isSubmitBtnDisabledHoCaseNote: boolean = false;
  @ViewChild('formDirectiveHoCaseNote') formDirectiveHoCaseNote: FormGroupDirective;
  fileDataHoCase = [];

  //replyTo
  selectedReplyTo: string;
  selectedConversionType: string = "All";
  callTypeEnum = CallType;
  activityTypeEnum = ActivityType;

  //For Send Notification
  featureId: string;
  pmCompanyAssociationMappingId: string;

  //assign to board
  assignMsg: string;
  assignIcon: string;
  assignvoteReceiveMsg: string;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;



  constructor(private service: ServiceRequestService,
    private ngZone: NgZone,
    public commonService: CommonService,
    private emailNotification: EmailNotificationService,
    private route: ActivatedRoute,
    private _location: Location,
    private formBuilder: FormBuilder,
    private progressbarService: ProgeressBarService,
    private router: Router,
    private _matDialog: MatDialog, private readonly snb: MatSnackBar,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.role = this.userData.Role;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.profilePath = this.userData.UserProfileBlobPath;
    this.domain = this.userData.UserAssociations[0].Domain;// "testassociation";
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.createMotionForm();
    this.notificationService = new NotificationService(snb);
  }

  MobActionToggle() {
    if (this.MobActoin)
      this.MobActoin = false;
    else
      this.MobActoin = true;
  }

  MobShowDetail() {
    if (this.MobDetail)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  MobShowChat() {
    if (this.MobChat)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }


  toGoBack() {
    let page = localStorage.getItem("previousPage");
    if (page === AppRouteUrl.mainMotionsRouteUrl) {
      this.router.navigate([AppRouteUrl.mainMotionsRouteUrl]);
    } else if (page === AppRouteUrl.mainHoaMembersDetailRouteUrl) {
      this._location.back();
    } else {
      this.router.navigate([AppRouteUrl.mainServiceRequestBMRouteUrl]);
    }
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        // this.service.requestId = id;
        this.requestId = id;
        this.service.domain = this.domain;
        this.getServiceRequestDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });

    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Service_Request && (feature.UnitId !== null && feature.UnitId !== "")) {
          this.featureId = feature.FeatureId
        }
      });

    this.addMotionForm = this.formBuilder.group({
      description: ['', Validators.required],
    });

    this.reopenForm = this.formBuilder.group({
      reason: ['', Validators.required],
    });
    this.completeForm = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]],
    });
    this.rateForm = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]],
    });
    this.createCaseNoteForm();
  }



  createCaseNoteForm() {
    /*BM Case Note */
    this.frmCreateBmCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
    /*HO Case Note */
    this.frmCreateHoCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
    /*IC Case Note */
    this.frmCreateIcCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  // get Detail Data
  getServiceRequestDetail() {
    this.isCommentAndReopen = true;
    this.progressbarService.show();
    this.service.getServiceRequestDetail(this.requestId).subscribe(
      (response: any) => {
        console.log(response);
        this.progressbarService.hide();
        if (response.Errors.length > 0) {
          console.log("Details Not Found");
          this.router.navigate([AppRouteUrl.errorRouteUrl]);
        }
        else {
          if (response.RequestDetail.Success) {
            this.serviceRequestData = response.RequestDetail.ServiceRequest;
            this.serviceRequestStatus = this.serviceRequestData.ServiceRequestStatus;
            this.documents = response.RequestDetail.Document;
            if (this.serviceRequestData !== null) {
              this.serviceRequestStatus = this.serviceRequestData.ServiceRequestStatus;
              this.service.caseId = this.serviceRequestData.CaseId;
              this.isShowNextAndPreviewsButton();
              if (this.serviceRequestData.Ratings !== null) {
                if (this.serviceRequestData.Ratings.length > 0) {
                  this.isCommentAndReopen = false;
                }
              }
            }
            this.motionList = response.RequestDetail.Motion;
            this.service.caseId = this.serviceRequestData !== null ? this.serviceRequestData.CaseId : '';
            if (response.RequestDetail.CaseNoteDetails != null) {
              if (response.RequestDetail.CaseNoteDetails.length > 0) {
                this.setListValue(response.RequestDetail.CaseNoteDetails);
              } else {
                this.removeListValue();
              }
            }

            this.isComponentLoad = true;
          }
          else {
            console.log("Details Not Found");
            this.router.navigate([AppRouteUrl.mainServiceRequestBMRouteUrl]);
          }
        }
      }
    );
  }


  onSubmitBmCaseNote() {
    let resData;
    if (this.frmCreateBmCaseNote.valid) {
      this.isSubmitBtnDisabledBmCaseNote = true;
      let model = this.createCaseNoteFormModel(NoteType.BoardMember, this.frmCreateBmCaseNote, this.fileDataBMCase);
      this.service.createCaseNote(model).subscribe(res => {
        resData = res;
        this.resetCaseNoteForm();
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Service_Request, TriggerType.Update,
            AudienceType.HomeOwner).subscribe(res => {
              console.log(res);
            });
          if (this.fileDataBMCase.length > 0)
            this.getServiceRequestDetail();
          else {
            if (resData.caseRequestListResults[0].CaseNoteDetails !== null) {
              this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);
            } else {
              this.removeListValue();
            }
          }
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  onSubmitHoCaseNote() {
    let resData;
    if (this.frmCreateHoCaseNote.valid) {
      this.isSubmitBtnDisabledHoCaseNote = true;
      let model = this.createCaseNoteFormModel(NoteType.Homeowner, this.frmCreateHoCaseNote, this.fileDataHoCase);
      console.log("model ", model);
      this.service.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledHoCaseNote = false;
        resData = res;
        this.resetCaseNoteForm();
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Service_Request, TriggerType.Update,
            AudienceType.HomeOwner).subscribe(res => {
              console.log(res);
            });
          // this.notificationService.showNotification("Case note save successfully");
          if (this.fileDataHoCase.length > 0)
            this.getServiceRequestDetail();
          else {
            if (resData.caseRequestListResults[0].CaseNoteDetails !== null) {
              this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);
            } else {
              this.removeListValue();
            }
          }
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  onSubmitIcCaseNote() {
    let resData;
    if (this.frmCreateIcCaseNote.valid) {
      this.isSubmitBtnDisabledIcCaseNote = true;
      let model = this.createCaseNoteFormModel(NoteType.PropertyManager, this.frmCreateIcCaseNote, this.fileDataICCase);
      this.service.createCaseNote(model).subscribe(res => {
        resData = res;
        this.resetCaseNoteForm();
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Service_Request, TriggerType.Update,
            AudienceType.HomeOwner).subscribe(res => {
              console.log(res);
            });
          // this.notificationService.showNotification("Case note save successfully");
          if (this.fileDataICCase.length > 0)
            this.getServiceRequestDetail();
          else {
            if (resData.caseRequestListResults[0].CaseNoteDetails !== null) {
              this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);
            } else {
              this.removeListValue();
            }
          }
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  resetCaseNoteForm() {
    if (this.selectedReplyTo === NoteType.BoardMember) {
      this.frmCreateBmCaseNote.reset();
      if (this.formDirectiveBmCaseNote !== undefined) {
        this.formDirectiveBmCaseNote.resetForm();
      }
      this.isSubmitBtnDisabledBmCaseNote = false;
      this.fileDataBMCase = [];
    }
    else if (this.selectedReplyTo === NoteType.Homeowner) {
      this.frmCreateHoCaseNote.reset();
      if (this.formDirectiveHoCaseNote !== undefined) {
        this.formDirectiveHoCaseNote.resetForm();
      }
      this.isSubmitBtnDisabledHoCaseNote = false;
      this.fileDataHoCase = [];
    } else {
      this.frmCreateIcCaseNote.reset();
      this.fileDataICCase = [];
      this.isSubmitBtnDisabledIcCaseNote = false;
      if (this.formDirectiveIcCaseNote !== undefined) {
        this.formDirectiveIcCaseNote.resetForm();
      }
    }
    this.fileData = [];
    this.selectedReplyTo = "";
  }



  createCaseNoteFormModel(noteType, caseFrm, caseNotefileData) {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: caseNotefileData,
      Domain: this.domain,
      RequestId: this.serviceRequestData.id,
      CaseNotes:
      {
        CaseNoteId: caseFrm.controls.caseNoteId.value,
        Note: caseFrm.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: noteType,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        StatusReason: null
      }
    }
    return model;
  }

  
  getUnitAddress() {
    var associationUnit = {
      AssociationUnitNumber: this.serviceRequestData.CreatedByUnitNumber,
      AssociationUnitAddress1: this.serviceRequestData.CreatedByUnitAddress1,
      AssociationUnitAddress2: this.serviceRequestData.CreatedByUnitAddress2,
      AssociationUnitCity: this.serviceRequestData.CreatedByUnitCity,
      AssociationUnitState: this.serviceRequestData.CreatedByUnitState,
      AssociationUnitZip: this.serviceRequestData.CreatedByUnitZip,
    }
    return this.commonService.getFullAssociationAddress(associationUnit);
  }


  //change reply to 
  changeReplyTo() {
    this.isDisplayMotionDiv = false;
    this.fileData = [];
  }

  //change conversion
  changeConversion() {
    if (this.selectedConversionType === "All") {
      this.caseNotes = this.allCaseNotes;
    } else if (this.selectedConversionType === NoteType.Homeowner) {
      this.caseNotes = this.allCaseNotes.filter(note => (note.CaseNotes.NotesType == NoteType.Homeowner));
    } else if (this.selectedConversionType === NoteType.BoardMember) {
      this.caseNotes = this.allCaseNotes.filter(note => note.CaseNotes.NotesType == NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.BoardMember);
    } else if (this.selectedConversionType === NoteType.PropertyManager) {
      this.caseNotes = this.allCaseNotes.filter(note => (note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.BoardMember && note.CaseNotes.IsAssignedToBoard === false) || (note.CaseNotes.NotesType == NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager && note.CaseNotes.IsAssignedToBoard === false));
    } else if (this.selectedConversionType === this.activityTypeEnum.Phone) {
      this.caseNotes = this.allCaseNotes.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Phone && note.CaseNotes.IsVotingRequired !== true);
    } else if (this.selectedConversionType === this.activityTypeEnum.Email) {
      this.caseNotes = this.allCaseNotes.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Email && note.CaseNotes.EmailAudience !== EmailAudience.None);
    } else if (this.selectedConversionType === this.activityTypeEnum.AssignToBoard) {
      this.caseNotes = this.allCaseNotes.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.AssignToBoard || (note.CaseNotes.ActivityType === this.activityTypeEnum.Phone && note.CaseNotes.IsVotingRequired === true));
    }
  }

  /*Display list of vote*/
  displayVoteListToggle() {
    this.isDisplayVoteList
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }

  /*Display list of vote escalate*/
  displayVoteEscalateListToggle() {
    this.isDisplayEsclateVoteList
    if (this.isDisplayEsclateVoteList)
      this.isDisplayEsclateVoteList = false;
    else
      this.isDisplayEsclateVoteList = true;
  }

  /*Display list of vote escalate*/
  displayEscalatVoteListToggle() {
    this.isDisplayEsclateVoteList1
    if (this.isDisplayEsclateVoteList1)
      this.isDisplayEsclateVoteList1 = false;
    else
      this.isDisplayEsclateVoteList1 = true;
  }


  // upload Document
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        if (this.selectedReplyTo === NoteType.Homeowner) {
          this.fileDataHoCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.BoardMember) {
          this.fileDataBMCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.PropertyManager) {
          this.fileDataICCase = this.fileData;
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
    if (this.selectedReplyTo === NoteType.Homeowner) {
      this.fileDataHoCase = this.fileDataHoCase.filter(a => a.imageId !== imageId);;
    } else if (this.selectedReplyTo === NoteType.BoardMember) {
      this.fileDataBMCase = this.fileDataBMCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.PropertyManager) {
      this.fileDataICCase = this.fileDataICCase.filter(a => a.imageId !== imageId);
    }
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  // reset Add CaseNote Form
  resetAddaddCaseForm() {
    this.addCaseForm.reset();
    this.formDirective.resetForm()
    this.fileData = [];
  }
  // add new case note
  addCase(notType) {
    let CaseNotes = this.createCaseModel(notType);
    console.log(CaseNotes);
    this.disableBtn = true;
    this.service.createCaseNote(CaseNotes).subscribe(
      (response: any) => {
        this.disableBtn = false;
        if (response.caseRequestListResults[0].Success === true) {
          // this.notificationService.showNotification("Case note save successfully");
          if (this.fileData.length > 0)
            this.getServiceRequestDetail();
          else {
            if (response.caseRequestListResults[0].CaseNoteDetails !== null) {
              this.setListValue(response.caseRequestListResults[0].CaseNoteDetails);
            } else {
              this.removeListValue();
            }
          }
          this.resetAddaddCaseForm();
        }
        else if (response.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      }
    );
  }
  // case note model
  createCaseModel(notType) {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.serviceRequestData.id,
      CaseNotes:
      {
        CaseNoteId: this.addCaseForm.controls.caseNoteId.value,
        Note: this.addCaseForm.controls.note.value,
        NotesType: notType,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        CreatedByUserName: this.userName,
        CreatedByUserId: this.userId,
        CaseId: this.serviceRequestData.CaseId,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        StatusReason: ''
      }
    }
    return model;
  }


  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.desLimit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.readMoreDescBtnMsg = "Read Less";
      this.desLimit = this.serviceRequestData.Description.length;

    }
  }
  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.documents.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }

  createEsclateVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model = {
      Vote: vote,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      ProfilePath: this.profilePath,
      Remarks: ''
    }
    return model;
  }
  /*Display list of vote*/
  displayVoteListToggle1() {
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }
  //For Vote
  createEsclateVote(voteStatus, caseNoteId) {
    this.progressbarService.show();
    let model = this.createEsclateVoteModel(voteStatus);
    this.service.createEsclateVote(this.serviceRequestData.CaseId, caseNoteId, this.serviceRequestData.id, this.associationId, model).subscribe(
      (response: any) => {
        this.progressbarService.hide();
        if (response.Success) {
          this.pendingAction = response.CaseActivity;
          this.esclateVoteCount = this.pendingAction.Votes.length;
          this.esclateResult = this.pendingAction.VoteStatus;
          this.serviceRequestData = response.serviceRequestDetail;
          //this.getServiceRequestDetail();
          this.caseNotes = this.caseNotes.map((a) => {
            if (a.CaseNotes.id === this.pendingAction.id) {
              a.CaseNotes = this.pendingAction;
            }
            return a;
          });
          if (this.esclateVoteCount > 0) {
            this.esclateVoterList = this.pendingAction.Votes;
            let voteByUser = this.pendingAction.Votes.find(v => v.CreatedByUserId === this.userId);
            if (voteByUser) {
              this.isVote = voteByUser.Vote;
            }
          }
        }
      }
    );
  }

  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
  }

  updateCaseNote(noteType) {
    if (this.editComments === "") {
      this.isEditValidation = true;
      return;
    }
    this.isEditValidation = false;
    let model = this.editCaseNoteModel(noteType);
    this.commonService.updateCaseNote(model).subscribe(res => {
      let resData;
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.resetEditCaseNote();
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
            this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);
          } else {
            this.removeListValue();
          }
        }
        console.log("Case note updated successfully.");
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        this.notificationService.showNotification("Not update");
      }
    });
  }

  

  editCaseNoteModel(noteType) {
    const model: CaseNoteEditModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.serviceRequestData.id,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.serviceRequestData.CaseId,
        CreatedByUserId: this.userId,
        NotesType: noteType,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        RoleType: this.role

      }
    }
    return model;
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
  }

  /*Delete case note*/
  delete(id) {
    let resData;
    this.commonService.deleteCaseNote(id, this.serviceRequestData.CaseId, this.associationId, this.domain).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
            this.allCaseNotes = resData.caseRequestListResults[0].CaseNoteDetails;
            this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);
            this.boardMemberCaseNoteList = this.caseNotes.filter(note => note.CaseNotes.NotesType == NoteType.BoardMember);
            this.homeOwnerCaseNoteList = this.caseNotes.filter(note => note.CaseNotes.NotesType == NoteType.Homeowner);
            this.pendingAction = this.caseNotes.find(note => note.CaseNotes.IsAssignedToBoard == true);
          }
          else {
            this.removeListValue();
          }
        }
        else {
          this.removeListValue();
        }
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })

  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;

    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }

  /*Create motion of Service Request */
  createMotionForm() {
    this.frmCreateMotion = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitMotion() {
    let resData
    if (this.frmCreateMotion.valid) {
      this.isSubmitBtnDisabledMotion = true;
      let model = this.createMotionFormModel();
      this.resetMotionForm();
      this.service.createMotion(model, this.serviceRequestData.id).subscribe(res => {
        this.isSubmitBtnDisabledMotion = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.Motion, TriggerType.Create,
            AudienceType.HomeOwner).subscribe(res => {
              console.log(res);
            });
          this.getServiceRequestDetail();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createMotionFormModel() {
    const model: MotionModel = {
      MotionId: '',
      CaseId: this.serviceRequestData.CaseId,
      AssociationId: this.associationId,
      CaseFeatureType: CaseFeatureType.ServiceRequest,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      AssociationName: this.associationName,
      Description: this.frmCreateMotion.controls.comments.value,
      ProfilePath: this.profilePath
    }
    return model;
  }


  resetMotionForm() {
    this.frmCreateMotion.reset();
    if (this.formDirectiveMotion !== undefined) {
      this.formDirectiveMotion.resetForm();
    }
    this.isDisplayMotionDiv = false;
  }

  showMotionDiv() {
    this.resetMotionForm();
    this.selectedReplyTo = '';
    this.isDisplayMotionDiv = true;
  }

  /**Create Motion Vote */
  createMotionVote(voteStatus, id) {
    let model = this.createMotionVoteModel(voteStatus);
    let resData;
    this.progressbarService.show();
    this.service.createMotionVote(this.service.caseId, id, this.associationId, model).subscribe(res => {
      this.progressbarService.hide();
      resData = res;
      console.log(res);
      if (resData.caseRequestListResults[0].Success === true) {
        var motion = resData.caseRequestListResults[0].Motion;
        var caseMotion: any = this.commonService.convertMotionToCaseNote(motion);
        var count = motion.Votes.length;
        this.caseNotes = this.caseNotes.map((a) => {
          if (a.CaseNotes.id === caseMotion.CaseNotes.id) {
            a.CaseNotes = caseMotion.CaseNotes;
          }
          return a;
        });
        if (count > 0) {
          var voterList = caseMotion.CaseNotes.Votes;
          let voteByUser = caseMotion.CaseNotes.Votes.find(v => v.CreatedByUserId === this.userId);
          if (voteByUser) {
            this.isMotionVote = voteByUser.Vote;
          }
        }
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        console.log("error");
      }
    });
  }

  createMotionVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: VoteModel = {
      Vote: vote,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      ProfilePath: this.profilePath,
      Remarks: ''
    }
    return model;
  }


  //download document
  downloadDocument(filename) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.ServiceRequest,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Document not found");
        }
      });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.FilePath, DocumentFeatureName.ServiceRequest, DownloadfeatureName.Download).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image");
      }
    });
  }

  setListValue(caseDetail) {
    this.allCaseNotes = caseDetail.filter(note => note.CaseNotes.NotesType !== NoteType.PropertyManager && note.CaseNotes.RoleType !== RoleEnum.PropertyManager);

    var activity = caseDetail.filter(note => ((note.CaseNotes.ActivityType === ActivityType.Email && note.CaseNotes.EmailAudience !== EmailAudience.None) || (note.CaseNotes.ActivityType === ActivityType.Phone && note.CaseNotes.IsVotingRequired !== true)));

    if (activity.length > 0) {
      this.allCaseNotes = this.allCaseNotes.concat(activity);
    }
    var assignToBoardAfterVote = caseDetail.filter(note => (note.CaseNotes.ActivityType === ActivityType.AssignToBoard && note.CaseNotes.VoteStatus !== null));
    if (assignToBoardAfterVote.length > 0) {
      this.allCaseNotes = this.allCaseNotes.concat(assignToBoardAfterVote);
    }
    var assignToBoardData = caseDetail.filter(note => (note.CaseNotes.ActivityType === ActivityType.AssignToBoard && note.CaseNotes.IsVotingRequired === false || ((note.CaseNotes.ActivityType === this.activityTypeEnum.Phone && note.CaseNotes.IsVotingRequired === false))));
    if (assignToBoardData.length > 0) {
      this.allCaseNotes = this.allCaseNotes.concat(assignToBoardData);
    }
    var reasons = caseDetail.filter(note => note.CaseNotes.StatusReason !== null && note.CaseNotes.StatusReason !== '');
    if (reasons.length > 0) {
      this.allCaseNotes = this.allCaseNotes.concat(reasons);
    }
    var bmCaseNote = caseDetail.filter(note => note.CaseNotes.NotesType === NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager || note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.BoardMember);
    if (bmCaseNote.length > 0) {
      this.allCaseNotes = this.allCaseNotes.concat(bmCaseNote);
    }

    var hocaseNote = caseDetail.filter(note => note.CaseNotes.NotesType === NoteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.PropertyManager);
    if (hocaseNote.length > 0) {
      this.allCaseNotes = this.allCaseNotes.concat(hocaseNote);
    }

    // Add motion in to case note
    if (this.motionList.length > 0) {
      this.motionList.map(m => {
        var motion = this.commonService.convertMotionToCaseNote(m);
        caseDetail.push(motion);
      });
    }
    // get motion with final status
    var motionCaseNoteWithStatus = caseDetail.filter(m => {
      return m.CaseNotes.VoteStatus !== null && m.CaseNotes.DocumentType === 'Motion';
    });

    // get motion with not final status
    var motionCaseNoteWithNotStatus = caseDetail.find(m => {
      return m.CaseNotes.VoteStatus === null && m.CaseNotes.DocumentType === 'Motion';
    });
    if (motionCaseNoteWithNotStatus !== null && motionCaseNoteWithNotStatus !== undefined) {
      this.isMotionCreated = true;
      if (motionCaseNoteWithNotStatus.CaseNotes.Votes.length > 0) {
        let voteByUser = motionCaseNoteWithNotStatus.CaseNotes.Votes.find(v => v.CreatedByUserId === this.userId);
        if (voteByUser) {
          this.isMotionVote = voteByUser.Vote;
        }
      }
    }

    //concat motion
    if (motionCaseNoteWithStatus.length > 0) {
      this.allCaseNotes = this.allCaseNotes.concat(motionCaseNoteWithStatus);
    }

    // sort data with motion data
    this.allCaseNotes = _.sortBy(this.allCaseNotes, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();


    //get before data
    var caseNoteBeforeVote = caseDetail.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null || note.CaseNotes.DocumentType === "Motion" && note.CaseNotes.VoteStatus === null));

    if (caseNoteBeforeVote.length > 0) {
      caseNoteBeforeVote = _.sortBy(caseNoteBeforeVote, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();
      this.allCaseNotes = caseNoteBeforeVote.concat(this.allCaseNotes);
    }
    this.changeConversion();

    let pendingAction = caseDetail.find(note => note.CaseNotes.IsAssignedToBoard == true || (note.CaseNotes.ActivityType === ActivityType.Phone && note.CaseNotes.IsVotingRequired === true));
    if (pendingAction !== null && pendingAction !== undefined) {
      this.pendingAction = pendingAction.CaseNotes;
      if (this.pendingAction.Votes !== null) {
        if (this.pendingAction.Votes.length > 0) {
          this.esclateVoteCount = this.pendingAction.Votes.length;
          this.esclateVoterList = this.pendingAction.Votes;
          let voteByUser = this.pendingAction.Votes.find(v => v.CreatedByUserId === this.userId);
          if (voteByUser) {
            this.isVote = voteByUser.Vote;
          }
        }
      }
    }
  }

  removeListValue() {
    this.caseNotes = [];
    this.boardMemberCaseNoteList = [];
    this.homeOwnerCaseNoteList = [];
    this.decisionReason = [];
    this.pendingAction = null;
  }

  // view more Motions
  viewMoreMotions() {
    if (this.readMoreMotionBtn) {
      this.readMoreMotionBtn = false;
      this.readMoreMotionBtnMsg = "Read More";
      this.motionLimit = 160;
    }
    else {
      this.readMoreMotionBtn = true;
      this.readMoreMotionBtnMsg = "Read Less";
      this.motionLimit = this.motion.Description.length;
    }
  }

  //**Next AND Preview */
  PreviousCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('SRBM'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = ar[currentEl - 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getServiceRequestDetail();
    }
  }

  NextCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('SRBM'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < ar.length) {
      let prevIndex = ar[currentEl + 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getServiceRequestDetail();
    }
  }

  isShowNextAndPreviewsButton() {
    let localStorageData = JSON.parse(localStorage.getItem('SRBM'));
    if (localStorageData === null || localStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.requestId;
      var ar = JSON.parse(localStorage.getItem('SRBM'));
      this.totalPages = ar.length - 1;
      var el = ar.find(a => { return a.id === current });
      var currentEl = ar.indexOf(el);
      this.currentPage = currentEl;
    }
  }



}
