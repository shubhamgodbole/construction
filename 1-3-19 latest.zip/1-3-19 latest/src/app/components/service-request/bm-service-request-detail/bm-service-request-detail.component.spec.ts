import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmServiceRequestDetailComponent } from './bm-service-request-detail.component';

describe('BmServiceRequestDetailComponent', () => {
  let component: BmServiceRequestDetailComponent;
  let fixture: ComponentFixture<BmServiceRequestDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmServiceRequestDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmServiceRequestDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
