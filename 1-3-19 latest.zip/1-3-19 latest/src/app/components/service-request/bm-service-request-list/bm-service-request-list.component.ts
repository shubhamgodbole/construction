import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { fromEvent } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { Router, NavigationExtras } from '@angular/router';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
//import { NoteType } from './bm-servise-request.model';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { CustomerTypeEnum, NoDataFoundCaseFeatureName, NoteType, RoleEnum, MasterPaginationEnum, Pagination, DocumentFeatureName, requestSubTypeCount, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { ServiceRequestStatus, BmDisplayColumns } from '../service-request.model';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { MatPaginator } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { FilterListValues, FeatureNameLocalStorage } from 'src/app/shared/common/models';

@Component({
  selector: 'app-bm-service-request-list',
  templateUrl: './bm-service-request-list.component.html',
  styleUrls: ['./bm-service-request-list.component.scss']
})

export class BmServiceRequestListComponent implements OnInit {
  isShowList: boolean = false;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  serivceRequestStatusEnum = ServiceRequestStatus;
  //status = "All";
  filter = false;
  selectedCaseCategory: string;
  selectedPriority: string;
  AssociationId: string;
  UserId: string;
  Role: string;
  customerType = CustomerTypeEnum.Association;
  caseType: string;
  noDataMessage = "No Data Found";
  allServiceRequest: any;
  statusCount: any;
  allCount: any;
  allCategory: any;
  filterByKeyWords: string = "";
  userData: UserData;
  domain: string;
  @ViewChild('searchData') searchData: any;

  //for date filter
  dateTo: any = '';
  dateFrom: any = '';
  bsRangeValue: Date[] = [];

  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  /**End For Manage Columns*/

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;


  //for save data in localstorage
  localStorageFromDate;
  localStorageToDate;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  isApiResponceCome = false;
  constructor(public serviceRequest: ServiceRequestService,
    private progressbarService: ProgeressBarService,
    public commonService: CommonService,
    private router: Router, private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.AssociationId = this.userData.UserAssociations[0].AssociationId;
    this.UserId = this.userData.UserProfileId;
    this.Role = this.userData.Role;
    this.domain = this.userData.UserAssociations[0].Domain;// "testassociation";
    /**For Manage Columns*/
    this.seletedColumns = BmDisplayColumns.AwatingDecisionColumnsList;
    this.displayColumnsDdl = BmDisplayColumns.AwatingDecisionSelectedColumnsList;
    this.defaultColumnsList = BmDisplayColumns.DefaultColumnsList;
    /**End For Manage Columns*/
    this.getListCount();

  }
  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/
  ngOnInit() {
    this.serviceRequest.listStatus = localStorage.getItem('serviceRequestStatus');
    if (this.serviceRequest.listStatus === "" || this.serviceRequest.listStatus === undefined || this.serviceRequest.listStatus == null) {
      this.serviceRequest.listStatus = ServiceRequestStatus.AwaitingBoardDecision;
    }
    if (this.Role === RoleEnum.PropertyManager) {
      this.router.navigate([AppRouteUrl.mainServiceRequestPMRouteUrl]);
      this.serviceRequest.listStatus = ServiceRequestStatus.All;
    }
    this.getAllCategory();
    //get local storage filter data
    this.getLocalStorageData();
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.sort();
      });
  }

  //Get Count of list
  getListCount() {
    var model = this.commonService.getListModel(this.AssociationId, this.UserId, this.Role);
    let resData
    this.commonService.getListcount(model, DocumentFeatureName.ServiceRequest, requestSubTypeCount.Count).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success) {
        this.statusCount = resData.caseRequestListResults[0].StatusTypeCount;
      } else {
        this.statusCount = resData.caseRequestListResults[0].StatusTypeCount;
      }
    });
  }

  getLocalStorageData() {
    //get local storage filter data
    var data: FilterListValues = this.commonService.getFilterDataFromLocalStorge();
    if (data !== null && data !== undefined) {
      if (data.FeatureName === FeatureNameLocalStorage.ServiceRequestBM) {
        this.serviceRequest.listStatus = data.Status;
        this.selectedCaseCategory = data.Category;
        this.selectedPriority = data.Priority;
        this.filterByKeyWords = data.SearchKey;
        this.dateFrom = data.DateFrom !== null && data.DateFrom !== undefined && data.DateFrom !== '' ? new Date(data.DateFrom).toUTCString() : '';
        this.dateTo = data.DateTo !== null && data.DateTo !== undefined && data.DateTo !== '' ? new Date(data.DateTo).toUTCString() : '';
        this.filter = data.Filter;

        if (this.dateFrom !== "" && this.dateFrom !== null && this.dateFrom !== undefined && this.dateTo !== "" && this.dateTo !== null && this.dateTo !== undefined) {
          this.bsRangeValue = [new Date(data.DateFrom), new Date(data.DateTo)];
        } else {
          this.bsRangeValue = [];
        }
      }
    }
    this.statusChange(this.serviceRequest.listStatus);
  }

  filterDataLocalstorage() {
    var filtersModel: FilterListValues = {
      SearchKey: this.filterByKeyWords,
      DateTo: this.localStorageToDate,
      DateFrom: this.localStorageFromDate,
      Category: this.selectedCaseCategory,
      Priority: this.selectedPriority,
      AssignTo: "",
      Status: this.serviceRequest.listStatus,
      ViolationFieldType: "",
      Filter: this.filter,
      FeatureName: FeatureNameLocalStorage.ServiceRequestBM
    }
    return filtersModel;
  }


  // get all serviceRequest Data
  getAllServiceRequest() {
    this.isShowList = false;
    let status = this.serviceRequest.listStatus === 'All' ? '' : this.serviceRequest.listStatus;
    let resCategory = this.selectedCaseCategory;
    resCategory = resCategory === "All" ? resCategory = "" : resCategory;
    let resPriorty = this.selectedPriority;
    resPriorty = resPriorty === "All" ? resPriorty = "" : resPriorty;
    let resFilterByKeyWords = this.filterByKeyWords;
    this.progressbarService.show();
    this.serviceRequest.getBMServiceRequest(this.UserId, this.AssociationId, this.Role, status, resCategory, resPriorty, resFilterByKeyWords, this.dateTo, this.dateFrom, this.pageSkip, this.pageTake).subscribe(
      (response: any) => {
        this.isApiResponceCome = true;
        this.isShowList = true;
        console.log('responce ', response);
        this.progressbarService.hide();
        if (response.Errors.length == 0) {
          this.allServiceRequest = response.caseRequestListResults[0].serviceRequestList;
          this.allCount = response.caseRequestListResults[0].ResultCount;
          if (this.allServiceRequest !== null) {
            this.setPaginationData(this.allServiceRequest);
            this.SetDetailsOfNextPreviousOnDetailsPage();
          } else {
            this.TotalRecord = 0;
          }
        }
      }
    );
  }

  //for filter by date
  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.localStorageFromDate = event[0];
        this.dateTo = new Date(event[1]).toUTCString();
        this.localStorageToDate = event[1];
        this.getAllServiceRequest();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getAllServiceRequest();
    }
  }


  getAssociationAddressForList(request) {
    var associationUnit = {
      AssociationUnitAddress1: request.CreatedByUnitAddress1,
      AssociationUnitAddress2: request.CreatedByUnitAddress2,
      AssociationUnitCity: request.CreatedByUnitCity,
      AssociationUnitState: request.CreatedByUnitState,
      AssociationUnitZip: request.CreatedByUnitZip
    }
    return this.commonService.getAssociationAddressForList(associationUnit);
  }

  // get all categories
  getAllCategory() {
    this.caseType = "Homeowners";
    this.serviceRequest.getAllCategories(this.customerType, this.caseType).subscribe(
      (response: any) => {
        console.log(response);
        if (response.Errors.length === 0) {
          this.allCategory = response.CaseType.CaseCategory;
        }
      }
    );
  }
  addClass() {
    this.selectedCaseCategory = "All";
    this.selectedPriority = "All";
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }
  // change status
  status: string;
  statusChange(s) {
    this.serviceRequest.listStatus = s;
    /**For Manage Columns*/
    if (this.serivceRequestStatusEnum.InProgress === s) {
      this.seletedColumns = BmDisplayColumns.InProgressColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.InProgressSelectedColumnsList;
    } else if (this.serivceRequestStatusEnum.All === s) {
      this.seletedColumns = BmDisplayColumns.AllColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.AllSelectedColumnsList;
    } else if (this.serivceRequestStatusEnum.AwaitingBoardDecision === s) {
      this.seletedColumns = BmDisplayColumns.AwatingDecisionColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.AwatingDecisionSelectedColumnsList;
    } else if (this.serivceRequestStatusEnum.Cancelled === s) {
      this.seletedColumns = BmDisplayColumns.CancelledColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.CancelledSelectedColumnsList;
    } else if (this.serivceRequestStatusEnum.Resolved === s) {
      this.seletedColumns = BmDisplayColumns.ResolvedColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.ResolvedSelectedColumnsList;
    } else if (this.serivceRequestStatusEnum.New === s) {
      this.seletedColumns = BmDisplayColumns.NewColumnsList;
      this.displayColumnsDdl = BmDisplayColumns.NewSelectedColumnsList;
    }
    /**End For Manage Columns*/
    this.setPaginationVariables();
    this.getAllServiceRequest();
    this.getListCount();
  }

  onClickChangeStatus(s) {
    if (this.serviceRequest.listStatus === s) {
      return;
    } else {
      this.statusChange(s);
    }
  }

  // filter service Request data
  sort() {
    this.getAllServiceRequest();
  }
  // get Requst ID & redirect on Detail page
  getRequest(requestId) {
    this.serviceRequest.domain = this.domain;
    this.serviceRequest.requestId = requestId;
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": requestId
      }
    };
    //set localstorage data
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.router.navigate([AppRouteUrl.mainServiceRequestDetailBMRouteUrl], navigationExtras);
  }

  // clear FIlter
  clearFilter() {
    if (this.selectedCaseCategory === "All" && this.filterByKeyWords === "" && this.selectedPriority === "All" && (this.bsRangeValue === null || this.bsRangeValue === [] || this.bsRangeValue.length === 0)) {
      return
    }
    this.selectedCaseCategory = "All";
    this.selectedPriority = "All";
    this.filterByKeyWords = "";
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    this.localStorageFromDate = "";
    this.localStorageToDate = "";
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.getAllServiceRequest();
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }
  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }

  //For Pagination
  setPaginationData(arcList) {
    this.TotalRecord = this.allCount;
    this.FilterArray = arcList;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = arcList.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize
    this.pageTake = clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getAllServiceRequest();
    var elmnt: any = document.getElementById("contentTable");
    if (elmnt !== null) {
      elmnt.scrollTo(0, 0);
    }
  }

  //For Next Previous
  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('SRBM');
    var temp: any = [];
    this.allServiceRequest.forEach(element => {
      temp.push({
        id: element.id,
        caseid: element.CaseId,
        status: element.ServiceRequestStatus
      });
    });
    localStorage.setItem('SRBM', JSON.stringify(temp));
  }


}
