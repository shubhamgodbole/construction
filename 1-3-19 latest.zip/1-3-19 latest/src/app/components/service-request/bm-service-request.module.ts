import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatTooltipModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatPaginatorModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BmServiceRequestListComponent } from './bm-service-request-list/bm-service-request-list.component';
import { BmServiceRequestDetailComponent } from './bm-service-request-detail/bm-service-request-detail.component';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';

const routes: Routes = [
  {
    path: '',
    component: BmServiceRequestListComponent
  },
  {
    path: AppRouteUrl.serviceRequestDetailBMRouteUrl,
    component: BmServiceRequestDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoCaseNoteFoundModule,
    SafeModule,
    NoDataFoundModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatPaginatorModule,
    NumberOnlyDirectiveModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes),
    BsDatepickerModule.forRoot(),
    FilterUniqueArrayModule,
    HideIfUnauthorizedModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [BmServiceRequestListComponent, BmServiceRequestDetailComponent]
})
export class BmServiceRequestModule { }
