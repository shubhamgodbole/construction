import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatTooltipModule, MatCheckboxModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatPaginatorModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { HoServiceRequestListComponent } from './ho-service-request-list/ho-service-request-list.component';
import { HoServiceRequestDetailComponent } from './ho-service-request-detail/ho-service-request-detail.component';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { NoDataFoundComponent } from 'src/app/shared/component/no-data-found/no-data-found.component';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';


const routes: Routes = [
  {
    path: '',
    component: HoServiceRequestListComponent
  },
  {
    path: AppRouteUrl.serviceRequestDetailHORouteUrl,
    component: HoServiceRequestDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoCaseNoteFoundModule,
    NoDataFoundModule,
    SafeModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatPaginatorModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    FormsModule,
    RouterModule.forChild(routes),
    BsDatepickerModule.forRoot(),
    FilterUniqueArrayModule,
    HideIfUnauthorizedModule
  ],
  exports: [RouterModule],
  declarations: [HoServiceRequestListComponent, HoServiceRequestDetailComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class HoServiceRequestModule { }
