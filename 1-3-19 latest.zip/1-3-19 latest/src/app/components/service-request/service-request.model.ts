export class CaseRequestModel {
    id: string;
    Title: string;
    AssociationId: string;
    AssociationName: string;
    CaseTypeId: string;
    CaseType: string;
    SubCaseType: string;
    CaseCategory: string;
    CaseSubCategory: string;
    CasePriority: string;
    Description: string;
    CustomerType: string;
    CustomerTypeId: string;
    LastName: string;
    FirstName: String;
    AssociationUnitId: string;
    CreatedByUserId: string;
    CreatedByUserName: string;
    StatusReason: string;
    IsAuthorized: string;
    CaseOriginatingType: string;
    UserProfileId: string;
    PhoneofCaller: string;
    Phone: string;
    AssignedPartyType: string;
    AssignedTo: string;
    Email: string;
    CompanyCode: string;
    UserName: string;
    UnitRoleId: string;
    UnitRoleName: string;
    CaseDocuments: string[];
}

export class CaseUnitModel {
    id: string;
    CreatedByUnitId: string;
    CreatedByUnitNumber: string;
    CreatedByUnitAddress1: string;
    CreatedByUnitAddress2: string;
    CreatedByUnitCity: string;
    CreatedByUnitState: string;
    CreatedByUnitZip: string;
}
export enum ServiceRequestStatus {
    All = "All",
    New = "New",
    InProgress = "InProgress",
    AwaitingBoardDecision = "AwaitingBoardDecision",
    Resolved = "Completed",
    Completed = "Completed",
    Cancelled = "Canceled"
}
export class UpdateServiceStatus {
    RequestId: string;
    StatusType: string;
    CaseNotes: CaseNotesModel;
}
export class CaseNotesModel {
    CaseNoteId: string;
    Note: string;
    CaseId: string;
    CreatedByUserId: string;
    NotesType: string;
    CaseFeatureType: string;
    CreatedByUserName: string;
    RoleType: string;
}


export class RequestCaseNoteModel {
    CaseNoteId: string;
    Note: string;
    CreatedByUserId: string;
    CaseId: string;
    NotesType: string;
    CreatedByUserName: string;
    CaseFeatureType: string;
    ProfilePath: string;
    RoleType: string;
    StatusReason: string
}

export enum CaseFeatureType {
    ServiceRequest = "ServiceRequest",
    BoardTask = "BoardTask",
    Violation = "Violation",
    ARCRequest = "ARCRequest",
    Motion = "Motion"
}

export class addMotion {
    CaseId: string
    AssociationId: string
    AssociationName: string
    CreatedByUserId: string
    CreatedByUserName: string
    CreatedOn: Date
    Description: string
    CaseFeatureType: string
    // DocumentType: string
}

export class VoteModel {
    Vote: boolean;
    CreatedByUserId: string;
    CreatedByUserName: string;
    Remarks: string;
    ProfilePath: string;
}



export class CaseNoteModel {
    AssociationId: string;
    Domain: string;
    TypeOfDocument: string;
    RequestId:string;
    Document: any[];
    CaseNotes: RequestCaseNoteModel;
}

export class ReopenModel {
    CaseNoteId: string
    StatusReason: string
    Reason: string
    CreatedByUserId: string
    CreatedByUserName: string
    CreatedOn: Date
}


export class UpdateServiceRequestStatus {
    RequestId: string;
    StatusType: string;
    //CaseId: string;
    CaseNotes: RequestCaseNoteModel;
}

export class MotionModel {
    MotionId: string;
    CaseId: string;
    AssociationId: string;
    AssociationName: string;
    CreatedByUserId: string;
    CreatedByUserName: string;
    Description: string;
    CaseFeatureType: string;
    ProfilePath: string;
}



export class BmDisplayColumns {
    public static ColumnsList = [
        { value: "Status", text: "Status" },
        { value: "Priority", text: "Priority" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
       // { value: "Action", text: "Action" },
        { value: "CompletedOn", text: "Completed On" },
        { value: "Rating", text: "Rating" }
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "UnitNumber", text: "Unit Number" },
        { value: "UnitAddress", text: "Unit Address" },
        { value: "Category", text: "Category" },
        { value: "CreatedOn", text: "Created On" }
    ]

    public static AllSelectedColumnsList = [
        { value: "Status", text: "Status" },
        { value: "Priority", text: "Priority" }
    ]

    public static NewSelectedColumnsList = [
        { value: "Priority", text: "Priority" }
    ]

    public static InProgressSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "Priority", text: "Priority" }
    ]

    public static AwatingDecisionSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
       // { value: "Action", text: "Action" },
        { value: "Priority", text: "Priority" }
    ]

    public static ResolvedSelectedColumnsList = [
        { value: "CompletedOn", text: "Completed On" },
        { value: "Rating", text: "Rating" }
    ]

    public static CancelledSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" }
    ]

    public static AllColumnsList = [
        "Title", "Unit Number", "Unit Address", "Category", "Created On", "Status", "Priority"
    ]

    public static NewColumnsList = [
        "Title", "Unit Number", "Unit Address", "Category", "Created On", "Priority"
    ]

    public static InProgressColumnsList = [
        "Title", "Unit Number", "Unit Address", "Category", "Created On", "Last Updated On", "Priority"
    ]

    public static AwatingDecisionColumnsList = [
        "Title", "Unit Number", "Unit Address", "Category", "Created On", , "Last Updated On", "Action", "Priority"
    ]

    public static ResolvedColumnsList = [
        "Title", "Unit Number", "Unit Address", "Category", "Created On", "Completed On", "Rating"
    ]

    public static CancelledColumnsList = [
        "Title", "Unit Number", "Unit Address", "Category", "Created On", "Last Updated On"
    ]

}

export class HoDisplayColumns {
    public static ColumnsList = [
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
        { value: "Priority", text: "Priority" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "CompletedOn", text: "Completed On" },
        { value: "Rating", text: "Rating" }
    ]

    public static AllSelectedColumnList = [
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
        { value: "Priority", text: "Priority" },
    ]

    public static NewSelectedColumnList = [
        // { value: "Comments", text: "Comments" },
        { value: "Priority", text: "Priority" },
    ]

    public static InProgressSelectedColumnList = [
        // { value: "Comments", text: "Comments" },
        { value: "Priority", text: "Priority" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
    ]

    public static AwatingDecisionSelectedColumnList = [
        // { value: "Comments", text: "Comments" },
        { value: "Priority", text: "Priority" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
    ]

    public static ResolvedSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "CompletedOn", text: "Completed On" },
        { value: "Rating", text: "Rating" }
    ]

    public static CancelledSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "Priority", text: "Priority" },
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Category", text: "Category" },
        { value: "CreatedOn", text: "Created On" }
    ]

    public static AllColumnsList = [
        "Title", "Category", "Created On", "Status", "Priority", "Comments"
    ]

    public static NewColumnsList = [
        "Title", "Category", "Created On", "Priority", "Comments"
    ]

    public static InProgressColumnsList = [
        "Title", "Category", "Created On", "Last Updated On", "Priority", "Comments"
    ]

    public static AwatingDecisionColumnsList = [
        "Title", "Category", "Created On", "Last Updated On", "Priority", "Comments"
    ]

    public static ResolvedColumnsList = [
        "Title", "Category", "Created On", "Last Updated On", "Completed On", "Rating"
    ]

    public static CancelledColumnsList = [
        "Title", "Category", "Created On", "Last Updated On", "Priority"
    ]

}

/**For Manage Columns for PM*/
export class DisplayColumnsPM {
    public static ColumnsList = [
        { value: "Status", text: "Status" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "LastUpdated On", text: "Last Updated On" },
        { value: "CompletionTime", text: "Completion Time" },
        { value: "CanceledOn", text: "Canceled On" },
        { value: "CompletedOn", text: "Completed On" },
        { value: "Updated By", text: "Updated By" },
        { value: "PendingTime", text: "Pending Time" },
        { value: "Rating", text: "Rating" },
        { value: "Priority", text: "Priority" },
      //  { value: "Action", text: "Action" },
        // { value: "Comments", text: "Comments" },
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Association", text: "Association" },
        { value: "LotNo.", text: "Lot No." },
        { value: "LotAddress", text: "Lot Address" },
        { value: "CreatedOn", text: "Created On" },
        { value: "AssignTo", text: "Assign To" }
    ]

    public static AllSelectedColumnsList = [
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "Priority", text: "Priority" },
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
    ]

    public static NewSelectedColumnsList = [
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "Priority", text: "Priority" },
        // { value: "Comments", text: "Comments" },
    ]

    public static InProgressSelectedColumnsList = [
        { value: "LastUpdated On", text: "Last Updated On" },
        { value: "Updated By", text: "Updated By" },
        { value: "TimeElapsed", text: "Time Elapsed" },
        { value: "Priority", text: "Priority" },
        // { value: "Comments", text: "Comments" },
    ]

    public static AwaitingDecisionSelectedColumnsList = [
        { value: "LastUpdated On", text: "Last Updated On" },
        { value: "Updated By", text: "Updated By" },
        { value: "Priority", text: "Priority" },
        // { value: "PendingTime", text: "Pending Time" },
       // { value: "Action", text: "Action" },
        // { value: "Comments", text: "Comments" },
    ]

    public static CompletedSelectedColumnsList = [
        { value: "CompletedOn", text: "Completed On" },
        { value: "Updated By", text: "Updated By" },
        // { value: "CompletionTime", text: "Completion Time" },
        { value: "Rating", text: "Rating" }
    ]

    public static CancelledSelectedColumnsList = [
        { value: "CanceledOn", text: "Canceled On" },
        { value: "Updated By", text: "Updated By" },
    ]


    public static AllColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Status", "Time Elapsed", "Comments", "Priority"
    ]

    public static NewColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Assign To", "Time Elapsed", "Priority", "Comments"
    ]

    public static InProgressColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Last Updated On", "Updated By", "Assign To", "Time Elapsed", "Comments", "Priority"
    ]

    public static AwaitingDecisionColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Last Updated On","Updated By", "Assign To", "Pending Time", "Action", "Comments", "Priority"
    ]

    public static CompletedColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Completion On","Updated By", "Completion Time", "Assign To", "Rating"
    ]


    public static CancelledColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Canceled On","Updated By", "Assign To"
    ]

}
/**End For Manage Columns*/

// export class CaseSubCategory {
//     caseCategoryName: string;
//     caseSubCategoryNames: CaseSubCategoryName[];
// }
// export class CaseSubCategoryName {
//     caseSubCategory: string;
// }

export class CustomerType {
    customerTypeName: string;
    customerTypeId: string;
    documentType: string;
    caseTypes: CaseTypes[];
}

export class CaseTypes {
    CaseTypeId: string;
    Name: string;
    CaseCategory: CaseCategory[];
}

export class CaseCategory {
    CaseCategoryId: string;
    Name: string;
    CaseSubCategories: CaseSubCategories[];
}
export class CaseSubCategories {
    caseSubCategoryNames: CaseSubCategoryName[];
}

export class CaseSubCategoryName {
    caseSubCategory: string;
}

export enum UnitDocumentType {
    ServiceRequests = "Service Requests",
    Violations = "Violations",
    ARCRequests = "ARC Requests"
}

export class CallModel {
    RequestId: string;
    CaseNotes: {
        CallType: string;
        CallNumber: string;
        CallerName: string;
        IsShowCallConversation: boolean;
        IsVotingRequired: boolean;
        CallDuration: string;
        PhoneCallRecord: string;
        CaseNoteId: string;
        Note: string;
        CreatedByUserId: string;
        CaseId: string;
        NotesType: string;
        CreatedByUserName: string;
        CaseFeatureType: string;
        ProfilePath: string;
        RoleType: string;
        StatusReason: string;
        ActivityType: string;
    }
}

export class EmailModel {
    RequestId: string;
    AssociationId: string;
    TypeOfDocument: string;
    Document: any;
    Domain: string;
    CaseNotes: {
        To: string;
        CC: string;
        BCC: string;
        Message: string;
        Subject: string;
        CaseNoteId: string;
        Note: string;
        CreatedByUserId: string;
        CaseId: string;
        NotesType: string;
        CreatedByUserName: string;
        CaseFeatureType: string;
        ProfilePath: string;
        RoleType: string;
        StatusReason: string;
        ActivityType: string;
        EmailAudience: string;
    }
}


// Assign to model
export class AssignToModel {
    RequestId: string;
    CaseId: string;
    Case: {
        AssignedTo: string;
        ModifiedByUserId: string;
        ModifiedByUserName: string;
    }
}

export class CaseNoteDetailModel {
    CaseNotes: {
        ActivityType: string;
        BCC: string
        CC: string
        CallDuration: string;
        CallNumber: string;
        CallType: string;
        CallerName: string;
        CaseFeatureType: string;
        CaseId: string;
        CaseNoteDocuments: string;
        CreatedByUserId: string;
        CreatedByUserName: string;
        CreatedOrModifiedOn: string;
        DocumentType: string;
        IsAssignedToBoard: boolean;
        IsShowCallConversation: string;
        IsVotingRequired: boolean;
        Message: string;
        Note: string;
        NotesType: string;
        PhoneCallRecord: null;
        ProfilePath: string;
        RoleType: string;
        StatusReason: string;
        Subject: string;
        To: string;
        VoteStatus: string;
        id: string;
        Votes: any
    }
    Document: any
}

export enum RequestMsg {
    RequestCanceled = "Request Canceled",
    RequestReopened = "Request Reopened",
    RequestCompleted = "Request Completed",
    WorkCompleted = "Work Completed",
    RequestWorkCompleted = "Work Completed"
}
