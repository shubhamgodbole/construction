import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { fromEvent, Subscription } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { CaseRequestModel, CaseUnitModel } from '../service-request.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { ServiceRequestStatus, HoDisplayColumns } from '../service-request.model';
import { CustomerTypeEnum, SubCaseTypeEnum, TypeOfDocument, NoDataFoundCaseFeatureName, ImageNameEnums, CaseOriginatingType, IsAuthorized, StatusReason, NoteType, CaseTypeEnum, MasterPaginationEnum, Pagination, FeatureName, SourceType, TriggerType, AudienceType, DocumentFeatureName, requestSubTypeCount, RoleEnum, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { DisplayPriority, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { Guid } from 'guid-typescript';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { MatPaginator, MatSnackBar } from '@angular/material';
import { AssignedPartyType } from '../../arc/arc-model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { CommonService } from 'src/app/services/common.service';
import { FilterListValues, FeatureNameLocalStorage, GetListCountModel } from 'src/app/shared/common/models';
import { NotificationService } from 'src/app/shared/services/notification.service';

@Component({
  selector: 'app-ho-service-request-list',
  templateUrl: './ho-service-request-list.component.html',
  styleUrls: ['./ho-service-request-list.component.scss']
})
export class HoServiceRequestListComponent implements OnInit {
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  isShowList: boolean = false;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  serivceRequestStatusEnum = ServiceRequestStatus;
  // status = "All";
  selectedCaseCategory: string = "All";
  selectedPriority: string = "All";
  filter: boolean;
  sidebar = false;
  AssociationId: string;
  UserId: string;
  AssociationName: string;
  userName: string;
  FirstName: string;
  LastName: string;
  companyCode: string;
  role: string;
  customerType = CustomerTypeEnum.Association; //"Association";
  caseType: string;
  noDataMessage = "No Data Found";
  allServiceRequest: any;
  statusCount: any;
  allCount: any;
  allCategory: any;
  subCategory: any;
  addRequestForm: FormGroup;
  isSubmitBtnDisabled: boolean = false;
  filterByKeyWords: string = "";
  //imgFlag: boolean = false;
  fileData: any = [];
  associationUnitId;
  subCaseType = SubCaseTypeEnum.ServiceRequest;// "ServiceRequest"
  @ViewChild('searchData') searchData: any;
  associationUnitData: any = [];
  typeOfDocument = TypeOfDocument.CaseDocuments;// "CaseDocuments";
  domain: string;// = "testassociation";
  userData: UserData;
  errorMsg: string = "";
  priorityDdl: any;
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  /**End For Manage Columns*/

  //for date filter
  dateTo: any;
  dateFrom: any;
  bsRangeValue: Date[] = [];

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;

  //For Query string;
  querySubcription: Subscription;

  //For Send Notification
  featureId: string;
  pmCompanyAssociationMappingId: string;

  //for save data in localstorage
  localStorageFromDate;
  localStorageToDate;

  notificationService: NotificationService;

  status: any = this.serivceRequestStatusEnum.All;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;


  isApiResponceCome = false;

  constructor(public serviceRequest: ServiceRequestService,
    private formBuilder: FormBuilder, private router: Router,
    private readonly snb: MatSnackBar,
    private emailNotification: EmailNotificationService,
    public commonService: CommonService,
    private route: ActivatedRoute,
    private readonly appConfig: AppConfig, private progressbarService: ProgeressBarService) {

    this.priorityDdl = DisplayPriority.PriorityList;
    this.userData = this.appConfig.getCurrentUser();
    this.AssociationId = this.userData.UserAssociations[0].AssociationId;
    this.AssociationName = this.userData.UserAssociations[0].Name;
    this.UserId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    //   this.domain = this.userData.UserAssociations[0].Domain;
    this.FirstName = this.userName.split(' ')[0];
    this.LastName = this.userName.split(' ')[1];
    this.role = this.userData.Role;
    this.getListCount();
    this.domain = this.userData.UserAssociations[0].Domain;// "testassociation";
    this.notificationService = new NotificationService(snb);
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
  }

  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/

  ngOnInit() {
    /**For Manage Columns*/
    this.seletedColumns = HoDisplayColumns.AllColumnsList;
    this.displayColumnsDdl = HoDisplayColumns.AllSelectedColumnList;
    this.defaultColumnsList = HoDisplayColumns.DefaultColumnsList;
    /**End For Manage Columns*/
    this.createServiceRequestForm();
    this.getAllCategory();
    this.getAllAssociationUnit();

    //to open add dialog
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let isAdd = params["isAdd"];
      if (isAdd === "true") {
        this.sidebar = true;
      }
    });

    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.sort();
      });

    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Service_Request && (feature.UnitId !== null && feature.UnitId !== "")) {
          this.featureId = feature.FeatureId
        }
      });
  }

  getListCount() {
    var model = this.commonService.getListModel(this.AssociationId, this.UserId, RoleEnum.Member);
    let resData
    this.commonService.getListcount(model, DocumentFeatureName.ServiceRequest, requestSubTypeCount.Count).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success) {
        this.statusCount = resData.caseRequestListResults[0].StatusTypeCount;
      } else {
        this.statusCount = resData.caseRequestListResults[0].StatusTypeCount;
      }
    });
  }

  createServiceRequestForm() {
    this.addRequestForm = this.formBuilder.group({
      serviceRequestDetailId: [''],
      title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      category: ['', Validators.required],
      subCategory: ['', Validators.required],
      associationUnit: ['', Validators.required],
      urgencyLevel: ['', Validators.required],
      comment: ['', [Validators.required, Validators.minLength(1), ValidationService.noWhiteSpace]],
      attechment: [''],
    });
    this.getLocalStorageData();
  }
  getLocalStorageData() {
    //get local storage filter data
    var data: FilterListValues = this.commonService.getFilterDataFromLocalStorge();
    if (data !== null && data !== undefined) {
      if (data.FeatureName === FeatureNameLocalStorage.ServiceRequestHO) {
        this.status = data.Status;
        this.selectedCaseCategory = data.Category;
        this.selectedPriority = data.Priority;
        this.filterByKeyWords = data.SearchKey;
        this.dateFrom = data.DateFrom !== null && data.DateFrom !== undefined && data.DateFrom !== '' ? new Date(data.DateFrom).toUTCString() : '';
        this.dateTo = data.DateTo !== null && data.DateTo !== undefined && data.DateTo !== '' ? new Date(data.DateTo).toUTCString() : '';
        this.filter = data.Filter;

        if (this.dateFrom !== "" && this.dateFrom !== null && this.dateFrom !== undefined && this.dateTo !== "" && this.dateTo !== null && this.dateTo !== undefined) {
          this.bsRangeValue = [new Date(data.DateFrom), new Date(data.DateTo)];
        } else {
          this.bsRangeValue = [];
        }
      } else {
        this.status = "All";
      }
    }
    this.statusChange(this.status);
  }
  // get all serviceRequest Data
  getAllServiceRequest() {
    this.isShowList = false;
    let status = this.status === 'All' ? '' : this.status;
    let resCategory = this.selectedCaseCategory;
    resCategory = resCategory === "All" ? resCategory = "" : resCategory;
    let resPriorty = this.selectedPriority;
    resPriorty = resPriorty === "All" ? resPriorty = "" : resPriorty;
    let resFilterByKeyWords = this.filterByKeyWords;

    this.progressbarService.show();
    this.serviceRequest.getHOServiceRequest(this.UserId, this.AssociationId, this.role, status, resCategory, resPriorty, resFilterByKeyWords, this.dateTo, this.dateFrom, this.pageSkip, this.pageTake).subscribe(
      (response: any) => {
        this.isApiResponceCome = true;
        this.progressbarService.hide();
        this.isShowList = true;
        if (response.Errors.length == 0) {
          this.allServiceRequest = response.caseRequestListResults[0].serviceRequestList;
          this.allCount = response.caseRequestListResults[0].ResultCount;
          if (this.allServiceRequest !== null) {
            this.setPaginationData(this.allServiceRequest);
            this.SetDetailsOfNextPreviousOnDetailsPage();
          } else {
            this.TotalRecord = 0;
          }
        }
      }
    );
  }

  //for filter by date
  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.localStorageFromDate = event[0];
        this.dateTo = new Date(event[1]).toUTCString();
        this.localStorageToDate = event[1];
        this.getAllServiceRequest();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getAllServiceRequest();
    }
  }


  // get all categories
  getAllCategory() {
    this.caseType = "Homeowners";
    this.serviceRequest.getAllCategories(this.customerType, this.caseType).subscribe(
      (response: any) => {
        this.allCategory = response.CaseType.CaseCategory
        this.allCategory = this.allCategory.filter(x => x.Name !== "ARC" && x.Name !== "Violations")
      }
    );
  }

  filterToggle() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  sidebarToggle() {
    if (this.sidebar) {
      this.sidebar = false;
    }
    else
      this.sidebar = true;
    this.reset();
  }
  // change status
  statusChange(s) {
    this.status = s;
    /**For Manage Columns*/
    if (this.serivceRequestStatusEnum.InProgress === s) {
      this.seletedColumns = HoDisplayColumns.InProgressColumnsList;
      this.displayColumnsDdl = HoDisplayColumns.InProgressSelectedColumnList;
    } else if (this.serivceRequestStatusEnum.All === s) {
      this.seletedColumns = HoDisplayColumns.AllColumnsList;
      this.displayColumnsDdl = HoDisplayColumns.AllSelectedColumnList;
    } else if (this.serivceRequestStatusEnum.AwaitingBoardDecision === s) {
      this.seletedColumns = HoDisplayColumns.AwatingDecisionColumnsList;
      this.displayColumnsDdl = HoDisplayColumns.AwatingDecisionSelectedColumnList;
    } else if (this.serivceRequestStatusEnum.Cancelled === s) {
      this.seletedColumns = HoDisplayColumns.CancelledColumnsList;
      this.displayColumnsDdl = HoDisplayColumns.CancelledSelectedColumnsList;
    } else if (this.serivceRequestStatusEnum.Resolved === s) {
      this.seletedColumns = HoDisplayColumns.ResolvedColumnsList;
      this.displayColumnsDdl = HoDisplayColumns.ResolvedSelectedColumnsList;
    } else if (this.serivceRequestStatusEnum.New === s) {
      this.seletedColumns = HoDisplayColumns.NewColumnsList;
      this.displayColumnsDdl = HoDisplayColumns.NewSelectedColumnList;
    }
    /**End For Manage Columns*/
    this.setPaginationVariables();
    this.getAllServiceRequest();
    this.getListCount();
  }

  onClickChangeStatus(s) {
    if (this.status === s) {
      return;
    } else {
      this.statusChange(s);
    }
  }
  // filter service Request data
  sort() {
    this.getAllServiceRequest();
  }
  // upload Documents
  onUploadChange(evt: any) {
    //this.imgFlag = false;
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }

  }
  // remove uploaded Documents
  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }

  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };
  // get Category
  getCategory(event) {
    this.addRequestForm.controls.subCategory.setValue('');
    let subCategory = this.allCategory.filter(cat => cat.Name === event.value);
    this.subCategory = subCategory[0].CaseSubCategories;
  }
  // send Request
  onSubmit() {
    if (this.addRequestForm.valid) {
      this.isSubmitBtnDisabled = true;
      let CaseRequest = {
        Case: this.createRequestModel(),
        ServiceRequest: this.createCaseUnitModel(),
        TypeOfDocument: this.typeOfDocument,
        Domain: this.domain,
        Document: this.fileData,
      };
      this.serviceRequest.addRequest(CaseRequest).subscribe(
        (response: any) => {
          this.isSubmitBtnDisabled = false;
          if (response.caseRequestListResults[0].Success) {
            this.emailNotification.sendNotifications(this.featureId, response.caseRequestListResults[0].RequestId, this.UserId, this.pmCompanyAssociationMappingId,
              SourceType.Web, FeatureName.Service_Request, TriggerType.Create,
              AudienceType.HomeOwner).subscribe(res => {
                console.log(res);
              });
            this.sidebar = false;
            this.notificationService.showNotification("Service Request saved successfully")
            this.reset();
            this.getListCount();
            this.getAllServiceRequest();
            console.log('Added');
          }
        });
    }


  }
  // Request Model
  createRequestModel() {
    console.log(this.associationUnitId);
    let model: CaseRequestModel = {
      id: '',
      Title: this.addRequestForm.controls.title.value,
      AssociationId: this.AssociationId,
      AssociationName: this.AssociationName,
      CaseType: this.caseType,
      CaseTypeId: '',
      CustomerTypeId: '',
      SubCaseType: this.subCaseType,
      CaseCategory: this.addRequestForm.controls.category.value,
      CaseSubCategory: this.addRequestForm.controls.subCategory.value,
      CasePriority: this.addRequestForm.controls.urgencyLevel.value,
      Description: this.addRequestForm.controls.comment.value,
      CustomerType: this.customerType,
      FirstName: '',
      LastName: '',
      AssociationUnitId: this.addRequestForm.controls.associationUnit.value.id,
      CreatedByUserId: this.UserId,
      CreatedByUserName: this.userName,
      CaseOriginatingType: CaseOriginatingType.Website,
      IsAuthorized: IsAuthorized.Yes,
      StatusReason: StatusReason.New,
      UserProfileId: this.UserId,
      PhoneofCaller: '',
      Phone: '',
      AssignedPartyType: AssignedPartyType.PROPVIVO,
      AssignedTo: '',
      CompanyCode: this.companyCode,
      Email: '',
      UserName: this.userName,
      UnitRoleId: '',
      UnitRoleName: '',
      CaseDocuments: null
    }
    return model;
  }
  // Case Unit Model
  createCaseUnitModel() {
    let model1: CaseUnitModel = {
      id: this.addRequestForm.controls.serviceRequestDetailId.value,
      CreatedByUnitId: this.associationUnitData.length === 1 ? this.associationUnitData[0].id : this.addRequestForm.controls.associationUnit.value.id,
      CreatedByUnitAddress1: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitAddress1 : this.addRequestForm.controls.associationUnit.value.AssociationUnitAddress1,
      CreatedByUnitAddress2: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitAddress2 : this.addRequestForm.controls.associationUnit.value.AssociationUnitAddress2,
      CreatedByUnitCity: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitCity : this.addRequestForm.controls.associationUnit.value.AssociationUnitCity,
      CreatedByUnitState: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitState : this.addRequestForm.controls.associationUnit.value.AssociationUnitState,
      CreatedByUnitZip: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitZip : this.addRequestForm.controls.associationUnit.value.AssociationUnitZip,
      CreatedByUnitNumber: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitNumber : this.addRequestForm.controls.associationUnit.value.AssociationUnitNumber,
    }
    return model1
  }
  // get Requst ID & redirect on Detail page
  getRequest(requestId) {
    this.serviceRequest.domain = this.domain;
    this.serviceRequest.requestId = requestId;
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": requestId
      }
    };

    //set localstorage data
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());

    this.router.navigate([AppRouteUrl.mainServiceRequestDetailHORouteUrl], navigationExtras);
  }
  // reset Form
  reset() {
    //this.imgFlag = false;
    this.isSubmitBtnDisabled = false;
    this.errorMsg = "";
    this.addRequestForm.reset();
    this.formDirective.resetForm();
    if (this.associationUnitData.length === 1) {
      this.addRequestForm.controls.associationUnit.setValue(this.getAssociationUnitAddress());
    }
    this.fileData = [];
  }

  getAssociationUnitAddress(): string {
    let associationUnitAddress = "";
    let associationAddress = this.associationUnitData[0];
    if (associationAddress.AssociationUnitNumber !== null) {
      associationUnitAddress = associationAddress.AssociationUnitNumber;
    }
    if (associationAddress.AssociationUnitAddress1 !== null) {
      associationUnitAddress = associationUnitAddress + " " + associationAddress.AssociationUnitAddress1 + ",";
    }
    if (associationAddress.AssociationUnitAddress2 !== null) {
      associationUnitAddress = associationUnitAddress + associationAddress.AssociationUnitAddress2;
    }
    if (associationAddress.AssociationUnitCity !== null) {
      associationUnitAddress = associationUnitAddress + " " + associationAddress.AssociationUnitCity;
    }
    if (associationAddress.AssociationUnitState !== null) {
      associationUnitAddress = associationUnitAddress + " " + associationAddress.AssociationUnitState + ",";
    }
    // if (associationAddress.AssociationUnitCounty !== null) {
    //   associationUnitAddress = associationUnitAddress + associationAddress.AssociationUnitCounty;
    // }
    if (associationAddress.AssociationUnitZip !== null) {
      associationUnitAddress = associationUnitAddress + " " + associationAddress.AssociationUnitZip;
    }
    return associationUnitAddress;
  }
  // get All AssociationUnits
  getAllAssociationUnit() {
    this.serviceRequest.getAllAssociationUnit(this.UserId, this.AssociationId).subscribe(
      (response: any) => {
        this.associationUnitData = response.AssociationUnit;
        if (this.associationUnitData.length === 1) {
          this.addRequestForm.controls.associationUnit.setValue(this.getAssociationUnitAddress());
        }
      }
    );
  }
  // clear FIlter
  clearFilter() {
    if (this.selectedCaseCategory === "All" && this.filterByKeyWords === "" && this.selectedPriority === "All" && (this.bsRangeValue === null || this.bsRangeValue === [] || this.bsRangeValue.length === 0)) {
      return
    }
    this.selectedCaseCategory = "All";
    this.filterByKeyWords = "";
    this.selectedPriority = "All";
    this.filterByKeyWords = "";
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    this.localStorageFromDate = "";
    this.localStorageToDate = "";
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.getAllServiceRequest();
  }

  filterDataLocalstorage() {
    var filtersModel: FilterListValues = {
      SearchKey: this.filterByKeyWords,
      DateTo: this.localStorageToDate,
      DateFrom: this.localStorageFromDate,
      Category: this.selectedCaseCategory,
      Priority: this.selectedPriority,
      AssignTo: "",
      Status: this.status,
      ViolationFieldType: "",
      Filter: this.filter,
      FeatureName: FeatureNameLocalStorage.ServiceRequestHO
    }
    return filtersModel;
  }

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(arcList) {
    this.TotalRecord = this.allCount;
    this.FilterArray = arcList;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = arcList.slice(pageStartIndex - 1, pageEndIndex);
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize
    this.pageTake = clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getAllServiceRequest();
    var elmnt: any = document.getElementById("contentTable");
    if (elmnt !== null) {
      elmnt.scrollTo(0, 0);
    }
  }

  //For Next Previous
  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('SRHO');
    var temp: any = [];
    this.allServiceRequest.forEach(element => {
      temp.push({
        id: element.id,
        caseid: element.CaseId,
        status: element.ServiceRequestStatus
      });
    });
    localStorage.setItem('SRHO', JSON.stringify(temp));
  }

  ngOnDestroy(): void {
    this.querySubcription.unsubscribe();
  }
}
