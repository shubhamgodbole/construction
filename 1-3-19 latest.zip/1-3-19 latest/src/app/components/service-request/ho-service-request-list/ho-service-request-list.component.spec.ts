import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoServiceRequestListComponent } from './ho-service-request-list.component';

describe('HoServiceRequestListComponent', () => {
  let component: HoServiceRequestListComponent;
  let fixture: ComponentFixture<HoServiceRequestListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoServiceRequestListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoServiceRequestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
