import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main.component';
import { MatListModule, MatSelectModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatIconModule, MatInputModule, MatDialogModule, MatMenuModule, MatStepperModule, MatSliderModule, MatFormFieldModule, MatSlideToggleModule, MatSnackBarModule, MatTableModule, MatRadioModule, MatTooltipModule, MatDatepickerModule, MatAutocompleteModule } from '@angular/material';
import { NoDataFoundModule } from '../shared/component/no-data-found/no-data-found.module';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { NumberOnlyDirectiveModule } from '../shared/directives/allow-only-number/only-number.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AuthGuard } from '../shared/guards/auth.guard';
import { ErrorComponent } from './error/error.component';
import { ManageCaseComponent } from '../property-management/manage-case/manage-case.component';
import { HeaderModule } from './header/header.module';
import { AppRouteUrl } from '../shared/app-module-route';
import { ProgressBarModule } from '../shared/component/progress-bar/progress-bar.module';
import { SafeModule } from '../shared/pipes/safe/safe.module';
import { PmInspectionLetterComponent } from './property-inspection/pm-inspection-letter/pm-inspection-letter.component';
import { AllowOnlyPriceModule } from '../shared/directives/allow-only-price/allow-only-price.module';
//import { PaymentTypeComponent } from './manage-payment/payment-type/payment-type.component';
import { TagInputModule } from 'ngx-chips';
import { UserIdleModule } from 'angular-user-idle';
import { CommonConstant } from '../shared/common/constant.model';
import { SmallSpinerModule } from '../shared/component/small-spinner/small-spiner.module';
import { ServicesEmailModule } from '../property-management/services-email/services-email.module';


const routes: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      { path: '', redirectTo: AppRouteUrl.dashboardRouteUrl, pathMatch: 'full' },
      {
        path: AppRouteUrl.dashboardRouteUrl,
        loadChildren: './dashboard/dashboard.module#DashboardModule',
        canActivate: [AuthGuard]
      },
      // CSR landing (recent-updates) 
      {
        path: AppRouteUrl.csrLandingRouteUrl,
        loadChildren: '../property-management/csr-landing/csr-landing.module#CsrLandingModule',
        canActivate: [AuthGuard]
      },
      // MANAGE PAYMENTS
      {
        path: AppRouteUrl.managePaymentRouteUrl,
        loadChildren: './manage-payment/manage-payment.module#ManagePaymentModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.paymentRouteUrl,
        loadChildren: './payments/payment.module#PaymentModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.socialLandingHoRouteUrl,
        loadChildren: './ho-social-landing/ho-social-landing.module#HoSocialLandingModule',
      },
      {
        path: AppRouteUrl.serviceRequestBMRouteUrl,
        loadChildren: './service-request/bm-service-request.module#BmServiceRequestModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.serviceRequestHORouteUrl,
        loadChildren: './service-request/ho-service-request.module#HoServiceRequestModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.boardTasksBMRouteUrl,
        loadChildren: './board-tasks/board-task.module#BoardTaskModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.classifiedAdsRouteUrl,
        loadChildren: './market-place/market-place.module#MarketPlaceModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.arcCMRouteUrl,
        loadChildren: './arc/cm-arc.module#CmArcModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.arcBMRouteUrl,
        loadChildren: './arc/bm-arc.module#BmArcModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.arcHORouteUrl,
        loadChildren: './arc/ho-arc.module#HoArcModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.violationsBMRouteUrl,
        loadChildren: './violation/bm-violation.module#BmViolationModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.violationsHORouteUrl,
        loadChildren: './violation/ho-violation.module#HoViolationModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.boardMemberRouteUrl,
        loadChildren: './directries//board-member-directory.module#BoardMemberDirectoryModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.documentsRouteUrl,
        loadChildren: './documents/document.module#DocumentModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.newslettersRouteUrl,
        loadChildren: './newsletter/newsletter.module#NewsletterModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.meetingRouteUrl,
        loadChildren: './meeting/meeting.module#MeetingModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.hoaMembersRouteUrl,
        loadChildren: './directries/hoa-directory.module#HoaDirectoryModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.hoHoaMembersRouteUrl,
        loadChildren: './directries/ho-hoa-directory.module#HoHoaDirectoryModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.myProfileRouteUrl,
        loadChildren: './my-profile/my-profile.module#MyProfileModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.userProfileRouteUrl,
        loadChildren: './user-profile/user-profile.module#UserProfileModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.bmUserProfileRouteUrl,
        loadChildren: './user-profile/user-profile.module#UserProfileModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.inspectionHistoryRouteUrl,
        loadChildren: './property-inspection/property-inspection.module#PropertyInspectionModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.committeeRouteUrl,
        loadChildren: './committees/committee.module#CommitteeModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.committeeHORouteUrl,
        loadChildren: './committees/ho-committee.module#HoCommitteeModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.calanderRouteUrl,
        loadChildren: './calendar/association-calendar.module#AssociationCalendarModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.boardConversationRouteUrl,
        loadChildren: './board-conversation/board-conversation.module#BoardConversationModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.documentsPMRouteUrl,
        loadChildren: '../property-management/pm-document/pm-document.module#PmDocumentModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.pmNewslettersRouteUrl,
        loadChildren: '../property-management/pm-newsletter/pm-newsletter.module#PmNewsletterModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.feedBackRouteUrl,
        loadChildren: '../property-management/user-feedback/user-feedback.module#UserFeedbackModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.serviceRequestPMRouteUrl,
        loadChildren: '../property-management/pm-service-request/pm-service-request.module#PmServiceRequestModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.boardTasksPMRouteUrl,
        loadChildren: '../property-management/pm-board-task/pm-board-task.module#PmBoardTaskModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.arcPMRouteUrl,
        loadChildren: '../property-management/pm-arc/pm-arc.module#PmArcModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.pmUserProfileRouteUrl,
        loadChildren: '../property-management/pm-user-profile/pm-user-profile.module#PmUserProfileModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'pm-inspection-letter',
        component: PmInspectionLetterComponent,
        canActivate: [AuthGuard]
      },
      {
        path: 'error',
        component: ErrorComponent
      },
      {
        path: 'member-history',
        loadChildren: '../property-management/member-history/member-history.module#MemberHistoryModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.pmBoardMemberRouteUrl,
        loadChildren: '../property-management/directories/pm-board-member.module#PmBoardMemberModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.committeePMRouteUrl,
        loadChildren: '../property-management/pm-committee/pm-committee.module#PmCommitteeModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.meetingPMRouteUrl,
        loadChildren: '../property-management/pm-meeting/pm-meeting.module#PmMeetingModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'manage-requests',
        loadChildren: '../property-management/manage-request/manage-request.module#ManageRequestModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'manage-case',
        loadChildren: '../property-management/manage-case/manage-case.module#ManageCaseModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.violationsPMRouteUrl,
        loadChildren: '../property-management/pm-violation/pm-violation.module#PmViolationModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'my-tasks',
        loadChildren: '../property-management/my-tasks/my-tasks.module#MyTasksModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'emailtocase',
        loadChildren: '../property-management/emailtocase/emailtocase.module#EmailtocaseModule',
        canActivate: [AuthGuard]
      },
      {
        path: 'portfolio',
        loadChildren: '../property-management/portfolio/portfolio.module#PortfolioModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.pmProfileRouteUrl,
        loadChildren: '../property-management/pm-profile/pm-profile.module#PmProfileModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.motionsRouteUrl,
        loadChildren: './motions/motions.module#MotionsModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.notificationRouteUrl,
        loadChildren: './notification-list/notification-list.module#NotificationListModule',
        canActivate: [AuthGuard]
      },
      {
        path: AppRouteUrl.announcementsRouteUrl,
        loadChildren: './announcements/announcement.module#AnnouncementModule',
        canActivate: [AuthGuard]
      }
    ]
  }

];
@NgModule({
  imports: [
    CommonModule,
    MatListModule,
    HeaderModule,
    MatSelectModule,
    MatBottomSheetModule,
    MatAutocompleteModule,
    NoDataFoundModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatDatetimepickerModule,
    MatIconModule,
    MatInputModule,
    MatDialogModule,
    MatMenuModule,
    SafeModule,
    MatStepperModule,
    MatSliderModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatTableModule,
    MatRadioModule,
    MatTooltipModule,
    NumberOnlyDirectiveModule,
    AllowOnlyPriceModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    ProgressBarModule,
    SmallSpinerModule,
    FormsModule,
    TagInputModule,
    ServicesEmailModule,
    RouterModule.forChild(routes),
    UserIdleModule.forRoot({ idle: CommonConstant.Idle, timeout: CommonConstant.Timeout, ping: CommonConstant.Ping }),
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [MainComponent, RouterModule],
  declarations: [MainComponent,
    PmInspectionLetterComponent,
    ErrorComponent,
    ManageCaseComponent,
  ]
})
export class MainModule { }
