import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepicker, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule } from '@angular/material';
import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MarketListComponent } from './market-list/market-list.component';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { MarketDetailComponent } from './market-detail/market-detail.component';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { AllowOnlyPriceModule } from 'src/app/shared/directives/allow-only-price/allow-only-price.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { OnlyAlphabetsModule } from 'src/app/shared/directives/allow-only-alphabets/only-alphabets.module';
const routes: Routes = [
  {
    path: '',
    component: MarketListComponent
  },
  {
    path: AppRouteUrl.classifiedAdsDetailRouteUrl,
    component: MarketDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatetimepickerModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    MatBottomSheetModule,
    MatButtonModule,
    NumberOnlyDirectiveModule,
    MatButtonToggleModule,
    FormsModule,
    RouterModule.forChild(routes),
    AllowOnlyPriceModule,
    NoDataFoundModule,
    HideIfUnauthorizedModule,
    OnlyAlphabetsModule
  ],
  exports: [RouterModule],
  declarations: [MarketListComponent, MarketDetailComponent]
})
export class MarketPlaceModule { }
