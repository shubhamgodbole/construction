export class MarketPlace {
    Title: string
    ClassifiedAdCategory: string
    State: string
    City: string
    Zip: string
    Price: string
    CellPhone: string
    Details: string
    ExpiresOn: string
    HomePhone: string
    UserEmail: string
    AssociationId: string
    AssociationName : string
    ClassifiedAdCategoryId: string
    CreatedByUserId: string
    CreatedByUserName: string
    TransactionCurrencyId: string
    TransactionCurrencySymbol: string
    TransactionCurrencyName: string
    ExchangeRate: number   
    SoldDate: string
    PublishDate: string
}

export class RequestDocument {
    DocumentTitle: string
    Name: string
    MediaType: string
    PublishDate: string
    InputStream: string
}