import { Component, OnInit, ViewChild } from '@angular/core';
import { MarketPlaceApiService } from 'src/app/services/market-place-api.service';
import * as _ from 'lodash';
import { FormBuilder, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { MarketPlace, RequestDocument } from './market-list.model';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { TypeOfDocument, FeaturePermissions, FeatureName, NoDataFoundCaseFeatureName } from 'src/app/shared/Enums/commonEnums';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar } from '@angular/material';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { CommonService } from 'src/app/services/common.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { Guid } from 'guid-typescript';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { MatDialogRef, MatDialog } from '@angular/material';
import { CommonConstant } from 'src/app/shared/common/constant.model';
@Component({
  selector: 'app-market-list',
  templateUrl: './market-list.component.html',
  styleUrls: ['./market-list.component.scss']
})
export class MarketListComponent implements OnInit {
  notificationService: NotificationService;
  addMarketListForm: FormGroup;
  soldMarketListForm: FormGroup;
  sidebar = false;
  allListData: any = [];
  myListData: any = [];
  soldId: string;
  alladds: any;
  imgFlag: boolean = false;
  myadds: any;
  category: any;
  fileData: any = [];
  base64textString = [];
  urls = [];
  userData: UserData;
  associationId: string;
  associationName: string;
  domain: string;
  userId: string;
  userName: string;
  minDate = new Date(2000, 0, 1);
  maxDate = new Date();
  invalidImageType: string;
  shoInvalidImageMsg: boolean = false;
  showMinvalue: boolean = false;
  disableAddButton: boolean = false;
  currentTab: string = "All";
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  isApiResponceCome = false;

  @ViewChild('formDirective') formDirective: FormGroupDirective;
  @ViewChild('formSoldDirective') formSoldDirective: FormGroupDirective;
  //For Delete
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  constructor(public service: MarketPlaceApiService, private formBuilder: FormBuilder,
    private readonly snb: MatSnackBar,
    private progressbarService: ProgeressBarService,
    public commonService: CommonService,
    private _matDialog: MatDialog,
    private readonly appConfig: AppConfig, private router: Router) {
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.notificationService = new NotificationService(snb);
    if (this.service.classifiedAdTab !== '') {
      this.currentTab = this.service.classifiedAdTab;
    }
  }

  ngOnInit() {
    this.addMarketListForm = this.formBuilder.group({
      title: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      category: ['', Validators.required],
      state: ['', [Validators.required, Validators.maxLength(2), ValidationService.notStartWhiteSpace]],
      city: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      zipCode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10)]],
      price: ['', [Validators.required]],
      description: ['', [Validators.required, Validators.maxLength(2000),ValidationService.notStartWhiteSpace ]],
      attechment: ['', Validators.required],
    });
    this.soldMarketListForm = this.formBuilder.group({
      date: ['', Validators.required],
    });

    this.getAllList();
    this.getAllCategories();


  }

  getAllList() {
    this.progressbarService.show();
    this.service.getAllAdds(this.associationId, this.domain).subscribe((response: any) => {
      this.isApiResponceCome = true;
      this.myListData = [];
      this.allListData = [];
      response.Result[0].ClassifiedAdList.forEach((adds) => {
        if (adds.ClassifiedAd.CreatedByUserId !== this.userId && adds.ClassifiedAd.SoldDate == null) {
          this.allListData.push(adds);
        }
      });
      this.alladds = this.allListData;
      this.myListData = [];
      // fetch my adds
      response.Result[0].ClassifiedAdList.forEach((adds) => {
        if (adds.ClassifiedAd.CreatedByUserId === this.userId) {
          this.myListData.push(adds);
        }
      });
      this.myadds = this.myListData;
      this.progressbarService.hide();
    });
  }

  // filter adds
  filterData(event) {
    this.myListData = this.myadds;
    this.allListData = this.alladds;
    if (event.target.value !== 'Category') {
      this.myListData = this.myListData.filter((o) => o.ClassifiedAd.ClassifiedAdCategory === event.target.value);
      this.allListData = this.allListData.filter((o) => o.ClassifiedAd.ClassifiedAdCategory === event.target.value);
    }
  }
  // sort adds
  sortData(event) {
    if (event.target.value === 'low') {
      this.myListData = _.orderBy(this.myListData, ['ClassifiedAd.Price'], 'asc');
      this.allListData = _.orderBy(this.allListData, ['ClassifiedAd.Price'], 'asc');
    }
    if (event.target.value === 'heigh') {
      this.myListData = _.orderBy(this.myListData, ['ClassifiedAd.Price'], 'desc');
      this.allListData = _.orderBy(this.allListData, ['ClassifiedAd.Price'], 'desc');
    }
    if (event.target.value === 'recentPost') {
      this.myListData = _.orderBy(this.myListData, ['ClassifiedAd.PublishDate'], 'desc');
      this.allListData = _.orderBy(this.allListData, ['ClassifiedAd.PublishDate'], 'desc');
    }
  }
  // fetch all categories
  getAllCategories() {
    this.service.getAllCategories().subscribe((response: any) => {
      this.category = response.ClassifiedAdCategory;
    });
  }
  getCurrentTab(tab) {
    this.service.classifiedAdTab = tab;
  }
  // sidebar form
  sidebarToggle() {

    if (this.sidebar) {
      this.sidebar = false;
      this.reset();
      this.imgFlag = false;
    }

    else
      this.sidebar = true;

  }
  // on file upload
  onUploadChange(evt: any) {
    this.imgFlag = false;
    this.shoInvalidImageMsg = false;
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          let type = evt.target.files[i].name.split(".");
          if (type[type.length -1].toLowerCase() === 'jpeg' || type[type.length -1].toLowerCase() === 'jpg' || type[type.length -1].toLowerCase() === 'png' || type[type.length -1].toLowerCase() === 'gif' || type[type.length -1].toLowerCase() === 'bmp' || type[type.length -1].toLowerCase() === 'jfif' || type[1].toLowerCase() === 'tif' || type[type.length -1].toLowerCase() === 'tiff') {
            this.fileData.push({
              imageId: Guid.create(),
              inputStream: event.target.result,
              name: evt.target.files[i].name.toLowerCase(),
              type: evt.target.files[i].type,
              mediaType: type[type.length -1],
              CreatedByUserName: this.userName
            });
          }
          else {
            this.invalidImageType = "Select Only Images";
            this.shoInvalidImageMsg = true;
          }

        }
        reader.readAsDataURL(evt.target.files[i]);
        console.log('type', this.fileData);


      }

    }

  }
  // remove uploaded images
  removeImage(imageId) {
    var tempArray = [];
    this.fileData.forEach((e) => {
      if (e.imageId !== imageId) {
        tempArray.push(e);
      }
    });
    this.fileData = tempArray;
    if (this.fileData.length === 0) {
      this.imgFlag = true;
    }
  }
  // reset data
  reset() {
    this.addMarketListForm.reset();
    this.formDirective.resetForm();
    this.sidebar = false;
    this.fileData = [];
    this.shoInvalidImageMsg = false;
    this.disableAddButton = false;
    this.showMinvalue = false;
  }
  getPrice() {
    this.showMinvalue = false;
    if (this.addMarketListForm.controls.price.value !== '') {
      if(this.addMarketListForm.controls.price.value <= 0)
      this.showMinvalue = true;
    }
  }

  // on submit
  onSubmit() {


    const marketPlaceData = this.createMarketPlaceModel();
    const documentData = this.createDocumentModel();
    if (this.fileData.length === 0) {
      this.imgFlag = true;
    }

    if (this.addMarketListForm.valid && !this.shoInvalidImageMsg && !this.showMinvalue) {
      this.disableAddButton = true;
      this.service.addClassifiedAdds(marketPlaceData, this.domain, TypeOfDocument.ClassifiedAdDocuments, documentData).subscribe((response: any) => {
        this.disableAddButton = false;
        if (response.Success === true) {
          this.getAllList();
          this.notificationService.showNotification("Ad is saved Successfully.");
          this.reset();
        }
        else {
          console.log("error")
        }
      });
    }


  }
  // create model
  createMarketPlaceModel(): MarketPlace {
    let categoryData = this.addMarketListForm.controls.category.value;
    let model: MarketPlace = {
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      Title: this.addMarketListForm.controls.title.value,
      ClassifiedAdCategory: categoryData.ClassifiedAdCategoryName,
      State: this.addMarketListForm.controls.state.value,
      City: this.addMarketListForm.controls.city.value,
      Zip: this.addMarketListForm.controls.zipCode.value,
      Price: this.addMarketListForm.controls.price.value,
      ClassifiedAdCategoryId: categoryData.id,
      CellPhone: null,
      Details: this.addMarketListForm.controls.description.value,
      ExpiresOn: null,
      HomePhone: null,
      UserEmail: null,
      TransactionCurrencyId: null,
      TransactionCurrencySymbol: null,
      TransactionCurrencyName: null,
      ExchangeRate: null,
      SoldDate: null,
      PublishDate: null
    }
    return model;
  }

  createDocumentModel() {
    var fData = [];
    this.fileData.forEach((e) => {
      fData.push({
        DocumentTitle: e.name,
        Name: e.name,
        MediaType: e.type,
        PublishDate: new Date(),
        InputStream: e.inputStream
      });
    });
    return fData;
  }

  // detail
  detail(classifiedAdId: string) {
    this.service.classifiedAdId = classifiedAdId;
    this.router.navigate([AppRouteUrl.mainClassifiedAdsDetailRouteUrl], { queryParams: { id: classifiedAdId } });
  }
  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = valueObject.Title;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }
  // delte
  delete(id) {
   // if (confirm("Are you sure to delete ?")) {
      this.service.deleteClassifiedAdds(id).subscribe(
        (response: any) => {
          if (response.Success === true) {
            this.getAllList();
          }
          else {
            console.log('Some Error');
          }
        }
      );
   // }
  }
  // get classifiedID for sold
  getIdForSold(id) {
    this.soldId = id;
  }
  // sold
  sold() {
    var date = this.soldMarketListForm.controls.date.value;
    if (date) {
      this.service.soldClassifiedAdds(this.soldId, date).subscribe(
        (response:any) => {
          if (response.Success === true) {
          document.getElementById('close-model').click();
          this.getAllList();
          this.resetSoldForm();
          }
        });
    }
  }
  closeSoldModel() {
    this.resetSoldForm();
  }
  resetSoldForm() {
    this.soldMarketListForm.reset();
    this.formSoldDirective.resetForm();
  }
}
