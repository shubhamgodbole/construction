
export class Enquiry {
    UserName: string
    Email: string
    Phone: string
    Price: string
    Message: string
}
