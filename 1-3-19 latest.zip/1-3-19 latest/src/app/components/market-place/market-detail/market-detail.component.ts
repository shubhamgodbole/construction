import { Component, OnInit, ViewChild } from '@angular/core';
import { MarketPlaceApiService } from 'src/app/services/market-place-api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { Enquiry } from './market-detail.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { Subscription } from 'rxjs';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { CommonService } from 'src/app/services/common.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { MatDialogRef, MatDialog } from '@angular/material';
import { CommonConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-market-detail',
  templateUrl: './market-detail.component.html',
  styleUrls: ['./market-detail.component.scss']
})
export class MarketDetailComponent implements OnInit {
  addEnquiryForm: FormGroup;
  soldMarketListForm: FormGroup;
  sidebar = false;
  userData: UserData;
  associationId:string;
  userId: string;
  associationName: string;
  userName: string;
  domain: string;
  myadds: any;
  classifiedAd: any;
  classifiedAdDocumentList: any;
  relatedPostList: any;
  classifiedAdUserResponse: any;
  classifiedAdCreatedBy:any;
  categories: any;
  selectedCategory: string;
  displayDiv: boolean = false;
  showMinvalue: boolean = false;
  minDate = new Date(2000, 0, 1);
  maxDate = new Date();
  querySubcription: Subscription;
  requestId: string;
  isInquiryButtonDisable: boolean = false;
  @ViewChild('formDirective') formDirective: FormGroupDirective;
  @ViewChild('formSoldDirective') formSoldDirective: FormGroupDirective;
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  //For Delete
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;

  constructor(public service: MarketPlaceApiService, private router: Router,private route: ActivatedRoute,
    private formBuilder: FormBuilder, private readonly appConfig: AppConfig,private progressbarService: ProgeressBarService,
    public commonService: CommonService,
    private _matDialog: MatDialog,
    ) { 
    this.userData = this.appConfig.getCurrentUser();
    this.userData = appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain =  this.userData.UserAssociations[0].Domain;
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.requestId = id;
        this.service.classifiedAdId = id;
        this.getDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
  }
 
  setMobileNumber(event) {
    let ctrlValue = this.addEnquiryForm.controls.phone.value;
    let newCtrlValue ;
    if(ctrlValue) {
      if(ctrlValue.length < 10 ) {
      }
      else{
      ctrlValue = this.addEnquiryForm.controls.phone.value;
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.addEnquiryForm.controls.phone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.addEnquiryForm.controls.phone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }
  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }
  getDetail() {
    let resData;
    if(this.service.classifiedAdId){
      this.progressbarService.show();
      this.service.classifiedAdDetail(this.domain).subscribe(response =>{
        resData = response;
        if(resData.Success){
          this.displayDiv = true;
          this.classifiedAdCreatedBy = resData.ClassifiedAdDetail.ClassifiedAd.CreatedByUserId;
          this.classifiedAd = resData.ClassifiedAdDetail.ClassifiedAd;
          this.classifiedAdDocumentList = resData.ClassifiedAdDetail.Documents;
          this.relatedPostList = resData.ClassifiedAdDetail.GetPostAds[0].ClassifiedAdList;
          this.classifiedAdUserResponse = resData.ClassifiedAdDetail.ClassifiedAd.ClassifiedAdUserResponses;
          this.selectedCategory = this.categories.find(a=>a.ClassifiedAdCategoryName ==   this.classifiedAd.ClassifiedAdCategory);
          this.progressbarService.hide();
        }
      });
    } else {
      this.router.navigate([AppRouteUrl.mainClassifiedAdsRouteUrl]);
    }
  }

  ngOnInit() {
    this.createFrom();
    this.getAllCategories();
    //this.showEnquiry();
    this.soldMarketListForm = this.formBuilder.group({
      date: ['', Validators.required],
    });
  }

  createFrom() {
    this.addEnquiryForm = this.formBuilder.group({
      name: ['', [Validators.required,Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      email: new FormControl('', [Validators.required, ValidationService.emailValidator]),
      phone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13)] ],
      price: ['', [Validators.required,Validators.pattern('^[0-9][0-9.\\s]+$')] ],
      message: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
    });
  }

  sidebarToggle() {
    if (this.sidebar) {
      this.sidebar = false;
      this.reset();
    }
    else {
      this.sidebar = true;
    }
  }

  // fetch all categories
  getAllCategories() {
    this.service.getAllCategories().subscribe((response: any) => {
      this.categories = response.ClassifiedAdCategory;
    });
  }

  // filter adds
  filterData(event) {
    let resData;
    console.log('selected Value ',this.selectedCategory);
    this.service.getClassifiedAdListByCategory(event.value.ClassifiedAdCategoryName).subscribe(response => {
      resData = response;
      this.relatedPostList = resData.Result[0].ClassifiedAdList
    });
  }
  goBack() {
    window.history.go(-1);
  }
  // detail
  detail(id) {
   this.service.classifiedAdId = id;
   this.getDetail();
   window.scrollTo(0, 0);
  }
  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = valueObject.Title;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }
  // delete
  delete(id) {
      this.service.deleteClassifiedAdds(id).subscribe(
        (response: any) => {
          if (response.Success === true) {
            console.log('deleted');
            this.router.navigate([AppRouteUrl.mainClassifiedAdsRouteUrl]);
          }
          else {
            console.log('Some Error');
          }
        }
      );
  }

  checkPrice() {
    this.showMinvalue = false;
    if (this.addEnquiryForm.controls.price.value !== '') {
      if(this.addEnquiryForm.controls.price.value <= 0)
      this.showMinvalue = true;
    }
  }
  sold() {
    var date =  this.soldMarketListForm.controls.date.value;
    if(date) {
      
      this.service.soldClassifiedAdds(this.service.classifiedAdId,date).subscribe(
        (response) => {
          this.resetSoldForm();
          this.getDetail();
        });
    }
  }
  closeSoldModel() {
    this.resetSoldForm();
  }
  resetSoldForm() {
    this.soldMarketListForm.reset();
    this.formSoldDirective.resetForm();
  }
  addEnquiry() {
    const enquiryData = this.createEnqiryModel();
    const Id = this.service.classifiedAdId;
    if(this.addEnquiryForm.valid && !this.showMinvalue) {
      this.isInquiryButtonDisable =true;
      this.service.addClassifiedEnquiry(enquiryData, Id).subscribe(
        (response: any) =>{
          this.isInquiryButtonDisable =false;
          if(response.Success){
            this.getDetail();
            this.reset();
          }
        }
      );
    }
    
  }

   // reset data
   reset(){
    this.addEnquiryForm.reset();
    this.formDirective.resetForm();
    this.sidebar = false;
  }

  // Enquiry model
  createEnqiryModel() : Enquiry {
    let model: Enquiry = {
      UserName: this.addEnquiryForm.controls.name.value,
      Email: this.addEnquiryForm.controls.email.value,
      Phone: this.addEnquiryForm.controls.phone.value,
      Price: this.addEnquiryForm.controls.price.value,
      Message: this.addEnquiryForm.controls.message.value
    }
    return model;
  }
}
