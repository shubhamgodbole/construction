import { Component, OnInit } from '@angular/core';
import { AppConfig } from '../app.config';
import { ProgeressBarService } from '../shared/services/progeress-bar.service';
import { CookieService } from 'ngx-cookie-service';
import { LoginApiService } from '../services/login-api.service';
import { Router } from '@angular/router';
import { NotificationService } from '../shared/services/notification.service';
import { Title } from '@angular/platform-browser';
import { environment } from 'src/environments/environment';
import * as $ from 'jquery';
import { UserIdleService } from 'angular-user-idle';
import { MatDialogRef, MatDialog } from '@angular/material';
import { ThankYouComponent } from '../shared/component/thank-you/thank-you.component';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  isLogin: boolean;
  thanksDialogRef: MatDialogRef<ThankYouComponent>;
  constructor(private readonly appConfig: AppConfig, private loginService: LoginApiService,
    private titleService: Title, private userIdle: UserIdleService,
    private _matDialog: MatDialog,
    private router: Router, private notificationService: NotificationService,
    private progressbarService: ProgeressBarService, private cookieService: CookieService, ) {
    this.titleService.setTitle(environment.mainTitle);

    this.appConfig.isLoggedIn.subscribe(
      (login) => {
        this.isLogin = login;
      }
    );
  }



  ngOnInit() {
    if (this.isLogin) {
      this.userIdle.startWatching();
      // Start watching when user idle is starting.
      this.userIdle.onTimerStart().subscribe(count => console.log(count));
      // Start watch when time is up.
      this.userIdle.onTimeout().subscribe(() => {
        console.log('session expire ');
        let message = { header: 'Session Expired!', content: 'Please re-login to renew your session.' }
        this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
          width: '700px',
          disableClose: false
        });
        localStorage.clear();
        this.appConfig.removeCurrentUser();
        this.thanksDialogRef.componentInstance.data = message;
        this.thanksDialogRef.afterClosed().subscribe(result => {
          this.router.navigate(['/login']);
        });
      });
    }


    if (localStorage.getItem('token') === null || localStorage.getItem('token') === '' || localStorage.getItem('token') === undefined) {
      this.getUserData();
    }

    this.getUserData();

    $(document).ready(function () {
      $(".pv-mob-menu").click(function () {
        $('body').toggleClass('pv-closesidebar');
        $('.pv-mob-menu').toggleClass('pv-close-nav');
        $('.mat-paginator').toggleClass('pv-fullpagination');
      });
    });
  }


  getUserData() {
    let resData;
    if (this.cookieService.get('userId') !== null && this.cookieService.get('userId') !== '' && this.cookieService.get('userId') !== undefined) {
      var token = this.cookieService.get('token');
      localStorage.setItem('token', token);
      this.progressbarService.show();
      this.loginService.getUserClaim(this.cookieService.get('userId')).subscribe(res => {
        resData = res;
        this.progressbarService.hide();
        if (resData.Success) {
          this.appConfig.setCurrentUser(resData.UserClaim);
          localStorage.setItem('UserClaimData', resData.UserClaim.UserClaimData);

        }
      })
    }
  }
}
