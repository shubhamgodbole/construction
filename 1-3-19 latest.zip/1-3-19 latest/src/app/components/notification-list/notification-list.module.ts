import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { MatInputModule, MatListModule, MatMenuModule, MatRippleModule, MatSelectModule, MatSnackBarModule, MatTooltipModule, MatTreeModule, MatAutocompleteModule, MatButtonModule, MatDatepickerModule, MatBottomSheetModule, MatCheckboxModule, MatRadioModule, MatDialogModule, MatPaginatorModule } from '@angular/material';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DisplayTimeElapsedModule } from 'src/app/shared/modules/display-time-elapsed.module';
import { RouterModule, Routes } from '@angular/router';
import { NotificationListComponent } from './notification-list.component';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
const routes: Routes = [
  {
    path: '',
    component: NotificationListComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    NoCaseNoteFoundModule,
    SafeModule,
    DisplayTimeElapsedModule,
    MatInputModule,
    MatRadioModule,
    MatListModule,
    MatMenuModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatRippleModule,
    MatSelectModule,
    MatSnackBarModule,
    MatPaginatorModule,
    MatTooltipModule,
    MatTreeModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatDialogModule,
    FormsModule,
    MatDatepickerModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule,
  ],
  declarations: [NotificationListComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [RouterModule]
})
export class NotificationListModule { }
