import { Component, OnInit, ViewChild } from '@angular/core';
import { CaseFeatureType, FeatureName, RoleEnum, MasterPaginationEnum, Pagination, NoDataFoundCaseFeatureName, FeaturePermissions, notoficationStatus } from 'src/app/shared/Enums/commonEnums';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { NavigationExtras, Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { NotificationSliderService } from 'src/app/services/notification-slider.service';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { MatPaginator } from '@angular/material';

@Component({
  selector: 'app-notification-list',
  templateUrl: './notification-list.component.html',
  styleUrls: ['./notification-list.component.scss']
})
export class NotificationListComponent implements OnInit {

  NotifyFilter = false;

  //notification slider
  pmCompanyAssociationMappingId: string;
  notificationList: any = [];
  associationNotification: any = [];
  myNotification: any = [];
  caseFeatureTypeEnum = CaseFeatureType;
  featureNameEnum = FeatureName;
  userId: string;
  role: string;
  userData: UserData;
  globalAssociationModel: GlobalAssociationModel;
  roleType = RoleEnum;
  status = notoficationStatus;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  currentTab: any;
  myAllNotifications: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  isApiResponceCome = false;
  constructor(public commonService: CommonService,
    private readonly appConfig: AppConfig,
    private progressBarService: ProgeressBarService,
    private router: Router,
    private globalAssociationService: GlobalAssociationService,
    private notificationSliderService: NotificationSliderService) {
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData !== null) {
      this.userId = this.userData.UserProfileId;
      this.role = this.userData.Role;
      this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
      this.role === this.roleType.Member ? this.currentTab = 'MyNotification' : '';
    }
  }

  ngOnInit() {

    this.globalAssociationService.associationSubject.subscribe(res => {
      this.globalAssociationModel = res;
      //global search
      if (res !== 1) {
        this.notificationSliderService.currentTab.subscribe(res => {
          this.currentTab = res !== 1 ? res : this.role === this.roleType.Member ? 'MyNotification' : 'AssociationNotification';
          this.callCurrentTab();
        });
        //  this.getAllNotificaton();
      }
    });
  }
  gotoBack() {
    window.history.back();
  }
  NotifyFilterToggle() {
    if (this.NotifyFilter) {
      this.NotifyFilter = false;
    }
    else {
      this.NotifyFilter = true;
    }
  }
  callCurrentTab() {
    if (this.currentTab === 'MyNotification') {
      this.getMyNotification();
    }
    else {
      this.getAllNotificaton();
    }
  }

  // get all Notification 
  getAllNotificaton() {
    console.log('CTab', this.currentTab);
    this.notificationList = [];
    let pmCompanyAssociationMappingId;
    if (this.role === RoleEnum.PropertyManager) {
      pmCompanyAssociationMappingId = this.globalAssociationModel.PMCompanyAssociationMappingId;
    } else {
      pmCompanyAssociationMappingId = this.pmCompanyAssociationMappingId;
    }
    let resData;
    this.progressBarService.show();
    this.notificationSliderService.getAllNotifications(pmCompanyAssociationMappingId).subscribe(res => {
      //  console.log('NotificationDetails ', res);
      resData = res;

      this.isApiResponceCome = true;
      this.progressBarService.hide();
      if (resData.Success) {
        this.notificationList = resData.ProcessedNotifications.filter(n => {
          if (n.FeatureName !== null) {
            return n;
          }
        });

        this.notificationList.sort((val1, val2) => {
          return new Date(val2.SentDate).getTime() - new Date(val1.SentDate).getTime()
        });
        //  this.callCurrentTab();
        this.getAssociationNotification();

      }
    });
  }


  changeStatus(s) {
    this.getAssociationNotification();
    if (s === CaseFeatureType.ServiceRequest) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Service_Request || n.FeatureName === FeatureName.ServiceRequest
      });
      this.setPaginationData(this.associationNotification);
    } else if (s === CaseFeatureType.Meeting) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Meetings
      });
      this.setPaginationData(this.associationNotification);
    } else if (s === CaseFeatureType.Motion) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Motion
      });
    } else if (s === CaseFeatureType.ARCRequest) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.ARCRequests || n.FeatureName === FeatureName.ARC
      });
      this.setPaginationData(this.associationNotification);
    }
    else if (s === CaseFeatureType.Violation) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Violations
      });
      this.setPaginationData(this.associationNotification);
    } else if (s === CaseFeatureType.BoardTask) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Board_Task
      });
      console.log('bt', this.associationNotification);
      this.setPaginationData(this.associationNotification);
    } else if (s === CaseFeatureType.SocialAnnouncement) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.SocialAnnouncement
      });
      this.setPaginationData(this.associationNotification);
    } else if (s === CaseFeatureType.Document) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Document
      });
      this.setPaginationData(this.associationNotification);
    } else if (s === CaseFeatureType.Newsletters) {
      this.associationNotification = this.associationNotification.filter(n => {
        return n.FeatureName === FeatureName.Newsletter
      });
      this.setPaginationData(this.associationNotification);
    } else if (s === 'All') {
      this.associationNotification = this.associationNotification;
      this.setPaginationData(this.associationNotification);
    }
  }

  statusChangeMyNotification(s) {
    // this.getMyNotification();
    if (s === CaseFeatureType.ServiceRequest) {
      this.myNotification = this.myAllNotifications.filter(n => {
        return n.FeatureName === FeatureName.Service_Request || n.FeatureName === FeatureName.ServiceRequest
      });
      this.setPaginationData(this.myNotification);

    } else if (s === CaseFeatureType.Meeting) {
      this.myNotification = this.myAllNotifications.filter(n => {
        return n.FeatureName === FeatureName.Meetings
      });
      this.setPaginationData(this.myNotification);
    } else if (s === CaseFeatureType.Motion) {
      this.myNotification = this.myAllNotifications.filter(n => {
        return n.FeatureName === FeatureName.Motion
      });
      this.setPaginationData(this.myNotification);
    } else if (s === CaseFeatureType.ARCRequest) {
      this.myNotification = this.myAllNotifications.filter(n => {
        return n.FeatureName === FeatureName.ARCRequests || n.FeatureName === FeatureName.ARC
      });
      this.setPaginationData(this.myNotification);
    }
    else if (s === CaseFeatureType.Violation) {
      this.myNotification = this.myAllNotifications.filter(n => {
        return n.FeatureName === FeatureName.Violations
      });
      this.setPaginationData(this.myNotification);
    } else if (s === CaseFeatureType.BoardTask) {
      this.myNotification = this.myAllNotifications.filter(n => {
        return n.FeatureName === FeatureName.Board_Task
      });
      this.setPaginationData(this.myNotification);
    } else if (s === CaseFeatureType.SocialAnnouncement) {
      this.myNotification = this.myAllNotifications.filter(n => {
        return n.FeatureName === FeatureName.SocialAnnouncement
      });
      this.setPaginationData(this.myNotification);
    } else if (s === CaseFeatureType.Document) {
      this.myNotification = this.myAllNotifications.filter(n => {
        return n.FeatureName === FeatureName.Document
      });
      this.setPaginationData(this.myNotification);
    } else if (s === CaseFeatureType.Newsletters) {
      this.myNotification = this.myAllNotifications.filter(n => {
        return n.FeatureName === FeatureName.Newsletter
      });
      this.setPaginationData(this.myNotification);
    } else if (s === 'All') {
      this.myNotification = this.myAllNotifications;
      this.setPaginationData(this.myNotification);
    }
  }

  getAssociationNotification() {
    this.associationNotification = this.notificationList.filter(n => {
      return n.UserProfileId !== this.userId;
    });
    console.log('Associanotion Notification', this.associationNotification);
    this.setPaginationData(this.associationNotification);
  }

  getMyNotification() {

    // this.myNotification = this.notificationList.filter(n => {
    //   return n.UserProfileId === this.userId;
    // });
    let pmCompanyAssociationMappingId;
    if (this.role === RoleEnum.PropertyManager) {
      pmCompanyAssociationMappingId = this.globalAssociationModel.PMCompanyAssociationMappingId;
    } else {
      pmCompanyAssociationMappingId = this.pmCompanyAssociationMappingId;
    }
    let resData;
    this.notificationSliderService.getMyAllNotifications(pmCompanyAssociationMappingId, this.userId).subscribe(
      (response: any) => {
        this.isApiResponceCome = true;
        resData = response;
        if (resData.Success) {
          this.myNotification = resData.ProcessedNotifications.filter(n => {
            if (n.FeatureName !== null) {
              return n;
            }
          });
          this.myAllNotifications = this.myNotification;
          this.myNotification.sort((val1, val2) => {
            return new Date(val2.SentDate).getTime() - new Date(val1.SentDate).getTime()
          });
          console.log('My Notification ', this.myNotification);
          this.setPaginationData(this.myNotification);
          // document.getElementById('mynotification-tab').click();
        }
      }
    );
    //  this.callCurrentTab();
  }

  goToDetailPage(notification) {
    this.notificationSliderService.wasSeenNotifications(notification.id).subscribe(
      (response: any) => {
        console.log('wasSeen', response);
      });
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": notification.NotificationAction.ActionParams[0].Parameter
      }
    };
    if (this.role === RoleEnum.PropertyManager) {
      if (notification.FeatureName === FeatureName.Service_Request || notification.FeatureName === FeatureName.ServiceRequest) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Violations) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Board_Task) {
        this.router.navigate([AppRouteUrl.mainBoardTasksDeatilPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.ARC || notification.FeatureName === FeatureName.ARCRequests) {
        this.router.navigate([AppRouteUrl.mainArcDetailPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Meetings) {
        this.router.navigate([AppRouteUrl.mainMeetingPMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.SocialAnnouncement) {
        this.router.navigate([AppRouteUrl.mainAnnouncementsDetailRouteUrl], navigationExtras)
      }
    }
    if (this.role === RoleEnum.BoardMember) {
      if (notification.FeatureName === FeatureName.Service_Request || notification.FeatureName === FeatureName.ServiceRequest) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Violations) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Board_Task) {
        this.router.navigate([AppRouteUrl.mainBoardTasksDeatilBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.ARC || notification.FeatureName === FeatureName.ARCRequests) {
        this.router.navigate([AppRouteUrl.mainArcDetailBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Meetings) {
        this.router.navigate([AppRouteUrl.mainMeetingRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.SocialAnnouncement) {
        this.router.navigate([AppRouteUrl.mainAnnouncementsDetailRouteUrl], navigationExtras)
      }
    }
    if (this.role === RoleEnum.Member) {
      if (notification.FeatureName === FeatureName.Service_Request || notification.FeatureName === FeatureName.ServiceRequest) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailHORouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Violations) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilBMRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.ARC || notification.FeatureName === FeatureName.ARCRequests) {
        this.router.navigate([AppRouteUrl.mainArcDetailHORouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.Meetings) {
        this.router.navigate([AppRouteUrl.mainMeetingRouteUrl], navigationExtras)
      } else if (notification.FeatureName === FeatureName.SocialAnnouncement) {
        this.router.navigate([AppRouteUrl.mainAnnouncementsDetailRouteUrl], navigationExtras)
      }
    }
  }


  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(notificationList) {
    this.TotalRecord = notificationList.length;
    var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    this.FilterArray = notificationList.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any, isMyNotification): void {
    window.scroll(0, 0);
    var pageStartIndex = (clickObj.pageIndex * clickObj.pageSize) + 1;
    var pageEndIndex = (clickObj.pageIndex * clickObj.pageSize) + clickObj.pageSize;
    if (isMyNotification) {
      this.FilterArray = this.myNotification.slice(pageStartIndex - 1, pageEndIndex);
    } else {
      this.FilterArray = this.associationNotification.slice(pageStartIndex - 1, pageEndIndex);
    }
  }

}
