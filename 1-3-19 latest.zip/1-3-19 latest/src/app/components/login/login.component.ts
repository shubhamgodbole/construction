import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { LoginApiService } from '../../services/login-api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { MatSnackBar } from '@angular/material';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { environment } from 'src/environments/environment';
import { RoleEnum } from 'src/app/shared/Enums/commonEnums';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Title } from '@angular/platform-browser';
//import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  // providers: [Location, {provide: LocationStrategy, useClass: PathLocationStrategy}]

})
export class LoginComponent implements OnInit {
  notificationService: NotificationService;
  loginForm: FormGroup;
  submitted = false;
  disbaleLogin: boolean = false;
  hide = true;
  errorMsg: string = '';
  returnUrl: string;
  @ViewChild('loginFormDirective') loginFormDirective: FormGroupDirective;


  constructor(private formBuilder: FormBuilder, private titleService: Title,
    private service: LoginApiService, private router: Router,
    public commonService: CommonService, private readonly snb: MatSnackBar,
    private route: ActivatedRoute) {
    this.notificationService = new NotificationService(snb);
    this.titleService.setTitle(environment.mainTitle);
  }

  ngOnInit() {
    //s this.getUserData();
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, ValidationService.emailValidator]],
      password: ['', Validators.required]
    });
    if (this.route.snapshot.queryParams['returnUrl'] !== undefined && this.route.snapshot.queryParams['returnUrl'] !== '') {
      this.returnUrl = this.route.snapshot.queryParams['returnUrl'];
    } else {
      this.returnUrl = AppRouteUrl.mainDashboardRouteUrl;
    }
    console.log("this.returnUrl", this.returnUrl);
  }

  resetErrorMsg() {
    if (this.errorMsg !== "") {
      this.errorMsg = "";
    }
  }


  onSubmit() {
    let resData;
    if (!this.loginForm.valid) {
      return;
    }
    this.disbaleLogin = true;
    this.service.login(this.loginForm.value.email, this.loginForm.value.password).subscribe(res => {
      resData = res;
      console.log('res ', res);
      if (resData.Success === false) {
        //this.notificationService.showNotification("Invalid UserName or Password.");
        this.errorMsg = resData.Message;
        this.resetLoginForm();
      }
      else {
        let hostUrl = environment.hostUrl;
        let url;

        // else {
        // url = hostUrl.replace("*", "dev");
        // }

        var cookieName = 'userId';
        var cookieValue = resData.UserClaim.UserProfileId;
        var myDate = new Date();
        var domain = environment.domain;
        myDate.setMinutes(myDate.getMinutes() + 1);

        if (window.location.hostname.startsWith(environment.localDomain)) {
          document.cookie = cookieName + "=" + cookieValue + ";expires=" + myDate.toUTCString()
            + ";path=/";
          document.cookie = "token=" + resData.UserClaim.AuthToken + ";expires=" + myDate.toUTCString()
            + ";path=/";

          if (resData.UserClaim.Role === RoleEnum.PropertyManager) {
            console.log(AppRouteUrl.mainRecentUpdatesRouteUrl);
            this.router.navigate([AppRouteUrl.mainRecentUpdatesRouteUrl]);
          } else {
            this.router.navigate([AppRouteUrl.mainDashboardRouteUrl]);
          }
        }
        else {
          document.cookie = cookieName + "=" + cookieValue + ";expires=" + myDate.toUTCString()
            + ";domain=" + domain + ";path=/";
          document.cookie = "token=" + resData.UserClaim.AuthToken + ";expires=" + myDate.toUTCString()
            + ";domain=" + domain + ";path=/";
          document.cookie = "userDomain=" + resData.UserClaim.UserAssociations[0].Domain + ";expires=" + myDate.toUTCString()
            + ";domain=" + domain + ";path=/";

          if (resData.UserClaim.UserAssociations[0].Domain !== null) {
            if (resData.UserClaim.Role !== RoleEnum.PropertyManager) {
              url = hostUrl.replace("*", resData.UserClaim.UserAssociations[0].Domain);
              if (window.location.hostname.startsWith(resData.UserClaim.UserAssociations[0].Domain) === true) {
                console.log("this.returnUrl from condition : ", this.returnUrl);
                this.router.navigateByUrl(this.returnUrl);
              }
              else {
                window.location.href = url + AppRouteUrl.mainDashboardRouteUrl;
              }
            } else {
              url = hostUrl.replace("*", environment.pmDomain);
              console.log("url:", url);
              window.location.href = url + AppRouteUrl.mainRecentUpdatesRouteUrl;
            }
          }
          else {
            window.location.href = AppRouteUrl.mainDashboardRouteUrl;
          }
        }

      }
    },
      (err) => {
        console.log(err);
      }
    );
  }

  disbaleEyeIcon() {
    if (this.loginForm.value.password !== null && this.loginForm.value.password !== undefined && this.loginForm.value.password !== '') {
      this.hide = !this.hide
      return false;
    } else {
      //this.hide = false;
      return true;
    }
  }

  resetLoginForm() {
    this.loginForm.reset();
    this.loginFormDirective.resetForm();
    this.disbaleLogin = false;
  }
}