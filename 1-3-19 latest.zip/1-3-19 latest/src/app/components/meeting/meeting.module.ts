import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatTooltipModule, MatProgressBarModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MeetingComponent } from './meeting.component';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { Routes, RouterModule } from '@angular/router';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { SmallSpinerModule } from 'src/app/shared/component/small-spinner/small-spiner.module';

const routes: Routes = [
  {
    path: '',
    component: MeetingComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatetimepickerModule,
    MatBottomSheetModule,
    NumberOnlyDirectiveModule,
    MatButtonModule,
    MatTooltipModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    MatProgressBarModule,
    SafeModule,
    FormsModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule,
    SmallSpinerModule
  ],
  declarations: [MeetingComponent]
})
export class MeetingModule { }
