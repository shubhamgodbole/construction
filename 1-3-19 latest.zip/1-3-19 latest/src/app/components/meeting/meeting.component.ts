import { Component, OnInit, createPlatformFactory, ViewChild } from '@angular/core';
import { MeetingApiService } from 'src/app/services/meeting-api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators, FormArray, FormGroupDirective } from '@angular/forms';
import { Meeting, MeetingAgenda, RSVPType, MeetingRSVPs, MeetingMinuteStatusType, MeetingMinute } from './meeting-model';
import { Guid } from 'guid-typescript';
import { RequestDocument } from './meeting-model';
import { AppConfig } from 'src/app/app.config';
import { UserData, EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { TypeOfDocument, RoleEnum, ImageNameEnums, FeatureName, DownloadfeatureName, SourceType, TriggerType, DocumentFeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { MatDialogRef, MatDialog, MatSnackBar } from '@angular/material';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonService } from 'src/app/services/common.service';
import { EmailNotificationService, NotificationModel } from 'src/app/services/email-notification.service';
import { AudienceType } from '../board-tasks/board-task.model';
import { CommonConstant, AcceptFilesConstant, DisplayLoadMoreMeeting } from 'src/app/shared/common/constant.model';
import { Subscription } from 'rxjs/internal/Subscription';
import { ValidationService } from 'src/app/shared/services/validation.service';

@Component({
  selector: 'app-meeting',
  templateUrl: './meeting.component.html',
  styleUrls: ['./meeting.component.scss']
})

export class MeetingComponent implements OnInit {
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentDetails: boolean = false;

  //Confirm Dialog
  //For Delete
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  notificationService: NotificationService;

  pastMeetings: any;
  upcommingMeetings: any = [];
  meetingDetail: any;
  showMeetingDetail: Boolean = true;
  dateErrorMessage: string = "";
  display: Boolean = false;
  rsvpBtn: boolean = false;
  isDisplayDetail: boolean = false;
  documentIndex: number;
  singleUrl: string;
  meetingTypes: any;
  meetingMinutesStatusTypes: any;
  meetingMinutes = null;
  isUploadDraft: boolean;
  meetingForm: FormGroup;
  roleEnum = RoleEnum;
  showMeetingMinuteBox: boolean = false;
  rsvpUserListDisplay: boolean;
  meetingAgendaList: MeetingAgenda[] = new Array<MeetingAgenda>();
  agendaForm: FormGroup;
  agendaItemNumber: number = 0;
  fileData: RequestDocument[] = new Array<RequestDocument>();
  requestDocuments: RequestDocument[] = new Array<RequestDocument>();
  fileDataForMeetingMinute: RequestDocument = null;
  agendaEditMode: boolean = false;
  agendaId: string;
  isRSVP: boolean = false;
  rsvpTypes = RSVPType;
  meetingId: string;
  meetingMinuteForm: FormGroup;
  meetingMinuteStatusType = MeetingMinuteStatusType;
  meetingEditMode: boolean = false;
  disableBtn: boolean = false;
  userId: string;
  disableUploadMinuteBtn: boolean = false;
  showMeetingMinuteDiv: boolean;
  userData: UserData;
  associationId: string;
  associationName: string;
  userName: string;
  domain: string;
  btStartDate: any;
  btEndDate: any;
  role: string;
  docError: string = "";
  upcommingMeetingsHO: any = [];


  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  selectdMeetingMinutesType: boolean;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;

  @ViewChild('meetingMinuteFormDirective') meetingMinuteFormDirective: FormGroupDirective;
  @ViewChild('agendaFormDirective') agendaFormDirective: FormGroupDirective;
  @ViewChild('meetingFormDirective') meetingFormDirective: FormGroupDirective;

  @ViewChild('datetimePickerEnd') datetimePickerEnd;
  @ViewChild('datetimePickerStart') datetimePickerStart;

  //For Send Notification
  meetingFeatureId: string;
  meetingMinuteFeatureId: string;
  pmCompanyAssociationMappingId: string;

  //Querystring
  querySubcription: Subscription;

  /*Load more*/
  pageSkipRecentlyHeldMeetings: number = DisplayLoadMoreMeeting.pageSkip;
  pageTakeRecentlyHeldMeetings: number = DisplayLoadMoreMeeting.pageTake;

  pageSkipUpcomingMeetings: number = DisplayLoadMoreMeeting.pageSkip;
  pageTakeUpcomingMeetings: number = DisplayLoadMoreMeeting.pageTake;

  isLoadMorePast: boolean = false;
  isLoadMoreUpcomming: boolean = false;

  //Count
  upComingMeetingCount: number = 0;
  pastMeetingCount: number = 0;

  rsvpType: string;
  isRSVPClick: boolean = false;

  constructor(
    private service: MeetingApiService,
    private _matDialog: MatDialog,
    public commonService: CommonService,
    private route: ActivatedRoute,
    private router: Router,
    private emailNotification: EmailNotificationService,
    private readonly snb: MatSnackBar, private progressbarService: ProgeressBarService,
    private sanitizer: DomSanitizer, private formBuilder: FormBuilder, private readonly appConfig: AppConfig) {
    this.notificationService = new NotificationService(snb);

    this.btStartDate = this.commonService.getToday();
    this.btEndDate = this.commonService.getToday();

    setTimeout(() => {
      this.setData()
    }, 700);
  }

  ngOnInit() {
    if (this.role === RoleEnum.PropertyManager) {
      this.router.navigate([AppRouteUrl.mainMeetingPMRouteUrl]);
    }
    this.createForm();
    this.createAendaForm();
    this.createMeetingMinuteForm();
  }

  setData() {
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData !== null) {
      this.associationId = this.userData.UserAssociations[0].AssociationId;
      this.associationName = this.userData.UserAssociations[0].Name;
      this.userId = this.userData.UserProfileId;
      this.userName = this.userData.UserName;
      this.role = this.userData.Role;
      this.domain = this.userData.UserAssociations[0].Domain;
      this.getUpcommingMeetingList();
      this.getResentMeetingList();
      this.getMasterData();
      this.getCount();
      this.meetingId = null;
      //Notification
      this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
      this.userData.FeatureMenuPermissions.forEach(
        (feature) => {
          if (feature.Name === FeatureName.Meetings) {
            this.meetingFeatureId = feature.FeatureId
          }
        });
      this.userData.FeatureMenuPermissions.forEach(
        (feature) => {
          if (feature.Name === FeatureName.MeetingMinutes) {
            this.meetingMinuteFeatureId = feature.FeatureId
          }
        });
    }
  }

  createForm() {
    this.meetingForm = this.formBuilder.group({
      title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      meetingAudienceType: ['', Validators.required],
      location: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      startDateTime: ['', Validators.required],
      endDateTime: ['', Validators.required],
      meetingType: ['', Validators.required],
      attachment: [''],
      agenda: ['']
    });
  }

  createAendaForm() {
    this.agendaForm = this.formBuilder.group({
      agendaDetail: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      agendaDescription: ['', [Validators.minLength(1), Validators.maxLength(2000), Validators.pattern(CommonConstant.WhiteSpacePattern)]]
    });
  }

  createMeetingMinuteForm() {
    this.meetingMinuteForm = this.formBuilder.group({
      meetingMinutesType: ['', Validators.required],
      meetingMinuteStatusType: [this.meetingMinuteStatusType.Draft, Validators.required]
    });
  }


  createMeetingModel(): Meeting {
    let model: Meeting = {
      Title: this.meetingForm.controls.title.value,
      ScheduledStart: new Date(this.meetingForm.controls.startDateTime.value).toUTCString(),
      ScheduledEnd: new Date(this.meetingForm.controls.endDateTime.value).toUTCString(),
      MeetingAudienceType: this.meetingForm.controls.meetingAudienceType.value,
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      MeetingType: this.meetingForm.controls.meetingType.value.Name,
      CreatedOn: new Date().toUTCString(),
      Location: this.meetingForm.controls.location.value,
      MeetingAgenda: this.meetingAgendaList,
      id: this.meetingEditMode ? this.meetingId : ''
    }
    return model;
  }

  createMeetingRSVPModel(rsvpType, meeting): MeetingRSVPs {
    console.log('meeting ', meeting);
    var id = "";
    if (meeting.MeetingRSVPs !== null && meeting.MeetingRSVPs.length > 0) {
      var rsvp = meeting.MeetingRSVPs.find(m => m.CreatedByUserId === this.userId);
      if(rsvp !== undefined && rsvp !== null){
        id = rsvp.MeetingRSVPId;
      }
    }
    var model: MeetingRSVPs = {
      MeetingRSVPId: id,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      RSVPType: rsvpType,
      IsRSVP: (rsvpType == this.rsvpTypes.Accept) ? true : false,
      UserImagePath: this.userData.UserProfilePath
    }
    return model;
  }

  createMeetingMinutesModel(): MeetingMinute {
    var model: MeetingMinute = {
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      MeetingMinuteStatusTypeName: this.meetingMinuteForm.value.meetingMinuteStatusType,
      MeetingMinutesType: this.meetingMinuteForm.value.meetingMinutesType,
      PublishDate: new Date().toUTCString()
    }
    return model;
  }


  getUpcommingMeetingList() {
    let resData;
    if (this.isLoadMoreUpcomming === false && this.isRSVPClick === false) {
      this.progressbarService.show();
    } 
    this.service.getUpcommingMeetingList(this.associationId, this.userId, this.role, this.pageSkipUpcomingMeetings, this.pageTakeUpcomingMeetings).subscribe(response => {
      resData = response;
       this.progressbarService.hide();
      this.isLoadMoreUpcomming = false;
      if (resData.Success) {
        this.display = true;
        this.upcommingMeetings = resData.MeetingList.UpcommingMeetings;
        if (this.upcommingMeetings.length > 0) {
          this.setFirstDetail();
        } else {
          this.meetingId = null;
          this.meetingDetail = null;
          this.upcommingMeetings = [];
        }
        this.upcommingMeetingsHO = resData.MeetingList.UpcommingMeetings.filter(m => m.MeetingAudienceType !== true);

      } else {
        console.log('Error');
      }
    }, error => {
      console.log('error');
    });
  }

  getResentMeetingList() {
    let resData;
    if (this.isLoadMorePast === false) {
      this.progressbarService.show();
    }
    this.service.getResentMeetingList(this.associationId, this.userId, this.role, this.pageSkipRecentlyHeldMeetings, this.pageTakeRecentlyHeldMeetings).subscribe(response => {
      resData = response;
      this.progressbarService.hide();
      this.isLoadMorePast = false;

      if (resData.Success) {
        this.pastMeetings = resData.MeetingList.PastMeetings;
        this.setFirstDetail();
        // var ele = document.getElementById('metting_div');
        // ele.scrollTop = ele.scrollHeight + 1500;
      } else {
        console.log('Error');
      }
    }, error => {
      console.log('error');
    });
  }

  setFirstDetail() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.getMeetingDetail(id);
        return;
      } else {
        if (this.meetingId !== "" && this.meetingId !== undefined && this.meetingId !== null) {
          this.getMeetingDetail(this.meetingId);
          return;
        } else if (this.upcommingMeetings.length !== 0 && this.role === this.roleEnum.BoardMember) {
          this.getMeetingDetail(this.upcommingMeetings[0].id);
          return;
        } else if (this.pastMeetings.length !== 0) {
          this.getMeetingDetail(this.pastMeetings[0].id);
          return;
        } else {
          this.showMeetingDetail = false;
        }
      }
    });
  }

  getMeetingDetail(meetingId: string) {
    this.resetMeetingMinuteForm();
    this.isDisplayDetail = false;
    this.docError = "";
    let resData;
    this.meetingId = meetingId;
    this.meetingMinutes = null;
    this.rsvpUserListDisplay = false;
    // this.progressbarService.show();
    this.meetingMinuteForm.controls.meetingMinuteStatusType.setValue(this.meetingMinuteStatusType.Draft);
    this.service.getMeetingDetail(meetingId, this.domain).subscribe(response => {
      resData = response;
      // this.progressbarService.hide();
      if (resData.Success) {
        this.meetingDetail = resData.MeetingDetail;
        if (this.meetingDetail.Meeting.MeetingMinutes.length > 0) {
          this.meetingMinutes = this.meetingDetail.Meeting.MeetingMinutes[0];
          if (this.meetingMinutes.MeetingMinuteStatusTypeName === this.meetingMinuteStatusType.Draft) {
            this.meetingMinuteForm.controls.meetingMinuteStatusType.setValue(this.meetingMinuteStatusType.Final);
            let meetingMinutesType = this.meetingMinutes.MeetingMinutesType !== null ? this.meetingMinutes.MeetingMinutesType.toString() : "true";
            this.meetingMinuteForm.controls.meetingMinutesType.setValue(meetingMinutesType);
          }
          this.pastMeetings[this.pastMeetings.findIndex(el => el.id === meetingId)] = this.meetingDetail.Meeting;
        }
        this.showMeetingDetail = true;
        this.isDisplayDetail = true;
      } else {
        console.log('Error');
      }
    }, error => {

    });
  }



  getMasterData() {
    let resData;
    this.service.getMasterData().subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.meetingTypes = resData.MasterData.MeetingTypes;
        this.meetingMinutesStatusTypes = resData.MasterData.MeetingMinutesStatusTypes;
      } else {
        console.log('Error');
      }
    }, error => {

    });
  }

  scheduleMeeting() {
    if (!this.meetingForm.valid) {
      return;
    }
    this.disableBtn = true;
    this.createMeeting();
  }


  createMeeting() {
    const meeting = this.createMeetingModel();
    let resData;
    this.service.createMeeting(meeting, this.fileData, TypeOfDocument.MeetingDocuments, this.domain).subscribe(response => {
      resData = response;
      this.disableBtn = false;
      if (resData.Success) {
        if (this.meetingEditMode) {
          this.notificationService.showNotification("Meeting Updated Successfully");
          this.emailNotification.sendNotifications(this.meetingFeatureId, resData.RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.Meetings, TriggerType.Update,
            AudienceType.BoardMember).subscribe(res => {
              console.log(res);
            });
        } else {
          this.getCount();
          this.notificationService.showNotification("Meeting Saved Successfully");
          this.emailNotification.sendNotifications(this.meetingFeatureId, resData.RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.Meetings, TriggerType.Create,
            AudienceType.BoardMember).subscribe(res => {
              console.log('save meeting ', res);
            });
        }
        this.isRSVPClick === false;
        this.getUpcommingMeetingList();
        this.resetForm();
      }
    }, error => {

    });
  }

  addRSVP(rsvpType, meeting) {
    var meetingRSVP: MeetingRSVPs = this.createMeetingRSVPModel(rsvpType, meeting);
    let resData;
    this.isRSVPClick = true;
    this.service.addRSVP(meeting.id, meetingRSVP).subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.getUpcommingMeetingList();
      } else {
        console.log('Error');
      }
    }, error => {

    });
  }

  uploadMeetingMinute(meetingId: string) {
    if (!this.meetingMinuteForm.valid) {
      return;
    } else if (this.requestDocuments.length === 0) {
      this.docError = "Please select document."
      return;
    }

    this.disableUploadMinuteBtn = true;
    const meetingMinutesModel = this.createMeetingMinutesModel();
    let resData;
    this.service.uploadMeetingMinutes(meetingMinutesModel, this.requestDocuments, TypeOfDocument.MeetingMinuteDocuments, meetingId, this.domain).subscribe(response => {
      resData = response;
      this.disableUploadMinuteBtn = false;
      if (resData.Success) {
        this.notificationService.showNotification("Meeting minutes uploaded successfully");
        this.getMeetingDetail(meetingId);
        this.emailNotification.sendNotifications(this.meetingMinuteFeatureId, resData.RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.MeetingMinutes, TriggerType.Create,
          AudienceType.BoardMember).subscribe(res => { });
        this.showMeetingMinuteBox = false;
        this.resetMeetingMinuteForm();
      }
    });
  }

  cleanURL(oldURL: string) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(oldURL);
  }

  displayNextDocument() {
    console.log(this.documentIndex);
    this.singleUrl = this.meetingDetail.MeetingDocuments[this.documentIndex].DocumentPath;
  }

  displayDocument(index: number) {
    this.display = true;
    this.singleUrl = this.meetingDetail.MeetingDocuments[this.documentIndex].DocumentPath;
  }

  addAgenda() {
    this.agendaItemNumber = this.agendaItemNumber + 1;
    let meetingAgenda = new MeetingAgenda();
    meetingAgenda.MeetingAgendaId = Guid.create().toString(),
      meetingAgenda.AgendaItemNumber = this.agendaItemNumber,
      meetingAgenda.AgendaDetail = this.agendaForm.controls.agendaDetail.value,
      meetingAgenda.AgendaDescription = this.agendaForm.controls.agendaDescription.value
    this.meetingAgendaList.push(meetingAgenda);
    this.agendaForm.reset();
    this.agendaFormDirective.resetForm();
    this.meetingForm.controls.agenda.markAsDirty();
  }

  //remove agenda
  removeAgenda(agendaId) {
    this.meetingAgendaList = this.meetingAgendaList.filter(a => a.MeetingAgendaId !== agendaId);
    this.meetingForm.controls.agenda.markAsDirty();
  }

  //edit agenda
  editAgendaIconClick(agendaId) {
    this.agendaEditMode = true;
    this.agendaId = agendaId;
    const agenda = this.meetingAgendaList.find(a => a.MeetingAgendaId === agendaId);
    this.agendaForm = this.formBuilder.group({
      agendaDetail: [agenda.AgendaDetail, Validators.required],
      agendaDescription: [agenda.AgendaDescription]
    });
    this.meetingForm.controls.agenda.markAsDirty();
  }

  editMeetingIconClick() {
    this.showMeetingDetail = false;
    this.isDisplayDetail = false;
    this.meetingEditMode = true;
    this.btStartDate = this.meetingDetail.Meeting.ScheduledStart;
    this.btEndDate = this.meetingDetail.Meeting.ScheduledEnd;
    this.fileData = [];
    if (this.meetingDetail.Meeting !== null) {
      this.meetingId = this.meetingDetail.Meeting.id;
      const meetingAudienceType = this.meetingDetail.Meeting.MeetingAudienceType != null ? this.meetingDetail.Meeting.MeetingAudienceType.toString() : null;
      const meetingType = this.meetingTypes.find(a => a.Name == this.meetingDetail.Meeting.MeetingType);
      this.meetingForm.controls.title.setValue(this.meetingDetail.Meeting.Title);
      let sD = new Date(this.meetingDetail.Meeting.ScheduledStart);
      let eD = new Date(this.meetingDetail.Meeting.ScheduledEnd);
      this.meetingForm.controls.startDateTime.setValue(sD);
      this.meetingForm.controls.endDateTime.setValue(eD);
      this.meetingForm.controls.meetingType.setValue(meetingType);
      this.meetingForm.controls.location.setValue(this.meetingDetail.Meeting.Location);
      this.meetingForm.controls.meetingAudienceType.setValue(meetingAudienceType);
      this.meetingAgendaList = this.meetingDetail.Meeting.MeetingAgenda;
      if (this.meetingDetail.MeetingDocuments !== null && typeof this.meetingDetail.MeetingDocuments != 'undefined') {
        this.meetingDetail.MeetingDocuments.forEach(document => {
          let doc: RequestDocument = {
            ImageId: Guid.create().toString(),
            Name: document.DocumentName,
            FileSize: document.FileSize,
            InputStream: document.ThumbnailPath,
            MediaType: document.MediaType,
            DocumentId: document.id,
            CreatedByUserName: this.userName
          }
          this.fileData.push(doc);
        });

      }
    }

  }


  editAgenda() {
    this.meetingAgendaList.forEach(
      a => {
        if (a.MeetingAgendaId === this.agendaId) {
          a.AgendaDescription = this.agendaForm.value.agendaDescription,
            a.AgendaDetail = this.agendaForm.value.agendaDetail
        }
        return a;
      }
    );
    this.agendaForm.reset();
    this.agendaEditMode = false;
    this.agendaFormDirective.resetForm();
  }

  // showRSVP(meetingId: string) {
  //   this.meetingId = meetingId;
  //   if (this.rsvpUserListDisplay) {
  //     this.rsvpUserListDisplay = false;
  //   } else {
  //     this.rsvpUserListDisplay = true;
  //   }
  // }

  hideRSVP(meetingId: string) {
    this.meetingId = meetingId;
    this.rsvpUserListDisplay = false;
  }


  // on file upload for multiple
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            ImageId: Guid.create().toString(),
            InputStream: event.target.result,
            Name: evt.target.files[i].name,
            MediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            FileSize: evt.target.files[i].size.toString(),
            DocumentId: '',
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  // on file upload For singke file
  onUploadChangeMeetingMinute(evt: any) {
    this.requestDocuments = [];
    if (evt.target.files && evt.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.fileDataForMeetingMinute = {
          ImageId: Guid.create().toString(),
          InputStream: event.target.result,
          Name: evt.target.files[0].name,
          MediaType: evt.target.files[0].name.substring(evt.target.files[0].name.indexOf(".")).toLowerCase(),
          FileSize: evt.target.files[0].size.toString(),
          DocumentId: '',
          CreatedByUserName: this.userName
        };
        if (this.fileDataForMeetingMinute !== null && this.fileDataForMeetingMinute.Name.toLowerCase().substring(this.fileDataForMeetingMinute.Name.indexOf(".")) === ".pdf") {
          this.docError = "";
        } else {
          this.docError = " Please select pdf file.";
        }
        this.requestDocuments.push(this.fileDataForMeetingMinute);
      }
      reader.readAsDataURL(evt.target.files[0]);

    }
  }


  // remove uploaded images
  removeImage(id) {
    this.fileData = this.fileData.filter(a => a.ImageId !== id);
    this.meetingForm.controls.attachment.markAsDirty();
  }

  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  showMeetingMinute() {
    return new Date(this.meetingDetail.Meeting.ScheduledStart).getTime() < new Date().getTime() ? true : false;
  }

  meetingMinuteToggle(meetingId: string) {
    this.meetingId = meetingId;
    if (this.showMeetingMinuteBox)
      this.showMeetingMinuteBox = false;
    else
      this.showMeetingMinuteBox = true;
  }

  showUploadMeetingBoxWithDetail(meetingId: string) {
    this.showMeetingMinuteBox = true;
    this.getMeetingDetail(meetingId);
  }

  showMeetingDetailById(meetingId: string) {
    this.showMeetingMinuteBox = false;
    this.getMeetingDetail(meetingId);
  }

  resetForm() {
    this.meetingForm.reset();
    this.fileData = [];
    this.meetingFormDirective.resetForm();
    this.agendaEditMode = false;
    this.meetingEditMode = false;
    this.disableBtn = false;
    this.agendaForm.reset();
    this.agendaFormDirective.resetForm();
    this.meetingAgendaList = [];
    this.showMeetingDetail = true;
    this.getMeetingDetail(this.meetingId);
    this.btEndDate = null;
    this.btStartDate = null;
  }

  resetMeetingMinuteForm() {
    this.meetingMinuteForm.reset();
    if (this.meetingMinuteFormDirective) {
      this.meetingMinuteFormDirective.resetForm();
    }
    //this.meetingMinuteFormDirective.resetForm();
    this.disableUploadMinuteBtn = false;
    this.fileDataForMeetingMinute = null;
    this.requestDocuments = [];
    this.meetingMinuteForm.controls.meetingMinuteStatusType.setValue(this.meetingMinuteStatusType.Draft);
    this.docError = "";
  }

  showEditMeetingIcon() {
    if (this.meetingDetail != null)
      if (new Date(this.meetingDetail.Meeting.ScheduledStart).getTime() > new Date().getTime() && this.role === this.roleEnum.BoardMember)
        return true;
      else
        return false;
    else
      return false;
  }

  changeSDate() {
    this.btStartDate = this.meetingForm.controls.startDateTime.value;
    let stDate = new Date(this.meetingForm.controls.startDateTime.value);
    if (stDate.getTime() > this.btEndDate.getTime()) {
      this.meetingForm.controls.endDateTime.reset('');
    }
  }

  changeEDate() {
    this.btEndDate = this.meetingForm.controls.endDateTime.value;
    let stDate = new Date(this.meetingForm.controls.startDateTime.value);
    if (this.btEndDate.getTime() < stDate.getTime()) {
      this.meetingForm.controls.startDateTime.reset('');
    }
  }

  cancelMeeting(meetingId: string) {
    let resData;
    this.service.cancelMeeting(meetingId).subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.notificationService.showNotification("Meeting deleted successfully");
        this.meetingDetail = null;
        this.meetingId = null;
        this.isRSVPClick === false;
        this.getUpcommingMeetingList();
        this.getCount();
        this.emailNotification.sendNotifications(this.meetingFeatureId, resData.RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.Meetings, TriggerType.Delete,
          AudienceType.BoardMember).subscribe(res => {
          });
      } else {
        console.log('Error');
      }
    }, error => {

    });
  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = valueObject.Title;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.CancelMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.cancelMeeting(valueObject.id);
      }
    });
  }

  //download document
  downloadDocument(filename) {
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.Meeting,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Document not found");
        }
      });
  }

  getMeetingRsvpUser(rsvpList) {
    var rsvpStr = "";
    var l = rsvpList.length - 1;
    var firstUser = rsvpList[0].CreatedByUserName;
    if (rsvpList.length > 0) {
      rsvpList.map(a => {
        if (a.CreatedByUserId === this.userId && rsvpList.length === 1) {
          rsvpStr = "You responded"
        } else if (a.CreatedByUserId === this.userId && rsvpList.length > 1) {
          rsvpStr = "You & " + l + " more responded";
        } else if (a.CreatedByUserId !== this.userId && rsvpList.length === 1) {
          rsvpStr = firstUser + " responded";
        } else if (a.CreatedByUserId !== this.userId && rsvpList.length > 1) {
          rsvpStr = firstUser + " & " + l + " more responded";
        }
      });
    }
    return rsvpStr;
  }



  //For Preview Minut document
  previewMeetingMinutDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    this.fileURL = "";
    if (document.MediaType !== '.pdf') {
      this.fileURL = document.DocumentPath;
    }
    else {
      this.commonService.downloadFile(document.DocumentPath).subscribe(
        (response) => {
          this.fileURL = URL.createObjectURL(response);
        }
      );
    }
  }



  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.FilePath, DocumentFeatureName.Meeting, DownloadfeatureName.Download).subscribe(res => {
      resDoumentData = res;
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image");
      }
    });
  }

  /*Load more*/
  loadMoreRecentlyHeldMeetings() {
    this.isLoadMorePast = true;
    let nextpageTake = this.pageTakeRecentlyHeldMeetings + DisplayLoadMoreMeeting.pageTake;
    this.pageTakeRecentlyHeldMeetings = nextpageTake;
    this.getResentMeetingList();
  }

  loadMoreUpcomingMeetings() {
    this.isLoadMoreUpcomming = true;
    this.isRSVPClick = false;
    let nextpageTake = this.pageTakeUpcomingMeetings + DisplayLoadMoreMeeting.pageTake;
    this.pageTakeUpcomingMeetings = nextpageTake;
    this.getUpcommingMeetingList();
  }

  getCount() {
    let resData;
    this.service.getMeetingCount(this.associationId, this.userId, this.role).subscribe(res => {
      resData = res;
      if (resData.Success) {
        this.upComingMeetingCount = resData.UPComingMeetingCount;
        this.pastMeetingCount = resData.RecentMeetingCount;
      } else {
        this.upComingMeetingCount = 0;
        this.pastMeetingCount = 0;
      }
    });
  }

  rsvpOfMeeting(meeting) {
    if (meeting.MeetingRSVPs !== null && meeting.MeetingRSVPs.length > 0) {
      var rsvp = meeting.MeetingRSVPs.find(m => m.CreatedByUserId === this.userId);
      if (rsvp !== null && rsvp !== undefined) {
        this.rsvpType = rsvp.RSVPType;
        return true;
      }
    }
  }

}
