export class Meeting {
    id: string
    Title: string
    MeetingType: string
    ScheduledStart: string
    ScheduledEnd: string
    MeetingAudienceType: string
    AssociationId: string
    Location: string
    AssociationName : string
    CreatedByUserId: string
    CreatedByUserName: string
    CreatedOn: string
    MeetingAgenda: MeetingAgenda []
}

export class RequestDocument {
    ImageId: string;
    Name: string
    MediaType: string
    InputStream: string
    FileSize: string
    DocumentId: string
    CreatedByUserName: string
}

export class MeetingAgenda {
    MeetingAgendaId: string
    AgendaItemNumber: number
    AgendaDetail: string
    AgendaDescription: string
}

export class MeetingRSVPs {
    MeetingRSVPId: string
    CreatedByUserId: string
    CreatedByUserName: string
    RSVPType: string
    IsRSVP: boolean
    UserImagePath: string;
}

export class MeetingMinute {
    CreatedByUserId: string
    CreatedByUserName: string
    MeetingMinutesType: boolean
    MeetingMinuteStatusTypeName: string
    PublishDate: string   
}

export enum RSVPType {
    Accept = "Attending",
    Tentative = "May Be Attending",
    Decline = "Not Attending"
}

export enum MeetingMinuteStatusType {
  Draft = "Draft",
  Final = "Approved"
}



