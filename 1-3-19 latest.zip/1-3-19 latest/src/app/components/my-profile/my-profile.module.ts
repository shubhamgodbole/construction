import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatIconModule, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule } from '@angular/material';
import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MyProfileComponent } from './my-profile.component';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { OnlyAlphabetsModule } from 'src/app/shared/directives/allow-only-alphabets/only-alphabets.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { AllowOnlyDateModule } from 'src/app/shared/directives/allow-only-date/allow-only-date.module';

const routes: Routes = [
  {
    path: '',
    component: MyProfileComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatIconModule,
    MatDatepickerModule,
    NumberOnlyDirectiveModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    OnlyAlphabetsModule,
    AllowOnlyDateModule,
    FormsModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule
  ],
  exports: [RouterModule],
  declarations: [MyProfileComponent]
})
export class MyProfileModule { }
