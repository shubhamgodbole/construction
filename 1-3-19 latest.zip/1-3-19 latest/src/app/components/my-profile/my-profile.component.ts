import { Component, OnInit, ViewChild } from '@angular/core';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';
import { BasicDetailsModel, UnitPetsModel, UnitVehiclesModel, EmergencyContactModel, DisplayGender, UpdateUserProfileModel, UserTenantInfoModel } from './my-profile.model';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { takeUntil, filter, pairwise } from 'rxjs/operators';
import { Subject, Subscription } from 'rxjs';
import { ValidationService, ConfirmPasswordValidator } from 'src/app/shared/services/validation.service';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { CommonService } from 'src/app/services/common.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { MatDialogRef, MatDialog, MatSnackBar } from '@angular/material';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonConstant } from 'src/app/shared/common/constant.model';
import { FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {
  isApiResponceCome: boolean = false;
  notificationService: NotificationService;
  hide = true;

  isOwnProfile: boolean = false;
  userId: string = "";

  //Confirm Dialog
  //For Delete
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  //base64textStringProfilePicture = [];
  inputStreamString = "";
  isProfilePicture: boolean = true;
  frmChangePassword: FormGroup;
  resData: any;
  //For get Query String.
  querySubcription: Subscription;
  /*For get list variables*/
  userProfileList: any;
  tenantsList: any;
  unitEmergencyContactsList: any;
  vehiclesList: any;
  petsList: any;
  userProfileDetails: any;
  associationUnitId: string;
  activationCode: string = "";
  //accountNumber: string;
  coverImagePath: string;
  profileImagePath: string;
  basicDetails: BasicDetailsModel;
  userData: UserData;
  onChangeProfileUserData: UserData;
  unitRoleProfiles: any;
  /*Variables for Add or Edit Pet*/
  addPet: boolean = false;
  resDataCreatePet: any;
  frmPet: FormGroup;
  isEditModePet: boolean = false;
  isSubmitBtnDisabledForPet: boolean = false;
  petTypeList: any[];
  @ViewChild('formDirectiveForPet') formDirectiveForPet: FormGroupDirective;


  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;


  /*Variables for Add or Edit Vehicle*/
  addVehicle: boolean = false;
  resDataCreateVehicle: any;
  frmVehicle: FormGroup;
  isEditModeVehicle: boolean = false;
  isSubmitBtnDisabledForVehicle: boolean = false;
  @ViewChild('formDirectiveForVehicle') formDirectiveForVehicle: FormGroupDirective;

  /*Variables for Edit Basic Details*/
  frmEditBasicDetails: FormGroup;
  addBasicDetails: boolean = false;
  resDataCreateBasicDetail: any;
  isSubmitBtnDisabledForBasicDetail: boolean = false;
  genderDdl: any;
  @ViewChild('editdob') editdob;
  editUserProfile: any;
  @ViewChild('formDirectiveForBasicDetail') formDirectiveForBasicDetail: FormGroupDirective;

  /*Variables for Add or Edit Emergency Contact*/
  addEmergencyContact: boolean = false;
  resDataCreateEmergencyContact: any;
  frmEmergencyContact: FormGroup;
  isEditModeEmergencyContact: boolean = false;
  isSubmitBtnDisabledForEmergencyContact: boolean = false;
  @ViewChild('formDirectiveForEmergencyContact') formDirectiveForEmergencyContact: FormGroupDirective;

  /*Variables for Add or Edit Tenant*/
  addTenant: boolean = false;
  resDataCreateTenant: any;
  frmTenant: FormGroup;
  isEditModeTenant: boolean = false;
  isSubmitBtnDisabledForTenant: boolean = false;
  @ViewChild('tenantstartdate') tenantstartdate;
  @ViewChild('tenantenddate') tenantenddate;
  tEndDate = Date;
  tStartDate = Date;
  @ViewChild('formDirectiveForTenant') formDirectiveForTenant: FormGroupDirective;

  //private subject = new Subject<any>();
  // Private
  private unsubscribeAll: Subject<any>;
  isSubmitBtnDisabled: boolean = false;
  //routeasas: string;

  //msg for password
  invalidPassword = CommonConstant.InvalidPassword;
  invalidConfirmPassword = CommonConstant.InvalidConfirmPassword;

  constructor(
    private _router: Router,
    private route: ActivatedRoute,
    private readonly snb: MatSnackBar,
    private _matDialog: MatDialog,
    private _location: Location,
    private readonly formBuilder: FormBuilder,
    private hoaDirectoryApiService: HoaDirectoryApiService,
    public commonService: CommonService,
    private progressbarService: ProgeressBarService,
    location: Location,
    private readonly appConfig: AppConfig) {
    this.unsubscribeAll = new Subject();
    this.genderDdl = DisplayGender.GenderList;
    this.userData = this.appConfig.getCurrentUser();
    this.userId = this.userData.UserProfileId;
    this.createAllForms();
    this.createFormBasicDetails();
    this.notificationService = new NotificationService(snb);

  }
  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      let associationUnitId = params["auid"];
      if (id) {
        this.hoaDirectoryApiService.userId = id;
        this.hoaDirectoryApiService.associationUnitId = associationUnitId;
        //To show edit icon of profile or not
        if (this.userId === id) {
          this.isOwnProfile = true;
        }
        else {
          this.isOwnProfile = false;
        }
        this.getPetTypeList();
        this.getData();
      }
      else {
        console.log("details Not found.")
        this._router.navigate([AppRouteUrl.mainHoaMembersRouteUrl]);
      }
    });
  }

  ngOnDestroy() {
    this.querySubcription.unsubscribe();
    this.isOwnProfile = false;
    this.hoaDirectoryApiService.isMyProfileComesFromHeader = false;
  }

  getPetTypeList() {
    this.progressbarService.show();
    this.hoaDirectoryApiService.getPetTypeList().subscribe(res => {
      this.resData = res;
      this.progressbarService.hide();
      console.log(res);
      if (this.resData.Errors > 0) {
        console.log("Api Error is comming");
      } else {
        if (this.resData.Success) {
          this.petTypeList = this.resData.PetTypes;
        } else {
          console.log("pet details not found.");
        }
      }

    },
      (err) => {
        console.log(err);
      }
    )
  }

  getData() {
    this.progressbarService.show();
    this.hoaDirectoryApiService.getMyprofile(this.hoaDirectoryApiService.userId, this.hoaDirectoryApiService.associationUnitId).subscribe(res => {
      this.resData = res;
      this.isApiResponceCome = true;
      this.progressbarService.hide();
      console.log(res);
      if (this.resData.Errors > 0) {
        console.log("Api Error is comming");
      } else {
        if (this.resData.Success) {
          this.userProfileList = this.resData.UserProfileDetailWithAddress;
          this.associationUnitId = this.hoaDirectoryApiService.associationUnitId;
          if (this.userProfileList !== null && this.userProfileList !== undefined) {
            this.activationCode = this.userProfileList.UserActivation.ActivationCode;
            // this.associationUnitId = this.resData.UserProfileDetailWithAddress.AssociationUnit.id;
            //  this.hoaDirectoryApiService.associationUnitId = this.resData.UserProfileDetailWithAddress.AssociationUnit.id;
            this.userProfileDetails = this.userProfileList.UserProfileDetail;
            this.editUserProfile = this.userProfileList.UserProfile;
            console.log(this.editUserProfile);
            this.unitEmergencyContactsList = this.userProfileList.UnitEmergencyContacts;
            this.vehiclesList = this.userProfileList.UnitVehicles;
            this.petsList = this.userProfileList.UnitPets;
            this.tenantsList = this.userProfileList.UserTenant;
            console.log("this.tenantsList", this.tenantsList);
            this.unitRoleProfiles = this.userProfileList.UnitRole.UnitRoleProfiles[0];
            this.coverImagePath = this.userProfileList.UserProfile.CoverImagePath;
            //let randomNumber = new Date().getTime();
            //this.profileImagePath = "";            
            //this.profileImagePath = this.userProfileList.UserProfile.ProfileImagePath + '?p=' + randomNumber;
            this.profileImagePath = this.userProfileList.UserProfile.ProfileImagePath;
            this.getBasicDetails();
          }
        } else {
          this.notificationService.showNotification("Details not found.");
        }
      }

    },
      (err) => {
        console.log(err);
      }
    )
  }

  getBasicDetails() {
    let propertyAddress = this.getFullPropertyAddress();
    let mailAddress = this.getFullMailingAddress();
    let basicDetail: BasicDetailsModel = {
      dateOfBirth: this.userProfileList.UserProfile.BirthDate,
      emailAddress: this.userProfileList.UserProfile.EmailAddress,
      gender: this.userProfileList.UserProfile.Gender,
      homePhoneNumber: this.userProfileList.UserProfile.HomePhone,
      mailingAddress: mailAddress,
      mobileNumber: this.userProfileList.UserProfile.Mobile,
      propertyAddress: propertyAddress,
      workPhoneNumber: this.userProfileList.UserProfile.WorkPhone1,
    }
    this.basicDetails = basicDetail;
    console.log("this.basicDetails", this.basicDetails);
  }

  getFullPropertyAddress(): string {
    let propertyAddress = "";
    let fullPropertyAddress = this.userProfileList.AssociationUnit;
    if (fullPropertyAddress !== null) {
      if (fullPropertyAddress.AssociationUnitAddress1 !== null) {
        propertyAddress = fullPropertyAddress.AssociationUnitAddress1 + ",";
      }
      if (fullPropertyAddress.AssociationUnitAddress2 !== null) {
        propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitAddress2;
      }
      if (fullPropertyAddress.AssociationUnitCity !== null) {
        propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitCity;
      }
      if (fullPropertyAddress.AssociationUnitState !== null) {
        propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitState + ",";
      }
      // if (fullPropertyAddress.AssociationUnitCounty !== null) {
      //   propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitCounty;
      // }
      if (fullPropertyAddress.AssociationUnitZip !== null) {
        propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitZip;
      }
    }

    return propertyAddress;
  }

  getFullMailingAddress(): string {
    let fullMailingAddress = this.userProfileList.Address;
    let mailAddress = "";
    if (fullMailingAddress !== null) {
      if (fullMailingAddress.Address1 !== null) {
        mailAddress = fullMailingAddress.Address1 + ",";
      }
      if (fullMailingAddress.Address2 !== null) {
        mailAddress = mailAddress + fullMailingAddress.Address2;
      }
      if (fullMailingAddress.City !== null) {
        mailAddress = mailAddress + " " + fullMailingAddress.City;
      }
      if (fullMailingAddress.State !== null) {
        mailAddress = mailAddress + " " + fullMailingAddress.State + ",";
      }
      // if (fullMailingAddress.County !== null) {
      //   mailAddress = mailAddress + fullMailingAddress.County;
      // }
      if (fullMailingAddress.ZIP !== null) {
        mailAddress = mailAddress + " " + fullMailingAddress.ZIP;
      }
    }

    return mailAddress;
  }


  createAllForms() {
    /**Change Password form */
    this.frmChangePassword = this.formBuilder.group({
      currentPassword: ['', [Validators.required]],
      newPassword: ['', [Validators.required, ValidationService.passwordValidator]],
      confirmPassword: ['', [Validators.required, ConfirmPasswordValidator]],
    });

    // Update the validity of the 'passwordConfirm' field
    // when the 'password' field changes
    this.frmChangePassword.get('newPassword').valueChanges
      .pipe(takeUntil(this.unsubscribeAll))
      .subscribe(() => {
        this.frmChangePassword.get('confirmPassword').updateValueAndValidity();
      });
    /** End Change Password form */

    /** Tenant form */
    this.frmTenant = this.formBuilder.group({
      userTenantDetailId: [''],
      userLeaseDetailId: [''],
      userProfileId: [''],
      userProfileUnitRoleId: [''],
      unitRoleId: [''],
      unitNumber: [''],
      firstName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      middleName: ['', [Validators.minLength(1), Validators.maxLength(50)]],
      lastName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      startDate: ['', Validators.required],
      endDate: [''],
      email: ['', [Validators.required, ValidationService.emailValidator]],
      mobile: ['', [Validators.required, Validators.minLength(13), Validators.maxLength(13)]],
    });
    /**End Pet form */


    /** Pet form */
    this.frmPet = this.formBuilder.group({
      userPetDetailId: [''],
      petType: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      petName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      breedName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]]
    });
    /**End Pet form */

    /**Vehicle form */
    this.frmVehicle = this.formBuilder.group({
      userVehicleDetailId: [''],
      makeModel: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      year: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(4)]],
      licensePlate: ['', [Validators.required, Validators.maxLength(20), ValidationService.noWhiteSpace]],
      state: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2), ValidationService.noWhiteSpace]],
    });
    /**End Vehicle form */

    /**EmergencyContact  form */
    this.frmEmergencyContact = this.formBuilder.group({
      emergencyContactDetailId: [''],
      firstName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      middleName: ['', [Validators.minLength(1), Validators.maxLength(50)]],
      lastName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      mobile: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13)]], //[Validators.required, Validators.minLength(10)]],
      email: ['', [Validators.required, ValidationService.emailValidator]],
      addressLine1: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
      addressLine2: ['', [Validators.maxLength(100), Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      city: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(30), ValidationService.noWhiteSpace]],
      state: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      zip: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10), ValidationService.noWhiteSpace]],
      homePhone: ['', [Validators.maxLength(13), Validators.minLength(13)]],
      workPhone: ['', [Validators.maxLength(13), Validators.minLength(13)]],
    });
    /**End EmergencyContact  form */

  }




  doChangePassword() {
    // const oldPassword = "Macosx123";
    // const newPassword = "Macosx123";
    let model = {
      userId: this.hoaDirectoryApiService.userId,//this.userId,
      currentPassword: this.frmChangePassword.controls.currentPassword.value,
      newPassword: this.frmChangePassword.controls.newPassword.value,
      confirmPassword: this.frmChangePassword.controls.confirmPassword.value
    };
    if (this.frmChangePassword.valid) {
      this.isSubmitBtnDisabled = true;
      this.hoaDirectoryApiService.doChangePassword(model).subscribe(res => {
        this.resData = res;
        this.isSubmitBtnDisabled = false;
        console.log(this.resData);
        if (this.resData.Success === true) {
          this.notificationService.showNotification("Your password changed successfully.");
          this.resetForm();
        }
        else if (this.resData.Success === false) {
          this.notificationService.showNotification(this.resData.Message);
        }
        else {
          this.notificationService.showNotification("Your password not changed, Please try again.");
        }
      },
        (err) => {
          console.log(err);
        }
      )
    }
  }
  resetForm() {
    this.frmChangePassword.reset();
    this.frmChangePassword.controls.currentPassword.setErrors(null);
    this.frmChangePassword.controls.newPassword.setErrors(null);
    this.frmChangePassword.controls.confirmPassword.setErrors(null);
    this.frmChangePassword.clearValidators();
  }

  onChangeProfilePicture(evt: any, imageType: string) {
    if (imageType === "CoverImage")
      this.isProfilePicture = false;
    else
      this.isProfilePicture = true;

    const file = evt.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = this.handleReaderLoadedProfilePicture.bind(this);
      reader.readAsBinaryString(file);
    }
  }

  handleReaderLoadedProfilePicture(e) {
    this.inputStreamString = 'data:image/png;base64,' + btoa(e.target.result);
    this.onChangePicture();
  }

  onChangePicture() {
    const inputStream = this.inputStreamString;
    if (this.isProfilePicture) {
      this.hoaDirectoryApiService.changeProfilePicture(this.hoaDirectoryApiService.userId, inputStream).subscribe(res => {
        this.resData = res;
        console.log(this.resData);
        if (this.resData.Success === true) {
          let randomNumber = new Date().getTime(); //Math.floor(1000 + Math.random() * 9000);
          this.profileImagePath = "";
          this.profileImagePath = this.resData.ProfileUrl + '?p=' + randomNumber;
          this.notificationService.showNotification("Your Profile Picture changed successfully.");
          //On change profile image change header image also.
          this.onChangeProfileUserData = this.appConfig.getCurrentUser();
          this.onChangeProfileUserData.UserProfileBlobPath = this.profileImagePath;
          this.appConfig.setCurrentUser(this.onChangeProfileUserData);
          this.commonService.userProfileUrlSubject.next(this.resData.ProfileUrl);
          console.log("this.onChangeProfileUserData", this.onChangeProfileUserData);
        }
        else {
          this.notificationService.showNotification("Your Profile Picture not changed, Please try again.");
        }
      },
        (err) => {
          console.log(err);
        }
      )
    }
    else {
      this.hoaDirectoryApiService.changeCoverPicture(this.hoaDirectoryApiService.userId, inputStream).subscribe(res => {
        this.resData = res;
        console.log(this.resData);
        if (this.resData.Success === true) {
          let randomNumber = new Date().getTime();
          this.coverImagePath = this.resData.CoverProfileUrl + '?c=' + randomNumber;
          console.log("this.coverImagePath", this.coverImagePath);
          this.notificationService.showNotification("Your Cover Picture changed successfully.");
        }
        else {
          this.notificationService.showNotification("Your Cover Picture not changed, Please try again.");
        }
      },
        (err) => {
          console.log(err);
        }
      )
    }
  }


  deleteVehical(vehicleDetails, unitId) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = vehicleDetails.MakeModel;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.hoaDirectoryApiService.deleteVehical(this.hoaDirectoryApiService.userId, unitId, vehicleDetails.UserVehicleDetailId).subscribe(res => {
          this.resData = res;
          if (this.resData.Success === true) {
            this.notificationService.showNotification("Vehical Deleted successfully.");
            this.getData();
          }
          else {
            this.notificationService.showNotification("Vehical is not deleted, Please try again.");
          }
        },
          (err) => {
            console.log(err);
          }
        )
      }
    });

  }


  deletePet(petDetails, unitId) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = petDetails.PetTypeName;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.hoaDirectoryApiService.deletePet(this.hoaDirectoryApiService.userId, unitId, petDetails.UserPetDetailId).subscribe(res => {
          this.resData = res;
          if (this.resData.Success === true) {
            this.notificationService.showNotification("Pet deleted successfully.");
            this.getData();
          }
          else {
            this.notificationService.showNotification("Pet is not deleted, Please try again.");
          }
        },
          (err) => {
            console.log(err);
          }
        )
      }
    });

  }
  deleteTenant(tenantDetaiils, unitId) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = tenantDetaiils.FirstName + " " + tenantDetaiils.LastName;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.hoaDirectoryApiService.deleteTenant(this.hoaDirectoryApiService.userId, unitId, tenantDetaiils.UserTenantDetailsId).subscribe(res => {
          this.resData = res;
          if (this.resData.Success === true) {
            this.notificationService.showNotification("Tenant Deleted successfully.");
            this.getData();
          }
          else {
            this.notificationService.showNotification("Tenant is not deleted, Please try again.");
          }
        },
          (err) => {
            console.log(err);
          }
        )
      }
    });

  }

  deleteContact(emergencyContactDetail, unitId) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = emergencyContactDetail.FirstName + " " + emergencyContactDetail.LastName;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.hoaDirectoryApiService.deleteContact(this.hoaDirectoryApiService.userId, unitId, emergencyContactDetail.EmergencyContactDetailId).subscribe(res => {
          this.resData = res;
          if (this.resData.Success === true) {
            this.notificationService.showNotification("Contact Deleted successfully.");
            this.getData();
          }
          else {
            this.notificationService.showNotification("Contact is not deleted, Please try again.");
          }
        },
          (err) => {
            console.log(err);
          }
        )
      }
    });
  }

  /* Region Edit or Add Basic details */
  addBasicDetailsToggle() {
    if (this.addBasicDetails) {
      this.addBasicDetails = false;
    }
    else
      this.addBasicDetails = true;
    this.setBasicDetailsFormValue();
  }

  createFormBasicDetails() {
    this.frmEditBasicDetails = this.formBuilder.group({
      id: [''],
      firstName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      middleName: ['', [Validators.minLength(1), Validators.maxLength(50)]],
      lastName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      propertyAddressLine1: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
      propertyAddressLine2: ['', [Validators.maxLength(100), Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      propertyCity: ['', [Validators.minLength(1), Validators.maxLength(30), ValidationService.noWhiteSpace]],
      propertyState: ['', [Validators.minLength(1), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      propertyZip: ['', [Validators.minLength(5), Validators.maxLength(10), ValidationService.noWhiteSpace]],
      mailingAddressLine1: ['', [Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
      mailingAddressLine2: ['', [Validators.maxLength(100), Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      mailingCity: ['', [Validators.minLength(1), Validators.maxLength(30), ValidationService.noWhiteSpace]],
      mailingState: ['', [Validators.minLength(1), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      mailingZip: ['', [Validators.minLength(1), Validators.maxLength(10), ValidationService.noWhiteSpace]],
      email: ['', [Validators.required, ValidationService.emailValidator]],
      mobile: ['', [Validators.required, Validators.minLength(13), Validators.maxLength(13)]],
      homePhone: ['', [Validators.minLength(13), Validators.maxLength(13)]],
      workPhone: ['', [Validators.minLength(13), Validators.maxLength(13)]],
      gender: ['', Validators.required],
      dateOfBirth: ['']
      // aboutMe: ['', [Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]],
      // extraInformation: ['', [Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  setBasicDetailsFormValue() {
    this.frmEditBasicDetails.controls.id.setValue(this.hoaDirectoryApiService.userId);
    this.frmEditBasicDetails.controls.firstName.setValue(this.editUserProfile.FirstName);
    this.frmEditBasicDetails.controls.lastName.setValue(this.editUserProfile.LastName);
    this.frmEditBasicDetails.controls.middleName.setValue(this.editUserProfile.MiddleName);

    this.frmEditBasicDetails.controls.propertyAddressLine1.setValue(this.userProfileList.AssociationUnit.AssociationUnitAddress1);
    this.frmEditBasicDetails.controls.propertyAddressLine2.setValue(this.userProfileList.AssociationUnit.AssociationUnitAddress2);
    this.frmEditBasicDetails.controls.propertyCity.setValue(this.userProfileList.AssociationUnit.AssociationUnitCity);
    this.frmEditBasicDetails.controls.propertyState.setValue(this.userProfileList.AssociationUnit.AssociationUnitState);
    this.frmEditBasicDetails.controls.propertyZip.setValue(this.userProfileList.AssociationUnit.AssociationUnitZip);

    this.frmEditBasicDetails.controls.mailingAddressLine1.setValue(this.userProfileList.Address.Address1);
    this.frmEditBasicDetails.controls.mailingAddressLine2.setValue(this.userProfileList.Address.Address2);
    this.frmEditBasicDetails.controls.mailingCity.setValue(this.userProfileList.Address.City);
    this.frmEditBasicDetails.controls.mailingState.setValue(this.userProfileList.Address.State);
    this.frmEditBasicDetails.controls.mailingZip.setValue(this.userProfileList.Address.ZIP);

    if (this.editUserProfile.Mobile !== null && this.editUserProfile.Mobile !== "") {
      let mobileNumber = this.convertMobileNumber(this.editUserProfile.Mobile);
      this.frmEditBasicDetails.controls.mobile.setValue(mobileNumber);
    }
    else {
      this.frmEditBasicDetails.controls.mobile.setValue("");
    }
    if (this.editUserProfile.WorkPhone1 !== null && this.editUserProfile.WorkPhone1 !== "") {
      let workPhone1 = this.convertMobileNumber(this.editUserProfile.WorkPhone1);
      this.frmEditBasicDetails.controls.workPhone.setValue(workPhone1);
    }
    else {
      this.frmEditBasicDetails.controls.workPhone.setValue("");
    }
    if (this.editUserProfile.HomePhone !== null && this.editUserProfile.HomePhone !== "") {
      let homePhone = this.convertMobileNumber(this.editUserProfile.HomePhone);
      this.frmEditBasicDetails.controls.homePhone.setValue(homePhone);
    }
    else {
      this.frmEditBasicDetails.controls.homePhone.setValue("");
    }
    this.frmEditBasicDetails.controls.email.setValue(this.editUserProfile.EmailAddress);
    // this.frmEditBasicDetails.controls.workPhone.setValue(this.editUserProfile.WorkPhone1);
    // this.frmEditBasicDetails.controls.homePhone.setValue(this.editUserProfile.HomePhone);
    let selectedGender = this.genderDdl.find(x => x.text === this.editUserProfile.Gender)
    this.frmEditBasicDetails.controls.gender.setValue(selectedGender.text);
    this.frmEditBasicDetails.controls.dateOfBirth.setValue(this.editUserProfile.BirthDate);
  }

  /*:Check Current Date*/
  getToday(): string {
    return new Date().toISOString().split('T')[0]
  }

  onBasicDetailSubmit() {
    if (this.frmEditBasicDetails.valid) {
      this.isSubmitBtnDisabledForBasicDetail = true;
      let model = this.createEditBasicFormModel();
      console.log("Edit", model);
      this.hoaDirectoryApiService.editBasicDetails(model).subscribe(res => {
        this.isSubmitBtnDisabledForBasicDetail = false;
        this.resDataCreatePet = res;
        if (this.resDataCreatePet.Success === true) {
          this.addBasicDetails = false;
          this.notificationService.showNotification("Basic details updated successfully.");
          this.getData();
          this.resetEditBasicForm();
        }
        else if (this.resDataCreatePet.Success === false) {
          this.notificationService.showNotification("Not Saved");
        }
      });
    }
  }
  resetEditBasicForm() {
    this.frmEditBasicDetails.reset();
    this.formDirectiveForBasicDetail.resetForm();
    this.isSubmitBtnDisabledForBasicDetail = false;
  }

  createEditBasicFormModel() {

    const model: UpdateUserProfileModel = {
      UserProfile: {
        id: this.frmEditBasicDetails.controls.id.value,
        FirstName: this.frmEditBasicDetails.controls.firstName.value,
        MiddleName: this.frmEditBasicDetails.controls.middleName.value,
        LastName: this.frmEditBasicDetails.controls.lastName.value,
        Gender: this.frmEditBasicDetails.controls.gender.value,
        EmailAddress: this.frmEditBasicDetails.controls.email.value,
        Mobile: this.frmEditBasicDetails.controls.mobile.value,
        HomePhone: this.frmEditBasicDetails.controls.homePhone.value,
        WorkPhone1: this.frmEditBasicDetails.controls.workPhone.value,
        BirthDate: this.frmEditBasicDetails.controls.dateOfBirth.value !== null || '' ? new Date(this.frmEditBasicDetails.controls.dateOfBirth.value).toUTCString() : ''


      },
      Address: {
        IsPrimary: this.userProfileList.Address.IsPrimary,
        Remarks: this.userProfileList.Address.Remarks,
        UserAddressType: this.userProfileList.Address.UserAddressType,
        UseraddressId: this.userProfileList.Address.UseraddressId,
        Address1: this.frmEditBasicDetails.controls.mailingAddressLine1.value,
        Address2: this.frmEditBasicDetails.controls.mailingAddressLine2.value,
        City: this.frmEditBasicDetails.controls.mailingCity.value,
        County: "",
        State: this.frmEditBasicDetails.controls.mailingState.value,
        ZIP: this.frmEditBasicDetails.controls.mailingZip.value,
      },
      AssociationUnit: {
        id: this.userProfileList.AssociationUnit.id,
        AssociationId: this.userProfileList.AssociationUnit.AssociationId,
        AssociationUnitAddress1: this.frmEditBasicDetails.controls.propertyAddressLine1.value,
        AssociationUnitAddress2: this.frmEditBasicDetails.controls.propertyAddressLine2.value,
        AssociationUnitCity: this.frmEditBasicDetails.controls.propertyCity.value,
        AssociationUnitCounty: "",
        AssociationUnitState: this.frmEditBasicDetails.controls.propertyState.value,
        AssociationUnitZip: this.frmEditBasicDetails.controls.propertyZip.value,
      },
      MemberEndDate: this.unitRoleProfiles.EndDate,
      MemberStartDate: this.unitRoleProfiles.StartDate,
      UserProfileUnitRoleId: this.unitRoleProfiles.UserProfileUnitRoleId
    }
    return model;
  }



  /* Region Edit or Add Tenant details */
  addTenantToggle() {
    if (this.addTenant) {
      this.addTenant = false;
    }
    else
      this.addTenant = true;
    this.resetFormTenant();
  }

  changeSDate() {
    this.tStartDate = this.frmTenant.controls.startDate.value;
  }
  changeEDate() {
    this.tEndDate = this.frmTenant.controls.endDate.value;
    let stDate = this.frmTenant.controls.startDate.value;
    if (stDate > this.tEndDate) {
      this.frmTenant.controls.endDate.reset('');
    }
  }

  onTenantSubmit() {
    if (this.frmTenant.valid) {
      this.isSubmitBtnDisabledForTenant = true;
      let model = this.createTenantFormModel();
      console.log("model:", model);
      if (this.isEditModeTenant) {
        this.editTenant(model);
      } else {
        this.saveTenant(model);
      }
    }
  }

  saveTenant(model) {
    this.hoaDirectoryApiService.createTenant(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.isSubmitBtnDisabledForTenant = false;
      this.resDataCreateTenant = res;
      if (this.resDataCreateTenant.Success === true) {
        this.notificationService.showNotification("Tenant details saved successfully.");
        this.addTenant = false;
        this.getData();
        this.resetFormTenant();
      }
      else if (this.resDataCreateTenant.Success === false) {
        this.notificationService.showNotification("Not Saved");
      }
    });
  }

  editTenant(model) {
    this.hoaDirectoryApiService.editTenant(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.isSubmitBtnDisabledForTenant = false;
      this.resDataCreateTenant = res;
      if (this.resDataCreateTenant.Success === true) {
        this.notificationService.showNotification("Tenant details updated successfully.");
        this.addTenant = false;
        this.getData();
        this.resetFormTenant();
      }
      else if (this.resDataCreateTenant.Success === false) {
        this.notificationService.showNotification("Not saved");
      }
    });
  }
  createTenantFormModel() {
    console.log(this.frmTenant.controls.startDate.value);

    const model: UserTenantInfoModel = {
      UserTenant: {
        UserProfileId: this.frmTenant.controls.userProfileId.value != null || '' ? this.frmTenant.controls.userProfileId.value : '',
        FirstName: this.frmTenant.controls.firstName.value,
        MiddleName: this.frmTenant.controls.middleName.value,
        LastName: this.frmTenant.controls.lastName.value,
        LeaseStartDate: this.frmTenant.controls.startDate.value != null || '' ? new Date(this.frmTenant.controls.startDate.value).toUTCString() : '',
        LeaseEndDate: this.frmTenant.controls.endDate.value != null || '' ? new Date(this.frmTenant.controls.endDate.value).toUTCString() : '',
        Mobile: this.frmTenant.controls.mobile.value,
        Email: this.frmTenant.controls.email.value,
        UnitId: this.associationUnitId,
        UserTenantDetailsId: this.frmTenant.controls.userTenantDetailId.value != null || '' ? this.frmTenant.controls.userTenantDetailId.value : '',
        AccountNumber: "",
        UnitNumber: this.frmTenant.controls.unitNumber.value != null || '' ? this.frmTenant.controls.unitNumber.value : '',
        UnitRoleId: this.frmTenant.controls.unitRoleId.value != null || '' ? this.frmTenant.controls.unitRoleId.value : '',
        UserProfielUnitRoleId: this.frmTenant.controls.userProfileUnitRoleId.value != null || '' ? this.frmTenant.controls.userProfileUnitRoleId.value : '',
      },
      UnitTenants: {
        UnitId: this.associationUnitId,
        TenantDetails: [{
          UserTenantDetailsId: this.frmTenant.controls.userTenantDetailId.value != null || '' ? this.frmTenant.controls.userTenantDetailId.value : '',
          UserProfileUnitRoleId: this.frmTenant.controls.userProfileUnitRoleId.value != null || '' ? this.frmTenant.controls.userProfileUnitRoleId.value : '',
          UserLease: {
            UserLeaseDetailId: this.frmTenant.controls.userLeaseDetailId.value != null || '' ? this.frmTenant.controls.userLeaseDetailId.value : '',
            UserProfileUnitRoleId: this.frmTenant.controls.userProfileUnitRoleId.value != null || '' ? this.frmTenant.controls.userProfileUnitRoleId.value : '',
            LeaseStartDate: this.frmTenant.controls.startDate.value,
            LeaseEndDate: this.frmTenant.controls.endDate.value,
            UserProfileId: this.frmTenant.controls.userProfileId.value != null || '' ? this.frmTenant.controls.userProfileId.value : ''
          }
        }]
      }
    }
    return model;
  }

  editRowTenant(tenantDetaiils) {
    console.log(tenantDetaiils);

    this.isEditModeTenant = true;
    this.addTenant = true;
    this.frmTenant.controls.userProfileId.setValue(tenantDetaiils.UserProfileId);
    this.frmTenant.controls.userLeaseDetailId.setValue(tenantDetaiils.UserLeaseDetailId);
    this.frmTenant.controls.userProfileUnitRoleId.setValue(tenantDetaiils.UserProfielUnitRoleId);
    this.frmTenant.controls.unitNumber.setValue(tenantDetaiils.UnitNumber);
    this.frmTenant.controls.unitRoleId.setValue(tenantDetaiils.UnitRoleId);
    this.frmTenant.controls.userTenantDetailId.setValue(tenantDetaiils.UserTenantDetailsId);
    this.frmTenant.controls.firstName.setValue(tenantDetaiils.FirstName);
    this.frmTenant.controls.middleName.setValue(tenantDetaiils.MiddleName);
    this.frmTenant.controls.lastName.setValue(tenantDetaiils.LastName);
    this.frmTenant.controls.email.setValue(tenantDetaiils.Email);
    this.frmTenant.controls.mobile.setValue(tenantDetaiils.Mobile);
    console.log(tenantDetaiils.LeaseStartDate);
    console.log(tenantDetaiils.LeaseStartDate);
    this.frmTenant.controls.startDate.setValue(tenantDetaiils.LeaseStartDate);
    this.frmTenant.controls.endDate.setValue(tenantDetaiils.LeaseEndDate);
  }

  resetFormTenant() {
    this.frmTenant.reset();
    this.formDirectiveForTenant.resetForm();
    this.isSubmitBtnDisabledForTenant = false;
    this.isEditModeTenant = false;
  }




  /* Region Edit or Add Pet details */
  addPetToggle() {
    if (this.addPet) {
      this.addPet = false;
    }
    else
      this.addPet = true;
    this.resetFormPet();
  }

  // createFormPet() {
  //   this.frmPet = this.formBuilder.group({
  //     userPetDetailId: [''],
  //     petType: ['', Validators.required],
  //     petName: ['', Validators.required],
  //     breedName: ['', Validators.required]
  //   });
  // }

  onPetSubmit() {
    if (this.frmPet.valid) {
      this.isSubmitBtnDisabledForPet = true;
      let model = this.createPetFormModel();
      if (this.isEditModePet) {
        this.editPet(model);
      } else {
        this.savePet(model);
      }
    }
  }

  savePet(model) {
    this.hoaDirectoryApiService.createPet(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.isSubmitBtnDisabledForPet = false;
      this.resDataCreatePet = res;
      if (this.resDataCreatePet.Success === true) {
        this.notificationService.showNotification("Pet details saved successfully.");
        this.addPet = false;
        this.getData();
        this.resetFormPet();
      }
      else if (this.resDataCreatePet.Success === false) {
        this.notificationService.showNotification("Not Saved");
      }
    });
  }

  editPet(model) {
    this.hoaDirectoryApiService.editPet(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.isSubmitBtnDisabledForPet = false;
      this.resDataCreatePet = res;
      if (this.resDataCreatePet.Success === true) {
        this.notificationService.showNotification("Pet details updated successfully.");
        this.addPet = false;
        this.getData();
        this.resetFormPet();
      }
      else if (this.resDataCreatePet.Success === false) {
        this.notificationService.showNotification("Not saved");
      }
    });
  }
  createPetFormModel() {
    const model: UnitPetsModel = {
      unitId: this.hoaDirectoryApiService.associationUnitId,
      PetDetails:
        [{
          userPetDetailId: this.frmPet.controls.userPetDetailId.value,
          petName: this.frmPet.controls.petName.value,
          petTypeName: this.frmPet.controls.petType.value,
          breedName: this.frmPet.controls.breedName.value
        }]
    }
    return model;
  }

  editRowPet(pet) {
    this.isEditModePet = true;
    this.addPet = true;
    this.frmPet.controls.userPetDetailId.setValue(pet.UserPetDetailId);
    this.frmPet.controls.petType.setValue(pet.PetTypeName);
    this.frmPet.controls.petName.setValue(pet.PetName);
    this.frmPet.controls.breedName.setValue(pet.BreedName);
  }

  resetFormPet() {
    this.frmPet.reset();
    this.formDirectiveForPet.resetForm();
    this.isSubmitBtnDisabledForPet = false;
    this.isEditModePet = false;
  }

  /* Region Edit or Add Vehicle details */
  addVehicleToggle() {
    // this.createFormPet();
    if (this.addVehicle) {
      this.addVehicle = false;
    }
    else
      this.addVehicle = true;
    this.resetFormVehicle();
  }

  // createFormVehicle() {
  //   this.frmVehicle = this.formBuilder.group({
  //     userVehicleDetailId: [''],
  //     makeModel: ['', Validators.required],
  //     year: ['', Validators.required],
  //     licensePlate: ['', Validators.required],
  //     state: ['', Validators.required],
  //   });
  // }

  onVehicleSubmit() {
    if (this.frmVehicle.valid) {
      this.isSubmitBtnDisabledForVehicle = true;
      let model = this.createVehicleFormModel();
      if (this.isEditModeVehicle) {
        this.editVehicle(model);
      } else {
        this.saveVehicle(model);
      }
    }
  }

  saveVehicle(model) {
    this.hoaDirectoryApiService.createVehicle(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.resDataCreateVehicle = res;
      this.isSubmitBtnDisabledForVehicle = false;
      if (this.resDataCreateVehicle.Success === true) {
        this.notificationService.showNotification("Vehicle details saved successfully.");
        this.addVehicle = false;
        this.resetFormPet();
        this.getData();
      }
      else if (this.resDataCreateVehicle.Success === false) {
        this.notificationService.showNotification("Not Saved");
      }
    });
  }

  editVehicle(model) {
    this.hoaDirectoryApiService.editVehicle(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.resDataCreateVehicle = res;
      this.isSubmitBtnDisabledForVehicle = false;
      if (this.resDataCreateVehicle.Success === true) {
        this.notificationService.showNotification("Vehicle details updated successfully.");
        this.addVehicle = false;
        this.resetFormVehicle();
        this.getData();
      }
      else if (this.resDataCreateVehicle.Success === false) {
        this.notificationService.showNotification("Not updated");
      }
    });
  }
  createVehicleFormModel() {

    const model: UnitVehiclesModel = {
      unitId: this.hoaDirectoryApiService.associationUnitId,
      VehicleDetails:
        [{
          userVehicleDetailId: this.frmVehicle.controls.userVehicleDetailId.value,
          makeModel: this.frmVehicle.controls.makeModel.value,
          licensePlate: this.frmVehicle.controls.licensePlate.value,
          state: this.frmVehicle.controls.state.value,
          year: this.frmVehicle.controls.year.value
        }]
    }
    return model;
  }

  editRowVehicle(vehicle) {
    this.isEditModeVehicle = true;
    this.addVehicle = true;
    this.frmVehicle.controls.userVehicleDetailId.setValue(vehicle.UserVehicleDetailId);
    this.frmVehicle.controls.makeModel.setValue(vehicle.MakeModel);
    this.frmVehicle.controls.licensePlate.setValue(vehicle.LicensePlate);
    this.frmVehicle.controls.state.setValue(vehicle.State);
    this.frmVehicle.controls.year.setValue(vehicle.Year);
  }

  resetFormVehicle() {
    this.frmVehicle.reset();
    this.formDirectiveForVehicle.resetForm();
    this.isSubmitBtnDisabledForVehicle = false;
    this.isEditModeVehicle = false;
  }



  /* Region Edit or Add Emergency Contact */

  setMobileNumber(event) {
    let ctrlValue = this.frmEmergencyContact.controls.mobile.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmEmergencyContact.controls.mobile.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmEmergencyContact.controls.mobile.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmEmergencyContact.controls.mobile.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }

  // setMobileNumber() {
  //   let ctrlValue = this.frmEmergencyContact.controls.mobile.value;
  //   let newCtrlValue = this.convertMobileNumber(ctrlValue);
  //   this.frmEmergencyContact.controls.mobile.setValue(newCtrlValue);
  // }

  setWorkPhoneNumber(event) {
    let ctrlValue = this.frmEmergencyContact.controls.workPhone.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmEmergencyContact.controls.workPhone.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmEmergencyContact.controls.workPhone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmEmergencyContact.controls.workPhone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }

  // setWorkPhoneNumber() {
  //   let ctrlValue = this.frmEmergencyContact.controls.workPhone.value;
  //   let newCtrlValue = this.convertMobileNumber(ctrlValue);
  //   this.frmEmergencyContact.controls.workPhone.setValue(newCtrlValue);
  // }

  setHomePhoneNumber(event) {
    let ctrlValue = this.frmEmergencyContact.controls.homePhone.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmEmergencyContact.controls.homePhone.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmEmergencyContact.controls.homePhone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmEmergencyContact.controls.homePhone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }

  // setHomePhoneNumber() {
  //   let ctrlValue = this.frmEmergencyContact.controls.homePhone.value;
  //   let newCtrlValue = this.convertMobileNumber(ctrlValue);
  //   this.frmEmergencyContact.controls.homePhone.setValue(newCtrlValue);
  // }

  setMobileNumberForEditBasic(event) {
    // var x = event.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
    // event.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
    // this.frmEditBasicDetails.controls.mobile.setValue(event.target.value);
    let ctrlValue = this.frmEditBasicDetails.controls.mobile.value;
    let newCtrlValue;
    if (ctrlValue) {
      // if (event.key === 'Backspace' || event.key === 'Delete') {
      //   this.frmEditBasicDetails.controls.mobile.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      // } else {
      //   if (ctrlValue.length < 10) {
      //   }
      //   else if (ctrlValue.length === 10) {
      //     ctrlValue = this.frmEditBasicDetails.controls.mobile.value;
      //     newCtrlValue = this.convertMobileNumber(ctrlValue);
      //     this.frmEditBasicDetails.controls.mobile.setValue(newCtrlValue);
      //   }
      // }
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmEditBasicDetails.controls.mobile.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmEditBasicDetails.controls.mobile.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmEditBasicDetails.controls.mobile.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }
  setWorkPhoneNumberForEditBasic(event) {
    // let ctrlValue = this.frmEditBasicDetails.controls.workPhone.value;
    // let newCtrlValue = this.convertMobileNumber(ctrlValue);
    // this.frmEditBasicDetails.controls.workPhone.setValue(newCtrlValue);
    let ctrlValue = this.frmEditBasicDetails.controls.workPhone.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmEditBasicDetails.controls.workPhone.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmEditBasicDetails.controls.workPhone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmEditBasicDetails.controls.workPhone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }

  setHomePhoneNumberForEditBasic(event) {
    // let ctrlValue = this.frmEditBasicDetails.controls.homePhone.value;
    // let newCtrlValue = this.convertMobileNumber(ctrlValue);
    // this.frmEditBasicDetails.controls.homePhone.setValue(newCtrlValue);
    let ctrlValue = this.frmEditBasicDetails.controls.homePhone.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmEditBasicDetails.controls.homePhone.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmEditBasicDetails.controls.homePhone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmEditBasicDetails.controls.homePhone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }

  setMobileNumberForTenant(event) {
    // let ctrlValue = this.frmTenant.controls.mobile.value;
    // let newCtrlValue = this.convertMobileNumber(ctrlValue);
    // this.frmTenant.controls.mobile.setValue(newCtrlValue);
    let ctrlValue = this.frmTenant.controls.mobile.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmTenant.controls.mobile.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmTenant.controls.mobile.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmTenant.controls.mobile.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }


  addEmergencyContactToggle() {
    if (this.addEmergencyContact) {
      this.addEmergencyContact = false;
    }
    else
      this.addEmergencyContact = true;
    this.resetFormEmergencyContact();
  }

  // createFormEmergencyContact() {
  //   this.frmEmergencyContact = this.formBuilder.group({
  //     emergencyContactDetailId: [''],
  //     firstName: ['', Validators.required],
  //     middleName: ['', Validators.required],
  //     lastName: ['', Validators.required],
  //     mobile: ['', [Validators.required, Validators.minLength(10)]],
  //     email: ['', [Validators.required, ValidationService.emailValidator]],
  //     addressLine1: ['', Validators.required],
  //     addressLine2: [''],
  //     city: ['', Validators.required],
  //     state: ['', Validators.required],
  //     zip: ['', Validators.required],
  //     homePhone: [''],
  //     workPhone: [''],
  //   });
  // }

  onEmergencyContactSubmit() {

    if (this.frmEmergencyContact.valid) {
      this.isSubmitBtnDisabledForEmergencyContact = true;
      let model = this.createEmergencyContactFormModel();
      if (this.isEditModeEmergencyContact) {
        this.editEmergencyContact(model);
      } else {
        this.saveEmergencyContact(model);
      }
    }
  }

  saveEmergencyContact(model) {
    this.hoaDirectoryApiService.createEmergencyContact(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.resDataCreateEmergencyContact = res;
      this.isSubmitBtnDisabledForEmergencyContact = false;
      if (this.resDataCreateEmergencyContact.Success === true) {
        this.notificationService.showNotification("Contact details saved successfully.");
        this.addEmergencyContact = false;
        this.resetFormEmergencyContact();
        this.getData();


      }
      else if (this.resDataCreateEmergencyContact.Success === false) {
        this.notificationService.showNotification("Not Saved");
      }
    });
  }

  editEmergencyContact(model) {
    this.hoaDirectoryApiService.editEmergencyContact(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.resDataCreateEmergencyContact = res;
      this.isSubmitBtnDisabledForEmergencyContact = false;
      if (this.resDataCreateEmergencyContact.Success === true) {
        this.notificationService.showNotification("Contact details updated successfully.");
        this.addEmergencyContact = false;
        this.resetFormEmergencyContact();
        this.getData();
      }
      else if (this.resDataCreateEmergencyContact.Success === false) {
        this.notificationService.showNotification("Not updated");
      }
    });
  }
  createEmergencyContactFormModel() {
    const model: EmergencyContactModel = {
      unitId: this.hoaDirectoryApiService.associationUnitId,
      EmergencyContacts:
        [{
          emergencyContactDetailId: this.frmEmergencyContact.controls.emergencyContactDetailId.value,
          firstName: this.frmEmergencyContact.controls.firstName.value,
          lastName: this.frmEmergencyContact.controls.lastName.value,
          middleName: this.frmEmergencyContact.controls.middleName.value,
          mobile: this.frmEmergencyContact.controls.mobile.value,
          email: this.frmEmergencyContact.controls.email.value,
          addressLine1: this.frmEmergencyContact.controls.addressLine1.value,
          addressLine2: this.frmEmergencyContact.controls.addressLine2.value,
          state: this.frmEmergencyContact.controls.state.value,
          city: this.frmEmergencyContact.controls.city.value,
          workPhone: this.frmEmergencyContact.controls.workPhone.value,
          homePhone: this.frmEmergencyContact.controls.homePhone.value,
          zip: this.frmEmergencyContact.controls.zip.value
        }]
    }
    return model;
  }

  editRowEmergencyContact(emergencyContact) {
    this.isEditModeEmergencyContact = true;
    this.addEmergencyContact = true;
    this.frmEmergencyContact.controls.emergencyContactDetailId.setValue(emergencyContact.EmergencyContactDetailId);
    this.frmEmergencyContact.controls.firstName.setValue(emergencyContact.FirstName);
    this.frmEmergencyContact.controls.lastName.setValue(emergencyContact.LastName);
    this.frmEmergencyContact.controls.middleName.setValue(emergencyContact.MiddleName);
    if (emergencyContact.Mobile !== null && emergencyContact.Mobile !== "") {
      let mobileNumber = this.convertMobileNumber(emergencyContact.Mobile);
      this.frmEmergencyContact.controls.mobile.setValue(mobileNumber);
    }
    else {
      this.frmEmergencyContact.controls.mobile.setValue("");
    }
    this.frmEmergencyContact.controls.email.setValue(emergencyContact.Email);
    this.frmEmergencyContact.controls.addressLine1.setValue(emergencyContact.AddressLine1);
    this.frmEmergencyContact.controls.addressLine2.setValue(emergencyContact.AddressLine2);
    this.frmEmergencyContact.controls.state.setValue(emergencyContact.State);
    this.frmEmergencyContact.controls.city.setValue(emergencyContact.City);
    this.frmEmergencyContact.controls.workPhone.setValue(emergencyContact.WorkPhone);
    this.frmEmergencyContact.controls.homePhone.setValue(emergencyContact.HomePhone);
    this.frmEmergencyContact.controls.zip.setValue(emergencyContact.Zip);
  }

  resetFormEmergencyContact() {
    this.frmEmergencyContact.reset();
    this.formDirectiveForEmergencyContact.resetForm();
    this.isSubmitBtnDisabledForEmergencyContact = false;
    this.isEditModeEmergencyContact = false;
  }

  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    // var x = ctrlValue.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
    // return !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }

  toGoBack() {
    this._location.back();
  }

}