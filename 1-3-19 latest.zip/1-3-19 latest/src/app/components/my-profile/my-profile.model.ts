export class BasicDetailsModel {
    propertyAddress: string;
    mailingAddress: string;
    emailAddress: string;
    dateOfBirth: string;
    mobileNumber: string;
    homePhoneNumber: string;
    workPhoneNumber: string;
    gender: string;
}

export class DisplayGender {
    public static GenderList = [
        { value: "Female", text: "Female" },
        { value: "Male", text: "Male" }
    ]
}

// export class UnitPetsModel
// {
//     userId:string;
//     UnitPetModel :UnitPetModel;
// }

export class UnitPetsModel {
    unitId: string;
    PetDetails: PetDetailModel[];
}
export class PetDetailModel {
    userPetDetailId: string;
    petName: string;
    petTypeName: string;
    breedName: string;
}

export class UserTenantInfoModel {
    UserTenant: UserTenantModel;
    UnitTenants: UnitTenantsModel;
}
export class UnitTenantsModel {
    UnitId: string;
    TenantDetails: TenantDetailsModel[];
}
export class TenantDetailsModel {
    UserTenantDetailsId: string;
    UserProfileUnitRoleId: string;
    UserLease: UserLeaseModel;

}
export class UserLeaseModel {
    UserLeaseDetailId: string;
    UserProfileUnitRoleId: string;
    LeaseStartDate: string;
    LeaseEndDate: string;
    UserProfileId: string;
}
export class UserTenantModel {
    UserProfileId:string;
    FirstName: string;
    MiddleName: string;
    LastName: string;
    LeaseStartDate: string;
    LeaseEndDate: string;
    Mobile: string;
    Email: string;
    UnitId: string;
    UserTenantDetailsId: string;
    AccountNumber: string;
    UnitNumber: string;
    UnitRoleId: string;
    UserProfielUnitRoleId: string;

}


export class UnitVehiclesModel {
    unitId: string;
    VehicleDetails: VehicleDetailModel[];
}
export class VehicleDetailModel {
    userVehicleDetailId: string;
    makeModel: string;
    year: string;
    licensePlate: string;
    state: string;
}

export class EmergencyContactModel {
    unitId: string;
    EmergencyContacts: EmergencyContactsModel[];
}
export class EmergencyContactsModel {
    firstName: string;
    lastName: string;
    middleName: string;
    email: string;
    city: string;
    state: string;
    zip: string;
    mobile: string;
    homePhone: string;
    workPhone: string;
    addressLine1: string;
    addressLine2: string;
    emergencyContactDetailId: string;
}


export class UpdateUserProfileModel {
    UserProfileUnitRoleId:string;
    MemberStartDate: string;
    MemberEndDate: string;
    UserProfile: UserProfileModel;
    Address: AddressModel;
    AssociationUnit: AssociationUnitModel;
}
export class UserProfileModel {
    id: string;
    FirstName: string;
    MiddleName: string;
    LastName: string;
    Gender: string;
    EmailAddress: string;
    Mobile: string;
    HomePhone: string;
    WorkPhone1: string;
    BirthDate: string;
}

export class AddressModel {
    UseraddressId: string;
    Address1: string;
    Address2: string;
    City: string;
    County: string;
    State: string;
    ZIP: string;
    IsPrimary: boolean;
    UserAddressType: string;
    Remarks: string;
}

export class AssociationUnitModel {
    id: string;
    AssociationId: string;
    AssociationUnitAddress1: string;
    AssociationUnitAddress2: string;
    AssociationUnitCity: string;
    AssociationUnitCounty: string;
    AssociationUnitState: string;
    AssociationUnitZip: string;
}


export enum AddressTypeEnum {
    Mailing,
    Alternate,
    Temporary,
    Business
}