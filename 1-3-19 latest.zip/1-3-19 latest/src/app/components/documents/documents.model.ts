export class DocumentModel{
    Domain :string;
    AssociationId:string;
    TypeOfDocument
    RequestDocuments :RequestDocumentsModel[];
}
export class RequestDocumentsModel{
    mediaType:string;
    name:string;
    documentId:string;
    inputStream: string;
    isPublished:boolean ;
    publishDate:string;
    documentTitle:string;
    documentCategoryId:string;
    associationDocumentCategoryId:string;
    documentCategoryName:string;
    CreatedByUserId:string;
    CreatedByUserName:string;
    AccessType: string;
    AssociationName:string;
}