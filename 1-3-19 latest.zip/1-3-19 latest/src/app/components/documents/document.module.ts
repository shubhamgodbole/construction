import { NgModule } from '@angular/core';
import { DocumentRoutingModule } from './document-routing.module';
import { DocumentsComponent } from './documents.component';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatAutocompleteModule, MatPaginatorModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatCheckboxModule, MatTooltipModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';


@NgModule({
  imports: [
    DocumentRoutingModule,
    SafeModule,
    NoDataFoundModule,
    CommonModule,
    MatInputModule,
    MatSelectModule,
    MatPaginatorModule,
    ReactiveFormsModule,
    FormsModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    HideIfUnauthorizedModule
  ],
  declarations: [DocumentsComponent]
})
export class DocumentModule { }
