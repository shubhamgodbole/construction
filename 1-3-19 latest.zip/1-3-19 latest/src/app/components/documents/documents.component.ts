import { Component, OnInit, ViewChild } from '@angular/core';
import { DocumentsApiService } from 'src/app/services/documents-api.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { DocumentModel } from './documents.model';
import { AppConfig } from 'src/app/app.config';
import { MatDialogRef, MatDialog, MatSnackBar, MatPaginator } from '@angular/material';
import { UserData, EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { TypeOfDocument, RoleEnum, NoDataFoundCaseFeatureName, ImageNameEnums, FeatureName, SourceType, TriggerType, AudienceType, DocumentFeatureName, DownloadfeatureName, MasterPaginationEnum, Pagination, FeaturePermissions, AccessTypeEnum } from 'src/app/shared/Enums/commonEnums';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Router, NavigationEnd } from '@angular/router';
import { DisplayAccessType, CommonConstant } from 'src/app/shared/common/constant.model';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService } from 'src/app/services/common.service';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit {
  // ... your class variables here
  // navigationSubscription;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;

  //Preview the document
  fileURL: any;
  documentDetails: any;
  isDocumentDetails: boolean = false;

  //Confirm Dialog
  //For Delete
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  notificationService: NotificationService;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  isApiResponseCome: boolean = false;
  associationId: string;
  associationName: string;
  //selectedAssociationId:string;
  //userAssociationId:string;
  canRead = "true";
  userId: string;
  role: string = "";
  domain: string;
  userName: string;
  isEditMode: boolean = false;
  frmCreateDocument: FormGroup;
  isTableList: boolean = true;
  adddocument = false;
  documentsList: any;
  documentCategoryDdl: any;
  accessTypeDdl: any;
  userData: UserData;
  resData: any;
  resDataCreate: any;
  fileFullName: any;
  url: string = "";
  pdfImageUrl: string;
  fileName: string;
  resDoumentData: any;
  pdfvalidation: boolean = false;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  featureName: any;
  featureId: any;

  //For Filter data
  selectedDocumentCategory: string = "All";
  filterDocumentList: any;
  isSubmitBtnDisabled: boolean = false;
  pdfShow: boolean = false;
  // base64textString = [];
  inputStreamString = "";
  isMailPermision: boolean = false;
  isStatusShow: boolean = false;

  @ViewChild('formDirective') formDirective: FormGroupDirective;

  @ViewChild('displayfrom') displayfrom;
  open() {
    this.displayfrom.open();
  }

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;

  /*For server side paginaion */
  allCount: any;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;

  constructor(private readonly formBuilder: FormBuilder,
    private _matDialog: MatDialog,
    private emailNotification: EmailNotificationService,
    private readonly snb: MatSnackBar,
    public commonService: CommonService,
    private progressbarService: ProgeressBarService,
    private _router: Router,
    private documentsApiService: DocumentsApiService,
    public sanitizer: DomSanitizer,
    private readonly appConfig: AppConfig) {
    this.notificationService = new NotificationService(snb);

    // this.navigationSubscription = this._router.events.subscribe((e: any) => {
    //   // If it is a NavigationEnd event re-initalise the component
    //   if (e instanceof NavigationEnd) {
    //     this.initialiseInvites();
    //   }
    // });

    this.setMasterOfPagination();
    setTimeout(() => {
      this.setData()
    }, 1000);

  }

  setData() {
    this.pdfImageUrl = "../../../../assets/images/" + this.imageNameEnums.pdfName;
    this.accessTypeDdl = DisplayAccessType.accessTypeList;
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData !== null) {
      this.associationId = this.userData.UserAssociations[0].AssociationId;
      this.associationName = this.userData.UserAssociations[0].Name;
      this.userId = this.userData.UserProfileId;
      this.userName = this.userData.UserName;
      this.domain = this.userData.UserAssociations[0].Domain;
      this.role = this.userData.Role;
      this.userData.Role !== RoleEnum.Member ? this.isStatusShow = true : this.isStatusShow = false;

      this.userData.Role === RoleEnum.Member ? this.isMailPermision = false : this.isMailPermision = true;
      if (this.role === RoleEnum.PropertyManager) {
        this._router.navigate([AppRouteUrl.mainDocumentsPMRouteUrl]);
      }
      this.userData.FeatureMenuPermissions.forEach(
        (feature) => {
          if (feature.Name === FeatureName.Document) {
            // feature.CanDelete ? this.isDeletePermision = true : this.isDeletePermision = false
            // feature.CanCreate ? this.isCreatePermision = true : this.isCreatePermision = false
            this.featureName = feature.Name
            this.featureId = feature.FeatureId
          }
        });

      this.getData();
    }

  }
  // initialiseInvites() {
  //   this.setMasterOfPagination();
  //   this.getData();
  // }


  ngOnInit() {
    this.createForm();
  }
  createNotificationModel(featureId, requestId, triggerType, audienceType) {
    var notificationModel = new Array<EmailNotificationModel>();
    notificationModel = [{
      FeatureId: featureId,
      FeatureName: FeatureName.Document,
      CreatedBy: this.userId,
      SourceType: SourceType.Web,
      TriggerType: triggerType,
      PMCompanyAssociationMappingId: this.userData.UserAssociations[0].PMCompanyAssociationMappingId,
      AudienceType: audienceType,
      Url: "",
      RequestId: requestId,
      CustomAttribute: {
        Request: FeatureName.Document,
        RequestSubType: audienceType
      }
    }];
    return notificationModel;
  }

  sendNotification(featureId, requestId, triggerType, audienceType) {
    //let emailNotificationModel = this.createNotificationModel("",response.RequestId);
    let emailNotificationModel = this.createNotificationModel(featureId, requestId, triggerType, audienceType);
    this.emailNotification.sendNotification(emailNotificationModel).subscribe(
      (emailresponse: any) => {
        if (emailresponse.Success) {
          //this.notificationService.showNotification('Notification Send SuccessFully');
        }
      }
    );
  }
  displayList(d) {
    if (d === "tableView") {
      this.isTableList = true;
    } else {
      this.isTableList = false;
    }
  }

  //For Download document
  downloadDocument(documentDetails) {
    this.commonService.getDownloadDocumentUrl(documentDetails.Domain, documentDetails.FilePath, DocumentFeatureName.Documents,
      DownloadfeatureName.Download).subscribe(res => {
        this.resDoumentData = res;
        if (this.resDoumentData.Success === true) {
          this.commonService.downloadFile(this.resDoumentData.DocumentPath).subscribe(
            (response) => {
              console.log(response);
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (documentDetails.FilePath)
                downloadLink.setAttribute('download', documentDetails.FilePath);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          ),
            (error) => {
              console.log("error doc", error);
            }
        }
        else if (this.resDoumentData.Success === false) {
          this.notificationService.showNotification("Can not download it");
        }
      });
  }

  //For Preview document
  previewDocument(docDetails) {
    this.isDocumentDetails = true;
    this.documentDetails = docDetails;
    this.isShowNextAndPreviewsButton();
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, docDetails.FilePath, DocumentFeatureName.Documents,
      DownloadfeatureName.Download).subscribe(res => {
        this.resDoumentData = res;
        if (this.resDoumentData.Success === true) {
          this.documentsApiService._downloadPDF(this.resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
        else if (this.resDoumentData.Success === false) {
          this.notificationService.showNotification("Preview not Found");
        }
      });
  }

  onUploadChange(evt: any) {
    const file = evt.target.files[0];
    if (file !== undefined) {
      this.fileFullName = file;
      this.fileName = this.fileFullName.name;
      const reader = new FileReader();
      reader.onload = this.handleReaderLoaded.bind(this);
      reader.readAsBinaryString(file);
    }
    else {
      this.fileName = "";
      this.url = "";
      this.pdfvalidation = true;
    }
  }
  removeFile() {
    this.url = "";
    this.fileName = "";
    this.pdfvalidation = true;
  }

  handleReaderLoaded(e) {
    // this.base64textString = [];
    // this.base64textString.push('data:image/png;base64,' + btoa(e.target.result));
    this.inputStreamString = 'data:image/png;base64,' + btoa(e.target.result);
    if (this.fileFullName.name.toLowerCase().substring(this.fileFullName.name.indexOf(".")) === ".pdf") {
      this.url = this.pdfImageUrl;
      this.pdfvalidation = false;
    }
    else {
      this.url = "";
      this.fileName = "";
      this.pdfvalidation = true;
    }
  }

  onSubmit(formDirective: FormGroupDirective) {
    if (this.isEditMode) {
      if (this.fileFullName === undefined || this.fileFullName === null || this.fileFullName === "") {
        this.pdfvalidation = true;
        return;
      }
    } else {
      if (this.fileFullName === undefined || this.fileFullName === null || this.fileFullName === ""
        || this.inputStreamString === undefined || this.inputStreamString === null || this.inputStreamString === "") {
        this.pdfvalidation = true;
        return;
      }
    }
    if (this.pdfvalidation === false) {
      if (this.frmCreateDocument.valid) {
        this.isSubmitBtnDisabled = true;
        let model = this.createFormModel();
        if (this.isEditMode) {
          this.editData(model, formDirective);
        } else {
          this.saveData(model, formDirective);
        }
      }
    }
  }

  editData(model: any, formDirective: FormGroupDirective) {
    this.documentsApiService.editDocument(model).subscribe(res => {
      this.resDataCreate = res;
      this.isSubmitBtnDisabled = false;
      if (this.resDataCreate.Success === true) {
        this.notificationService.showNotification("Document updated successfully");
        this.selectedDocumentCategory = "All";
        this.adddocument = false;
        this.getData();
        this.resetForm();
        this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Update, AudienceType.BoardMember);
      }
      else if (this.resDataCreate.Success === false) {
        this.notificationService.showNotification("Not Save");
      }
    });
  }

  saveData(model: any, formDirective: FormGroupDirective) {    
    this.documentsApiService.createDocument(model).subscribe(res => {
      this.resDataCreate = res;      
      this.isSubmitBtnDisabled = false;
      if (this.resDataCreate.Success === true) {
        console.log("Documnet", this.resDataCreate);
        this.notificationService.showNotification("Document saved successfully");
        this.selectedDocumentCategory = "All";
        this.adddocument = false;
        this.getData();
        this.resetForm();
        this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Create, AudienceType.BoardMember);

        //        this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Upload, AudienceType.BoardMember);
        // if (model.RequestDocuments[0].AccessType === AccessTypeEnum.Private) {
        //   this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Create, AudienceType.BoardMember);
        // } else {
        //   this.sendNotification(this.featureId, this.resDataCreate.RequestId, TriggerType.Publish, AudienceType.BoardMember);
        // }
      }
      else if (this.resDataCreate.Success === false) {
        this.notificationService.showNotification("Document Not Updated");
      }
    });
  }
  createFormModel() {
    let isPublished;
    let currentDate = new Date();
    const publishDate = new Date(this.frmCreateDocument.controls.publishDate.value);
    if (publishDate <= currentDate) {
      isPublished = true;
    } else {
      isPublished = false;
    }
    let inputStream = "";
    let name = "";
    let mediaType = "";
    if (this.inputStreamString !== "") {
      inputStream = this.inputStreamString;//this.base64textString[0];
      name = this.fileFullName.name.toLowerCase();
      mediaType = this.fileFullName.name.toLowerCase().substring(this.fileFullName.name.indexOf("."));
    }



    const model: DocumentModel = {
      Domain: this.domain,
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.AssociationDocuments,
      RequestDocuments:
        [{
          documentId: this.frmCreateDocument.controls.documentId.value,
          documentTitle: this.frmCreateDocument.controls.documentTitle.value,
          documentCategoryId: this.frmCreateDocument.controls.documentCategoryId.value.DocumentCategoryId,
          associationDocumentCategoryId: this.frmCreateDocument.controls.documentCategoryId.value.id,
          publishDate: publishDate.toUTCString(),
          isPublished: isPublished,
          documentCategoryName: this.frmCreateDocument.controls.documentCategoryId.value.DocumentCategory,
          inputStream: inputStream,
          name: name,
          mediaType: mediaType,
          CreatedByUserId: this.userId,
          CreatedByUserName: this.userName,
          AccessType: this.frmCreateDocument.controls.accessType.value,
          AssociationName: this.associationName,
        }]
    }
    return model;
  }


  createForm() {
    this.frmCreateDocument = this.formBuilder.group({
      documentId: [''],
      documentTitle: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      documentCategoryId: ['', Validators.required],
      publishDate: ['', Validators.required],
      accessType: ['', Validators.required],
      attachment: ['']
    });
  }

  getData() {
    this.progressbarService.show();
    let resDoumentCategory = this.selectedDocumentCategory === "All" ? "" : this.selectedDocumentCategory;
    this.documentsApiService.getDocument(this.associationId, this.domain, TypeOfDocument.AssociationDocuments, resDoumentCategory, this.role,
      this.pageSkip, this.pageTake).subscribe(res => {
        this.resData = res;
        this.getDocumentCategoryDdl();
        this.progressbarService.hide();
        this.isApiResponseCome = true;
        if (this.resData.Success === true) {
          console.log("this.filterDocumentList12312312", this.resData.DocumentDetails.Documents);
          // if (this.role !== "" || this.role !== null && this.role !== undefined) {
          //   if (this.role === RoleEnum.Member) {
          //     let documents = this.resData.DocumentDetails.Documents;
          //     this.documentsList = documents.filter(x => x.IsPublished && x.AccessType !== 'Private');
          //     this.filterDocumentList = documents.filter(x => x.IsPublished && x.AccessType !== 'Private');
          //   } else {
          //     this.documentsList = this.resData.DocumentDetails.Documents;
          //     this.filterDocumentList = this.resData.DocumentDetails.Documents;
          //   }
          // } else {
          //   this.documentsList = this.resData.DocumentDetails.Documents;
          //   this.filterDocumentList = this.resData.DocumentDetails.Documents;
          // }
          let documents = this.resData.DocumentDetails.Documents;
          this.documentsList = documents;
          this.filterDocumentList = documents;

          if (this.documentsList !== null) {
            //For Pagination
            this.allCount = this.resData.DocumentCount;
            console.log("this.filterDocumentList", this.filterDocumentList);

            this.setPaginationData(this.filterDocumentList);
            this.SetDetailsOfNextPreviousOnDetailsPage();
          }
        } else {
          console.log("api errors");
        }
      },
        (err) => {
          console.log(err);
        }
      )
  }

  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('DocList');
    var temp: any = [];
    this.documentsList.forEach(element => {
      temp.push({
        filePath: element.FilePath,
        documentId: element.id
      });
    });
    localStorage.setItem('DocList', JSON.stringify(temp));
  }

  filterGetData() {
    // let filterDocument = this.filterDocumentList;
    // if (this.selectedDocumentCategory === "All") {
    //   this.documentsList = filterDocument;
    // } else {
    //   this.documentsList = filterDocument.filter(x => x.DocumentCategoryName === this.selectedDocumentCategory);
    // }
    //For Pagination
    this.setPaginationVariables();
    this.getData();
    //this.setPaginationData(this.documentsList);
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }

  //For Pagination
  setPaginationData(documentLists) {
    this.TotalRecord = this.allCount;
    this.FilterArray = documentLists;
    // var pageStartIndex = (this.PageIndex * this.pageTake) + 1;
    // var pageEndIndex = (this.PageIndex * this.pageTake) + this.pageTake;
    // this.FilterArray = documentLists.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageTake = clickObj.pageSize;
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);

    this.getData();

    // var pageStartIndex = (clickObj.pageIndex * clickObj.pageSize) + 1;
    // var pageEndIndex = (clickObj.pageIndex * clickObj.pageSize) + clickObj.pageSize;
    // this.FilterArray = this.documentsList.slice(pageStartIndex - 1, pageEndIndex);
    if (this.isTableList === true) {
      var elmnt: any = document.getElementById("contentTable");
      if (elmnt !== null) {
        elmnt.scrollTo(0, 0);
      }
    } else {
      var elmnt: any = document.getElementById("contentCard");
      if (elmnt !== null) {
        elmnt.scrollTo(0, 0);
      }
    }
  }


  getDocumentCategoryDdl() {
    this.documentsApiService.getDocumentCategoryDdl(this.associationId, this.canRead, this.userId).subscribe(res => {
      this.resData = res;
      if (this.resData.Success === true) {
        this.documentCategoryDdl = [];
        this.documentCategoryDdl = this.resData.DocumentCategories;
      }
      else {
        console.log("category not found");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  editRow(document: any) {
    this.isEditMode = true;
    this.adddocument = true;

    if (document.FilePath !== "" && document.FilePath !== null) {
      this.url = this.pdfImageUrl;
      this.fileName = document.DocumentName;
      this.pdfvalidation = false;
      this.fileFullName = document.FilePath;
    }
    this.frmCreateDocument.controls.documentId.setValue(document.id);
    this.frmCreateDocument.controls.accessType.setValue(document.AccessType);
    this.frmCreateDocument.controls.documentTitle.setValue(document.DocumentTitle);
    this.frmCreateDocument.controls.publishDate.setValue(document.PublishDate);
    let selectedDocumentCategory = this.documentCategoryDdl.find(x => x.id === document.DocumentCategoryId)
    this.frmCreateDocument.controls.documentCategoryId.setValue(selectedDocumentCategory);
  }

  adddocumentToggle() {

    if (this.adddocument)
      this.adddocument = false;
    else
      this.adddocument = true;
    this.resetForm();
  }


  resetForm() {
    this.url = "";
    this.pdfvalidation = false;
    this.frmCreateDocument.reset();
    this.formDirective.resetForm();
    this.fileFullName = "";
    this.fileName = "";
    this.isEditMode = false;
    this.isSubmitBtnDisabled = false;
    this.inputStreamString = "";
    //this.selectedDocumentCategory = "All";
  }

  deleteDocument(documentId) {
    this.progressbarService.show();
    // if (confirm("Are you sure to delete ?")) {
    this.documentsApiService.deleteDocument(documentId).subscribe(res => {
      this.progressbarService.hide();
      this.resData = res;
      if (this.resData.Success === true) {
        this.notificationService.showNotification("Document deleted successfully");
        this.selectedDocumentCategory = "All";
        this.getData();
        this.sendNotification(this.featureId, documentId, TriggerType.Delete, AudienceType.BoardMember);
      }

    },
      (err) => {
        console.log(err);
      })
    //  }
  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = valueObject.DocumentTitle;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteDocument(valueObject.id);
      }
    });
  }

  PreviousDocument() {
    var current = this.documentDetails;
    var btAr = JSON.parse(localStorage.getItem('DocList'));
    this.totalPages = btAr.length - 1;
    var el = btAr.find(a => { return a.documentId === current.id });
    var currentEl = btAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevFile = btAr[currentEl - 1].documentId;
      this.documentsList.forEach((element: any) => {
        if (element.id === prevFile) {
          this.documentDetails = element;
          this.previewDocument(this.documentDetails);
        }
      });
    }
  }

  NextDocument() {
    var current = this.documentDetails;
    var btAr = JSON.parse(localStorage.getItem('DocList'));
    this.totalPages = btAr.length - 1;
    var el = btAr.find(a => { return a.documentId === current.id });
    var currentEl = btAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < btAr.length) {
      let nextFile = btAr[currentEl + 1].documentId;
      this.documentsList.forEach((element: any) => {
        if (element.id === nextFile) {
          this.documentDetails = element;
          this.previewDocument(this.documentDetails);
        }
      });
    }
  }


  isShowNextAndPreviewsButton() {
    let BTlocalStorageData = JSON.parse(localStorage.getItem('DocList'));
    if (BTlocalStorageData === null || BTlocalStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.documentDetails;
      var btAr = JSON.parse(localStorage.getItem('DocList'));
      this.totalPages = btAr.length - 1;
      var el = btAr.find(a => { return a.documentId === current.id });
      var currentEl = btAr.indexOf(el);
      this.currentPage = currentEl;
    }
  }

  // ngOnDestroy() {
  //   // avoid memory leaks here by cleaning up after ourselves. If we  
  //   // don't then we will continue to run our initialiseInvites()   
  //   // method on every navigationEnd event.
  //   if (this.navigationSubscription) {
  //     this.navigationSubscription.unsubscribe();
  //   }
  // }

}


