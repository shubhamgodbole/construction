import { Component, OnInit } from '@angular/core';
import { AppRouteUrl } from 'src/app/shared/app-module-route';

@Component({
  selector: 'app-recurrence-payment',
  templateUrl: './recurrence-payment.component.html',
  styleUrls: ['./recurrence-payment.component.scss']
})
export class RecurrencePaymentComponent implements OnInit {
  managePaymentUrl =  AppRouteUrl.mainManagePaymentRouteUrl;
  isDisplayMenu: boolean = false;
  disableSelect: boolean;
  hide: boolean = false;
  isLinear
  constructor() { }

  ngOnInit() {
  }
  menuToggle() {
    console.log('fvgg ');
    if(this.isDisplayMenu) {
      this.isDisplayMenu = false;
    } else {
      this.isDisplayMenu = true;
    }
  }

}
