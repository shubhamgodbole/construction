import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecurrencePaymentComponent } from './recurrence-payment.component';

describe('RecurrencePaymentComponent', () => {
  let component: RecurrencePaymentComponent;
  let fixture: ComponentFixture<RecurrencePaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecurrencePaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecurrencePaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
