import { Component, OnInit, ViewChild } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';

import { MatRadioChange, MatSnackBar, MatStepper } from '@angular/material';
import { paymentCardTypeEnum, PaymentTypeEnum, StandardEntryCodeEnum } from 'src/app/shared/Enums/commonEnums';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CreatePaymentTransactionModel, DisplayLoadMore, ManagePaymentModel } from '../manage-payment.model';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { Router } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';

@Component({
  selector: 'app-onetime-payment',
  templateUrl: './onetime-payment.component.html',
  styleUrls: ['./onetime-payment.component.scss']
})
export class OnetimePaymentComponent implements OnInit {

  @ViewChild('stepper') stepper: MatStepper;

  hide: boolean;
  disableSelect
  isLinear: boolean = true;
  managePaymentUrl = AppRouteUrl.mainManagePaymentRouteUrl;

  notificationService: NotificationService;

  /*page variables*/
  paymentType = PaymentTypeEnum;
  accountNumber: string = "";
  amount: string = ""; //= "$1532.56";
  cashDiscount = "$2.50"


  /*Is payment method set up or not */
  bankPaymentSetupList: any;
  cardPaymentSetupList: any;
  paymentCardTypeEnum = paymentCardTypeEnum;
  userData: UserData;
  //assocaitionUnitId: string;
  userProfileId: string;
  userName: string;
  companyCode: any;


  /*Form setup*/
  frmAccountDetail: FormGroup;
  frmPaymentMethod: FormGroup;
  selectedNumber: string = "";

  addNewPaymentMethodSetup: boolean = false;
  managePaymentModel: ManagePaymentModel;

  constructor(private paymentsApiService: PaymentsApiService,
    private progressbarService: ProgeressBarService,
    private readonly snb: MatSnackBar,
    private readonly formBuilder: FormBuilder,
    private _router: Router,
    private readonly appConfig: AppConfig) {
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    this.userName = this.userData.UserName;
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    //this.assocaitionUnitId = this.userData.UserUnits[0].UnitId;
    this.userProfileId = this.userData.UserProfileId;
    this.createForm();

  }

  ngOnInit() {
    this.paymentsApiService.accountNumberSubject.subscribe(res => {
      console.log('from accountNumberSubject ', res);
      this.accountNumber = res;
      this.frmAccountDetail.controls.accountNumber.setValue(this.accountNumber);
    });

    this.paymentsApiService.managePaymentModelSubject.subscribe(res => {
      console.log('from managePaymentModelSubject ', res);
      this.managePaymentModel = res;
      this.amount = this.managePaymentModel.CurrentBalance;
    });
    this.checkPaymentMethodSetup();
  }

  createForm() {
    this.frmAccountDetail = this.formBuilder.group({
      teamsAndConditions: ['', [Validators.required]],
      accountNumber: ['', [Validators.required]],
      amount: ['', [Validators.required]],
    });

    this.frmPaymentMethod = this.formBuilder.group({
      paymentType: ['', [Validators.required]],
      paymentNumber: ['', [Validators.required]],
    });
  }

  checkPaymentMethodSetup() {
    let resData;
    //let userProfileId = "2a8c1774-865d-e811-80d8-00155d000c26";
    let userProfileId = this.userProfileId;
    this.progressbarService.show();
    this.paymentsApiService.getPaymentMethod(userProfileId).subscribe(res => {
      this.progressbarService.hide();
      resData = res;
      console.log("respaymentmethod", res);
      if (resData.Success === true) {
        this.bankPaymentSetupList = resData.UserPaymentMethodProcess.PaymentTypes.BankDetails;
        this.cardPaymentSetupList = resData.UserPaymentMethodProcess.PaymentTypes.CreditCardDetails;
        console.log(this.cardPaymentSetupList);
        console.log(this.bankPaymentSetupList);
      }
      else if (resData.Success === false) {
        this.addNewPaymentMethodSetup = true;
        console.log("this.cardPaymentSetupList", this.cardPaymentSetupList);
        console.log("this.bankPaymentSetupList", this.bankPaymentSetupList);
      }
    });
  }

  radioChange(paymentNumber: string, type: string) {
    this.selectedNumber = paymentNumber;
    if (type === this.paymentType.Card) {
      this.frmPaymentMethod.controls.paymentType.setValue(this.paymentType.Card);
    } else {
      this.frmPaymentMethod.controls.paymentType.setValue(this.paymentType.Bank);
    }
  }

  changecheckBox() {
    if (this.frmAccountDetail.value.teamsAndConditions === false) {
      this.frmAccountDetail.controls.teamsAndConditions.setValue('');
    }
  }

  onSubmitOnetimePayment() {
    let model: CreatePaymentTransactionModel = {
      userProfileId: this.userProfileId,
      amount: this.frmPaymentMethod.controls.amount.value,
      type: this.frmPaymentMethod.controls.paymentType.value,
      number: this.frmPaymentMethod.controls.paymentNumber.value,
      standEntryCode: StandardEntryCodeEnum.WEB
    }
    let resData;
    this.progressbarService.show();
    this.paymentsApiService.createPaymentPostTransaction(model).subscribe(res => {
      this.progressbarService.hide();
      resData = res;
      console.log("result", res);
      if (resData.Success === true) {
        this.notificationService.showNotification("Payment done successfully.");
        this._router.navigate([AppRouteUrl.mainManagePaymentRouteUrl]);
      }
      else if (resData.Success === false) {
        this.notificationService.showNotification("Payment not done");
      }
    });
  }

  /*:Check Current Date*/
  getToday(): string {
    return new Date().toISOString().split('T')[0]
  }

  //Add New Payment Methods
  addNewPaymentMethod() {
    if (this.addNewPaymentMethodSetup) {
      this.addNewPaymentMethodSetup = false;
    } else {
      this.addNewPaymentMethodSetup = true;
    }
  }

  nextBtnClick(clickObj: any): void {
    this.frmPaymentMethod.controls.paymentType.setValue(clickObj.paymentType);
    this.frmPaymentMethod.controls.paymentNumber.setValue(clickObj.paymentNumber);
    this.selectedNumber = clickObj.paymentNumber;
    this.stepper.next();
  }

  previousBtnClick(): void {
    this.stepper.reset();
  }

  confirmPaymentBack() {
    this.addNewPaymentMethodSetup = false;
    this.checkPaymentMethodSetup();
  }
  
  convertToDecimal() {
    var currentAmount = this.frmAccountDetail.controls.amount.value;
    var newAmount = parseFloat(currentAmount).toFixed(2);
    this.frmAccountDetail.controls.amount.setValue(newAmount);
  }

  /**For Get Amount */
  // currentBalance: string = "";
  // nextRecordCount: string = DisplayLoadMore.nextRecordCount;

  // getData() {
  //   let paymentReport = {
  //     "Count": DisplayLoadMore.count,
  //     "LastCount": DisplayLoadMore.lastCount,
  //     "AccountNum": this.accountNumber,
  //     "NextRecordCount": this.nextRecordCount,
  //     "Association": this.companyCode
  //   };
  //   let resData;
  //   this.progressbarService.show();
  //   this.paymentsApiService.getPaymentSheet(paymentReport).subscribe(res => {
  //     this.progressbarService.hide();
  //     console.log("res", res);
  //     resData = res;
  //     if (resData.PaymentReport !== null && resData.PaymentReport !== undefined) {
  //       if (resData.PaymentReport.PaymentHeaderList !== null && resData.PaymentReport.PaymentHeaderList !== undefined) {
  //         this.currentBalance = resData.PaymentReport.PaymentHeaderList[0].PaymentDetailsList[0].PaymentReportDetails.BALANCEMST;
  //         this.amount = resData.PaymentReport.PaymentHeaderList[0].PaymentDetailsList[0].PaymentReportDetails.BALANCEMST;
  //         this.frmAccountDetail.controls.amount.setValue(this.amount);
  //         this.paymentsApiService.currentBalanceSubject.next(this.currentBalance);
  //         console.log("this.currentBalance", this.currentBalance);
  //       } else {
  //         this.currentBalance = "";
  //         this.amount = "";
  //         this.frmAccountDetail.controls.amount.setValue('');
  //         this.paymentsApiService.currentBalanceSubject.next(this.currentBalance);
  //       }
  //     }
  //     else {
  //       this.currentBalance = "";
  //       this.amount = "";
  //       this.frmAccountDetail.controls.amount.setValue('');
  //       this.paymentsApiService.currentBalanceSubject.next(this.currentBalance);
  //     }
  //   },
  //     (err) => {
  //       console.log(err);
  //     }
  //   )
  // }


}
