export class UserPaymentMethodProcess {
    AssocaitionUnitId: string;
    UserProfileId: string;
    PaymentTypes: PaymentTypesModel;
}
export class PaymentTypesModel {
    CreditCardDetails: CreditCardDetailsModel[];
}

export class CreditCardDetailsModel {
    CardType: string;
    CardNumber: string;
    ExpiryMonth: string;
    ExpiryYear: string;
    Cvv: string;
    IsDefault: boolean;
    FirstName: string;
    LastName: string;
    Address1: string;
    Address2: string;
    City: string;
    State: string;
    Zip: string;
    EmailAddress: string;
}

export class UserBankPaymentMethodProcess {
    AssocaitionUnitId: string;
    UserProfileId: string;
    PaymentTypes: PaymentTypesBankModel;
}
export class PaymentTypesBankModel {
    BankDetails: BankDetailsModel[];
}

export class BankDetailsModel {
    AccountType: string;
    AccountNumber: string;
    AccountHolderName: string;
    RoutingNumber: string;
    BankName: string;
    IsDefault: boolean;
    FirstName: string;
    LastName: string;
    Address1: string;
    Address2: string;
    City: string;
    State: string;
    Zip: string;
    EmailAddress: string;
}



export class CreatePaymentTransactionModel {
    userProfileId: string;
    amount: string;
    type: string;
    number: string;
    standEntryCode: string;
}

const nextRecordCount = '10';
const lastCount = '0';
const count = '0';

export class DisplayLoadMore {
    public static nextRecordCount: string = nextRecordCount;
    public static lastCount: string = lastCount;
    public static count: string = count;
}


export class ManagePaymentModel {
    AccountNumber: string;
    CurrentBalance: string;
    NumberOfPaymentMethod: string;
    CurrentPaymentMethod: string;
    PaymentStatus: string;
}