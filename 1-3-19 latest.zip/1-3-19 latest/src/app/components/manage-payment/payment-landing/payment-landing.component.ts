import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { AppConfig } from 'src/app/app.config';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Router } from '@angular/router';
import { NoDataFoundCaseFeatureName } from 'src/app/shared/Enums/commonEnums';
import { DisplayLoadMore, ManagePaymentModel } from '../manage-payment.model';

@Component({
  selector: 'app-payment-landing',
  templateUrl: './payment-landing.component.html',
  styleUrls: ['./payment-landing.component.scss']
})
export class PaymentLandingComponent implements OnInit {
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  //locatstroge data 
  userData: any;
  companyCode: any;

  /**Payment sheet list variables */
  paymentSheetList: any;
  accountNumber: string = "";
  currentBalance: string = "";
  nextRecordCount: string = DisplayLoadMore.nextRecordCount;

  isApiResponceCome = false;
  constructor(private paymentsApiService: PaymentsApiService,
    private progressbarService: ProgeressBarService,
    private _router: Router,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
  }

  ngOnInit() {
    this.paymentsApiService.accountNumberSubject.subscribe(res => {
      console.log('from accountNumberSubject ', res);
      this.accountNumber = res;
      this.getData();
    });
  }

  getData() {
    let paymentReport = {
      "Count": DisplayLoadMore.count,
      "LastCount": DisplayLoadMore.lastCount,
      "AccountNum": this.accountNumber,
      "NextRecordCount": this.nextRecordCount,
      "Association": this.companyCode
    };
    let resData;
    this.progressbarService.show();
    this.paymentsApiService.getPaymentSheet(paymentReport).subscribe(res => {
      this.progressbarService.hide();
      this.isApiResponceCome = true;
      console.log("res", res);
      resData = res;
      if (resData.PaymentReport !== null && resData.PaymentReport !== undefined) {
        if (resData.PaymentReport.PaymentHeaderList !== null && resData.PaymentReport.PaymentHeaderList !== undefined) {
          this.paymentSheetList = resData.PaymentReport.PaymentHeaderList[0].PaymentDetailsList;
          //this.currentBalance = resData.PaymentReport.CurrentBalance;//.PaymentHeaderList[0].PaymentDetailsList[0].PaymentReportDetails.BALANCEMST;
          let model = this.setManagePaymentModel(resData.PaymentReport.AccountNum, resData.PaymentReport.CurrentBalance, resData.PaymentReport.CurrentPaymentMethod, resData.PaymentReport.NumberOfPaymentMethod, resData.paymentReport.PaymentStatus);
          this.paymentsApiService.managePaymentModelSubject.next(model);
          console.log("this.currentBalance", this.currentBalance);
          console.log("this.paymentSheetList", this.paymentSheetList);
        } else {
          let model = this.setManagePaymentModel("", "", "", "", "");
          this.paymentsApiService.managePaymentModelSubject.next(model);
        }
      }
      else {
        let model = this.setManagePaymentModel("", "", "", "", "");
        this.paymentsApiService.managePaymentModelSubject.next(model);
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  setManagePaymentModel(accountNumber, currentBalance, currentPaymentMethod, numberOfPaymentMethod, paymentStatus) {
    let managePaymentModel: ManagePaymentModel =
    {
      AccountNumber: accountNumber,
      CurrentBalance: currentBalance,
      CurrentPaymentMethod: currentPaymentMethod,
      NumberOfPaymentMethod: numberOfPaymentMethod,
      PaymentStatus: paymentStatus
    }
    return managePaymentModel
  }


  loadMorePaymentSheet() {
    let count = this.nextRecordCount;
    let nextCount = +count + 10;
    this.nextRecordCount = nextCount.toString();
    this.getData();
  }

}
