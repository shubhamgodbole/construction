import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { DisplayPaymentCardType, DisplayMonthForPayment, DisplayState, DisplayAccountType, CommonConstant } from 'src/app/shared/common/constant.model';
import { FormGroup, FormGroupDirective, Validators, FormBuilder } from '@angular/forms';
import { ValidationService, ConfirmAccountNumberValidator } from 'src/app/shared/services/validation.service';
import { CorporateBlogService } from 'src/app/services/corporate-blog.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { UserPaymentMethodProcess, UserBankPaymentMethodProcess } from '../manage-payment.model';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { StandardEntryCodeEnum, paymentCardTypeEnum, PaymentTypeEnum } from 'src/app/shared/Enums/commonEnums';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { CommonService } from 'src/app/services/common.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment-method',
  templateUrl: './payment-method.component.html',
  styleUrls: ['./payment-method.component.scss']
})
export class PaymentMethodComponent implements OnInit {

  //Confirm Dialog
  //For Delete
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;


  apiErrorsComes = "";
  notificationService: NotificationService;
  isDisplayMenu: boolean = false;
  hide: boolean = true;

  cardType: string = "";

  //Credit Card Payment Form
  cardTypeDdl: any;
  monthDdl: any;
  yearDdl: any;
  stateDdl: any;
  frmCreateCardPayment: FormGroup;
  isSubmitBtnDisabledCardPayment: boolean = false;
  @ViewChild('formDirectiveCardPayment') formDirectiveCardPayment: FormGroupDirective;

  //Bank Payment Form
  accountTypeDdl: any;
  frmCreateBankPayment: FormGroup;
  isSubmitBtnDisabledBankPayment: boolean = false;
  @ViewChild('formDirectiveBankPayment') formDirectiveBankPayment: FormGroupDirective;

  userData: UserData;
  assocaitionUnitId: string;
  userProfileId: string;

  // Private
  private unsubscribeAll: Subject<any>;

  paymentCardTypeEnum = paymentCardTypeEnum;
  /*Is payment method set up or not */
  bankPaymentSetupList: any;
  cardPaymentSetupList: any;
  isPaymentMethodExist: boolean = false;
  addNewPaymentMethodSetup: boolean = false;
  paymentType = PaymentTypeEnum;

  constructor(private readonly formBuilder: FormBuilder,
    private readonly snb: MatSnackBar,
    private readonly appConfig: AppConfig,
    private progressbarService: ProgeressBarService,
    private _router: Router,
    public commonService: CommonService,
    private _matDialog: MatDialog,
    private PaymentsApiService: PaymentsApiService,
    private corporatePaymentsApiService: CorporateBlogService) {
    this.unsubscribeAll = new Subject();

    this.cardTypeDdl = DisplayPaymentCardType.paymentCardTypeList;
    this.accountTypeDdl = DisplayAccountType.accountTypeList;
    this.monthDdl = DisplayMonthForPayment.monthMonthForPaymentList;
    this.stateDdl = DisplayState.stateList;
    this.yearDdl = this.corporatePaymentsApiService.getYearDropDownList();
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    this.assocaitionUnitId = this.userData.UserUnits[0].UnitId;
    this.userProfileId = this.userData.UserProfileId;
  }

  ngOnInit() {
    this.createPaymentForm();
    this.checkPaymentMethodSetup();
  }

  menuToggle() {
    console.log('fvgg ');
    if (this.isDisplayMenu) {
      this.isDisplayMenu = false;
    } else {
      this.isDisplayMenu = true;
    }
  }

  deletePaymentMethodDetails(number: string, type: string) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = number;
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log("type", type);
        console.log("number", number);
        let resData;
        this.PaymentsApiService.deletePaymentMethod(number, type, this.userProfileId).subscribe(res => {
          this.isSubmitBtnDisabledCardPayment = false;
          resData = res;
          if (resData.Success === true) {
            this.notificationService.showNotification("Payment deleted successfully");
            this.checkPaymentMethodSetup();
          }
          else if (resData.Success === false) {
            this.apiErrorsComes = resData.Message;
            //this.notificationService.showNotification(resDataCreateCard.Message);
          }
        });
      }
    });
  }

  createPaymentForm() {
    this.frmCreateBankPayment = this.formBuilder.group({
      paymentId: [''],
      accountType: ['', [Validators.required]],
      //accountHolderName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
      routingNumber: ['', [Validators.required, Validators.minLength(9), Validators.maxLength(9), ValidationService.validateRoutingNumber]],
      accountNumber: ['', [Validators.required, Validators.minLength(9), Validators.maxLength(18), ValidationService.noWhiteSpace]],
      confirmAccountNumber: ['', [Validators.required, ConfirmAccountNumberValidator]],
      bankName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      firstName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(19), ValidationService.noWhiteSpace]],
      lastName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(19), ValidationService.noWhiteSpace]],
      addressLine1: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(39), ValidationService.noWhiteSpace]],
      addressLine2: [''],
      city: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(39), ValidationService.noWhiteSpace]],
      state: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      zipCode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10), ValidationService.noWhiteSpace]],
      country: [''],
      emailAddress: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(39), ValidationService.emailValidator]],
    });

    // Update the validity of the 'accountNumberConfirm' field
    // when the 'accountNumber' field changes
    this.frmCreateBankPayment.get('accountNumber').valueChanges
      .pipe(takeUntil(this.unsubscribeAll))
      .subscribe(() => {
        this.frmCreateBankPayment.get('confirmAccountNumber').updateValueAndValidity();
      });


    this.frmCreateCardPayment = this.formBuilder.group({
      cardType: ['', [Validators.required]],
      cardNumber: ['', [Validators.required, Validators.minLength(14), Validators.maxLength(17), ValidationService.noWhiteSpace]],
      month: ['', Validators.required],
      year: ['', Validators.required],
      CVVNumber: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3), ValidationService.noWhiteSpace]],
      firstName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(19), ValidationService.noWhiteSpace]],
      lastName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(19), ValidationService.noWhiteSpace]],
      addressLine1: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(39), ValidationService.noWhiteSpace]],
      addressLine2: [''],
      city: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(39), ValidationService.noWhiteSpace]],
      state: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      zipCode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10), ValidationService.noWhiteSpace]],
      country: [''],
      emailAddress: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(39), ValidationService.emailValidator]],
    });
  }

  /*Card Payment Method*/
  onSubmitCardPayment() {
    if (this.frmCreateCardPayment.valid) {
      let model = this.createCardFormModel();
      console.log("Card", model);
      let resDataCreateCard;
      this.isSubmitBtnDisabledCardPayment = true;
      this.apiErrorsComes = "";
      this.PaymentsApiService.createcardPaymentMethod(model).subscribe(res => {
        this.isSubmitBtnDisabledCardPayment = false;
        resDataCreateCard = res;
        if (resDataCreateCard.Success === true) {
          this.notificationService.showNotification("Payment method saved successfully");
          this.resetCardForm();
          this.checkPaymentMethodSetup();
        }
        else if (resDataCreateCard.Success === false) {
          this.apiErrorsComes = resDataCreateCard.Message;
          //this.notificationService.showNotification(resDataCreateCard.Message);
        }
      });
    }
  }

  createCardFormModel() {
    const model: UserPaymentMethodProcess = {
      AssocaitionUnitId: this.assocaitionUnitId,
      UserProfileId: this.userProfileId,
      PaymentTypes: {
        CreditCardDetails: [{
          CardType: this.frmCreateCardPayment.controls.cardType.value,
          CardNumber: this.frmCreateCardPayment.controls.cardNumber.value,
          ExpiryMonth: this.frmCreateCardPayment.controls.month.value,
          ExpiryYear: this.frmCreateCardPayment.controls.year.value,
          Cvv: this.frmCreateCardPayment.controls.CVVNumber.value,
          IsDefault: true,
          FirstName: this.frmCreateCardPayment.controls.firstName.value,
          LastName: this.frmCreateCardPayment.controls.lastName.value,
          Address1: this.frmCreateCardPayment.controls.addressLine1.value,
          Address2: this.frmCreateCardPayment.controls.addressLine2.value,
          City: this.frmCreateCardPayment.controls.city.value,
          State: this.frmCreateCardPayment.controls.state.value,
          Zip: this.frmCreateCardPayment.controls.zipCode.value,
          EmailAddress: this.frmCreateCardPayment.controls.emailAddress.value,
        }]
      }
    }
    return model;
  }

  resetCardForm() {
    this.frmCreateCardPayment.reset();
    this.formDirectiveCardPayment.resetForm();
    this.isSubmitBtnDisabledCardPayment = false;
    this.apiErrorsComes = "";
  }

  /*Bank Payment Method*/
  onSubmitBankPayment() {
    if (this.frmCreateBankPayment.valid) {
      this.isSubmitBtnDisabledBankPayment = true;
      let model = this.createBankFormModel();
      console.log("Bank", model);
      let resDataCreateBank;
      this.PaymentsApiService.createBankPaymentMethod(model, StandardEntryCodeEnum.WEB).subscribe(res => {
        this.isSubmitBtnDisabledBankPayment = false;
        resDataCreateBank = res;
        if (resDataCreateBank.Success === true) {
          this.notificationService.showNotification("Payment method saved successfully");
          this.resetBankForm();
          this.checkPaymentMethodSetup();
        }
        else if (resDataCreateBank.Success === false) {
          this.apiErrorsComes = resDataCreateBank.Message;
          //this.notificationService.showNotification("Not Saved");
        }
      });
    }
  }

  createBankFormModel() {
    const model: UserBankPaymentMethodProcess = {
      AssocaitionUnitId: this.assocaitionUnitId,
      UserProfileId: this.userProfileId,
      PaymentTypes: {
        BankDetails: [{
          AccountType: this.frmCreateBankPayment.controls.accountType.value,
          AccountNumber: this.frmCreateBankPayment.controls.accountNumber.value,
          AccountHolderName: this.frmCreateBankPayment.controls.firstName.value + " " + this.frmCreateBankPayment.controls.lastName.value,
          RoutingNumber: this.frmCreateBankPayment.controls.routingNumber.value,
          BankName: this.frmCreateBankPayment.controls.bankName.value,
          IsDefault: true,
          FirstName: this.frmCreateBankPayment.controls.firstName.value,
          LastName: this.frmCreateBankPayment.controls.lastName.value,
          Address1: this.frmCreateBankPayment.controls.addressLine1.value,
          Address2: this.frmCreateBankPayment.controls.addressLine2.value,
          City: this.frmCreateBankPayment.controls.city.value,
          State: this.frmCreateBankPayment.controls.state.value,
          Zip: this.frmCreateBankPayment.controls.zipCode.value,
          EmailAddress: this.frmCreateBankPayment.controls.emailAddress.value,
        }]
      }
    }
    return model;
  }

  resetBankForm() {
    this.frmCreateBankPayment.reset();
    this.formDirectiveBankPayment.resetForm();
    this.isSubmitBtnDisabledBankPayment = false;
    this.apiErrorsComes = "";
  }


  checkPaymentMethodSetup() {
    let resData;
    let userProfileId = this.userProfileId;
    this.progressbarService.show();
    this.PaymentsApiService.getPaymentMethod(userProfileId).subscribe(res => {
      this.progressbarService.hide();
      resData = res;
      console.log("respaymentmethoid", res);
      if (resData.Success === true) {
        this.isPaymentMethodExist = true;
        this.addNewPaymentMethodSetup = false;
        this.bankPaymentSetupList = resData.UserPaymentMethodProcess.PaymentTypes.BankDetails;
        this.cardPaymentSetupList = resData.UserPaymentMethodProcess.PaymentTypes.CreditCardDetails;
        console.log(this.cardPaymentSetupList);
        console.log(this.bankPaymentSetupList);
      }
      else if (resData.Success === false) {
        this.isPaymentMethodExist = false;
        console.log(this.cardPaymentSetupList);
        console.log(this.bankPaymentSetupList);
      }
    });
  }

  addNewPaymentMethod() {
    if (this.addNewPaymentMethodSetup) {
      this.addNewPaymentMethodSetup = false;
    } else {
      this.addNewPaymentMethodSetup = true;
    }
  }

  // For Check card type
  checkCardType() {
    let cardNumber = this.frmCreateCardPayment.controls.cardNumber.value;
    if (cardNumber.match(/^4[0-9]{0,}$/)) {
      this.cardType = this.paymentCardTypeEnum.VISA;
    } else if (cardNumber.match(/^(5[1-5]|222[1-9]|22[3-9]|2[3-6]|27[01]|2720)[0-9]{0,}$/)) {
      this.cardType = this.paymentCardTypeEnum.MSTR;
    } else if (cardNumber.match(/^(6011|65|64[4-9]|62212[6-9]|6221[3-9]|622[2-8]|6229[01]|62292[0-5])[0-9]{0,}$/)) {
      this.cardType = this.paymentCardTypeEnum.DISC;
    } else if (cardNumber.match(/^3[47][0-9]{0,}$/)) {
      this.cardType = this.paymentCardTypeEnum.AMEX;
    } else {
      this.cardType = "";
    }
    if (this.cardType !== "") {
      let selectedCardType = this.cardTypeDdl.find(x => x.text === this.cardType);
      this.frmCreateCardPayment.controls.cardType.setValue(selectedCardType.value);
    } else {
      this.frmCreateCardPayment.controls.cardType.setValue('');
    }
  }


  onChange(event: any) {
    if (this.frmCreateBankPayment.controls.routingNumber.valid) {
      let values = event.target.value;
      console.log(values);
      if (values !== null && values !== undefined && values !== '') {
        this.getbankNameUsingRoutingNumber(values);
      }
    }
  };


  /*Bank Payment Method*/
  getbankNameUsingRoutingNumber(rn) {
    let resData;
    this.commonService.getBankNameUsingRoutingNumber(rn).subscribe(res => {
      resData = res;
      if (resData.code === 200) {
        this.frmCreateBankPayment.controls.bankName.setValue(resData.customer_name);
      } else {
        this.frmCreateBankPayment.controls.bankName.setValue('');
      }
      console.log("Bankdata", res);
    });
  }

  goToPaymentLanding() {
    this._router.navigate([AppRouteUrl.mainManagePaymentRouteUrl]);

  }
}
