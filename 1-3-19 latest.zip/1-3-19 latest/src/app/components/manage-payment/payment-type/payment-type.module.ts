import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaymentTypeComponent } from './payment-type.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule, MatInputModule, MatDialogModule, MatStepperModule, MatSliderModule, MatFormFieldModule, MatSnackBarModule, MatListModule, MatSelectModule, MatBottomSheetModule, MatButtonModule, MatCheckboxModule, MatButtonToggleModule, MatTableModule, MatRadioModule, MatTooltipModule, MatDatepickerModule } from '@angular/material';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatListModule,
    MatSelectModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatCheckboxModule,
    MatButtonToggleModule,
    MatDatetimepickerModule,
    MatTableModule,
    MatRadioModule,
    MatTooltipModule,
    NumberOnlyDirectiveModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatDialogModule,
    MatStepperModule,
    MatSliderModule,
    MatFormFieldModule,
    MatSnackBarModule,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [PaymentTypeComponent],
  declarations: [PaymentTypeComponent]
})
export class PaymentTypeModule { }
