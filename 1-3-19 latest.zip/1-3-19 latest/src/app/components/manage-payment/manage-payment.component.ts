import { Component, OnInit, ViewChild } from '@angular/core';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { RoleEnum } from 'src/app/shared/Enums/commonEnums';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { MatAutocompleteTrigger } from '@angular/material';
import { ManagePaymentModel } from './manage-payment.model';
//import { PaymentLandingComponent } from './payment-landing/payment-landing.component';

@Component({
  selector: 'app-manage-payment',
  templateUrl: './manage-payment.component.html',
  styleUrls: ['./manage-payment.component.scss']
})
export class ManagePaymentComponent implements OnInit {
  userData: UserData;
  accountNumber: string = "";
  currentBalance: string = "";
  currRole: string = "";
  globalAssociationModel: GlobalAssociationModel;
  managePaymentModel: ManagePaymentModel;
  roleEnum = RoleEnum;
  isDisplayMenu: boolean = false;
  oneTimePaymentRouteUrl = AppRouteUrl.oneTimePaymentRouteUrl;
  paymentMethodsRouteUrl = AppRouteUrl.paymentMethodsRouteUrl;
  recurrencePaymentMethods = AppRouteUrl.recurrencePaymentMethods;

  accountDetailsList: any[];
  accountDetailsAutocompleteList: any[];
  @ViewChild('accountNumberAutoComplete', { read: MatAutocompleteTrigger })
  accountNumbertrigger: MatAutocompleteTrigger;

  constructor(private readonly appConfig: AppConfig,
    private progressbarService: ProgeressBarService,
    private paymentsApiService: PaymentsApiService) {
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData !== null) {
      this.currRole = this.userData.Role;
      this.accountNumber = this.userData.AccountNumber;
      this.paymentsApiService.accountNumberSubject.next(this.accountNumber);
    }

  }
  ngOnInit() {
    this.paymentsApiService.managePaymentModelSubject.subscribe(res => {
      console.log('from managePaymentModelSubject ', res);
      this.managePaymentModel = res;
    });
  }

  menuToggle() {
    if (this.isDisplayMenu) {
      this.isDisplayMenu = false;
    } else {
      this.isDisplayMenu = true;
    }
  }
}
