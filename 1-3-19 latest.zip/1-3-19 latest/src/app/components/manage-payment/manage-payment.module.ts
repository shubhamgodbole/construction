import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PaymentLandingComponent } from './payment-landing/payment-landing.component';
import { MatListModule, MatSelectModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatRadioModule, MatTooltipModule, MatDatepickerModule, MatIconModule, MatInputModule, MatDialogModule, MatStepperModule, MatSliderModule, MatSlideToggleModule, MatSnackBarModule, MatTableModule, MatFormFieldModule, MatCheckboxModule, MatAutocompleteModule ,MatMenuModule} from '@angular/material';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { OnetimePaymentComponent } from './onetime-payment/onetime-payment.component';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { RecurrencePaymentComponent } from './recurrence-payment/recurrence-payment.component';
import { PaymentMethodComponent } from './payment-method/payment-method.component';
import { ManagePaymentComponent } from './manage-payment.component';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { PaymentTypeModule } from './payment-type/payment-type.module';
import { AllowOnlyPriceModule } from 'src/app/shared/directives/allow-only-price/allow-only-price.module';
const routes: Routes = [
  {
    path: '',
    component: ManagePaymentComponent,
    children: [
      { path: '', redirectTo: AppRouteUrl.paymentLandingRouteUrl },
      { path: AppRouteUrl.paymentLandingRouteUrl, component: PaymentLandingComponent },
      { path: AppRouteUrl.oneTimePaymentRouteUrl, component: OnetimePaymentComponent },
      { path: AppRouteUrl.paymentMethodsRouteUrl, component: PaymentMethodComponent },
      { path: AppRouteUrl.recurrencePaymentMethods, component: RecurrencePaymentComponent, },
    ]
  }
];
@NgModule({
  imports: [
    CommonModule,
    PaymentTypeModule,
    MatListModule,
    MatSelectModule,
    MatBottomSheetModule,
    NoDataFoundModule,
    MatButtonModule,
    MatCheckboxModule,
    MatButtonToggleModule,
    MatDatetimepickerModule,
    MatIconModule,
    MatInputModule,
    MatDialogModule,
    MatStepperModule,
    MatSliderModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatMenuModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatTableModule,
    MatRadioModule,
    MatTooltipModule,
    NumberOnlyDirectiveModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    AllowOnlyPriceModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [PaymentLandingComponent, OnetimePaymentComponent, RecurrencePaymentComponent, PaymentMethodComponent, ManagePaymentComponent]
})
export class ManagePaymentModule { }
