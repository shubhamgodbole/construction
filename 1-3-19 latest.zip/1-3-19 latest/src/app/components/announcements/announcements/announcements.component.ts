import { Component, OnInit, ViewChild } from '@angular/core';
import { UserData } from 'src/app/shared/models/user-data-model';
import { DashboardService } from 'src/app/services/dashboard.service';
import { LoginApiService } from 'src/app/services/login-api.service';
import { AppConfig } from 'src/app/app.config';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { Guid } from 'guid-typescript';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { ImageNameEnums, MasterPaginationEnum, Pagination, RoleEnum, NoDataFoundCaseFeatureName, FeatureName, TriggerType, SourceType, AudienceType, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { MatPaginator, MatSnackBar, MatAutocompleteTrigger } from '@angular/material';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { AddAnnouncementModel } from '../../dashboard/dashboard.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { CommonService } from 'src/app/services/common.service';
import { AcceptFilesConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-announcements',
  templateUrl: './announcements.component.html',
  styleUrls: ['./announcements.component.scss']
})
export class AnnouncementsComponent implements OnInit {
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;

  userData: UserData;
  associationId: string;
  associationName: string;
  domain: string;
  userId: string;
  userName: string;
  userRole: string;
  userProfile: string;
  announcementList: any;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  SendtoData: any;
  FromtoData: any;
  fileData: any = [];
  isComponentLoad: boolean = false;
  // multi select drop-down
  dropdownSettings = {};
  // add Announcement
  addAnnouncementForm: FormGroup;
  isAnnouncementButton: boolean = false;
  notificationService: NotificationService;
  @ViewChild('addAnnouncementDirective') addAnnouncementDirective: FormGroupDirective;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  isAnnouncementShow: boolean = true;
  isAnnouncementDesError: boolean = false;
  isAnnouncementSendToError: boolean = false;
  // editor Formating Option
  public editorOptions = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote'],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'script': 'sub' }, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
      [{ 'font': [] }],
      [{ 'align': [] }],
      ['clean'],                                         // remove formatting button
    ]
  };






  isAddAnnouncement: boolean = false;
  isAnnouncementDetail: boolean = false;
  querySubcription: Subscription;
  requestId: string;
  roleEnum = RoleEnum;
  //For Send Notification
  announcementFeatureId: string;
  pmCompanyAssociationMappingId: string;
  audienceType: any;
  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  //For Association
  associationData: any[] = [];
  associationDdlAutocompleteList: any[] = [];
  @ViewChild('announcementAssociationAutoComplete', { read: MatAutocompleteTrigger })
  announcementAssociationtrigger: MatAutocompleteTrigger;
  globalAssociationModel: GlobalAssociationModel;
  isApiResponceCome = false;

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  /*For server side paginaion */
  allCount: any;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;

  constructor(public service: DashboardService,
    private readonly appConfig: AppConfig,
    private formBuilder: FormBuilder,
    private progressbarService: ProgeressBarService,
    private router: Router,
    private route: ActivatedRoute,
    private readonly snb: MatSnackBar,
    private emailNotification: EmailNotificationService,
    private globalAssociationService: GlobalAssociationService,
    public commonService: CommonService,
  ) {
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData !== null) {
      this.setData(this.userData);
    }

  }
  setData(userClaim) {

    this.userId = userClaim.UserProfileId;
    this.userRole = userClaim.Role;
    this.userName = userClaim.UserName;
    this.associationId = userClaim.UserAssociations[0].AssociationId;
    this.associationName = userClaim.UserAssociations[0].Name;
    this.userProfile = userClaim.UserProfileBlobPath;
    this.domain = userClaim.UserAssociations[0].Domain;
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Announcement) {
          this.announcementFeatureId = feature.FeatureId
        }
      });
  }
  ngOnInit() {
    this.setMasterOfPagination();
    this.addAnnouncementForm = this.formBuilder.group({
      sendTo: ['', [Validators.required, Validators.maxLength(200)]],
      from: [''],
      //password: ['', [Validators.required, Validators.maxLength(50), ValidationService.noWhiteSpace]],
      subject: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      description: ['', [Validators.required, Validators.maxLength(2000)]],
      association: [''],
    });
    if (this.userRole === this.roleEnum.PropertyManager) {
      this.addAnnouncementForm.controls.from.setValidators([Validators.required, ValidationService.emailValidator, ValidationService.noWhiteSpace]);
      this.addAnnouncementForm.controls.association.setValidators([Validators.required]);
      this.audienceType = AudienceType.PropertyManager;
    }
    else {
      this.audienceType = AudienceType.BoardMember;
    }
    this.globalAssociationService.associationSubject.subscribe(res => {
      console.log('from association data ', res);
      this.globalAssociationModel = res;
      if (res !== 1) {
        this.getAnnouncementList();
      }
    });

    this.getSendToData();
    this.getAssociation();
 
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(list) {
    this.TotalRecord = this.allCount;
    this.FilterArray = list;
    // const total = [];
    // this.TotalRecord = list.length;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = list.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageTake = clickObj.pageSize;
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getAnnouncementList();
    // var pageStartIndex = (clickObj.pageIndex * clickObj.pageSize) + 1;
    // var pageEndIndex = (clickObj.pageIndex * clickObj.pageSize) + clickObj.pageSize;
    // this.FilterArray = this.announcementList.slice(pageStartIndex - 1, pageEndIndex);
    var elmnt: any = document.getElementById("contentTable");
    if (elmnt !== null) {
      elmnt.scrollTo(0, 0);
    }
    
  }
  Add() {
    this.isAnnouncementShow = false;
    this.isAnnouncementDetail = false;
    this.isAddAnnouncement = true;
  }
  // get sendTo data
  getSendToData() {
    this.service.GetSendToMasterData().subscribe(
      (response: any) => {
        if (response.Success) {
          this.SendtoData = response.AssociationDistributionGroup.filter((s) => s.Name === "HomeOwner");
          this.FromtoData = response.EmailConfigurations;
        }
      }
    );
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'id',
      textField: 'Name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: false
    };
  }
  // get Announcement list
  getAnnouncementList() {
    this.progressbarService.show(); 
    this.service.getAnnouncement(this.globalAssociationModel.AssociationId ? this.globalAssociationModel.AssociationId : null, this.pageSkip, this.pageTake).subscribe(
      (response: any) => {
        this.isApiResponceCome = true;
        this.isComponentLoad = true;
        if (response.Success) {
          this.announcementList = response.GetSocialList.SocialAnnouncementList;
          this.allCount = response.ResultCount;
          if (this.announcementList !== null) {
            this.setPaginationData(this.announcementList);
            this.SetDetailsOfNextPreviousOnDetailsPage();
            this.progressbarService.hide();
            console.log('AnnouncementList', response.GetSocialList.SocialAnnouncementList);
          }

        }
        else {
          this.progressbarService.hide();
        }

      }
    );
    this.announcementList = [];
  }
  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('AnnouncemtnList');
    var temp: any = [];
    this.announcementList.forEach(element => {
      temp.push({
        id: element.id
      });
    });
    localStorage.setItem('AnnouncemtnList', JSON.stringify(temp));
  }

  // get Announcement Description
  getAnnoucementdesc() {
    if (this.addAnnouncementForm.controls.description.value === '<p> </p>' || this.addAnnouncementForm.controls.description.value === '<p><br></p><p><br></p>') {
      this.addAnnouncementForm.controls.description.setValue(null);
      return false;
    }
    else {
      if (this.addAnnouncementForm.controls.description.value && this.addAnnouncementForm.controls.description.value.length > 0) {
        this.isAnnouncementDesError = false;
      }
    }
  }
  // on file upload
  onAnnouncementDocChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            fileName: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
      // console.log(this.fileData);
    }
  }
  // remove uploaded Documents
  removeAnnouncementDocs(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };
  // on sendTo Select
  onItemSelect(item: any) {
    this.isAnnouncementSendToError = false;
  }
  // add Announcement Model
  addAnnouncementModel() {
    let model: AddAnnouncementModel = {
      SendTo: this.addAnnouncementForm.controls.sendTo.value,
      Subject: this.addAnnouncementForm.controls.subject.value,
      BodyText: this.addAnnouncementForm.controls.description.value,
      From: this.addAnnouncementForm.controls.from.value,
      AssociationId: this.userRole !== this.roleEnum.PropertyManager ? this.associationId : this.addAnnouncementForm.controls.association.value.id,
      Attachments: this.fileData,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      CreatedOn: new Date(),
      ModifiedOn: new Date()
    }
    return model;
  }
  // reset Announcement Form
  resetAnnouncementForm() {
    this.addAnnouncementForm.reset();
    this.addAnnouncementDirective.resetForm();
    this.isAnnouncementShow = true;
    this.isAnnouncementDesError = false;
    this.fileData = [];
    this.isAnnouncementSendToError = false;
    this.isAnnouncementDetail = false;
    this.isAddAnnouncement = false;
    this.isAnnouncementButton = false;
  }
  // add Announcement
  addAnnouncement() {
    let model = this.addAnnouncementModel();
    //  console.log(model);
    if (model.BodyText === '' || model.BodyText === null) {
      this.isAnnouncementDesError = true;
    }
    else {
      this.isAnnouncementDesError = false;
    }
    if (model.SendTo === '' || model.SendTo === null) {
      this.isAnnouncementSendToError = true;
    }
    else {
      this.isAnnouncementSendToError = false;
    }

    if (this.addAnnouncementForm.valid) {
      this.isAnnouncementButton = true;
      this.service.addAnnouncement(model.AssociationId, model).subscribe(
        (response: any) => {
          if (response.Success) {
            this.notificationService.showNotification('Announcement Saved Successfully');
            this.emailNotification.sendNotifications(this.announcementFeatureId, response.RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.Announcement, TriggerType.Create,
              this.audienceType).subscribe(res => {
                console.log('save Announcement ', res);
              });
            this.resetAnnouncementForm();
            this.getAnnouncementList();
          }
        }
      );
    }
  }
  getDetail(id) {
    this.isAnnouncementShow = false;
    this.isAnnouncementDetail = true;
    this.isAddAnnouncement = false;
    this.requestId = id;
    //  console.log(AppRouteUrl.mainAnnouncementsDetailRouteUrl);
    this.router.navigate([AppRouteUrl.mainAnnouncementsDetailRouteUrl], { queryParams: { id: id } });

  }
  copy(list) {
    this.addAnnouncementForm.controls.sendTo.setValue(list.SendTo);
    this.addAnnouncementForm.controls.subject.setValue(list.subject);
    this.addAnnouncementForm.controls.description.setValue(list.BodyText);
    this.addAnnouncementForm.controls.from.setValue(list.From);
    list.Attachments.forEach((attechment) => {
      this.fileData.push({
        imageId: Guid.create(),
        inputStream: attechment.Link,
        fileName: attechment.FileName,
        type:attechment.FileName.toLowerCase().substring(attechment.FileName.indexOf(".")),
        mediaType: attechment.FileName.toLowerCase().substring(attechment.FileName.indexOf(".")),
      });
    });
    this.Add();
    // let model: AddAnnouncementModel = {
    //   SendTo: list.SendTo,
    //   Subject: list.subject,
    //   BodyText: list.BodyText,
    //   From: this.userName,
    //   AssociationId: this.globalAssociationModel.AssociationId,
    //   Attachments: list.Attachments,
    //   CreatedByUserId: this.userId,
    //   CreatedByUserName: this.userName,
    //   CreatedOn: new Date(),
    //   ModifiedOn: new Date()
    // }
    // this.service.addAnnouncement(model.AssociationId, model).subscribe(
    //   (response: any) => {
    //     if (response.Success) {
    //       this.notificationService.showNotification('Announcement Copy Successfully');
    //       this.emailNotification.sendNotifications(this.announcementFeatureId, response.RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.Announcement, TriggerType.Create,
    //         this.audienceType).subscribe(res => {
    //           console.log('save Announcement ', res);
    //         });
    //       //this.resetAnnouncementForm();
    //       this.getAnnouncementList();
    //     }
    //   }
    // );
  }
  getAssociation() {
    this.service.getAssociation().subscribe(
      (response: any) => {
        if (response.success) {
          this.associationData = response.AssociationList;
          this.associationDdlAutocompleteList = response.AssociationList;
          // this.selectedAssociation = this.associationData.find(x => x.id === this.associationId.toLowerCase());
        }
      }
    );
  }


  /*auto complete*/

  /*Reset mat auto compelte*/
  ngAfterViewInit() {
    if (this.announcementAssociationtrigger !== undefined) {
      this.announcementAssociationtrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.addAnnouncementForm.controls.association.setValue('');
            this.announcementAssociationtrigger.closePanel();
            this.associationDdlAutocompleteList = this.associationData;
          }
        });
    }
  }
  /**Auto complete Display Function**/
  displayFnAutoCompleteAssociation(association) {
    if (association != null && association.AssociationName != null) {
      return association.AssociationName;
    } else association;
  }

  /**Auto complete filter on change**/
  onInputChangedAssociation(searchStr: string): void {
    this.associationDdlAutocompleteList = [];
    this.associationDdlAutocompleteList = this.associationData.filter(option =>
      option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
  }

  //for clear association drop down
  onFocusOut(searchStr) {
    if (this.announcementAssociationtrigger !== undefined) {
      this.announcementAssociationtrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.associationDdlAutocompleteList = this.associationData;
            this.addAnnouncementForm.controls.association.setValue('');
            this.announcementAssociationtrigger.closePanel();
          }
        });
      this.associationDdlAutocompleteList = this.associationData.filter(option =>
        option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
      if (this.associationDdlAutocompleteList.length === 0) {
        this.associationDdlAutocompleteList = this.associationData;
        this.addAnnouncementForm.controls.association.setValue('');
      }
    }
  }
}
