import { Component, OnInit } from '@angular/core';
import { UserData } from 'src/app/shared/models/user-data-model';
import { DashboardService } from 'src/app/services/dashboard.service';
import { AppConfig } from 'src/app/app.config';
import { FormBuilder } from '@angular/forms';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonService } from 'src/app/services/common.service';
import { DocumentFeatureName, DownloadfeatureName, ImageNameEnums, NoDataFoundCaseFeatureName } from 'src/app/shared/Enums/commonEnums';

@Component({
  selector: 'app-announcement-detail',
  templateUrl: './announcement-detail.component.html',
  styleUrls: ['./announcement-detail.component.scss']
})
export class AnnouncementDetailComponent implements OnInit {
  
  isApiResponceCome = false;
  
  userData: UserData;
  associationId: string;
  associationName: string;
  domain: string;
  userId: string;
  userName: string;
  userRole: string;
  userProfile: string;
  announcementList: any;
  announcementDetail: any;
  querySubcription: Subscription;
  requestId: string;
  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentPreview: boolean = false;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;
//ImageNameEnums
  imageNameEnums = ImageNameEnums;
  isComponentLoad:boolean = false;
  constructor(public service: DashboardService,
    private readonly appConfig: AppConfig,
    private formBuilder: FormBuilder,
    private progressbarService: ProgeressBarService,
    private router: Router,
    private route: ActivatedRoute,
    public commonService: CommonService,
  ) {
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData !== null) {
      this.setData(this.userData);
    }
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.requestId = id;
        this.getDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
  }
  //For Preview document
  previewDocument(document) {
    this.isDocumentPreview = true;
    this.documentDetails = document;
    this.fileURL = "";
    if (document.FileName.split('.')[1] !== 'pdf') {
      this.fileURL = document.Link;
    }
    else {
      this.commonService.downloadFile(document.Link).subscribe(
        (response) => {
          this.fileURL = URL.createObjectURL(response);
        }
      );
    }
  }
  
  setData(userClaim) {
    this.userId = userClaim.UserProfileId;
    this.userRole = userClaim.Role;
    this.userName = userClaim.UserName;
    this.associationId = userClaim.UserAssociations[0].AssociationId;
    this.associationName = userClaim.UserAssociations[0].Name;
    this.userProfile = userClaim.UserProfileBlobPath;
    this.domain = userClaim.UserAssociations[0].Domain;
  }
  ngOnInit() {
  }
  getDetail() {
    this.progressbarService.show();
    this.service.getAnnouncementDetail(this.requestId).subscribe(
      (response: any) => {
        this.isApiResponceCome = true;
        if (response.Success) {
          this.isComponentLoad = true;
          this.announcementDetail = response.SocialAnnouncement;
          this.isShowNextAndPreviewsButton();
          //console.log('detail',response.SocialAnnouncement);
          this.progressbarService.hide();
        }
        else {
          this.isComponentLoad = true;
          this.announcementDetail = null;
        }
      }
    );
  }
  //**Next AND Preview */
  PreviousCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('AnnouncemtnList'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = ar[currentEl - 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  NextCase() {
    var current = this.requestId;
    var ar = JSON.parse(localStorage.getItem('AnnouncemtnList'));
    this.totalPages = ar.length - 1;
    var el = ar.find(a => { return a.id === current });
    var currentEl = ar.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < ar.length) {
      let prevIndex = ar[currentEl + 1].id;
      this.requestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  isShowNextAndPreviewsButton() {
    let localStorageData = JSON.parse(localStorage.getItem('AnnouncemtnList'));
    if (localStorageData === null || localStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.requestId;
      var ar = JSON.parse(localStorage.getItem('AnnouncemtnList'));
      this.totalPages = ar.length - 1;
      var el = ar.find(a => { return a.id === current });
      var currentEl = ar.indexOf(el);
      this.currentPage = currentEl;
    }
  }
  goToBack() {
    this.router.navigate([AppRouteUrl.mainAnnouncementsRouteUrl]);
  }
}
