import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MatInputModule, MatListModule, MatDatepickerModule, MatSelectModule, MatChipsModule, MatIconModule, MatRadioModule, MatMenuModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatRippleModule, MatSnackBarModule, MatPaginatorModule, MatTooltipModule, MatTreeModule, MatCheckboxModule, MatDialogModule, MatAutocompleteModule } from '@angular/material';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { AllowOnlyPriceModule } from 'src/app/shared/directives/allow-only-price/allow-only-price.module';
import { QuillModule } from 'ngx-quill';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { AnnouncementDetailComponent } from './announcement-detail/announcement-detail.component';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
const routes: Routes = [
  {
    path: '',
    component: AnnouncementsComponent
  },
  {
    path: AppRouteUrl.announcementDetailRouteUrl,
    component: AnnouncementDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    MatAutocompleteModule,
    NoCaseNoteFoundModule,
    SafeModule,
    MatInputModule,
    MatRadioModule,
    MatListModule,
    NumberOnlyDirectiveModule,
    AllowOnlyPriceModule,
    MatMenuModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatRippleModule,
    MatSelectModule,
    MatSnackBarModule,
    MatPaginatorModule,
    MatTooltipModule,
    NumberOnlyDirectiveModule,
    MatTreeModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatDialogModule,
    FormsModule,
    MatDatepickerModule,
    QuillModule,
    RouterModule.forChild(routes),
    NgMultiSelectDropDownModule.forRoot(),
    HideIfUnauthorizedModule,
  ],
  declarations: [AnnouncementsComponent, AnnouncementDetailComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [RouterModule]
})
export class AnnouncementModule { }
