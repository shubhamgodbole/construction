import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  MatCheckboxModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatRippleModule,
  MatSelectModule,
  MatSnackBarModule,
  MatTooltipModule,
  MatTreeModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatBottomSheetModule,
  MatDialogModule,
  MatDatepickerModule,
  MatRadioModule,
  MatPaginatorModule,
} from '@angular/material';
import { CommonModule } from '@angular/common';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { RouterModule, Routes } from '@angular/router';
import { HoArcListComponent } from './ho-arc-list/ho-arc-list.component';
import { HoArcDetailComponent } from './ho-arc-detail/ho-arc-detail.component';
import { NoCaseNoteFoundComponent } from 'src/app/shared/component/no-case-note-found/no-case-note-found.component';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { CreateArcComponent } from './create-arc/create-arc.component';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { AllowOnlyPriceModule } from 'src/app/shared/directives/allow-only-price/allow-only-price.module';
import { OnlyAlphabetsModule } from 'src/app/shared/directives/allow-only-alphabets/only-alphabets.module';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { TransformBlankValueModule } from 'src/app/shared/pipes/blankValue/transform-blank-value.module';
const routes: Routes = [
  {
    path: '',
    component: HoArcListComponent
  },
  {
    path: AppRouteUrl.arcDetailHORouteUrl,
    component: HoArcDetailComponent
  },
  {
    path: AppRouteUrl.createArcRouteUrl,
    component: CreateArcComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    NoCaseNoteFoundModule,
    SafeModule,
    MatInputModule,
    MatRadioModule,
    MatListModule,
    NumberOnlyDirectiveModule,
    OnlyAlphabetsModule,
    AllowOnlyPriceModule,
    MatMenuModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatRippleModule,
    MatSelectModule,
    MatSnackBarModule,
    MatPaginatorModule,
    MatTooltipModule,
    MatTreeModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatDialogModule,
    FormsModule,
    MatDatepickerModule,
    RouterModule.forChild(routes),
    BsDatepickerModule.forRoot(),
    FilterUniqueArrayModule,
    HideIfUnauthorizedModule,
    TransformBlankValueModule
  ],
  declarations: [HoArcListComponent, HoArcDetailComponent, CreateArcComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [RouterModule]
})
export class HoArcModule { }
