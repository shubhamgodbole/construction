import { Component, OnInit, ViewChild } from '@angular/core';
import { ARCStatus, DisplayColumnsCM } from '../arc-model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { fromEvent } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { AppConfig } from 'src/app/app.config';
import { Router, NavigationExtras } from '@angular/router';
import { NoDataFoundCaseFeatureName, MasterPaginationEnum, Pagination, DocumentFeatureName, requestSubTypeCount, RoleEnum, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { MatPaginator } from '@angular/material';
import { FilterListValues, FeatureNameLocalStorage } from 'src/app/shared/common/models';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-cm-arc-list',
  templateUrl: './cm-arc-list.component.html',
  styleUrls: ['./cm-arc-list.component.scss']
})
export class CmArcListComponent implements OnInit {
  isList: boolean;
  filter = false;
  userData: UserData;
  associationId: string;
  arcList: any = null;
  arcStatusCount: any;
  count: number;
  arcRequestStatus = ARCStatus;
  role: string;

  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  /**End For Manage Columns*/

  //for filter by date
  dateTo: any;
  dateFrom: any;
  bsRangeValue: Date[] = [];

  //For filter by key word
  filterByKeyWords: string = "";
  @ViewChild('searchData') searchData: any;

  //for display comments
  isViewComment: boolean = false;

  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  //for save data in localstorage
  localStorageFromDate;
  localStorageToDate;
  allCount: any;
  userId: string;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  
  isApiResponceCome = false;

  constructor(public service: ArcRequestApiService, private readonly appConfig: AppConfig,
    public commonService: CommonService,
    private router: Router, private progressbarService: ProgeressBarService, ) {
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.role = this.userData.Role;
    this.userId = this.userData.UserProfileId;
  }

  ngOnInit() {
    /**For Manage Columns*/
    this.seletedColumns = DisplayColumnsCM.AllColumnsList;
    this.displayColumnsDdl = DisplayColumnsCM.AllSelectedColumnsList;
    this.defaultColumnsList = DisplayColumnsCM.DefaultColumnsList;
    //Filter By Key word
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.getData();
      });
    this.getLocalStorageData();
  }

  //for filter by date
  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.localStorageFromDate = event[0];
        this.dateTo = new Date(event[1]).toUTCString();
        this.localStorageToDate = event[1];
        this.getData();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getData();
    }
  }


  getLocalStorageData() {
    //get local storage filter data
    var data: FilterListValues = this.commonService.getFilterDataFromLocalStorge();
    if (data !== null && data !== undefined) {
      if (data.FeatureName === FeatureNameLocalStorage.ARCCM) {
        this.service.listStatus = data.Status;
        this.filterByKeyWords = data.SearchKey;
        this.dateFrom = data.DateFrom !== null && data.DateFrom !== undefined && data.DateFrom !== '' ? new Date(data.DateFrom).toUTCString() : '';
        this.dateTo = data.DateTo !== null && data.DateTo !== undefined && data.DateTo !== '' ? new Date(data.DateTo).toUTCString() : '';
        this.filter = data.Filter;
        if (this.dateFrom !== "" && this.dateFrom !== null && this.dateFrom !== undefined && this.dateTo !== "" && this.dateTo !== null && this.dateTo !== undefined) {
          this.bsRangeValue = [new Date(data.DateFrom), new Date(data.DateTo)];
        } else {
          this.bsRangeValue = [];
        }
      }
    } else {
      this.service.listStatus = this.arcRequestStatus.All;
    }

    this.statusChange(this.service.listStatus);
  }

  filterDataLocalstorage() {
    var filtersModel: FilterListValues = {
      SearchKey: this.filterByKeyWords,
      DateTo: this.localStorageToDate,
      DateFrom: this.localStorageFromDate,
      Category: '',
      Priority: '',
      AssignTo: '',
      Status: this.service.listStatus,
      ViolationFieldType: "",
      Filter: this.filter,
      FeatureName: FeatureNameLocalStorage.ARCCM
    }
    return filtersModel;
  }

  getData() {
    this.isList = false;
    let resData;
    let resFilterByKeyWords = this.filterByKeyWords;
    let resStatus = this.service.listStatus === "All" ? "" : this.service.listStatus;
    this.progressbarService.show();
    this.service.getFilteredARCRequestForCM(this.associationId, this.role, resStatus, resFilterByKeyWords, this.dateTo, this.dateFrom, this.pageSkip, this.pageTake).subscribe(res => {
      resData = res;
      this.isApiResponceCome = true;
      this.progressbarService.hide();
      console.log('cm res ', res);
      if (resData.Errors.length == 0) {
        this.isList = true;
        this.arcList = resData.caseRequestListResults[0].arcRequestList;
        this.allCount = resData.caseRequestListResults[0].ResultCount;
        if (this.arcList !== null) {
          this.setPaginationData(this.arcList);
          this.SetDetailsOfNextPreviousOnDetailsPage();
        }
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }


  getAssociationAddressForList(request) {
    var associationUnit = {
      AssociationUnitAddress1: request.CreatedByUnitAddress1,
      AssociationUnitAddress2: request.CreatedByUnitAddress2,
      AssociationUnitCity: request.CreatedByUnitCity,
      AssociationUnitState: request.CreatedByUnitState,
      AssociationUnitZip: request.CreatedByUnitZip
    }
    return this.commonService.getAssociationAddressForList(associationUnit);
  }


  //Get Count of list
  getListCount() {
    var model = this.commonService.getListModel(this.associationId, this.userId, RoleEnum.BoardMember);
    let resData
    this.commonService.getListcount(model, DocumentFeatureName.ARCRequest, requestSubTypeCount.Count).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success) {
        this.arcStatusCount = resData.caseRequestListResults[0].ARCStatusCount;
      } else {
        this.arcStatusCount = resData.caseRequestListResults[0].ARCStatusCount;
      }
    });
  }



  addClass() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  clearFilter() {
    if (this.filterByKeyWords === "" && (this.bsRangeValue === null || this.bsRangeValue === [] || this.bsRangeValue.length === 0)) {
      return
    }
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    this.filterByKeyWords = "";
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.getData();
  }

  arcDetail(id, caseId) {
    this.service.caseId = caseId;
    this.service.arcRequestId = id;
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": id
      }
    };
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.router.navigate([AppRouteUrl.mainArcDetailCMRouteUrl], navigationExtras);
  }


  statusChange(s) {
    this.service.listStatus = s;
    /**For Manage Columns*/
    if (this.arcRequestStatus.Submitted === s) {
      this.seletedColumns = DisplayColumnsCM.SubmittedColumnsList;
      this.displayColumnsDdl = DisplayColumnsCM.SubmittedSelectedColumnsList;
    } else if (this.arcRequestStatus.All === s) {
      this.seletedColumns = DisplayColumnsCM.AllColumnsList;
      this.displayColumnsDdl = DisplayColumnsCM.AllSelectedColumnsList;
    } else if (this.arcRequestStatus.Approved === s) {
      this.seletedColumns = DisplayColumnsCM.ApprovedColumnsList;
      this.displayColumnsDdl = DisplayColumnsCM.ApprovedSelectedColumnsList;
    } else if (this.arcRequestStatus.Cancelled === s) {
      this.seletedColumns = DisplayColumnsCM.CancelledColumnsList;
      this.displayColumnsDdl = DisplayColumnsCM.CancelledSelectedColumnsList;
    } else if (this.arcRequestStatus.WorkCompleted === s) {
      this.seletedColumns = DisplayColumnsCM.CompletedColumnsList;
      this.displayColumnsDdl = DisplayColumnsCM.CompletedSelectedColumnsList;
    } else if (this.arcRequestStatus.Denied === s) {
      this.seletedColumns = DisplayColumnsCM.DeniedColumnsList;
      this.displayColumnsDdl = DisplayColumnsCM.DeniedSelectedColumnsList;
    }
    /**End For Manage Columns*/
    this.setPaginationVariables();
    this.getData();
    //get list count
    this.getListCount();
  }

  onClickChangeStatus(s) {
    if (this.service.listStatus === s) {
      return;
    } else {
      this.statusChange(s);
    }
  }

  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/


  //for comments 
  commentToggle() {
    if (this.isViewComment) {
      this.isViewComment = false;
    } else {
      this.isViewComment = true;
    }
  }

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(arcList) {
    this.TotalRecord = this.allCount;
    this.FilterArray = arcList;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = arcList.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize
    this.pageTake = clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getData();
    var elmnt: any = document.getElementById("contentTable");
    if (elmnt !== null) {
      elmnt.scrollTo(0, 0);
    }
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Next Previous
  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('ARCListCM');
    var temp: any = [];
    this.arcList.forEach(element => {
      temp.push({
        id: element.id,
        caseid: element.CaseId,
        status: element.ARCStatus
      });
    });
    localStorage.setItem('ARCListCM', JSON.stringify(temp));
  }

}
