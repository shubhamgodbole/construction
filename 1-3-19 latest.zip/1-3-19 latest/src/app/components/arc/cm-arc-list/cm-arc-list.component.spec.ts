import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmArcListComponent } from './cm-arc-list.component';

describe('CmArcListComponent', () => {
  let component: CmArcListComponent;
  let fixture: ComponentFixture<CmArcListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmArcListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmArcListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
