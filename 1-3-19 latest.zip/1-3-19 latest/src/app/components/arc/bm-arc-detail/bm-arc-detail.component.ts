import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { Router, ActivatedRoute } from '@angular/router';
import { NoteType, CaseOriginatingType, ARCStatus, IsAuthorized, CaseNoteModel } from '../arc-model';
import { FormGroup, FormGroupDirective, Validators, FormBuilder } from '@angular/forms';
import { CaseFeatureType, VoteModel, AudienceType, MotionModel } from '../../board-tasks/board-task.model';
import { TypeOfDocument, ImageNameEnums, RoleEnum, FeatureName, DownloadfeatureName, DocumentFeatureName, PlaceHolderText, VoteStatus, CallType, ActivityType, SourceType, TriggerType, StatusReason, FeaturePermissions, EmailAudience } from 'src/app/shared/Enums/commonEnums';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { MatDialogRef, MatDialog, MatSnackBar } from '@angular/material';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { Guid } from 'guid-typescript';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonConstant, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { RequestMsg } from '../../service-request/service-request.model';
import * as _ from 'lodash';

@Component({
  selector: 'app-bm-arc-detail',
  templateUrl: './bm-arc-detail.component.html',
  styleUrls: ['./bm-arc-detail.component.scss']
})
export class BmArcDetailComponent implements OnInit {
  propVivoName = CommonConstant.PropVivo;
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;

  notificationService: NotificationService;
  querySubcription: Subscription;
  role: string;
  userData: UserData;
  userId: string;
  profilePath: string;
  domain: string;
  userName: string;
  arcRequest: any;
  arcRequestDocuments: any;
  committeeMemberCaseNotes: any;
  caseNoteList: any;
  hocaseNotes: any;
  noteType = NoteType;
  caseNoteType: string;
  displayDiv: boolean = false;
  associationId: string;
  projectCompletionDocuments: any;
  caseOriginatingType = CaseOriginatingType;
  arcStatus = ARCStatus;

  bmCaseNotes: any[];

  //for esclate vote
  pendingDecision: any;
  esclateVoteCount: number;
  isVote: boolean;
  esclateVoterList: any[];
  esclateResult: string;

  /*Case Note Form*/
  cmCaseNoteForm: FormGroup;
  hoCaseNoteForm: FormGroup;
  bmCaseNoteForm: FormGroup;
  pmCaseNoteForm: FormGroup;

  isHoBtnDisabled: boolean = false;
  isBmBtnDisabled: boolean = false;
  isAuthorized = IsAuthorized;
  fileData = [];
  isCMBtnDisabled: boolean = false;

  decisionReason = [];
  voteRemarks = [];

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;

  isMotionCreated: boolean;

  resDataCreate: any;
  @ViewChild('formDirectiveCm') formDirectiveCm: FormGroupDirective;

  //for ho chat
  @ViewChild('formDirectiveHo') formDirectiveHo: FormGroupDirective;

  //for BM chat
  @ViewChild('formDirectiveBm') formDirectiveBm: FormGroupDirective;

  //for PM chat
  @ViewChild('formDirectivePm') formDirectivePm: FormGroupDirective;


  // view more 
  shoNDocs: number = 3;
  viewDocs: boolean;
  viwAllDocBtnMsg: string = "View All Attachments";

  // view more work completed Doc
  shoNDocsCompleted: number = 3;
  viewDocsCompleted: boolean;
  viwAllDocBtnMsgCompleted: string = "View All Attachments";

  readMoreBtn: boolean;
  desLimit: number = 160;
  readMoreDescBtnMsg: string = "Read More";

  //for Display Vote List
  isDisplayVoteList: boolean;
  isDisplayEsclateVoteList: boolean;


  //for image enum
  imageNameEnums = ImageNameEnums;


  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;

  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentDetails: boolean = false;

  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;

  //replyTo
  selectedReplyTo: string;
  placeHolderText = PlaceHolderText;

  allCaseNoteList = [];
  //vote status enum 
  VoteStatusEnum = VoteStatus;

  selectedConversionType: string = "All";

  noteTypeEnums = NoteType;
  activityTypeEnum = ActivityType;

  selectedActivityType: string;

  caseNotes: any = [];
  //file data for case note
  fileDataHoCase = [];
  fileDataBMCase = [];
  fileDataICCase = [];
  fileDataCMCase = [];
  isPMBtnDisabled: boolean = false;

  //For Send Notification
  featureId: string;
  pmCompanyAssociationMappingId: string;
  featureName: string;

  statusReasonEnum = StatusReason;
  callTypeEnum = CallType;



  /*Motion Form*/
  isDisplayMotionDiv: boolean = false;
  frmCreateMotion: FormGroup;
  isSubmitBtnDisabledMotion: boolean = false;
  resDataCreateMotion: any;
  @ViewChild('formDirectiveMotion') formDirectiveMotion: FormGroupDirective;
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  //Read More motion
  readMoreMotionBtn: boolean;
  readMoreMotionBtnMsg: string = "Read More";
  motionList = null;
  motionLimit: number = 160;

  motionMsg: string;
  motionIcon: string;
  voteReceiveMsg: string;
  isMotionVote: boolean;
  motionVoteCount: number;

  //requestMsg enum 
  requestMsgEnum = RequestMsg

  motionFeatureId: string;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;


  constructor(private service: ArcRequestApiService,
    private ngZone: NgZone, private _location: Location,
    private readonly appConfig: AppConfig,
    public commonService: CommonService,
    private route: ActivatedRoute,
    private emailNotification: EmailNotificationService,
    private readonly snb: MatSnackBar,
    private _matDialog: MatDialog,
    private progressbarService: ProgeressBarService,
    private router: Router, private formBuilder: FormBuilder) {
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    this.domain = this.userData.UserAssociations[0].Domain;
    this.userName = this.userData.UserName;
    this.role = this.userData.Role;
    this.userId = this.userData.UserProfileId;
    this.profilePath = this.userData.UserProfilePath;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.createCMCaseNoteForm();
    this.createPMCaseNoteForm();
    this.createHOCaseNoteForm();
    this.createBmCaseNoteForm();
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.ARC) {
          this.featureName = feature.Name
          this.featureId = feature.FeatureId
        }
      });
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Motion) {
          this.featureName = feature.Name
          this.motionFeatureId = feature.FeatureId
        }
      });

  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.service.arcRequestId = id;
        this.getDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.mainArcBMRouteUrl]);
      }
    });

    this.createMotionForm();

  }

  getDetail() {
    this.progressbarService.show();
    let resData;
    this.caseNoteList = [];
    this.projectCompletionDocuments = [];
    this.arcRequestDocuments = [];
    this.pendingDecision = null;
    this.hocaseNotes = [];
    this.committeeMemberCaseNotes = [];
    this.service.getARCRequestDetail(this.service.arcRequestId, this.domain).subscribe(response => {
      this.progressbarService.hide();
      resData = response;
      if (resData.RequestDetail.Success === true) {
        console.log(resData);
        this.displayDiv = true;
        this.arcRequest = resData.RequestDetail.ARCRequest;
        this.motionList = resData.RequestDetail.Motion;
        this.isShowNextAndPreviewsButton();
        this.service.caseId = this.arcRequest.CaseId;
        this.arcRequestDocuments = resData.RequestDetail.Document;
        this.projectCompletionDocuments = resData.RequestDetail.ProjectCompletionDocuments;
        this.setVoteRemark(resData.RequestDetail.CaseNoteDetails);
      } else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
  }

  /*Case Note Add Module*/
  createCMCaseNoteForm() {
    this.cmCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitCaseNoteForCM() {
    let resData;
    if (this.cmCaseNoteForm.valid) {
      this.isCMBtnDisabled = true;
      let model = this.createCMFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isCMBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARC, TriggerType.Update,
            AudienceType.BoardMember).subscribe(res => {
              console.log(res);
            });
          if (this.fileDataCMCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }

          this.resetCaseNoteCMForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  createCMFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataCMCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.cmCaseNoteForm.controls.caseNoteId.value,
        Note: this.cmCaseNoteForm.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.CommitteeMember,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        IsAssignedToBoard: false,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null
      }
    }
    return model;
  }

  resetCaseNoteCMForm() {
    this.cmCaseNoteForm.reset();
    this.formDirectiveCm.resetForm();
    this.isCMBtnDisabled = false;
    this.fileDataCMCase = [];
    this.fileData = [];
    this.selectedReplyTo = '';
  }

  /*Case Note Add  Module For Internal Chat*/
  createPMCaseNoteForm() {
    this.pmCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitCaseNoteForPM() {
    let resData;
    if (this.pmCaseNoteForm.valid) {
      this.isPMBtnDisabled = true;
      let model = this.createPMFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isPMBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARC, TriggerType.Update,
            AudienceType.BoardMember).subscribe(res => {
              console.log(res);
            });
          if (this.fileDataICCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetCaseNotePMForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log('error');
        }
      });
    }
  }

  createPMFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataICCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.pmCaseNoteForm.controls.caseNoteId.value,
        Note: this.pmCaseNoteForm.controls.comments.value,
        CaseId: this.arcRequest.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.PropertyManager,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }



  resetCaseNotePMForm() {
    this.pmCaseNoteForm.reset();
    this.formDirectivePm.resetForm();
    this.isPMBtnDisabled = false;
    this.fileDataICCase = [];
    this.selectedReplyTo = "";
    this.fileData = [];
  }

  /*Case Note Add Module for ho*/
  createHOCaseNoteForm() {
    this.hoCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }


  onSubmitCaseNoteForHO() {
    let resData;
    if (this.hoCaseNoteForm.valid) {
      this.isHoBtnDisabled = true;
      let model = this.createhoFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isHoBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARC, TriggerType.Update,
            AudienceType.BoardMember).subscribe(res => {
              console.log(res);
            });
          if (this.fileDataHoCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetCaseNoteHoForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  createhoFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataHoCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.hoCaseNoteForm.controls.caseNoteId.value,
        Note: this.hoCaseNoteForm.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.Homeowner,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        IsAssignedToBoard: false,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null
      }
    }
    return model;
  }

  resetCaseNoteHoForm() {
    this.hoCaseNoteForm.reset();
    this.formDirectiveHo.resetForm();
    this.isHoBtnDisabled = false;
    this.fileDataHoCase = [];
    this.selectedReplyTo = '';
    this.fileData = [];
  }

  /*Case Note Add Module For BM*/
  createBmCaseNoteForm() {
    this.bmCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }


  onSubmitCaseNoteForBM() {
    let resData;
    if (this.bmCaseNoteForm.valid) {
      this.isBmBtnDisabled = true;
      let model = this.createBMFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isCMBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARC, TriggerType.Update,
            AudienceType.BoardMember).subscribe(res => {
              console.log(res);
            });
          if (this.fileDataBMCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetCaseNoteBmForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  createBMFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataBMCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.bmCaseNoteForm.controls.caseNoteId.value,
        Note: this.bmCaseNoteForm.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.BoardMember,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        IsAssignedToBoard: false,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null
      }
    }
    return model;
  }

  resetCaseNoteBmForm() {
    this.bmCaseNoteForm.reset();
    this.formDirectiveBm.resetForm();
    this.isBmBtnDisabled = false;
    this.fileDataBMCase = [];
    this.selectedReplyTo = '';
    this.fileData = [];
  }

  //For Vote
  createEsclateVote(voteStatus, caseNoteId) {
    this.progressbarService.show();
    let model = this.createEsclateVoteModel(voteStatus);
    this.service.createEsclateVote(this.service.caseId, caseNoteId, this.arcRequest.id, this.associationId, model).subscribe(
      (response: any) => {
        this.progressbarService.hide();
        if (response.Success) {
          this.pendingDecision = response.CaseActivity;
          this.esclateVoteCount = this.pendingDecision.Votes.length;
          this.esclateResult = this.pendingDecision.VoteStatus;
          this.arcRequest = response.arcRequestDetail;
          //this.getServiceRequestDetail();
          this.caseNotes = this.caseNotes.map((a) => {
            if (a.CaseNotes.id === this.pendingDecision.id) {
              a.CaseNotes = this.pendingDecision;
            }
            return a;
          });
          if (this.esclateVoteCount > 0) {
            this.esclateVoterList = this.pendingDecision.Votes;
            let voteByUser = this.pendingDecision.Votes.find(v => v.CreatedByUserId === this.userId);
            if (voteByUser) {
              this.isVote = voteByUser.Vote;
            }
          }
        }
      }
    );
  }

  createEsclateVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: VoteModel = {
      Vote: vote,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      ProfilePath: this.profilePath,
      Remarks: ''
    }
    return model;
  }

  /*Display list of vote*/
  displayVoteListToggle() {
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }

  /*Display list of vote*/
  displayEsclateVoteListToggle() {
    if (this.isDisplayEsclateVoteList)
      this.isDisplayEsclateVoteList = false;
    else
      this.isDisplayEsclateVoteList = true;
  }

  // view more description
  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.desLimit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.readMoreDescBtnMsg = "Read Less";
      this.desLimit = this.arcRequest.ARCDescription.length;
    }
  }

  //view more documents
  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.arcRequestDocuments.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }

  //view more documents
  viewMoreCompletedDocs() {
    if (this.viewDocsCompleted) {
      this.shoNDocsCompleted = 3;
      this.viewDocsCompleted = false;
      this.viwAllDocBtnMsgCompleted = "View All Attachments";
    }
    else {
      this.shoNDocsCompleted = this.projectCompletionDocuments.length;
      this.viewDocsCompleted = true;
      this.viwAllDocBtnMsgCompleted = "View Less Attachments";
    }
  }
  //convert size in to byte
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  }


  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
    this.caseNoteType = caseNotes.NotesType
  }

  updateCaseNote() {
    if (this.editComments === "") {
      this.isEditValidation = true;
      return;
    }
    this.isEditValidation = false;
    let model = this.editCaseNoteModel();
    this.commonService.updateCaseNote(model).subscribe(res => {
      let resData;
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.resetEditCaseNote();
        this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);

        console.log("Case note updated successfully.");
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        this.notificationService.showNotification("Not Update");
      }
    });
  }

  editCaseNoteModel() {
    const model: CaseNoteEditModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: this.caseNoteType,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        RoleType: this.role
      }
    }
    return model;
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
    this.fileData = [];
  }


  /*Delete case note*/
  delete(id) {
    let resData;
    this.commonService.deleteCaseNote(id, this.service.caseId, this.associationId, this.domain).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })

  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;    
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }


  ngOnDestroy() {
    this.querySubcription.unsubscribe();
  }



  downloadDocument(filename) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.ARCRequest, DownloadfeatureName.Download).subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.commonService.downloadFile(resData.DocumentPath).subscribe(
          (response) => {
            let dataType = response.type;
            let binaryData = [];
            binaryData.push(response);
            let downloadLink = document.createElement('a');
            downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
            if (filename)
              downloadLink.setAttribute('download', filename);
            document.body.appendChild(downloadLink);
            downloadLink.click();
          }
        );
      }
      else if (resData.Success === false) {
        this.notificationService.showNotification("Not get");
      }
    });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.FilePath, DocumentFeatureName.ARCRequest, DownloadfeatureName.Download).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image");
      }
    });
  }

  toGoBack() {
    //this.router.navigate([AppRouteUrl.mainArcBMRouteUrl])
    let page = localStorage.getItem("previousPage");
    if (page === AppRouteUrl.mainHoaMembersDetailRouteUrl) {
      this._location.back();
    } else {
      this.router.navigate([AppRouteUrl.mainArcBMRouteUrl]);
    }
  }

  //**Next AND Preview */
  PreviousCase() {
    var current = this.service.arcRequestId;
    var serviceRequestAr = JSON.parse(localStorage.getItem('ARCListBM'));
    this.totalPages = serviceRequestAr.length - 1;
    var el = serviceRequestAr.find(a => { return a.id === current });
    var currentEl = serviceRequestAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = serviceRequestAr[currentEl - 1].id;
      this.service.arcRequestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  NextCase() {
    var current = this.service.arcRequestId;
    var serviceRequestAr = JSON.parse(localStorage.getItem('ARCListBM'));
    this.totalPages = serviceRequestAr.length - 1;
    var el = serviceRequestAr.find(a => { return a.id === current });
    var currentEl = serviceRequestAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < serviceRequestAr.length) {
      let prevIndex = serviceRequestAr[currentEl + 1].id;
      this.service.arcRequestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  isShowNextAndPreviewsButton() {
    let localStorageData = JSON.parse(localStorage.getItem('ARCListBM'));
    if (localStorageData === null || localStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.service.arcRequestId;
      var serviceRequestAr = JSON.parse(localStorage.getItem('ARCListBM'));
      this.totalPages = serviceRequestAr.length - 1;
      var el = serviceRequestAr.find(a => { return a.id === current });
      var currentEl = serviceRequestAr.indexOf(el);
      this.currentPage = currentEl;
    }
  }

  getUnitAddress() {
    var associationUnit = {
      AssociationUnitNumber: this.arcRequest.CreatedByUnitNumber,
      AssociationUnitAddress1: this.arcRequest.CreatedByUnitAddress1,
      AssociationUnitAddress2: this.arcRequest.CreatedByUnitAddress2,
      AssociationUnitCity: this.arcRequest.CreatedByUnitCity,
      AssociationUnitState: this.arcRequest.CreatedByUnitState,
      AssociationUnitZip: this.arcRequest.CreatedByUnitZip,
    }
    return this.commonService.getFullAssociationAddress(associationUnit);
  }

  getVenderAddress(venderDetail) {
    var associationUnit = {
      AssociationUnitAddress1: venderDetail.VendorAddress1,
      AssociationUnitAddress2: venderDetail.VendorAddress2,
      AssociationUnitCity: venderDetail.VendorCity,
      AssociationUnitState: venderDetail.VendorState,
      AssociationUnitZip: venderDetail.VendorZip,
    }
    return this.commonService.getAssociationAddressForList(associationUnit);
  }


  //change conversion
  changeConversion() {
    if (this.selectedConversionType === "All") {
      this.caseNotes = this.caseNoteList;
    } else if (this.selectedConversionType === NoteType.Homeowner) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.BoardMember) || (note.CaseNotes.NotesType === this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.Member) || (note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.Member));
    } else if (this.selectedConversionType === NoteType.BoardMember) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType === this.noteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.BoardMember);
    } else if (this.selectedConversionType === NoteType.PropertyManager) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType === this.noteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager || (note.CaseNotes.NotesType === this.noteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.BoardMember));
    } else if (this.selectedConversionType === this.activityTypeEnum.Phone) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Phone);
    } else if (this.selectedConversionType === this.activityTypeEnum.Email) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Email && note.CaseNotes.EmailAudience !== EmailAudience.None);
    } else if (this.selectedConversionType === this.activityTypeEnum.AssignToBoard) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.AssignToBoard);
    } else if (this.selectedConversionType === NoteType.CommitteeMember) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === this.noteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.CommitteeMember) || (note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.BoardMember));
    }
  }

  setListValue(caseNoteDetails) {
    let cmToHO = [];
    this.allCaseNoteList = caseNoteDetails;
    cmToHO = this.allCaseNoteList.filter(note => note.CaseNotes.RoleType === RoleEnum.CommitteeMember && note.CaseNotes.NotesType === this.noteType.Homeowner);

    this.caseNoteList = this.allCaseNoteList.filter(note => note.CaseNotes.RoleType !== RoleEnum.CommitteeMember && note.CaseNotes.NotesType !== this.noteType.CommitteeMember && note.CaseNotes.ActivityType !== ActivityType.Email);
    var emailActivity = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === ActivityType.Email && note.CaseNotes.EmailAudience !== EmailAudience.None);
    if (emailActivity !== null && emailActivity !== undefined && emailActivity.length > 0) {
      this.caseNoteList = this.caseNoteList.concat(emailActivity);
    }
    this.hocaseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.BoardMember) || (note.CaseNotes.NotesType === this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.Member) || (note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.Member));
    this.committeeMemberCaseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === this.noteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.CommitteeMember) || (note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.BoardMember));
    if (this.committeeMemberCaseNotes !== null && this.committeeMemberCaseNotes !== undefined) {
      this.caseNoteList = this.caseNoteList.concat(this.committeeMemberCaseNotes);
    }

    if (cmToHO !== null && cmToHO !== undefined && cmToHO.length > 0) {
      this.caseNoteList = this.caseNoteList.concat(cmToHO);
    }

    this.pendingDecision = this.allCaseNoteList.find(note => note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null);

    this.decisionReason = this.allCaseNoteList.filter(note => note.CaseNotes.StatusReason !== null);
 
    if (this.hocaseNotes !== null) {
      this.caseNoteList = this.caseNoteList.concat(this.hocaseNotes);
    }
    this.bmCaseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType === this.noteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.BoardMember || (note.CaseNotes.NotesType === this.noteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager));
    if (this.pendingDecision !== null && this.pendingDecision !== undefined) {
      this.esclateResult = this.pendingDecision.VoteStatus;
      this.committeeMemberCaseNotes.push(this.pendingDecision);
      //this.caseNoteList.push(this.pendingDecision);
      if (this.pendingDecision.CaseNotes.Votes.length > 0) {
        this.esclateVoteCount = this.pendingDecision.CaseNotes.Votes.length;
        this.esclateVoterList = this.pendingDecision.CaseNotes.Votes;
        let voteByUser = this.pendingDecision.CaseNotes.Votes.find(v => v.CreatedByUserId === this.userId);
        if (voteByUser) {
          this.isVote = voteByUser.Vote;
        }
      }
    }
    // Add motion in to case note
    if (this.motionList.length > 0) {
      this.motionList.map(m => {
        var motion = this.commonService.convertMotionToCaseNote(m);
        caseNoteDetails.push(motion);
      });
    }
    // get motion with final status
    var motionCaseNoteWithStatus = caseNoteDetails.filter(m => {
      return m.CaseNotes.VoteStatus !== null && m.CaseNotes.DocumentType === 'Motion';
    });

    // get motion with not final status
    var motionCaseNoteWithNotStatus = caseNoteDetails.find(m => {
      return m.CaseNotes.VoteStatus === null && m.CaseNotes.DocumentType === 'Motion';
    });
    if (motionCaseNoteWithNotStatus !== null && motionCaseNoteWithNotStatus !== undefined) {
      this.isMotionCreated = true;
      if (motionCaseNoteWithNotStatus.CaseNotes.Votes.length > 0) {
        let voteByUser = motionCaseNoteWithNotStatus.CaseNotes.Votes.find(v => v.CreatedByUserId === this.userId);
        if (voteByUser) {
          this.isMotionVote = voteByUser.Vote;
        }
      }
    }

    //concat motion
    if (motionCaseNoteWithStatus.length > 0) {
      this.allCaseNoteList = this.allCaseNoteList.concat(motionCaseNoteWithStatus);
    }

    // sort data with motion data
    this.allCaseNoteList = _.sortBy(this.allCaseNoteList, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();


    // sort data without motion data
    this.caseNoteList = _.sortBy(this.caseNoteList, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();

    //get before data
    var caseNoteBeforeVote = caseNoteDetails.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null || note.CaseNotes.DocumentType === "Motion" && note.CaseNotes.VoteStatus === null));

    if (caseNoteBeforeVote.length > 0) {
      caseNoteBeforeVote = _.sortBy(caseNoteBeforeVote, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();

      this.caseNoteList = caseNoteBeforeVote.concat(this.caseNoteList);
    }

    this.changeConversion();
  }

  removeListValue() {
    this.caseNoteList = [];
    this.hocaseNotes = [];
    this.committeeMemberCaseNotes = []
    this.pendingDecision = [];

    this.decisionReason = [];
    if (this.arcRequest.ARCRequestCommitteeVotes !== null) {
      this.voteRemarks = this.arcRequest.ARCRequestCommitteeVotes;
    }
    this.bmCaseNotes = [];
  }

  // upload Document
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        if (this.selectedReplyTo === NoteType.Homeowner) {
          this.fileDataHoCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.BoardMember) {
          this.fileDataBMCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.PropertyManager) {
          this.fileDataICCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.CommitteeMember) {
          this.fileDataCMCase = this.fileData;
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
    if (this.selectedReplyTo === NoteType.Homeowner) {
      this.fileDataHoCase = this.fileDataHoCase.filter(a => a.imageId !== imageId);;
    } else if (this.selectedReplyTo === NoteType.BoardMember) {
      this.fileDataBMCase = this.fileDataBMCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.PropertyManager) {
      this.fileDataICCase = this.fileDataICCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.CommitteeMember) {
      this.fileDataCMCase = this.fileDataCMCase.filter(a => a.imageId !== imageId);
    }
  }

  //change reply to 
  changeReplyTo() {
    this.isDisplayMotionDiv = false;
    this.fileData = [];
  }

  setVoteRemark(caseNoteDetails) {
    if (this.arcRequest.ARCRequestCommitteeVotes !== null && this.arcRequest.ARCRequestCommitteeVotes.length > 0) {
      this.arcRequest.ARCRequestCommitteeVotes.map(a => {
        var caseNote = this.service.convertVoteRemarkToCaseNote(a);
        caseNoteDetails.push(caseNote);
        this.caseNoteList.push(caseNote);
      });
    }
    if (caseNoteDetails !== null) {
      if (caseNoteDetails.length > 0) {
        this.setListValue(caseNoteDetails);
      }
    } else {
      this.removeListValue()
    }
  }



  /*Create motion of Service Request */
  createMotionForm() {
    this.frmCreateMotion = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitMotion() {
    if (this.frmCreateMotion.valid) {
      this.isSubmitBtnDisabledMotion = true;
      let model = this.createMotionFormModel();
      this.resetMotionForm();
      this.service.createMotion(model, this.arcRequest.id).subscribe(res => {
        this.isSubmitBtnDisabledMotion = false;
        this.resDataCreateMotion = res;
        this.emailNotification.sendNotifications(this.featureId, this.resDataCreateMotion.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId, SourceType.Web, FeatureName.Motion, TriggerType.Create,
          AudienceType.BoardMember).subscribe(res => {
            console.log(res);
          });
        if (this.resDataCreateMotion.caseRequestListResults[0].Success === true) {
          this.getDetail();
        }
        else if (this.resDataCreateMotion.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createMotionFormModel() {
    const model: MotionModel = {
      MotionId: '',
      CaseId: this.arcRequest.CaseId,
      AssociationId: this.associationId,
      CaseFeatureType: CaseFeatureType.ServiceRequest,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      AssociationName: this.userData.UserAssociations[0].Name,
      Description: this.frmCreateMotion.controls.comments.value,
      ProfilePath: this.profilePath
    }
    return model;
  }


  resetMotionForm() {
    this.frmCreateMotion.reset();
    if (this.formDirectiveMotion !== undefined) {
      this.formDirectiveMotion.resetForm();
    }
    this.isDisplayMotionDiv = false;
  }

  showMotionDiv() {
    this.resetMotionForm();
    this.selectedReplyTo = '';
    this.isDisplayMotionDiv = true;
  }

  /**Create Motion Vote */
  createMotionVote(voteStatus, id) {
    let model = this.createMotionVoteModel(voteStatus);
    let resData;
    this.progressbarService.show();
    this.service.createMotionVote(this.service.caseId, id, this.associationId, model).subscribe(res => {
      this.progressbarService.hide();
      resData = res;
      console.log(res);
      if (resData.caseRequestListResults[0].Success === true) {
        var motion = resData.caseRequestListResults[0].Motion;
        var caseMotion: any = this.commonService.convertMotionToCaseNote(motion);
        var count = motion.Votes.length;
        this.caseNotes = this.caseNotes.map((a) => {
          if (a.CaseNotes.id === caseMotion.CaseNotes.id) {
            a.CaseNotes = caseMotion.CaseNotes;
          }
          return a;
        });
        if (count > 0) {
          var voterList = caseMotion.CaseNotes.Votes;
          let voteByUser = caseMotion.CaseNotes.Votes.find(v => v.CreatedByUserId === this.userId);
          if (voteByUser) {
            this.isMotionVote = voteByUser.Vote;
          }
        }
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        console.log("error");
      }
    });
  }

  createMotionVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: VoteModel = {
      Vote: vote,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      ProfilePath: this.profilePath,
      Remarks: ''
    }
    return model;
  }


}
