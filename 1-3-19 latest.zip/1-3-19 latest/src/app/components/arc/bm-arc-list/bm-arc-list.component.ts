import { Component, OnInit, ViewChild } from '@angular/core';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { ARCStatus, DisplayColumnsBM } from '../arc-model';
import { fromEvent } from 'rxjs';
import { debounceTime, map } from 'rxjs/operators';
import { Router, NavigationExtras } from '@angular/router';
import { NoDataFoundCaseFeatureName, RoleEnum, MasterPaginationEnum, Pagination, DocumentFeatureName, requestSubTypeCount, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { MatPaginator } from '@angular/material';
import { FilterListValues, FeatureNameLocalStorage } from 'src/app/shared/common/models';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-bm-arc-list',
  templateUrl: './bm-arc-list.component.html',
  styleUrls: ['./bm-arc-list.component.scss']
})
export class BmArcListComponent implements OnInit {
  isList: boolean;
  filter = false;
  userData: UserData;
  associationId: string;
  arcList: any;
  arcStatusCount: any;
  count: number;
  arcRequestStatus = ARCStatus;
  role: string;
  //For filter by key word
  filterByKeyWords: string = "";
  @ViewChild('searchData') searchData: any;

  isHoBtnDisabled: boolean = false;
  //for filter by date
  dateTo: any;
  dateFrom: any;
  bsRangeValue: Date[] = [];


  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  /**End For Manage Columns*/

  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  //for display comments
  isViewComment: boolean = false;

  //for save data in localstorage
  localStorageFromDate;
  localStorageToDate;

  allCount: any;
  userId: string;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  
  isApiResponceCome = false;

  constructor(public service: ArcRequestApiService, private readonly appConfig: AppConfig,
    public commonService: CommonService,
    private router: Router, private progressbarService: ProgeressBarService, ) {
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.role = this.userData.Role;
    this.userId = this.userData.UserProfileId;
  }

  ngOnInit() {
    if (this.role === RoleEnum.PropertyManager) {
      this.router.navigate([AppRouteUrl.mainArcPMRouteUrl]);
    }
    if (this.service.isCommitteeMember) {
      this.router.navigate([AppRouteUrl.mainArcCMRouteUrl]);
    }
    this.service.listStatus = this.arcRequestStatus.All;
    /**For Manage Columns*/
    this.seletedColumns = DisplayColumnsBM.AllColumnsList;
    this.displayColumnsDdl = DisplayColumnsBM.AllSelectedColumnsList;
    this.defaultColumnsList = DisplayColumnsBM.DefaultColumnsList;
    //Filter By Key word
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.getData();
      });
    this.getLocalStorageData();
  }


  getLocalStorageData() {
    //get local storage filter data
    var data: FilterListValues = this.commonService.getFilterDataFromLocalStorge();
    if (data !== null && data !== undefined) {
      if (data.FeatureName === FeatureNameLocalStorage.ARCBM) {
        this.service.listStatus = data.Status;
        this.filterByKeyWords = data.SearchKey;
        this.dateFrom = data.DateFrom !== null && data.DateFrom !== undefined && data.DateFrom !== '' ? new Date(data.DateFrom).toUTCString() : '';
        this.dateTo = data.DateTo !== null && data.DateTo !== undefined && data.DateTo !== '' ? new Date(data.DateTo).toUTCString() : '';
        this.filter = data.Filter;
        if (this.dateFrom !== "" && this.dateFrom !== null && this.dateFrom !== undefined && this.dateTo !== "" && this.dateTo !== null && this.dateTo !== undefined) {
          this.bsRangeValue = [new Date(data.DateFrom), new Date(data.DateTo)];
        } else {
          this.bsRangeValue = [];
        }
      }
    } else {
      this.service.listStatus = this.arcRequestStatus.All;
    }

    this.statusChange(this.service.listStatus);
  }

  filterDataLocalstorage() {
    var filtersModel: FilterListValues = {
      SearchKey: this.filterByKeyWords,
      DateTo: this.localStorageToDate,
      DateFrom: this.localStorageFromDate,
      Category: '',
      Priority: '',
      AssignTo: '',
      Status: this.service.listStatus,
      ViolationFieldType: "",
      Filter: this.filter,
      FeatureName: FeatureNameLocalStorage.ARCBM
    }
    return filtersModel;
  }



  addClass() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  getData() {
    this.isList = false;
    let resData;
    let resFilterByKeyWords = this.filterByKeyWords;
    let resStatus = this.service.listStatus === ARCStatus.All ? "" : this.service.listStatus;
    this.progressbarService.show();
    this.service.getFilteredARCRequestForBM(this.associationId, this.role, resStatus, resFilterByKeyWords, this.dateTo, this.dateFrom, this.pageSkip, this.pageTake).subscribe(res => {
      resData = res;
      this.isApiResponceCome = true;
      this.progressbarService.hide();
      if (resData.Errors.length == 0) {
        this.arcList = resData.caseRequestListResults[0].arcRequestList;
        this.allCount = resData.caseRequestListResults[0].ResultCount;
        if (this.arcList !== null) {
          this.setPaginationData(this.arcList);
          this.SetDetailsOfNextPreviousOnDetailsPage();
        }
        this.isList = true;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  //for filter by date
  //for filter by date
  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.localStorageFromDate = event[0];
        this.dateTo = new Date(event[1]).toUTCString();
        this.localStorageToDate = event[1];
        this.getData();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getData();
    }
  }

  clearFilter() {
    if (this.filterByKeyWords === "" && (this.bsRangeValue === null || this.bsRangeValue === [] || this.bsRangeValue.length === 0)) {
      return
    }
    this.filterByKeyWords = "";
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    this.localStorageFromDate = "";
    this.localStorageToDate = "";
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.getData();
  }

  arcDetail(id, caseId) {
    this.service.caseId = caseId;
    this.service.arcRequestId = id;
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": id
      }
    };
    //set localstorage data
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.router.navigate([AppRouteUrl.mainArcDetailBMRouteUrl], navigationExtras);
  }

  //Get Address for list page
  getAssociationAddressForList(request) {
    var associationUnit = {
      AssociationUnitAddress1: request.CreatedByUnitAddress1,
      AssociationUnitAddress2: request.CreatedByUnitAddress2,
      AssociationUnitCity: request.CreatedByUnitCity,
      AssociationUnitState: request.CreatedByUnitState,
      AssociationUnitZip: request.CreatedByUnitZip
    }
    return this.commonService.getAssociationAddressForList(associationUnit);
  }




  statusChange(s) {
    this.service.listStatus = s;
    /**For Manage Columns*/
    if (this.arcRequestStatus.Submitted === s) {
      this.seletedColumns = DisplayColumnsBM.SubmittedColumnsList;
      this.displayColumnsDdl = DisplayColumnsBM.SubmittedSelectedColumnsList;
    } else if (this.arcRequestStatus.All === s) {
      this.seletedColumns = DisplayColumnsBM.AllColumnsList;
      this.displayColumnsDdl = DisplayColumnsBM.AllSelectedColumnsList;
    } else if (this.arcRequestStatus.Approved === s) {
      this.seletedColumns = DisplayColumnsBM.ApprovedColumnsList;
      this.displayColumnsDdl = DisplayColumnsBM.ApprovedSelectedColumnsList;
    } else if (this.arcRequestStatus.Cancelled === s) {
      this.seletedColumns = DisplayColumnsBM.CancelledColumnsList;
      this.displayColumnsDdl = DisplayColumnsBM.CancelledSelectedColumnsList;
    } else if (this.arcRequestStatus.WorkCompleted === s) {
      this.seletedColumns = DisplayColumnsBM.CompletedColumnsList;
      this.displayColumnsDdl = DisplayColumnsBM.CompletedSelectedColumnsList;
    } else if (this.arcRequestStatus.Denied === s) {
      this.seletedColumns = DisplayColumnsBM.DeniedColumnsList;
      this.displayColumnsDdl = DisplayColumnsBM.DeniedSelectedColumnsList;
    }
    /**End For Manage Columns*/
    this.setPaginationVariables();
    //get list count
    this.getListCount();
    this.getData();
  }

  onClickChangeStatus(s) {
    if (this.service.listStatus === s) {
      return;
    } else {
      this.statusChange(s);
    }
  }



  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/


  //for comments 
  commentToggle() {
    if (this.isViewComment) {
      this.isViewComment = false;
    } else {
      this.isViewComment = true;
    }
  }
  //Get Count of list
  getListCount() {
    var model = this.commonService.getListModel(this.associationId, this.userId, this.role);
    let resData
    this.commonService.getListcount(model, DocumentFeatureName.ARCRequest, requestSubTypeCount.Count).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success) {
        this.arcStatusCount = resData.caseRequestListResults[0].ARCStatusCount;
      } else {
        this.arcStatusCount = resData.caseRequestListResults[0].ARCStatusCount;
      }
    });
  }
  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(arcList) {
    this.TotalRecord = this.allCount;
    this.FilterArray = arcList;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = arcList.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize
    this.pageTake = clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getData();
    var elmnt: any = document.getElementById("contentTable");
    if (elmnt !== null) {
      elmnt.scrollTo(0, 0);
    }
  }

  //For Next Previous
  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('ARCListBM');
    var temp: any = [];
    this.arcList.forEach(element => {
      temp.push({
        id: element.id,
        caseid: element.CaseId,
        status: element.ARCStatus
      });
    });
    localStorage.setItem('ARCListBM', JSON.stringify(temp));
  }

}
