import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmArcListComponent } from './bm-arc-list.component';

describe('BmArcListComponent', () => {
  let component: BmArcListComponent;
  let fixture: ComponentFixture<BmArcListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmArcListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmArcListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
