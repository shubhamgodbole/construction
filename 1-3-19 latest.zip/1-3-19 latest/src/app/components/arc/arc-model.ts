import { VoteModel, RequestCaseNoteModel } from "../board-tasks/board-task.model";
import { RequestDocument } from "../market-place/market-list/market-list.model";

export enum ARCStatus {
    All = "All",
    Submitted = "Submitted",
    Approved = "Approved",
    Denied = "Denied",
    WorkCompleted = "WorkCompleted",
    Cancelled = "Canceled",
    AwaitingBoardDecision = "AwaitingBoardDecision"
}

export class requestARCVoteModel {
    requestId: string
    associationId: string
    ARCRequestCommitteeVote: VoteModel
}

export class DisplayPriority {
    public static PriorityList = [
        { value: "High", text: "High" },
        { value: "Medium", text: "Medium" },
        { value: "Low", text: "Low" }
    ]
}

export enum NoteType {
    BoardMember = "BoardMember",
    CommitteeMember = "CommitteeMember",
    Homeowner = "Homeowner",
    General = "General",
    PropertyManager = "PropertyManager"
}

export class arcCase {
    id: string;
    Title: string;
    Description: string;
    CreatedByUserId: string;
    CaseType: string;
    SubCaseType: string;
    CasePriority: string;
    CaseCategory: string;
    CaseSubCategory: string;
    CaseOriginatingType: string;
    AssociationId: string;
    AssociationName: string;
    AssociationUnitId: string;
    CreatedByUserName: string;
    StatusReason: string;
    AssignedPartyType: string;
    AssignedTo: string;
    IsAuthorized: string;
    CompanyCode: string;
    UserProfileId: string;
    UserName: string;
    CaseDocuments: string[]
}

export class ARCRequest {
    ProjectStartDate: string;
    ProjectEndDate: string;
    ProjectEstimatedCost: string;
    CreatedByUnitAddress1: string;
    CreatedByUnitAddress2: string;
    CreatedByUnitCity: string;
    CreatedByUnitState: string;
    CreatedByUnitZip: string;
    CreatedByUnitNumber: string;
    ARCRquestVendorDetail: ARCRquestVendorDetail
}

export class ARCRquestVendorDetail {
    VendorName: string;
    VendorEmail: string;
    VendorPhone: string;
    VendorAddress1: string;
    VendorAddress2: string;
    VendorState: string;
    VendorCity: string;
    VendorZip: string;
}

export class CancelStatusModel {
    RequestId: string;
    StatusType: string;
    CaseNotes: RequestCaseNoteModel;
}

export class CompleteStatusModel {
    RequestId: string;
    StatusType: string;
    AssociationId: string;
    Domain: string;
    TypeOfDocument: string;
    Document: any[];
    CaseNotes: RequestCaseNoteModel;
}

export enum CaseOriginatingType {
    Mobile = "Mobile",
    Website = "Website",
    Phone = "Phone",
    Email = "Email"
}

export enum IsAuthorized {
    Yes = "Yes",
    No = "No"
}

export enum AssignedPartyType {
    PROPVIVO = "PROPVIVO",
    Board = "Board",
    Vendor = "Vendor"
}


export class CaseNoteModel {
    AssociationId: string;
    Domain: string;
    TypeOfDocument: string;
    RequestId: string;
    Document: any[];
    CaseNotes: ARCCaseNoteModel;
}

export class ARCCaseNoteModel {
    CaseNoteId: string;
    Note: string;
    CreatedByUserId: string;
    CaseId: string;
    NotesType: string;
    CreatedByUserName: string;
    CaseFeatureType: string;
    StatusReason: string;
    ProfilePath: string;
    IsAssignedToBoard: boolean;
    RoleType: string;
    IsVotingRequired: boolean;
    ActivityType: string;
}

/**For Manage Columns for ho*/
export class DisplayColumns {
    public static ColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "AnticipatedStartDate", text: "Anticipated Start Date" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "Status", text: "Status" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "ApprovedOn", text: "Approved on" },
        { value: "WorkCompletedOn", text: "Work Completed On" },
        { value: "Attachements", text: "Attachements" },
        // { value: "Comments", text: "Comments" },
        { value: "Canceled On", text: "Canceled On" }
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
    ]

    public static AllSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "AnticipatedStartDate", text: "Anticipated Start Date" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
    ]

    public static ApprovedSelectedColumnsList = [
        { value: "AnticipatedStartDate", text: "Anticipated Start Date" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "ApprovedOn", text: "Approved on" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
        // { value: "Comments", text: "Comments" },
    ]

    public static SubmittedSelectedColumnsList = [
        { value: "AnticipatedStartDate", text: "Anticipated Start Date" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
        // { value: "Comments", text: "Comments" },
    ]

    public static DeniedSelectedColumnsList = [
        { value: "AnticipatedStartDate", text: "Anticipated Start Date" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "LastUpdatedOn", text: "Last Updated On" }
    ]

    public static CompletedSelectedColumnsList = [
        { value: "AnticipatedStartDate", text: "Anticipated Start Date" },
        { value: "WorkCompletedOn", text: "Work Completed On" },
        { value: "CreatedOn", text: "Created On" },
        { value: "Attachements", text: "Attachements" }
    ]


    public static CancelledSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "Canceled On", text: "Canceled On" }
    ]

    public static AllColumnsList = [
        "Title", "Created On", "Anticipated Start Date", "Anticipated End Date", "Status", "Comments"
    ]

    public static ApprovedColumnsList = [
        "Title", "Anticipated Start Date", "Approved on", "Anticipated End Date", "Last Updated On", "Comments"
    ]

    public static SubmittedColumnsList = [
        "Title", "Anticipated Start Date", "Anticipated End Date", "Last Updated On", "Comments"
    ]

    public static DeniedColumnsList = [
        "Title", "Anticipated Start Date", "Anticipated End Date", "Last Updated On"
    ]

    public static CompletedColumnsList = [
        "Title", "Created On", "Anticipated End Date", "Work Completed On", "Attachments"
    ]


    public static CancelledColumnsList = [
        "Title", "Created On", "Canceled On"
    ]

}

/**End For Manage Columns*/

/**For Manage Columns for BM*/
export class DisplayColumnsBM {
    public static ColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "Action", text: "Action" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "ApprovedOn", text: "Approved on" },
        { value: "Completed Date", text: "Completed Date" },
        { value: "Attachements", text: "Attachements" },
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Lot Number", text: "Lot Number" },
        { value: "Unit Address", text: "Unit Address" }
    ]

    public static AllSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
    ]

    public static ApprovedSelectedColumnsList = [
        // { value: "Comments", text: "Comments" },
        { value: "AnticipatedStartDate", text: "Anticipated Start Date" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "ApprovedOn", text: "Approved On" }
    ]

    public static SubmittedSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "AnticipatedStartDate", text: "Anticipated Start Date" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "Action", text: "Action" },
        // { value: "Comments", text: "Comments" },
    ]

    public static DeniedSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
    ]

    public static CompletedSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "Completed Date", text: "Completed Date" },
        { value: "Attachements", text: "Attachements" },
        // { value: "Comments", text: "Comments" },
    ]

    public static CancelledSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
    ]

    public static AllColumnsList = [
        "Title", "Lot Number", "Unit Address", "Created On", "Status", "Comments"
    ]

    public static ApprovedColumnsList = [
        "Title", "Lot Number", "Unit Address", "Anticipated Start Date", "Anticipated End Date", "Approved On", "Comments"
    ]

    public static SubmittedColumnsList = [
        "Title", "Lot Number", "Unit Address", "Created On", "Anticipated Start Date", "Anticipated End Date", "Action", "Comments"
    ]

    public static DeniedColumnsList = [
        "Title", "Lot Number", "Unit Address", "Last Updated On"]

    public static CompletedColumnsList = [
        "Title", "Lot Number", "Unit Address", "Created On", "Anticipated End Date", "Completed Date", "Attachements", "Comments"
    ]


    public static CancelledColumnsList = [
        "Title", "Lot Number", "Unit Address", "Created On", "Last Updated On"
    ]

}

/**End For Manage Columns*/

/**For Manage Columns for CM*/
export class DisplayColumnsCM {
    public static ColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "Action", text: "Action" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "Reason", text: "Reason" },
        { value: "ApprovedOn", text: "Approved on" },
        { value: "Completed Date", text: "Completed Date" },
        { value: "Attachements", text: "Attachements" }
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Lot Number", text: "Lot Number" },
        { value: "Unit Address", text: "Unit Address" }
    ]

    public static AllSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "Status", text: "Status" },
        // { value: "Comments", text: "Comments" },
    ]

    public static ApprovedSelectedColumnsList = [
        { value: "ApprovedOn", text: "Approved on" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        // { value: "Comments", text: "Comments" },
    ]

    public static SubmittedSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "Action", text: "Action" },
        // { value: "Comments", text: "Comments" },
        "Title", "Lot Number", "Unit Address", "Created On", "Anticipated End Date", "Action", "Comments"

    ]

    public static DeniedSelectedColumnsList = [
        { value: "LastUpdatedOn", text: "Last Updated On" },
        { value: "Reason", text: "Reason" }
    ]

    public static CancelledSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "LastUpdatedOn", text: "Last Updated On" },
    ]

    public static CompletedSelectedColumnsList = [
        { value: "CreatedOn", text: "Created On" },
        { value: "AnticipatedEndDate", text: "Anticipated End Date" },
        { value: "CompletedDate", text: "Completed Date" },
        { value: "Attachements", text: "Attachements" },
        // { value: "Comments", text: "Comments" },
    ]

    public static AllColumnsList = [
        "Title", "Lot Number", "Unit Address", "Created On", "Status", "Comments"
    ]

    public static ApprovedColumnsList = [
        "Title", "Lot Number", "Unit Address", "Approved on", "Anticipated End Date", "Comments"
    ]

    public static SubmittedColumnsList = [
        "Title", "Lot Number", "Unit Address", "Created On", "Anticipated End Date", "Action", "Comments"
    ]

    public static DeniedColumnsList = [
        "Title", "Lot Number", "Unit Address", "Last Updated On", "Reason"
    ]

    public static CompletedColumnsList = [
        "Title", "Lot Number", "Unit Address", "Created On", "Anticipated End Date", "Completed Date", "Attachements", "Comments"
    ]


    public static CancelledColumnsList = [
        "Title", "Lot Number", "Unit Address", "Created On", "Last Updated On"
    ]

}

/**End For Manage Columns*/

/**For Manage Columns for PM*/
export class DisplayColumnsPM {
    public static ColumnsList = [
        { value: "Status", text: "Status" },
        { value: "Time Elapsed", text: "Time Elapsed" },
        { value: "Time Left", text: "Time Left" },
        { value: "Reason", text: "Reason" },
        { value: "Completion Time", text: "Completion Time" },
        // { value: "Comments", text: "Comments" },
        { value: "Denied On", text: "Denied On" },
        { value: "Canceled On", text: "Canceled On" }
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Association", text: "Association" },
        { value: "Lot No.", text: "Lot No." },
        { value: "Lot Address", text: "Lot Address" },
        { value: "Created On", text: "Created On" },
        { value: "Assign To", text: "Assign To" }
    ]

    public static AllSelectedColumnsList = [
        { value: "Status", text: "Status" },
    ]

    public static ApprovedSelectedColumnsList = [
        { value: "Time Elapsed", text: "Time Elapsed" },
        { value: "Approved On", text: "Approved On" },
        // { value: "Time Left", text: "Time Left" },
        // { value: "Comments", text: "Comments" },
    ]

    public static SubmittedSelectedColumnsList = [
        { value: "Time Elapsed", text: "Time Elapsed" },
        // { value: "Comments", text: "Comments" },
    ]

    public static DeniedSelectedColumnsList = [
        { value: "DeniedOn", text: "Denied On" },
        // { value: "Reason", text: "Reason" },
        // { value: "Comments", text: "Comments" },
    ]

    public static CompletedSelectedColumnsList = [
        // { value: "CompletionTime", text: "Completion Time" },
        { value: "Completed On", text: "Completed On" },
    ]

    public static CancelledSelectedColumnsList = [
        { value: "CanceledOn", text: "Canceled On" }
    ]

    public static AllColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Assign To", "Status"
    ]

    public static ApprovedColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On","Approved On", "Assign To", "Time Elapsed", "Time Left", "Comments"
    ]

    public static SubmittedColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Assign To", "Time Elapsed", "Comments"
    ]

    public static DeniedColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Denied On", "Assign To", "Reason", "Comments"
    ]


    public static CompletedColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Completed On","Updated By", "Completion Time", "Assign To"
    ]

    public static CancelledColumnsList = [
        "Title", "Association", "Lot No.", "Lot Address", "Created On", "Canceled On", "Updated By", "Assign To"
    ]

}

/**End For Manage Columns*/
