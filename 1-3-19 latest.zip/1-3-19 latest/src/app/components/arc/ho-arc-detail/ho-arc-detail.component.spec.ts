import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoArcDetailComponent } from './ho-arc-detail.component';

describe('HoArcDetailComponent', () => {
  let component: HoArcDetailComponent;
  let fixture: ComponentFixture<HoArcDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoArcDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoArcDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
