import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { UserData } from 'src/app/shared/models/user-data-model';
import { NoteType, CaseNoteModel, CaseFeatureType } from '../../board-tasks/board-task.model';
import { FormGroup, FormGroupDirective, FormBuilder, Validators, SelectMultipleControlValueAccessor } from '@angular/forms';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { AppConfig } from 'src/app/app.config';
import { Router, ActivatedRoute } from '@angular/router';
import { TypeOfDocument, StatusReason, ImageNameEnums, RoleEnum, FeatureName, DownloadfeatureName, DocumentFeatureName, CallType, ActivityType, PlaceHolderText, VoteStatus, FeaturePermissions, SourceType, TriggerType, AudienceType, EmailAudience } from 'src/app/shared/Enums/commonEnums';
import { ARCStatus, CancelStatusModel, CompleteStatusModel, CaseOriginatingType, IsAuthorized } from '../arc-model';
import { Subscription } from 'rxjs';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Guid } from 'guid-typescript';
import { CommonService } from 'src/app/services/common.service';
import { MatDialogRef, MatSnackBar, MatDialog } from '@angular/material';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonConstant, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { RequestMsg } from '../../service-request/service-request.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-ho-arc-detail',
  templateUrl: './ho-arc-detail.component.html',
  styleUrls: ['./ho-arc-detail.component.scss']
})
export class HoArcDetailComponent implements OnInit {
  propVivoName = CommonConstant.PropVivo;
  userData: UserData;
  userId: string;
  domain: string;
  profilePath: string;
  userName: string;
  arcRequest: any;
  arcRequestDocuments: any;
  caseNotes: any;
  hocaseNotes: any = [];
  noteType = NoteType;
  displayDiv: boolean = false;
  workComplatedbtnDisabled: boolean;
  cancelbtnDisabled: boolean;
  associationId: string;
  arcStatus = ARCStatus;
  decisionReason = [];
  voteRemarks = [];
  allChat = [];
  caseOriginatingType = CaseOriginatingType;
  isAuthorized = IsAuthorized;
  projectCompletionDocuments: any;
  status;
  docError: string = "";
  /*Cancel Status*/
  frmCancelStatus: FormGroup;
  isSubmitBtnDisabledCancel: boolean = false;

  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentDetails: boolean = false;

  @ViewChild('formDirectiveCancel') formDirectiveCancel: FormGroupDirective;

  /*Work Completed Status*/
  frmWorkComplatedStatus: FormGroup;
  isSubmitBtnDisabledWorkComplated: boolean = false;
  @ViewChild('formDirectiveWorkComplated') formDirectiveWorkComplated: FormGroupDirective;


  /*Case Note Form*/
  hoCaseNoteForm: FormGroup;
  fileData = [];
  workCompletedDocumentsData = [];
  isHoBtnDisabled: boolean = false;

  resDataCreate: any;

  // view more 
  shoNDocs: number = 3;
  viewDocs: boolean;
  viwAllDocBtnMsg: string = "View All Attachments";

  // view more work completed Doc
  shoNDocsCompleted: number = 3;
  viewDocsCompleted: boolean;
  viwAllDocBtnMsgCompleted: string = "View All Attachments";

  readMoreBtn: boolean;
  readMoreDescBtnMsg: string = "Read More";
  desLimit: number = 160;


  querySubcription: Subscription;
  @ViewChild('formDirectiveHo') formDirectiveHo: FormGroupDirective;
  caseNoteList: any[];

  notificationService: NotificationService;

  //for image enum
  imageNameEnums = ImageNameEnums;

  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;
  caseNoteType: string;
  role: string;

  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;

  MobActoin = false;
  MobDetail = false;
  MobChat = false;
  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;

  //For Send Notification
  featureId: string;
  pmCompanyAssociationMappingId: string;
  featureName: string;

  callTypeEnum = CallType;
  activityTypeEnum = ActivityType;

  placeHolderText = PlaceHolderText;
  statusReasonEnum = StatusReason;

  reasonType: string = '';
  VoteStatusEnum = VoteStatus;

  //requestMsg enum 
  requestMsgEnum = RequestMsg;

  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  acceptMediaType = AcceptFilesConstant.AcceptExcelMediaType;

   //For Permission
   permissionFeatureName = FeatureName;
   permission = FeaturePermissions;



  constructor(private service: ArcRequestApiService, private readonly appConfig: AppConfig,
    private ngZone: NgZone, private emailNotification: EmailNotificationService,
    private route: ActivatedRoute, private progressbarService: ProgeressBarService,
    public commonService: CommonService, private readonly snb: MatSnackBar,
    private _matDialog: MatDialog,
    private router: Router, private formBuilder: FormBuilder) {
    this.userData = this.appConfig.getCurrentUser();
    this.domain = this.userData.UserAssociations[0].Domain;
    this.role = this.userData.Role;
    this.userName = this.userData.UserName;
    this.userId = this.userData.UserProfileId;
    this.profilePath = this.userData.UserProfilePath;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.notificationService = new NotificationService(snb);
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.ARCRequests) {
          this.featureName = feature.Name
          this.featureId = feature.FeatureId
        }
      });
  }

  MobActionToggle() {
    if (this.MobActoin)
      this.MobActoin = false;
    else
      this.MobActoin = true;
  }

  MobShowDetail() {
    if (this.MobDetail)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  MobShowChat() {
    if (this.MobChat)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {
    this.createHOCaseNoteForm();
    this.createCancelStatusForm();
    this.createWorkCompletedStatusForm();
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.service.arcRequestId = id;
        this.getDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.mainArcHORouteUrl]);
      }
    });
  }

  getDetail() {
    let resData;
    this.progressbarService.show();
    this.service.getARCRequestDetail(this.service.arcRequestId, this.domain).subscribe(response => {
      resData = response;
      this.progressbarService.hide();
      console.log('res detail ho', resData);
      if (resData.RequestDetail.Success === true) {
        this.arcRequest = resData.RequestDetail.ARCRequest;
        this.isShowNextAndPreviewsButton();
        this.service.caseId = this.arcRequest.CaseId;
        this.arcRequestDocuments = resData.RequestDetail.Document;
        this.projectCompletionDocuments = resData.RequestDetail.ProjectCompletionDocuments;
        this.setListValue(resData.RequestDetail.CaseNoteDetails);
      }
    });
  }

  setListValue(caseNoteDetails) {
    //this.caseNotes = resData.RequestDetail.CaseNotes;
    this.caseNoteList = caseNoteDetails;
    this.decisionReason = this.caseNoteList.filter(note => note.CaseNotes.StatusReason !== null);
    // this.voteRemarks = this.arcRequest.ARCRequestCommitteeVotes;
    this.hocaseNotes = this.caseNoteList.filter(note => note.CaseNotes.NotesType == this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.BoardMember || note.CaseNotes.NotesType === this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.CommitteeMember || note.CaseNotes.NotesType === this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.Member || note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.Member || note.CaseNotes.NotesType == this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.PropertyManager || note.CaseNotes.IsAssignedToBoard === true || note.CaseNotes.ActivityType === ActivityType.Phone || (note.CaseNotes.ActivityType === ActivityType.Email && note.CaseNotes.EmailAudience === EmailAudience.All));
    this.allChat = this.hocaseNotes;
    if (this.decisionReason !== null && this.decisionReason !== undefined) {
      this.allChat = this.allChat.concat(this.decisionReason);
    }
    this.displayDiv = true;

    var assignToBoardAfterVote = caseNoteDetails.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus !== null));
    if (assignToBoardAfterVote.length > 0) {
      assignToBoardAfterVote.map(a => {
        this.allChat.push(a);
      })
    }

    this.allChat = _.sortBy(this.allChat, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();

     //get before data
     var caseNoteBeforeVote = caseNoteDetails.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null || note.CaseNotes.DocumentType === "Motion" && note.CaseNotes.VoteStatus === null));

     if (caseNoteBeforeVote.length > 0) {
       caseNoteBeforeVote = _.sortBy(caseNoteBeforeVote, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();
 
       this.caseNoteList = caseNoteBeforeVote.concat(this.caseNoteList);
     }
 
  }

  
  getUnitAddress() {
    var associationUnit = {
      AssociationUnitNumber: this.arcRequest.CreatedByUnitNumber,
      AssociationUnitAddress1: this.arcRequest.CreatedByUnitAddress1,
      AssociationUnitAddress2: this.arcRequest.CreatedByUnitAddress2,
      AssociationUnitCity: this.arcRequest.CreatedByUnitCity,
      AssociationUnitState: this.arcRequest.CreatedByUnitState,
      AssociationUnitZip: this.arcRequest.CreatedByUnitZip,
    }
    return this.commonService.getFullAssociationAddress(associationUnit);
  }

  removeListValue() {
    this.caseNoteList = [];
    this.decisionReason = [];
    this.hocaseNotes = [];
    this.allChat = [];
  }

  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }


  /*Case Note Add Module*/
  createHOCaseNoteForm() {
    this.hoCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }


  onSubmitCaseNoteForHO() {
    if (this.hoCaseNoteForm.valid) {
      this.isHoBtnDisabled = true;
      let model = this.createHoFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isHoBtnDisabled = false;
        this.resDataCreate = res;
        if (this.resDataCreate.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, this.resDataCreate.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARCRequests, TriggerType.Create,
            AudienceType.HomeOwner).subscribe(res => {
              console.log(res);
            });
          //  console.log(this.resDataCreate);
          if (this.fileData.length > 0)
            this.getDetail();
          else {
            if (this.resDataCreate.caseRequestListResults[0].CaseNoteDetails !== null) {
              this.setListValue(this.resDataCreate.caseRequestListResults[0].CaseNoteDetails);
            } else {
              this.removeListValue();
            }
          } this.resetCaseNoteHOForm();
        }
        else if (this.resDataCreate.caseRequestListResults[0].Success === false) {
          console.log("Not Save");
        }
      });
    }
  }

  createHoFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      RequestId: this.arcRequest.id,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: this.hoCaseNoteForm.controls.caseNoteId.value,
        Note: this.hoCaseNoteForm.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.Homeowner,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: RoleEnum.Member,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetCaseNoteHOForm() {
    this.hoCaseNoteForm.reset();
    this.formDirectiveHo.resetForm();
    this.isHoBtnDisabled = false;
    this.fileData = [];
    this.docError = "";
  }


  /*ARC Work Completed */

  createWorkCompletedStatusForm() {
    this.frmWorkComplatedStatus = this.formBuilder.group({
      reasonText: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  workComplatedStatus() {
    if (!this.frmWorkComplatedStatus.valid) {
      return;
    } else if (this.workCompletedDocumentsData.length === 0) {
      this.docError = "Please select socument"
      return;
    }
    let resData;
    this.workComplatedbtnDisabled = true;
    let model = this.createWorkCompletedStatusModel();
    this.service.updateArcStatus(model).subscribe(res => {
      this.workComplatedbtnDisabled = false;
      console.log('update status res ', res);
      resData = res;
     
      this.resetWorkComplatedForm();
      this.getDetail();
      this.emailNotification.sendNotifications(this.featureId, resData.RequestId, this.userId, this.pmCompanyAssociationMappingId,
        SourceType.Web, FeatureName.ARCRequests, TriggerType.Update_Completed,
        AudienceType.HomeOwner).subscribe(res => {
          console.log(res);
        });
    });
  }

  onWorkCompletedChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.workCompletedDocumentsData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
          if (this.workCompletedDocumentsData.length > 0) {
            this.docError = "";
          }
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  createWorkCompletedStatusModel() {
    const model: CompleteStatusModel = {
      RequestId: this.service.arcRequestId,
      StatusType: ARCStatus.WorkCompleted,
      AssociationId: this.associationId,
      Domain: this.domain,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.workCompletedDocumentsData,
      CaseNotes: {
        CaseNoteId: null,
        CreatedByUserId: this.userId,
        CreatedByUserName: this.userName,
        ProfilePath: this.profilePath,
        Note: this.frmWorkComplatedStatus.controls.reasonText.value,
        CaseId: this.service.caseId,
        NotesType: null,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: StatusReason.WorkCompleted,
        RoleType: RoleEnum.Member,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetWorkComplatedForm() {
    this.frmWorkComplatedStatus.reset();
    this.formDirectiveWorkComplated.resetForm();
    this.workCompletedDocumentsData = [];
    this.docError = "";
    this.reasonType = "";
  }

  /*ARC Cancel */

  createCancelStatusForm() {
    this.frmCancelStatus = this.formBuilder.group({
      reasonText: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  cancelStatus() {
    if (!this.frmCancelStatus.valid) {
      return;
    }
    let model = this.createCancelStatusModel();
    this.cancelbtnDisabled = true;
    let resData;
    this.service.updateArcStatus(model).subscribe(res => {
      console.log('cancel res ', res);
      this.cancelbtnDisabled = false;
     
      this.resetCancelForm();
      this.getDetail();
      this.emailNotification.sendNotifications(this.featureId, resData.RequestId, this.userId, this.pmCompanyAssociationMappingId,
        SourceType.Web, FeatureName.ARCRequests, TriggerType.Update_Cancelled,
        AudienceType.HomeOwner).subscribe(res => {
          console.log(res);
        });
    });
  }

  createCancelStatusModel() {
    const model: CancelStatusModel = {
      RequestId: this.service.arcRequestId,
      StatusType: ARCStatus.Cancelled,
      CaseNotes: {
        CaseNoteId: null,
        CreatedByUserId: this.userId,
        CreatedByUserName: this.userName,
        ProfilePath: this.profilePath,
        Note: this.frmCancelStatus.controls.reasonText.value,
        CaseId: this.service.caseId,
        NotesType: null,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: StatusReason.Cancelled,
        RoleType: RoleEnum.Member,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetCancelForm() {
    this.frmCancelStatus.reset();
    this.formDirectiveCancel.resetForm();
    this.fileData = [];
    this.docError = "";
    this.reasonType = "";
  }

  //convert size in to byte
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  }

  // Remove Image
  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }

  // Remove Image Work Completed
  removeImageWorkCompleted(imageId) {
    this.workCompletedDocumentsData = this.workCompletedDocumentsData.filter(a => a.imageId !== imageId);
  }


  // view more description
  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.desLimit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.readMoreDescBtnMsg = "Read Less";
      this.desLimit = this.arcRequest.ARCDescription.length;
    }
  }

  //view more documents
  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.arcRequestDocuments.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }

  //view more documents
  viewMoreCompletedDocs() {
    if (this.viewDocsCompleted) {
      this.shoNDocsCompleted = 3;
      this.viewDocsCompleted = false;
      this.viwAllDocBtnMsgCompleted = "View All Attachments";
    }
    else {
      this.shoNDocsCompleted = this.projectCompletionDocuments.length;
      this.viewDocsCompleted = true;
      this.viwAllDocBtnMsgCompleted = "View Less Attachments";
    }
  }

  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
    this.caseNoteType = caseNotes.NotesType
  }

  updateCaseNote() {
    if (this.editComments === "") {
      this.isEditValidation = true;
      return;
    }
    this.isEditValidation = false;
    let model = this.editCaseNoteModel();
    this.commonService.updateCaseNote(model).subscribe(res => {
      let resData;
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.resetEditCaseNote();
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
            this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);
          }
        }
        console.log("Case note updated successfully.");
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        this.notificationService.showNotification("Not Update");
      }
    });
  }

  editCaseNoteModel() {
    const model: CaseNoteEditModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: this.caseNoteType,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        RoleType: RoleEnum.Member
      }
    }
    return model;
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
  }


  /*Delete case note*/
  delete(id) {
    let resData;
    this.commonService.deleteCaseNote(id, this.service.caseId, this.associationId, this.domain).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
            this.setListValue(resData.caseRequestListResults[0].CaseNoteDetails);

          }
        }
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })

  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }

  downloadDocument(filename) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.ARCRequest,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Not get");
        }
      });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.FilePath, DocumentFeatureName.ARCRequest, DownloadfeatureName.Download).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image");
      }
    });
  }

  toGoBack() {
    this.router.navigate([AppRouteUrl.mainArcHORouteUrl])
  }

  ngOnDestroy() {
    this.querySubcription.unsubscribe();
    localStorage.removeItem('ARCListHo');
  }

  //**Next AND Preview */
  PreviousCase() {
    var current = this.service.arcRequestId;
    var listArr = JSON.parse(localStorage.getItem('ARCListHo'));
    this.totalPages = listArr.length - 1;
    var el = listArr.find(a => { return a.id === current });
    var currentEl = listArr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = listArr[currentEl - 1].id;
      this.service.arcRequestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  NextCase() {
    var current = this.service.arcRequestId;
    var listArr = JSON.parse(localStorage.getItem('ARCListHo'));
    this.totalPages = listArr.length - 1;
    var el = listArr.find(a => { return a.id === current });
    var currentEl = listArr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < listArr.length) {
      let prevIndex = listArr[currentEl + 1].id;
      this.service.arcRequestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  isShowNextAndPreviewsButton() {
    let localStorageData = JSON.parse(localStorage.getItem('ARCListHo'));
    if (localStorageData === null || localStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.service.arcRequestId;
      var listArr = JSON.parse(localStorage.getItem('ARCListHo'));
      this.totalPages = listArr.length - 1;
      var el = listArr.find(a => { return a.id === current });
      var currentEl = listArr.indexOf(el);
      this.currentPage = currentEl;
    }
  }

  onClickReason(reasonType) {
    this.reasonType = reasonType;
  }

  checkIconAssignToBoard(assignTOBoard) {
    if (assignTOBoard !== null && assignTOBoard !== undefined) {
      if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined || assignTOBoard.VoteStatus === VoteStatus.Withdraw) {
        return CommonConstant.MotionMovedIcon;
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
        return CommonConstant.MotionPassedIcon;
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
        return CommonConstant.MotionFailedIcon;
      }
    }
  }

  checkTextAssignToBoard(assignTOBoard) {
    if (assignTOBoard !== null && assignTOBoard !== undefined) {
      if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined) {
          return "Decision is Pending"
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
        return VoteStatus.Approved
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
        return VoteStatus.Denied
      }
    }
  }


}
