import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  MatCheckboxModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatRippleModule,
  MatSelectModule,
  MatSnackBarModule,
  MatTooltipModule,
  MatTreeModule,
  MatButtonModule,
  MatBottomSheetModule,
  MatButtonToggleModule,
  MatPaginatorModule,
} from '@angular/material';
import { CommonModule } from '@angular/common';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { RouterModule, Routes } from '@angular/router';
import { CmArcListComponent } from './cm-arc-list/cm-arc-list.component';
import { CmArcDetailComponent } from './cm-arc-detail/cm-arc-detail.component';
import { NoCaseNoteFoundComponent } from 'src/app/shared/component/no-case-note-found/no-case-note-found.component';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { TransformBlankValueModule } from 'src/app/shared/pipes/blankValue/transform-blank-value.module';
const routes: Routes = [
  {
    path: '',
    component: CmArcListComponent
  },
  {
    path: 'cm-arc-detail',
    component: CmArcDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    NoCaseNoteFoundModule,
    SafeModule,
    MatInputModule,
    MatListModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatMenuModule,
    MatRippleModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatTreeModule,
    NumberOnlyDirectiveModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    FormsModule,
    RouterModule.forChild(routes),
    BsDatepickerModule.forRoot(),
    FilterUniqueArrayModule,
    HideIfUnauthorizedModule,
    TransformBlankValueModule
  ],
  declarations: [CmArcListComponent, CmArcDetailComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [RouterModule]
})
export class CmArcModule { }
