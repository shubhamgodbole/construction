import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateArcComponent } from './create-arc.component';

describe('CreateArcComponent', () => {
  let component: CreateArcComponent;
  let fixture: ComponentFixture<CreateArcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateArcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateArcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
