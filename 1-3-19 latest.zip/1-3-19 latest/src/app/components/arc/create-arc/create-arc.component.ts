import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { FormBuilder, FormGroupDirective, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { RequestDocument } from '../../meeting/meeting-model';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { arcCase, ARCRquestVendorDetail, ARCRequest, CaseOriginatingType, IsAuthorized, AssignedPartyType } from '../arc-model';
import { TypeOfDocument, StatusReason, ImageNameEnums, FeatureName, DownloadfeatureName, SubCaseTypeEnum, CasePriority, DocumentFeatureName, CaseTypeEnum, FeaturePermissions, SourceType, TriggerType, AudienceType } from 'src/app/shared/Enums/commonEnums';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CommonService } from 'src/app/services/common.service';
import { Guid } from 'guid-typescript';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Subscription } from 'rxjs';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AcceptFilesConstant, CommonConstant } from 'src/app/shared/common/constant.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';

@Component({
  selector: 'app-create-arc',
  templateUrl: './create-arc.component.html',
  styleUrls: ['./create-arc.component.scss']
})
export class CreateArcComponent implements OnInit {

  isApiResponceCome = false;

  isDisplayVendor: boolean = false;
  btStartDate: any;
  isBtnDisabled: boolean = false;
  userData: UserData;
  associationId: string;
  userId: string;
  associationName: string;
  associationUnitData: any;
  userName: string;
  domain: string;
  FirstName: string;
  LastName: string;
  fileData: RequestDocument[] = new Array<RequestDocument>();
  planDocuments: RequestDocument[] = new Array<RequestDocument>();
  specificationDocuments: RequestDocument[] = new Array<RequestDocument>();
  detailDocuments: RequestDocument[] = new Array<RequestDocument>();
  role: string;
  frmCreateARCRequest: FormGroup;
  frmCreateVendor: FormGroup;
  isArcGuideLine: boolean = true;
  arcGuideLineDocument: any;
  apiResponseErrorMessage: string = "";
  companyCode: string;
  @ViewChild('startdate') startdate;
  @ViewChild('enddate') enddate;
  @ViewChild('arcFormDirective') arcFormDirective: FormGroupDirective;
  @ViewChild('vendorFormDirective') vendorFormDirective: FormGroupDirective;

  arcListUrl = AppRouteUrl.mainArcHORouteUrl;
  //for image enum
  imageNameEnums = ImageNameEnums;

  //for unit list
  associationUnitDataDdl: any;
  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentDetails: boolean = false;
  //For Query string;
  querySubcription: Subscription;

  message = "No ARC GuideLine Document";
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  notificationService: any;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  //For Send Notification
  featureId: string;
  pmCompanyAssociationMappingId: string;
  featureName: string;

  constructor(private serviceRequest: ServiceRequestService,
    private commonService: CommonService,
    private formBuilder: FormBuilder,
    private service: ArcRequestApiService,
    private route: ActivatedRoute,
    private emailNotification: EmailNotificationService,
    private router: Router,
    private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.FirstName = this.userName.split(' ')[0];
    this.LastName = this.userName.split(' ')[1];
    this.role = this.userData.Role;
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.ARCRequests) {
          this.featureName = feature.Name
          this.featureId = feature.FeatureId
        }
      });
  }

  ngOnInit() {
    this.getARCGuideLine();
    this.createARCForm();
    this.createVenderForm();
    //to open add dialog
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let isAdd = params["isAdd"];
      if (isAdd === "true") {
        this.isArcGuideLine = false;
      }
    });
  }



  createARCForm() {
    this.frmCreateARCRequest = this.formBuilder.group({
      associationUnit: ['', Validators.required],
      title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      cost: ['', [Validators.required, Validators.maxLength(15), ValidationService.noWhiteSpace]],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(1), ValidationService.noWhiteSpace]],
      workType: ['homeOwner']
    });

    this.getAllAssociationUnit();
  }

  createVenderForm() {
    this.frmCreateVendor = this.formBuilder.group({
      vendorName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
      address1: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
      address2: ['', [Validators.minLength(1), Validators.maxLength(100), Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      email: ['', [Validators.required, ValidationService.emailValidator]],
      phone: ['', [Validators.required, Validators.minLength(13), Validators.maxLength(13), ValidationService.noWhiteSpace]],
      city: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(30), ValidationService.noWhiteSpace]],
      state: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      zipCode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10), ValidationService.noWhiteSpace]],
    });
  }

  setMobileNumber(event) {
    let ctrlValue = this.frmCreateVendor.controls.phone.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmCreateVendor.controls.phone.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmCreateVendor.controls.phone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmCreateVendor.controls.phone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }
  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }


  arcGuildLineToggle() {
    if (this.isArcGuideLine) {
      this.isArcGuideLine = false;
    }
    else {
      this.isArcGuideLine = true;
    }
    this.resetFrom();
  }


  changeDiv(text) {
    if (text === 'vendor') {
      this.isDisplayVendor = true;
    }
    else {
      this.isDisplayVendor = false;
      this.frmCreateVendor.reset();
      if (this.vendorFormDirective !== undefined) {
        this.vendorFormDirective.resetForm();
      }
    }
  }

  // get All AssociationUnits
  getAllAssociationUnit() {
    this.associationUnitData = [];
    this.associationUnitDataDdl = [];
    this.serviceRequest.getAllAssociationUnit(this.userId, this.associationId).subscribe(
      (response: any) => {
        console.log(response);
        this.associationUnitData = response.AssociationUnit;
        console.log(this.associationUnitData);
        if (this.associationUnitData.length === 1) {
          var unitAddress = this.commonService.getFullAssociationAddress(this.associationUnitData[0]);
          this.frmCreateARCRequest.controls.associationUnit.setValue(unitAddress);
        } else {
          this.associationUnitData.forEach(element => {
            var unitAddress = this.commonService.getFullAssociationAddress(element);
            this.associationUnitDataDdl.push(unitAddress);
          });
        }
      }
    );
  }

  validateDate() {
    const startDate = new Date(this.frmCreateARCRequest.controls.startDate.value);
    const endDate = new Date(this.frmCreateARCRequest.controls.endDate.value);
    if (startDate.getTime() > endDate.getTime()) {
      this.apiResponseErrorMessage = "End date must be greater than start date.";
      return;
    }
  }

  onSubmit() {
    let resData;
    if (!this.frmCreateARCRequest.valid) {
      this.validateDate();
      return;
    }
    if (this.isDisplayVendor && !this.frmCreateVendor.valid) {
      this.validateDate();
      document.getElementById('uploadbtn').click();
      return;
    }
    var Case = this.createCaseModel();
    var arc = this.createARCModel();
    this.fileData = this.fileData.concat(this.planDocuments);
    this.fileData = this.fileData.concat(this.detailDocuments);
    this.fileData = this.fileData.concat(this.specificationDocuments);
    this.isBtnDisabled = true;
    this.service.createARCRequest(Case, this.fileData, arc, TypeOfDocument.CaseDocuments, this.domain).subscribe(response => {
      resData = response;
      
      this.isBtnDisabled = false;
      if (resData.caseRequestListResults[0].Success === true) {
        this.router.navigate([AppRouteUrl.mainArcHORouteUrl]);
      }
      this.resetFrom();
      this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
        SourceType.Web, FeatureName.ARCRequests, TriggerType.Update,
        AudienceType.HomeOwner).subscribe(res => {
          console.log(res);
        });
    });
  }

  // on file upload for Plan
  onUploadPlan(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.planDocuments.push({
            ImageId: Guid.create().toString(),
            InputStream: event.target.result,
            Name: evt.target.files[i].name,
            MediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            FileSize: evt.target.files[i].size.toString(),
            DocumentId: '',
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  // remove uploaded doc for plan
  removePlanDoc(id) {
    this.planDocuments = this.planDocuments.filter(a => a.ImageId !== id);
  }

  // on file upload for Specification
  onUploadSpecification(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.specificationDocuments.push({
            ImageId: Guid.create().toString(),
            InputStream: event.target.result,
            Name: evt.target.files[i].name,
            MediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")).toString(),
            FileSize: evt.target.files[i].size.toString(),
            DocumentId: '',
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  // remove uploaded doc for Specification
  removeSpecificationDoc(id) {
    this.specificationDocuments = this.specificationDocuments.filter(a => a.ImageId !== id);
  }


  // on file upload for Detail
  onUploadDetail(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.detailDocuments.push({
            ImageId: Guid.create().toString(),
            InputStream: event.target.result,
            Name: evt.target.files[i].name,
            MediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")).toString(),
            FileSize: evt.target.files[i].size.toString(),
            DocumentId: '',
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  // remove uploaded doc for Detail
  removeDetailDoc(id) {
    this.detailDocuments = this.detailDocuments.filter(a => a.ImageId !== id);
  }


  createCaseModel() {
    let model: arcCase = {
      id: '',
      Title: this.frmCreateARCRequest.controls.title.value,
      Description: this.frmCreateARCRequest.controls.description.value,
      CreatedByUserId: this.userId,
      CaseType: CaseTypeEnum.Homeowners,
      SubCaseType: SubCaseTypeEnum.ARCRequest,
      CasePriority: CasePriority.Medium,
      CaseCategory: CaseTypeEnum.ARC,
      CaseSubCategory: CaseTypeEnum.ARC,
      CaseOriginatingType: CaseOriginatingType.Website,
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      AssociationUnitId: this.associationUnitData.length === 1 ? this.associationUnitData[0].id : this.frmCreateARCRequest.controls.associationUnit.value.id,
      CreatedByUserName: this.userName,
      StatusReason: StatusReason.Submitted,
      AssignedPartyType: AssignedPartyType.PROPVIVO,
      AssignedTo: "",
      IsAuthorized: IsAuthorized.Yes,
      CompanyCode: this.companyCode,
      UserProfileId: this.userId,
      UserName: this.userName,
      CaseDocuments: null
    }
    return model;
  }

  createARCModel() {
    const arcRquestVendorDetail: ARCRquestVendorDetail = {
      VendorName: this.frmCreateVendor.controls.vendorName.value,
      VendorEmail: this.frmCreateVendor.controls.email.value,
      VendorPhone: this.frmCreateVendor.controls.phone.value,
      VendorAddress1: this.frmCreateVendor.controls.address1.value,
      VendorAddress2: this.frmCreateVendor.controls.address2.value,
      VendorState: this.frmCreateVendor.controls.state.value,
      VendorCity: this.frmCreateVendor.controls.city.value,
      VendorZip: this.frmCreateVendor.controls.zipCode.value
    };

    let model: ARCRequest = {
      ProjectStartDate: new Date(this.frmCreateARCRequest.controls.startDate.value).toUTCString(),
      ProjectEndDate: new Date(this.frmCreateARCRequest.controls.endDate.value).toUTCString(),
      ProjectEstimatedCost: this.frmCreateARCRequest.controls.cost.value,
      CreatedByUnitAddress1: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitAddress1 : this.frmCreateARCRequest.controls.associationUnit.value.AssociationUnitAddress1,
      CreatedByUnitAddress2: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitAddress2 : this.frmCreateARCRequest.controls.associationUnit.value.AssociationUnitAddress2,
      CreatedByUnitCity: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitCity : this.frmCreateARCRequest.controls.associationUnit.value.AssociationUnitCity,
      CreatedByUnitState: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitState : this.frmCreateARCRequest.controls.associationUnit.value.AssociationUnitState,
      CreatedByUnitZip: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitZip : this.frmCreateARCRequest.controls.associationUnit.value.AssociationUnitZip,
      CreatedByUnitNumber: this.associationUnitData.length === 1 ? this.associationUnitData[0].AssociationUnitNumber : this.frmCreateARCRequest.controls.associationUnit.value.AssociationUnitNumber,
      ARCRquestVendorDetail: this.isDisplayVendor ? arcRquestVendorDetail : null
    }
    console.log(model);
    return model;
  }

  resetFrom() {
    this.frmCreateARCRequest.reset();
    this.frmCreateVendor.reset();
    if (this.arcFormDirective !== undefined) {
      this.arcFormDirective.resetForm();
    }
    this.fileData = [];
    this.planDocuments = [];
    this.detailDocuments = [];
    this.specificationDocuments = [];
    this.frmCreateARCRequest.controls.workType.setValue('homeOwner');
    this.isDisplayVendor = false;
    if (this.associationUnitData.length === 1) {
      let address = this.commonService.getFullAssociationAddress(this.associationUnitData[0]);
      this.frmCreateARCRequest.controls.associationUnit.setValue(address);
    } else {
      this.associationUnitData.array.forEach(element => {
        var unitAddress = this.commonService.getFullAssociationAddress(element);
        this.associationUnitDataDdl.push(unitAddress);
      });
    }
    if (this.vendorFormDirective !== undefined) {
      this.vendorFormDirective.resetForm();
    }

  }

  getARCGuideLine() {
    let resData;
    this.service.getARCGuideLine(this.associationId, this.domain).subscribe(response => {
      resData = response;
      this.isApiResponceCome = true;
      this.arcGuideLineDocument = resData.RequestDetail.Document;
    })
  }


  changeSDate() {
    this.btStartDate = this.frmCreateARCRequest.controls.startDate.value;
  }

  downloadDocument(filename) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.ARCRequest,
      DownloadfeatureName.ARCGuidLineDownload).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Document not found");
        }
      });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.DocumentName, DocumentFeatureName.ARCRequest, DownloadfeatureName.ARCGuidLineDownload).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image");
      }
    });
  }

  ngOnDestroy(): void {
    this.querySubcription.unsubscribe();
  }

}
