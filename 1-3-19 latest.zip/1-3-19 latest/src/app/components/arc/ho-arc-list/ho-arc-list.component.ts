import { Component, OnInit, ViewChild } from '@angular/core';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ARCStatus, DisplayColumns } from '../arc-model';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { AppConfig } from 'src/app/app.config';
import { fromEvent } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { Router, NavigationExtras } from '@angular/router';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NoDataFoundCaseFeatureName, MasterPaginationEnum, Pagination, DocumentFeatureName, requestSubTypeCount, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { MatPaginator } from '@angular/material';
import { FilterListValues, FeatureNameLocalStorage } from 'src/app/shared/common/models';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-ho-arc-list',
  templateUrl: './ho-arc-list.component.html',
  styleUrls: ['./ho-arc-list.component.scss']
})
export class HoArcListComponent implements OnInit {
  isList: boolean;

  isApiResponceCome = false;
  filter = false;
  userData: UserData;
  associationId: string;
  arcList: any;
  arcStatusCount: any;
  count: number;
  arcRequestStatus = ARCStatus;
  //status: string = ARCStatus.All;
  role: string;
  userId: string;
  sidebar = false;
  //for filter by date
  dateTo: any;
  dateFrom: any;
  bsRangeValue: Date[] = [];

  //For filter by key word
  filterByKeyWords: string = "";
  @ViewChild('searchData') searchData: any;

  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  //for save data in localstorage
  localStorageFromDate;
  localStorageToDate;

  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  /**End For Manage Columns*/

  //for display comments
  isViewComment: boolean = false;

  createArcRouteUrl = AppRouteUrl.mainCreateArcRouteUrl;
  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;

  allCount: any;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;


  constructor(public service: ArcRequestApiService, private readonly appConfig: AppConfig,
    public commonService: CommonService,
    private progressbarService: ProgeressBarService,
    private router: Router) {
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.role = "Member";
    this.userId = this.userData.UserProfileId;
  }

  ngOnInit() {
    /**For Manage Columns*/
    this.seletedColumns = DisplayColumns.AllColumnsList;
    this.displayColumnsDdl = DisplayColumns.AllSelectedColumnsList;
    this.defaultColumnsList = DisplayColumns.DefaultColumnsList;
    this.service.listStatus = this.arcRequestStatus.All;
    /**End For Manage Columns*/
    //Filter By Key word
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.getData();
      });
    this.getLocalStorageData();
  }

  getLocalStorageData() {
    //get local storage filter data
    var data: FilterListValues = this.commonService.getFilterDataFromLocalStorge();
    if (data !== null && data !== undefined) {
      if (data.FeatureName === FeatureNameLocalStorage.ARCHO) {
        this.service.listStatus = data.Status;
        this.filterByKeyWords = data.SearchKey;
        this.dateFrom = data.DateFrom !== null && data.DateFrom !== undefined && data.DateFrom !== '' ? new Date(data.DateFrom).toUTCString() : '';
        this.dateTo = data.DateTo !== null && data.DateTo !== undefined && data.DateTo !== '' ? new Date(data.DateTo).toUTCString() : '';
        this.filter = data.Filter;
        if (this.dateFrom !== "" && this.dateFrom !== null && this.dateFrom !== undefined && this.dateTo !== "" && this.dateTo !== null && this.dateTo !== undefined) {
          this.bsRangeValue = [new Date(data.DateFrom), new Date(data.DateTo)];
        } else {
          this.bsRangeValue = [];
        }
      }
    } else {
      this.service.listStatus = this.arcRequestStatus.All;
    }

    this.statusChange(this.service.listStatus);
  }

  filterDataLocalstorage() {
    var filtersModel: FilterListValues = {
      SearchKey: this.filterByKeyWords,
      DateTo: this.localStorageToDate,
      DateFrom: this.localStorageFromDate,
      Category: '',
      Priority: '',
      AssignTo: '',
      Status: this.service.listStatus,
      ViolationFieldType: "",
      Filter: this.filter,
      FeatureName: FeatureNameLocalStorage.ARCHO
    }
    return filtersModel;
  }


  addClass() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  getData() {
    this.isList = false;
    let resData;
    let resFilterByKeyWords = this.filterByKeyWords;
    let resStatus = this.service.listStatus === ARCStatus.All ? "" : this.service.listStatus;
    this.progressbarService.show();
    this.service.getFilteredARCRequestForHo(this.associationId, this.userId, this.role, resStatus, resFilterByKeyWords, this.dateTo, this.dateFrom, this.pageSkip, this.pageTake).subscribe(res => {
      resData = res;
      this.isApiResponceCome = true;
      this.progressbarService.hide();
      if (resData.Errors.length == 0) {
        this.arcList = resData.caseRequestListResults[0].arcRequestList;
        this.allCount = resData.caseRequestListResults[0].ResultCount;
        if (this.arcList !== null) {
          this.setPaginationData(this.arcList);

          this.SetDetailsOfNextPreviousOnDetailsPage();
        }

        this.isList = true;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  //Get Count of list
  getListCount() {
    var model = this.commonService.getListModel(this.associationId, this.userId, this.role);
    let resData
    this.commonService.getListcount(model, DocumentFeatureName.ARCRequest, requestSubTypeCount.Count).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success) {
        this.arcStatusCount = resData.caseRequestListResults[0].ARCStatusCount;
      } else {
        this.arcStatusCount = resData.caseRequestListResults[0].ARCStatusCount;
      }
    });
  }

  //for filter by date
  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.localStorageFromDate = event[0];
        this.dateTo = new Date(event[1]).toUTCString();
        this.localStorageToDate = event[1];
        this.getData();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getData();
    }
  }

  clearFilter() {
    if (this.filterByKeyWords === "" && (this.bsRangeValue === null || this.bsRangeValue === [] || this.bsRangeValue.length === 0)) {
      return
    }
    this.filterByKeyWords = "";
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.getData();
  }

  arcDetail(id, caseId) {
    this.service.caseId = caseId;
    this.service.arcRequestId = id;
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": id
      }
    };
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.router.navigate([AppRouteUrl.mainArcDetailHORouteUrl], navigationExtras);
  }



  statusChange(s) {
    this.service.listStatus = s;
    /**For Manage Columns*/
    if (this.arcRequestStatus.Submitted === s) {
      this.seletedColumns = DisplayColumns.SubmittedColumnsList;
      this.displayColumnsDdl = DisplayColumns.SubmittedSelectedColumnsList;
    } else if (this.arcRequestStatus.All === s) {
      this.seletedColumns = DisplayColumns.AllColumnsList;
      this.displayColumnsDdl = DisplayColumns.AllSelectedColumnsList;
    } else if (this.arcRequestStatus.Approved === s) {
      this.seletedColumns = DisplayColumns.ApprovedColumnsList;
      this.displayColumnsDdl = DisplayColumns.ApprovedSelectedColumnsList;
    } else if (this.arcRequestStatus.Cancelled === s) {
      this.seletedColumns = DisplayColumns.CancelledColumnsList;
      this.displayColumnsDdl = DisplayColumns.CancelledSelectedColumnsList;
    } else if (this.arcRequestStatus.WorkCompleted === s) {
      this.seletedColumns = DisplayColumns.CompletedColumnsList;
      this.displayColumnsDdl = DisplayColumns.CompletedSelectedColumnsList;
    } else if (this.arcRequestStatus.Denied === s) {
      this.seletedColumns = DisplayColumns.DeniedColumnsList;
      this.displayColumnsDdl = DisplayColumns.DeniedSelectedColumnsList;
    }
    /**End For Manage Columns*/
    this.setPaginationVariables();
    this.getListCount();
    this.getData();
  }

  
  onClickChangeStatus(s) {
    if (this.service.listStatus === s) {
      return;
    } else {
      this.statusChange(s);
    }
  }

  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/


  //for comments 
  commentToggle() {
    if (this.isViewComment) {
      this.isViewComment = false;
    } else {
      this.isViewComment = true;
    }
  }

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(arcList) {
    this.TotalRecord = this.allCount;
    this.FilterArray = arcList;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = arcList.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize
    this.pageTake = clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getData();
    var elmnt: any = document.getElementById("contentTable");
    if (elmnt !== null) {
      elmnt.scrollTo(0, 0);
    }
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Next Previous
  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('ARCListHo');
    var temp: any = [];
    this.arcList.forEach(element => {
      temp.push({
        id: element.id,
        caseid: element.CaseId,
        status: element.ARCStatus
      });
    });
    localStorage.setItem('ARCListHo', JSON.stringify(temp));
  }

}
