import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  MatCheckboxModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatRippleModule,
  MatSelectModule,
  MatSnackBarModule,
  MatTooltipModule,
  MatTreeModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatBottomSheetModule,
  MatPaginatorModule,
} from '@angular/material';
import { CommonModule } from '@angular/common';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { RouterModule, Routes } from '@angular/router';
import { BmArcDetailComponent } from './bm-arc-detail/bm-arc-detail.component';
import { BmArcListComponent } from './bm-arc-list/bm-arc-list.component';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { TransformBlankValueModule } from 'src/app/shared/pipes/blankValue/transform-blank-value.module';
const routes: Routes = [
  {
    path: '',
    component: BmArcListComponent
  },
  {
    path: 'bm-arc-detail',
    component: BmArcDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    NoCaseNoteFoundModule,
    SafeModule,
    MatInputModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatListModule,
    NumberOnlyDirectiveModule,
    MatMenuModule,
    MatRippleModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatTreeModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    FormsModule,
    FilterUniqueArrayModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule,
    TransformBlankValueModule
  ],
  declarations: [BmArcListComponent, BmArcDetailComponent 
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [RouterModule]
})
export class BmArcModule { }
