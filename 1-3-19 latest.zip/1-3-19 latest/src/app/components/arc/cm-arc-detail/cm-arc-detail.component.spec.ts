import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmArcDetailComponent } from './cm-arc-detail.component';

describe('CmArcDetailComponent', () => {
  let component: CmArcDetailComponent;
  let fixture: ComponentFixture<CmArcDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmArcDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmArcDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
