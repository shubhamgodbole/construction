import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { CaseNoteModel, NoteType, CaseFeatureType, EscalteModel, VoteModel } from '../../board-tasks/board-task.model';
import { Validators, FormGroup, FormGroupDirective, FormBuilder } from '@angular/forms';
import { TypeOfDocument, StatusReason, ImageNameEnums, RoleEnum, FeatureName, DownloadfeatureName, DocumentFeatureName, ActivityType, VoteStatus, PlaceHolderText, CallType, FeaturePermissions, SourceType, TriggerType, AudienceType, EmailAudience } from 'src/app/shared/Enums/commonEnums';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { AppConfig } from 'src/app/app.config';
import { Router, ActivatedRoute } from '@angular/router';
import { requestARCVoteModel, CaseOriginatingType, IsAuthorized, ARCStatus } from '../arc-model';
import { Subscription } from 'rxjs';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { MatDialogRef, MatDialog, MatSnackBar } from '@angular/material';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { CommonService } from 'src/app/services/common.service';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { Guid } from 'guid-typescript';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonConstant, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { RequestMsg } from '../../service-request/service-request.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-cm-arc-detail',
  templateUrl: './cm-arc-detail.component.html',
  styleUrls: ['./cm-arc-detail.component.scss']
})
export class CmArcDetailComponent implements OnInit {
  propVivoName = CommonConstant.PropVivo;
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  notificationService: NotificationService;
  //for route
  querySubcription: Subscription
  userData: UserData;
  userId: string;
  profilePath: string;
  domain: string;
  userName: string;
  arcRequest: any;
  arcRequestDocuments: any[];
  committeeMemberCaseNotes: any[];
  boardMemberCaseNotes: any[];
  caseNoteList: any = [];
  caseNotes: any;
  isAuthorized = IsAuthorized;

  hocaseNotes: any;
  noteType = NoteType;
  displayDiv: boolean = false;
  associationId: string;
  decisionReason: any;
  voteRemarks: any = [];
  voteCount: number = 0;
  isARCVote: boolean;
  arcStatus = ARCStatus

  /*Case Note Form*/
  cmCaseNoteForm: FormGroup;
  bmCaseNoteForm: FormGroup;
  hoCaseNoteForm: FormGroup;
  pmCaseNoteForm: FormGroup;
  fileData = [];
  isHoBtnDisabled: boolean = false;
  isBMBtnDisabled: boolean = false;
  isCMBtnDisabled: boolean = false;
  caseOriginatingType = CaseOriginatingType;
  projectCompletionDocuments: any[];

  // view more 
  shoNDocs: number = 3;
  viewDocs: boolean;
  viwAllDocBtnMsg: string = "View All Attachments";

  // view more work completed Doc
  shoNDocsCompleted: number = 3;
  viewDocsCompleted: boolean;
  viwAllDocBtnMsgCompleted: string = "View All Attachments";

  readMoreBtn: boolean;
  readMoreDescBtnMsg: string = "Read More";
  desLimit: number = 160;

  roleEnum = RoleEnum;
  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentDetails: boolean = false;

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;


  //for esclate vote
  pendingDecision: any;
  esclateVoteCount: number;
  isVote: boolean;
  esclateVoterList: any[];
  esclateResult: string;

  @ViewChild('formDirectiveCm') formDirectiveCm: FormGroupDirective;
  @ViewChild('formDirectiveHo') formDirectiveHo: FormGroupDirective;
  @ViewChild('formDirectiveBm') formDirectiveBm: FormGroupDirective;
  @ViewChild('formDirectivePm') formDirectivePm: FormGroupDirective;



  /*Escalte form*/
  frmCreateEscalte: FormGroup;
  isSubmitBtnDisabledEscalte: boolean = false;
  @ViewChild('formDirectiveEscalte') formDirectiveEscalte: FormGroupDirective;

  /*ARC Vote*/
  vote: boolean = true;
  frmCreateVote: FormGroup;
  isSubmitBtnDisabledVote: boolean = false;
  @ViewChild('formDirectiveVote') formDirectiveVote: FormGroupDirective;
  isDisplayVoteList: boolean = false;
  isDisplayEsclateVoteList: boolean = false;

  //for image enum
  imageNameEnums = ImageNameEnums;

  //requestMsg enum 
  requestMsgEnum = RequestMsg;


  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;
  caseNoteType: string;

  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;

  role: string;

  MobActoin = false;
  MobDetail = false;
  MobChat = false;

  //replyTo
  selectedReplyTo: string;
  placeHolderText = PlaceHolderText;

  allCaseNoteList = [];
  //vote status enum 
  VoteStatusEnum = VoteStatus;

  selectedConversionType: string = "All";

  noteTypeEnums = NoteType;
  activityTypeEnum = ActivityType;
  selectedAssignment: string = '';

  selectedActivityType: string;

  //file data for case note
  fileDataHoCase = [];
  fileDataBMCase = [];
  fileDataICCase = [];
  fileDataCMCase = [];
  isPMBtnDisabled: boolean = false;
  statusReasonEnum = StatusReason;

  callTypeEnum = CallType;

  //For Send Notification
  featureId: string;
  pmCompanyAssociationMappingId: string;
  featureName: string;

  arcRequestVote: boolean;

  isDisplayMotionDiv
  allCaseNotes

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;


  constructor(private service: ArcRequestApiService, private readonly appConfig: AppConfig,
    private ngZone: NgZone, private _location: Location,
    private route: ActivatedRoute,
    private progressbarService: ProgeressBarService,
    private _matDialog: MatDialog,
    public commonService: CommonService,
    private emailNotification: EmailNotificationService,
    private readonly snb: MatSnackBar,
    private router: Router, private formBuilder: FormBuilder) {
    this.userData = this.appConfig.getCurrentUser();
    this.domain = this.userData.UserAssociations[0].Domain;
    this.userName = this.userData.UserName;
    this.userId = this.userData.UserProfileId;
    this.role = this.userData.Role;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.profilePath = this.userData.UserProfilePath;
    this.createCMCaseNoteForm();
    this.createHOCaseNoteForm();
    this.createBMCaseNoteForm();
    this.createEscalteForm();
    this.createVoteForm();
    this.createPMCaseNoteForm();
    this.notificationService = new NotificationService(snb);
    this.pmCompanyAssociationMappingId = this.userData.UserAssociations[0].PMCompanyAssociationMappingId;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.ARC) {
          this.featureName = feature.Name
          this.featureId = feature.FeatureId
        }
      });
  }

  MobActionToggle() {
    if (this.MobActoin)
      this.MobActoin = false;
    else
      this.MobActoin = true;
  }

  MobShowDetail() {
    if (this.MobDetail)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  MobShowChat() {
    if (this.MobChat)
      this.MobDetail = false,
        this.MobChat = false;
    else
      this.MobDetail = true,
        this.MobChat = true;
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.service.arcRequestId = id;
        this.getDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.mainArcCMRouteUrl]);
      }
    });

  }

  getDetail() {
    let resData;
    this.pendingDecision = null;
    this.arcRequestDocuments = [];
    this.progressbarService.show();
    this.service.getARCRequestDetail(this.service.arcRequestId, this.domain).subscribe(response => {
      resData = response;
      console.log('cm res ', response);
      this.progressbarService.hide();

      if (resData.RequestDetail.Success === true) {
        this.arcRequest = resData.RequestDetail.ARCRequest;
        if (this.arcRequest !== null || this.arcRequest !== undefined) {
          this.isShowNextAndPreviewsButton();
          this.service.caseId = this.arcRequest.CaseId;
        }
        this.arcRequestDocuments = resData.RequestDetail.Document;
        this.projectCompletionDocuments = resData.RequestDetail.ProjectCompletionDocuments;

        this.setVoteRemark(resData.RequestDetail.CaseNoteDetails)

        this.displayDiv = true;
      } else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
  }

  setVoteRemark(caseNoteDetails) {
    if (this.arcRequest.ARCRequestCommitteeVotes !== null && this.arcRequest.ARCRequestCommitteeVotes.length > 0) {
      this.voteRemarks = this.arcRequest.ARCRequestCommitteeVotes;
      this.voteCount = this.arcRequest.ARCRequestCommitteeVotes.length;
      let voteByUser = this.arcRequest.ARCRequestCommitteeVotes.find(v => v.CreatedByUserId === this.userId);
      if (voteByUser) {
        this.isARCVote = voteByUser.Vote;
      }
      this.arcRequest.ARCRequestCommitteeVotes.map(a => {
        var caseNote = this.service.convertVoteRemarkToCaseNote(a);
        caseNoteDetails.push(caseNote);
        this.caseNoteList.push(caseNote);
      });
    }
    if (caseNoteDetails !== null) {
      if (caseNoteDetails.length > 0) {
        this.setListValue(caseNoteDetails);
      }
    } else {
      this.removeListValue()
    }
  }

  /*Case Note Add Module*/
  createCMCaseNoteForm() {
    this.cmCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  // upload Document
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        if (this.selectedReplyTo === NoteType.Homeowner) {
          this.fileDataHoCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.BoardMember) {
          this.fileDataBMCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.PropertyManager) {
          this.fileDataICCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.CommitteeMember) {
          this.fileDataCMCase = this.fileData;
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  removeImage(imageId) {
    if (this.selectedReplyTo === NoteType.Homeowner) {
      this.fileDataHoCase = this.fileDataHoCase.filter(a => a.imageId !== imageId);;
    } else if (this.selectedReplyTo === NoteType.BoardMember) {
      this.fileDataBMCase = this.fileDataBMCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.PropertyManager) {
      this.fileDataICCase = this.fileDataICCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.CommitteeMember) {
      this.fileDataICCase = this.fileDataCMCase.filter(a => a.imageId !== imageId);
    }
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }

  onSubmitCaseNoteForCM() {
    let resData;
    if (this.cmCaseNoteForm.valid) {
      this.isCMBtnDisabled = true;
      let model = this.createCMFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isCMBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARC, TriggerType.Update,
            AudienceType.ARCCommitteeMember).subscribe(res => {
              console.log(res);
            });
          if (this.fileDataCMCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          } 
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log('error');
        }
        this.resetCaseNoteCMForm();
      });
    }
  }

  createCMFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataCMCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.cmCaseNoteForm.controls.caseNoteId.value,
        Note: this.cmCaseNoteForm.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.CommitteeMember,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: RoleEnum.CommitteeMember,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false,

      }
    }
    return model;
  }

  resetCaseNoteCMForm() {
    this.cmCaseNoteForm.reset();
    this.formDirectiveCm.resetForm();
    this.isCMBtnDisabled = false;
    this.fileDataCMCase = [];
    this.fileData = [];
    this.selectedReplyTo = "";
  }


  /*Case Note Add Module*/
  createHOCaseNoteForm() {
    this.hoCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }


  onSubmitCaseNoteForHO() {
    let resData;
    if (this.hoCaseNoteForm.valid) {
      this.isHoBtnDisabled = true;
      let model = this.createHoFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isHoBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARC, TriggerType.Update,
            AudienceType.ARCCommitteeMember).subscribe(res => {
              console.log(res);
            });
          if (this.fileDataHoCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("Not Save");
        }
        this.resetCaseNoteHOForm();
      });
    }
  }

  createHoFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataHoCase,
      RequestId: this.arcRequest.id,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: this.hoCaseNoteForm.controls.caseNoteId.value,
        Note: this.hoCaseNoteForm.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.Homeowner,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: RoleEnum.CommitteeMember,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetCaseNoteHOForm() {
    this.hoCaseNoteForm.reset();
    this.formDirectiveHo.resetForm();
    this.isHoBtnDisabled = false;
    this.fileDataHoCase = [];
    this.fileData = [];
    this.selectedReplyTo = "";
  }

  /*Case Note Add Module for BM*/
  createBMCaseNoteForm() {
    this.bmCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }


  onSubmitCaseNoteForBM() {
    let resData;
    if (this.bmCaseNoteForm.valid) {
      this.isBMBtnDisabled = true;
      let model = this.createBMFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isBMBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARC, TriggerType.Update,
            AudienceType.ARCCommitteeMember).subscribe(res => {
              console.log(res);
            });
          if (this.fileDataBMCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log('error');
        }
        this.resetCaseNoteBMForm();
      });
    }
  }

  createBMFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataBMCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.bmCaseNoteForm.controls.caseNoteId.value,
        Note: this.bmCaseNoteForm.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.BoardMember,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: RoleEnum.CommitteeMember,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetCaseNoteBMForm() {
    this.bmCaseNoteForm.reset();
    this.formDirectiveBm.resetForm();
    this.isBMBtnDisabled = false;
    this.fileDataBMCase = [];
    this.fileData = [];
    this.selectedReplyTo = "";
  }



  /*Create Escalte Form */

  createEscalteForm() {
    this.frmCreateEscalte = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitEscalte() {
    let resData;
    if (this.frmCreateEscalte.valid) {
      this.isSubmitBtnDisabledEscalte = true;
      let model = this.createEscalteModel();
      this.service.createEscalte(model).subscribe(res => {
        resData = res;
        this.resetEscalteForm();
        this.isSubmitBtnDisabledEscalte = false;
        if (resData.caseRequestListResults[0].Success === true) {
          this.getDetail();
        } else if (resData.caseRequestListResults[0].Success === false) {
          console.log("Not Save");
        }
      });
    }
  }

  createEscalteModel() {
    const model: EscalteModel = {
      RequestId: this.service.arcRequestId,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateEscalte.controls.comments.value,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        NotesType: null,
        ProfilePath: this.profilePath,
        RoleType: RoleEnum.CommitteeMember,
        IsVotingRequired: true,
        ActivityType: ActivityType.AssignToBoard,
        IsAssignedToBoard: true
      }
    }
    return model;
  }

  resetEscalteForm() {
    this.frmCreateEscalte.reset();
    this.formDirectiveEscalte.resetForm();
    this.selectedReplyTo = "";
    this.selectedAssignment = "";
  }

  /*Create ARC Vote */

  createVoteForm() {
    this.frmCreateVote = this.formBuilder.group({
      reasonText: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  createARCVote() {
    if (!this.frmCreateVote.valid) {
      return;
    }
    let model = this.createVoteModel();
    let resData;
    this.isSubmitBtnDisabledVote = true;
    this.service.createVote(model).subscribe(res => {
      console.log('vote res ', res);
      resData = res;
      this.isSubmitBtnDisabledVote = false;
      
      this.resetVoteForm();
      this.getDetail();
      this.emailNotification.sendNotifications(this.featureId, resData.RequestId, this.userId, this.pmCompanyAssociationMappingId,
        SourceType.Web, FeatureName.ARC, TriggerType.Update_Approved_Denied,
        AudienceType.ARCCommitteeMember).subscribe(res => {
          console.log(res);
        });
    });
  }

  createVoteModel() {
    const model: requestARCVoteModel = {
      associationId: this.associationId,
      requestId: this.service.arcRequestId,
      ARCRequestCommitteeVote: {
        Vote: this.vote,
        CreatedByUserId: this.userId,
        CreatedByUserName: this.userName,
        Remarks: this.frmCreateVote.value.reasonText,
        ProfilePath: this.profilePath
      }
    }
    return model;
  }

  resetVoteForm() {
    this.frmCreateVote.reset();
    this.formDirectiveVote.resetForm();
    this.selectedActivityType = '';
    this.selectedReplyTo = "";
    this.arcRequestVote = false;
  }

  voteCreate(voteValue) {
    this.arcRequestVote = true;
    this.vote = voteValue;
    //this.resetVoteForm();
  }

  //For Vote
  createEsclateVote(voteStatus, caseNoteId) {
    this.progressbarService.show();
    let model = this.createEsclateVoteModel(voteStatus);
    this.service.createEsclateVote(this.service.caseId, caseNoteId, this.arcRequest.id, this.associationId, model).subscribe(
      (response: any) => {
        this.progressbarService.hide();
        if (response.Success) {
          this.pendingDecision = response.CaseActivity;
          this.esclateVoteCount = this.pendingDecision.Votes.length;
          this.esclateResult = this.pendingDecision.VoteStatus;
          this.arcRequest = response.arcRequestDetail;
          //this.getServiceRequestDetail();
          this.caseNotes = this.caseNotes.map((a) => {
            if (a.CaseNotes.id === this.pendingDecision.id) {
              a.CaseNotes = this.pendingDecision;
            }
            return a;
          });
          if (this.esclateVoteCount > 0) {
            this.esclateVoterList = this.pendingDecision.Votes;
            let voteByUser = this.pendingDecision.Votes.find(v => v.CreatedByUserId === this.userId);
            if (voteByUser) {
              this.isVote = voteByUser.Vote;
            }
          }
        }
      }
    );
  }

  createEsclateVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: VoteModel = {
      Vote: vote,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      ProfilePath: this.profilePath,
      Remarks: ''
    }
    return model;
  }

  /*Display list of vote
  displayVoteListToggle() {
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }

  /*Display list of vote
  displayEsclateVoteListToggle() {
    if (this.isDisplayEsclateVoteList)
      this.isDisplayEsclateVoteList = false;
    else
      this.isDisplayEsclateVoteList = true;
  }*/


  // view more description
  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.desLimit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.readMoreDescBtnMsg = "Read Less";
      this.desLimit = this.arcRequest.ARCDescription;
    }
  }

  //view more documents
  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.arcRequestDocuments.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }

  //view more documents
  viewMoreCompletedDocs() {
    if (this.viewDocsCompleted) {
      this.shoNDocsCompleted = 3;
      this.viewDocsCompleted = false;
      this.viwAllDocBtnMsgCompleted = "View All Attachments";
    }
    else {
      this.shoNDocsCompleted = this.projectCompletionDocuments.length;
      this.viewDocsCompleted = true;
      this.viwAllDocBtnMsgCompleted = "View Less Attachments";
    }
  }
  //convert size in to byte
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  }



  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
    this.caseNoteType = caseNotes.NotesType
  }

  updateCaseNote() {
    if (this.editComments === "") {
      this.isEditValidation = true;
      return;
    }
    this.isEditValidation = false;
    let model = this.editCaseNoteModel();
    this.commonService.updateCaseNote(model).subscribe(res => {
      let resData;
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.resetEditCaseNote();
        this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
        console.log("Case note updated successfully.");
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        this.notificationService.showNotification("Not Update");
      }
    });
  }

  editCaseNoteModel() {
    const model: CaseNoteEditModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: this.caseNoteType,
        CreatedByUserName: this.userName,
        RoleType: RoleEnum.CommitteeMember,
        CaseFeatureType: CaseFeatureType.ServiceRequest

      }
    }
    return model;
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
  }


  /*Delete case note*/
  delete(id) {
    let resData;
    this.commonService.deleteCaseNote(id, this.service.caseId, this.associationId, this.domain).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
        }
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })

  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }

  ngOnDestroy() {
    this.querySubcription.unsubscribe();
  }


  removeListValue() {
    this.caseNoteList = [];
    this.hocaseNotes = [];
    this.caseNotes = [];
    this.committeeMemberCaseNotes = [];
    this.boardMemberCaseNotes = [];
    this.pendingDecision = [];
    this.decisionReason = [];
    if (this.arcRequest.ARCRequestCommitteeVotes !== null) {
      this.voteRemarks = this.arcRequest.ARCRequestCommitteeVotes;
      this.voteCount = this.arcRequest.ARCRequestCommitteeVotes.length;
      let voteByUser = this.arcRequest.ARCRequestCommitteeVotes.find(v => v.CreatedByUserId === this.userId);
      if (voteByUser) {
        this.isARCVote = voteByUser.Vote;
      }
    }
  }

  downloadDocument(filename) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(this.domain, filename, DocumentFeatureName.ARCRequest, DownloadfeatureName.Download).subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.commonService.downloadFile(resData.DocumentPath).subscribe(
          (response) => {
            let dataType = response.type;
            let binaryData = [];
            binaryData.push(response);
            let downloadLink = document.createElement('a');
            downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
            if (filename)
              downloadLink.setAttribute('download', filename);
            document.body.appendChild(downloadLink);
            downloadLink.click();
          }
        );
      }
      else if (resData.Success === false) {
        this.notificationService.showNotification("Not get");
      }
    });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(this.domain, document.FilePath, DocumentFeatureName.ARCRequest, DownloadfeatureName.Download).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);

            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image");
      }
    });
  }

  toGoBack() {
    this.router.navigate([AppRouteUrl.mainArcCMRouteUrl]);
  }

  //**Next AND Preview */
  PreviousCase() {
    var current = this.service.arcRequestId;
    var serviceRequestAr = JSON.parse(localStorage.getItem('ARCListCM'));
    this.totalPages = serviceRequestAr.length - 1;
    var el = serviceRequestAr.find(a => { return a.id === current });
    var currentEl = serviceRequestAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = serviceRequestAr[currentEl - 1].id;
      this.service.arcRequestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  NextCase() {
    var current = this.service.arcRequestId;
    var serviceRequestAr = JSON.parse(localStorage.getItem('ARCListCM'));
    this.totalPages = serviceRequestAr.length - 1;
    var el = serviceRequestAr.find(a => { return a.id === current });
    var currentEl = serviceRequestAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < serviceRequestAr.length) {
      let prevIndex = serviceRequestAr[currentEl + 1].id;
      this.service.arcRequestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  isShowNextAndPreviewsButton() {
    let localStorageData = JSON.parse(localStorage.getItem('ARCListCM'));
    if (localStorageData === null || localStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.service.arcRequestId;
      var serviceRequestAr = JSON.parse(localStorage.getItem('ARCListCM'));
      this.totalPages = serviceRequestAr.length - 1;
      var el = serviceRequestAr.find(a => { return a.id === current });
      var currentEl = serviceRequestAr.indexOf(el);
      this.currentPage = currentEl;
    }
  }

  //change reply to 
  changeReplyTo() {
    this.isDisplayMotionDiv = false;
    this.fileData = [];
  }

  //change conversion
  changeConversion() {
    if (this.selectedConversionType === "All") {
      this.caseNotes = this.caseNoteList;
    } else if (this.selectedConversionType === NoteType.Homeowner) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.Member) || (note.CaseNotes.NotesType === this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.CommitteeMember));
    } else if (this.selectedConversionType === NoteType.BoardMember) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === this.noteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.CommitteeMember) || (note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.BoardMember));
    } else if (this.selectedConversionType === NoteType.PropertyManager) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.CommitteeMember) || (note.CaseNotes.NotesType == NoteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager));
    } else if (this.selectedConversionType === this.activityTypeEnum.Phone) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Phone);
    } else if (this.selectedConversionType === this.activityTypeEnum.Email) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Email && note.CaseNotes.EmailAudience !== EmailAudience.None);
    } else if (this.selectedConversionType === this.activityTypeEnum.AssignToBoard) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.AssignToBoard);
    } else if (this.selectedConversionType === NoteType.CommitteeMember) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.CommitteeMember);
    }
  }


  getUnitAddress() {
    var associationUnit = {
      AssociationUnitNumber: this.arcRequest.CreatedByUnitNumber,
      AssociationUnitAddress1: this.arcRequest.CreatedByUnitAddress1,
      AssociationUnitAddress2: this.arcRequest.CreatedByUnitAddress2,
      AssociationUnitCity: this.arcRequest.CreatedByUnitCity,
      AssociationUnitState: this.arcRequest.CreatedByUnitState,
      AssociationUnitZip: this.arcRequest.CreatedByUnitZip,
    }
    return this.commonService.getFullAssociationAddress(associationUnit);
  }

  getVenderAddress(venderDetail) {
    var associationUnit = {
      AssociationUnitAddress1: venderDetail.VendorAddress1,
      AssociationUnitAddress2: venderDetail.VendorAddress2,
      AssociationUnitCity: venderDetail.VendorCity,
      AssociationUnitState: venderDetail.VendorState,
      AssociationUnitZip: venderDetail.VendorZip,
    }
    return this.commonService.getAssociationAddressForList(associationUnit);
  }
  
  setListValue(caseNoteDetails) {
    this.allCaseNoteList = caseNoteDetails;
    this.caseNoteList = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType !== this.noteType.BoardMember && note.CaseNotes.RoleType !== RoleEnum.BoardMember && note.CaseNotes.ActivityType !== ActivityType.Email);
    
    this.hocaseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.Member) || (note.CaseNotes.NotesType === this.noteType.Homeowner && note.CaseNotes.RoleType === RoleEnum.CommitteeMember));
    this.committeeMemberCaseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.CommitteeMember || (note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager));
    this.boardMemberCaseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === this.noteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.CommitteeMember) || (note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.BoardMember));
   
    var emailNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === ActivityType.Email && note.CaseNotes.EmailAudience !== EmailAudience.None);
    if (emailNotes !== null && emailNotes !== undefined && emailNotes.length > 0) {
      this.caseNoteList = this.caseNoteList.concat(emailNotes);
    }
    if (this.boardMemberCaseNotes !== null && this.boardMemberCaseNotes !== undefined && this.boardMemberCaseNotes.length > 0) {
      this.caseNoteList = this.caseNoteList.concat(this.boardMemberCaseNotes);
    }

     //get before data
     var caseNoteBeforeVote = caseNoteDetails.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null && note.CaseNotes.DocumentType !== "Motion" && note.CaseNotes.VoteStatus === null));

     if (caseNoteBeforeVote.length > 0) {
       caseNoteBeforeVote = _.sortBy(caseNoteBeforeVote, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();
 
       this.caseNoteList = caseNoteBeforeVote.concat(this.caseNoteList);
     }
 
    this.pendingDecision = caseNoteDetails.find(note => note.CaseNotes.IsAssignedToBoard === true);
    if (this.pendingDecision !== null && this.pendingDecision !== undefined) {
      this.esclateResult = this.pendingDecision.VoteStatus;
      this.boardMemberCaseNotes.push(this.pendingDecision);
      this.esclateVoteCount = this.pendingDecision.CaseNotes.Votes.length;
      this.esclateVoterList = this.pendingDecision.CaseNotes.Votes;
      let voteByUser = this.pendingDecision.CaseNotes.Votes.find(v => v.CreatedByUserId === this.userId);
      if (voteByUser) {
        this.isVote = voteByUser.Vote;
      }
    }
    this.decisionReason = this.caseNoteList.filter(note => note.CaseNotes.StatusReason !== null);

    this.changeConversion();
  }


  /*Case Note Add  Module For Internal Chat*/
  createPMCaseNoteForm() {
    this.pmCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitCaseNoteForPM() {
    let resData;
    if (this.pmCaseNoteForm.valid) {
      this.isPMBtnDisabled = true;
      let model = this.createPMFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isPMBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
        
          if (this.fileDataICCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetCaseNotePMForm();
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARC, TriggerType.Update,
            AudienceType.ARCCommitteeMember).subscribe(res => {
              console.log(res);
            });
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log('error');
        }
       
      });
    }
  }

  createPMFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataICCase,
      RequestId: this.arcRequest.id,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: this.pmCaseNoteForm.controls.caseNoteId.value,
        Note: this.pmCaseNoteForm.controls.comments.value,
        CaseId: this.arcRequest.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.PropertyManager,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: RoleEnum.CommitteeMember,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetCaseNotePMForm() {
    this.pmCaseNoteForm.reset();
    this.formDirectivePm.resetForm();
    this.isPMBtnDisabled = false;
    this.fileDataICCase = [];
    this.fileData = [];
    this.selectedReplyTo = "";
  }

  checkIconAssignToBoard(assignTOBoard) {
    if (assignTOBoard !== null && assignTOBoard !== undefined) {
      if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined || assignTOBoard.VoteStatus === VoteStatus.Withdraw) {
        return CommonConstant.MotionMovedIcon;
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
        return CommonConstant.MotionPassedIcon;
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
        return CommonConstant.MotionFailedIcon;
      }
    }
  }

  checkTextAssignToBoard(assignTOBoard) {
    if (assignTOBoard !== null && assignTOBoard !== undefined) {
      if (assignTOBoard.Votes.length > 0) {
        var voteCount = assignTOBoard.Votes.length;
      }
      if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined) {
        if (assignTOBoard.Votes.length > 0)
          return voteCount + " Votes Received"
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
        return VoteStatus.Approved
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
        return VoteStatus.Denied
      }
    }
  }

  //assign to board text 
  assignToBoardText(caseNote) {
    if (caseNote !== null) {
      if (caseNote.IsAssignedToBoard) {
        if (caseNote.Votes.length > 0 && caseNote.VoteStatus !== null) {
          return CommonConstant.BoardDecision
        } else if (caseNote.VoteStatus === null) {
          return CommonConstant.DecisionRequired
        }
      }
    }
  }

  onAssignment(value) {
    this.selectedAssignment = value;
  }

}
