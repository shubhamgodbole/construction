import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociationMarketListComponent } from './association-market-list.component';

describe('AssociationMarketListComponent', () => {
  let component: AssociationMarketListComponent;
  let fixture: ComponentFixture<AssociationMarketListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociationMarketListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociationMarketListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
