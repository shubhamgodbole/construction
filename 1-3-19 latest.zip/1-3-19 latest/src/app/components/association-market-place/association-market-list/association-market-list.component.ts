import { Component, OnInit } from '@angular/core';
import { MarketPlaceApiService } from 'src/app/services/market-place-api.service';
import * as _ from 'lodash';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Router } from '@angular/router';
import { UserData } from 'src/app/shared/models/user-data-model';
import { CommonService } from 'src/app/services/common.service';
import { AppConfig } from 'src/app/app.config';
import { RoleEnum, TypeOfDocument, NoDataFoundCaseFeatureName } from 'src/app/shared/Enums/commonEnums';
import { AssociationLandingService } from 'src/app/services/association-landing.service';
import { fileData } from '../../association-landing/association-landing.model';
import { Title } from '@angular/platform-browser';
import { environment } from 'src/environments/environment';
import { CommonConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-association-market-list',
  templateUrl: './association-market-list.component.html',
  styleUrls: ['./association-market-list.component.scss']
})
export class AssociationMarketListComponent implements OnInit {
  classifiedAdBuyData: any;
  allListData: any;
  alladds: any ;
  currentTab: string = "All";
  category: any;
  userData: UserData;
  associationId: string;
  userId: string;
  userName: string;
  domain: string;
  documnetType: string;
  isLogin: boolean;
  roleEnum = RoleEnum;
  role: string;
  backButtonTitle: string;
  fileData: any = [];
  isComponontLoad : boolean = false;
  
  isApiResponceCome = false;
  mobNav = false;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  constructor(private service: MarketPlaceApiService,private router: Router,
    public commonService: CommonService, private titleService: Title,
    private associationService: AssociationLandingService,
    private readonly appConfig: AppConfig) {
      this.titleService.setTitle(environment.mainTitle);
      this.userData = this.appConfig.getCurrentUser();
      this.appConfig.isLoggedIn.subscribe(
        (login) => {
          this.isLogin = login;
        }
      );
      if (this.userData !== null) {
      this.associationId = this.userData.UserAssociations[0].AssociationId;
      this.userId = this.userData.UserProfileId;
      this.domain = this.userData.UserAssociations[0].Domain;
      this.documnetType = TypeOfDocument.AssociationImages;
      this.userName = this.userData.UserName;
      this.role = this.userData.Role;
      if(this.userData.Role === this.roleEnum.PropertyManager) {
        this.backButtonTitle =  CommonConstant.ForPmMyApp; //'My App';
      }
      else {
        this.backButtonTitle = CommonConstant.ForMyDashboard;// 'My Dashboard';
      }
    }
  }

  ngOnInit() {
    this.getAdds();
    this.getAllCategories();
  }

  navToggle() {
    if (this.mobNav)
      this.mobNav = false;
    else
      this.mobNav = true;
  }
  // get classified adds without login
  getAdds() {
   let i=0;
    this.service.getClassifiedAds().subscribe(
      (response:any) => {
        this.isApiResponceCome = true;
        this.allListData = response.ClassifiedAdBuy;
        this.alladds = response.ClassifiedAdBuy;
        this.isComponontLoad = true;
          console.log('All Ads',response);
      }
    );
  }
  getCurrentTab(tab) {
    this.service.classifiedAdTab = tab;
  }
  // fetch all categories
  getAllCategories() {
    this.service.getAllCategories().subscribe((response: any) => {
      this.category = response.ClassifiedAdCategory;
      console.log('All Cats',response.ClassifiedAdCategory);
    });
  }
 // filter adds
 filterData(event) {
  this.allListData = this.alladds;
  if (event.target.value !== 'Category') {
    this.allListData = this.allListData.filter((o) => o.ClassifiedAd.ClassifiedAdCategory === event.target.value);
    console.log('filtre',this.allListData);
  }
}
// sort adds
sortData(event) {
  if (event.target.value === 'low') {
    this.allListData = _.orderBy(this.allListData, ['ClassifiedAd.Price'], 'asc');
  }
  if (event.target.value === 'heigh') {
    this.allListData = _.orderBy(this.allListData, ['ClassifiedAd.Price'], 'desc');
  }
  if (event.target.value === 'recentPost') {
    this.allListData = _.orderBy(this.allListData, ['ClassifiedAd.PublishDate'], 'desc');
  }
}
goToDashboard(){
  if (this.userData.Role === this.roleEnum.PropertyManager) {
    this.router.navigate([AppRouteUrl.mainRecentUpdatesRouteUrl]);
  } else {
    this.router.navigate([AppRouteUrl.mainDashboardRouteUrl]);
  }
  // this.router.navigate([AppRouteUrl.mainDashboardRouteUrl]);
}
  // detail
  detail(classifiedAd: any) {
    let classifiedAdId = classifiedAd.ClassifiedAd.id;
    let domain = classifiedAd.Documents[0] ? classifiedAd.Documents[0].Domain : '';
    this.router.navigate([AppRouteUrl.mainAssociationMarketDetailRouteUrl],{ queryParams: { id: classifiedAdId,domain:domain} });
  }
  goToHome() {
    this.router.navigate([AppRouteUrl.corporateHomeRouteUrl]);
    window.scrollTo(0, 0);
  } 
  goToResaleCertificate() {
    let element  = document.getElementById('resale-certificate');
    this.router.navigate([AppRouteUrl.corporateResaleCertificateRouteUrl]);
  }
  // redirect to corporate Demand Request
  goToDemandRequest() {
    let element  = document.getElementById('demand-request');
    this.router.navigate([AppRouteUrl.corporateDemandRequestRouteUrl]);
  }
  // redirect to Condo Questionnaire
  goToCondoQuestionnaire() {
    let element  = document.getElementById('condo-questionnaire');
    this.router.navigate([AppRouteUrl.corporateCondoQuestionnaireRouteUrl]);
  }
  // redirect to corporate blog
  goToBlog() {
    let element  = document.getElementById('why-propvivo');
    this.router.navigate([AppRouteUrl.corporateBlogListRouteUrl]);
  }
  // redirect to corporate contact
  goToContact() {
    let element  = document.getElementById('why-propvivo');
    this.router.navigate([AppRouteUrl.corporateContactUsRouteUrl]);
  }

  gotToCorporate() {
    this.router.navigate([AppRouteUrl.corporateHomeRouteUrl]);
  }
  // uplad images
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            inputStream: event.target.result,
            name: evt.target.files[i].name,
            type: evt.target.files[i].type,
            mediaType: type[1],
            CreatedByUserId: this.userId,
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }

      this.uploadImages();
    }
  }
  uploadImages() {
    let modeldata = this.uploadImagesModel();
    this.associationService.uploadData(this.domain, this.associationId, this.fileData, this.documnetType).subscribe(
      (response: any) => {
        if (response.Success === true) {
          console.log('Images uploaded');
        }
        else {
          console.log('Some Error');
        }
      }
    );
  }
  uploadImagesModel() {
    let model: fileData = {
      Domain: this.domain,
      AssociationId: this.associationId,
      AssociationImages: this.fileData,
      DocumentType: this.documnetType
    }
    return model;
  }
}
