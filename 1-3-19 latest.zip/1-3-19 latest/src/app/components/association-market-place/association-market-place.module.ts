import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssociationMarketDetailComponent } from './association-market-detail/association-market-detail.component';
import { AssociationMarketListComponent } from './association-market-list/association-market-list.component';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Routes, RouterModule } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule } from '@angular/material';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { OnlyAlphabetsModule } from 'src/app/shared/directives/allow-only-alphabets/only-alphabets.module';
import { AllowOnlyPriceModule } from 'src/app/shared/directives/allow-only-price/allow-only-price.module';
const routes: Routes = [
  {
    path: '',
    component: AssociationMarketListComponent
  },
  {
    path: AppRouteUrl.associationMarketDetailRouteUrl,
    component: AssociationMarketDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatetimepickerModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    MatBottomSheetModule,
    MatButtonModule,
    NumberOnlyDirectiveModule,
    MatButtonToggleModule,
    FormsModule,
    RouterModule.forChild(routes),
    NoDataFoundModule,
    AllowOnlyPriceModule,
    OnlyAlphabetsModule
  ],
  exports: [RouterModule],
  declarations: [AssociationMarketListComponent, AssociationMarketDetailComponent]
})
export class AssociationMarketPlaceModule { }
