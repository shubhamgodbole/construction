import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociationMarketDetailComponent } from './association-market-detail.component';

describe('AssociationMarketDetailComponent', () => {
  let component: AssociationMarketDetailComponent;
  let fixture: ComponentFixture<AssociationMarketDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociationMarketDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociationMarketDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
