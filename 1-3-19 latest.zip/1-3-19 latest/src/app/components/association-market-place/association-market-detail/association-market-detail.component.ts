import { Component, OnInit, ViewChild } from '@angular/core';
import { MarketPlaceApiService } from 'src/app/services/market-place-api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { FormBuilder, FormGroup, Validators, FormControl, FormGroupDirective } from '@angular/forms';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar } from '@angular/material';
import { UserData } from 'src/app/shared/models/user-data-model';
import { RoleEnum, TypeOfDocument } from 'src/app/shared/Enums/commonEnums';
import { CommonService } from 'src/app/services/common.service';
import { AppConfig } from 'src/app/app.config';
import { AssociationLandingService } from 'src/app/services/association-landing.service';
import { fileData } from '../../association-landing/association-landing.model';
import { Enquiry } from '../../market-place/market-detail/market-detail.model';

@Component({
  selector: 'app-association-market-detail',
  templateUrl: './association-market-detail.component.html',
  styleUrls: ['./association-market-detail.component.scss']
})
export class AssociationMarketDetailComponent implements OnInit {
  addEnquiryForm: FormGroup;
  querySubcription: Subscription;
  requestId: string;
  domain: string;
  displayDiv: boolean = false;
  classifiedAd: any;
  classifiedAdDocumentList: any;
  sidebar = false;
  notificationService: NotificationService;
  userData: UserData;
  associationId: string;
  userId: string;
  role: string;
  roleEnum = RoleEnum;
  backButtonTitle: string = '';
  isLogin: boolean;
  userName: string;
  fileData: any = [];
  documnetType: string;
  mobNav = false;
  showMinvalue: boolean = false;
  isButtonDisable: boolean = false;

  @ViewChild('formDirective') formDirective: FormGroupDirective;
  constructor(public service: MarketPlaceApiService, private router: Router, private route: ActivatedRoute, private progressbarService: ProgeressBarService,
    private formBuilder: FormBuilder,
    private readonly snb: MatSnackBar,
    public commonService: CommonService,
    private readonly appConfig: AppConfig,
    private associationService: AssociationLandingService
  ) {
    this.notificationService = new NotificationService(snb);
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      let domain = params["domain"];
      if (id) {
        this.requestId = id;
        this.domain = domain;
        this.service.classifiedAdId = id;
        this.getDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
    this.userData = this.appConfig.getCurrentUser();
    this.appConfig.isLoggedIn.subscribe(
      (login) => {
        this.isLogin = login;
      }
    );
    if (this.userData !== null) {
      this.associationId = this.userData.UserAssociations[0].AssociationId;
      this.userId = this.userData.UserProfileId;
      this.domain = this.userData.UserAssociations[0].Domain;
      this.role = this.userData.Role;
      this.userName = this.userData.UserName;
      this.documnetType = TypeOfDocument.AssociationImages;
      if (this.userData.Role === this.roleEnum.PropertyManager) {
        this.backButtonTitle = 'My App';
      }
      else {
        this.backButtonTitle = 'My Dashboard';
      }
    }
    // else {
    //   this.router.navigate([AppRouteUrl.associationMarketDetail]);  
    // }
  }
  setMobileNumber(event) {
    let ctrlValue = this.addEnquiryForm.controls.phone.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.addEnquiryForm.controls.phone.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.addEnquiryForm.controls.phone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.addEnquiryForm.controls.phone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }

  navToggle() {
    if (this.mobNav)
      this.mobNav = false;
    else
      this.mobNav = true;
  }
  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }
  ngOnInit() {
    this.addEnquiryForm = this.formBuilder.group({
      name: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      email: ['', [Validators.required, ValidationService.emailValidator]],
      phone: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13)]],
      price: ['', [Validators.required]],
      message: ['', [Validators.required, Validators.maxLength(200), ValidationService.notStartWhiteSpace]],
    });
  }
  sidebarToggle() {
    if (this.sidebar) {
      this.sidebar = false;
      this.reset();
    }
    else {
      this.sidebar = true;
    }
  }
  // reset data
  reset() {
    this.addEnquiryForm.reset();
    this.formDirective.resetForm();
    this.sidebar = false;
    this.showMinvalue = false;
  }
  getPrice() {
    this.showMinvalue = false;
    if (this.addEnquiryForm.controls.price.value !== '') {
      if(this.addEnquiryForm.controls.price.value <= 0)
      this.showMinvalue = true;
    }
  }
  getDetail() {
    let resData;
    this.progressbarService.show();
    if (this.service.classifiedAdId) {
      this.service.classifiedAdDetail(this.domain).subscribe(response => {
        resData = response;
        if (resData.Success) {
          this.displayDiv = true;
          this.progressbarService.hide();
          this.classifiedAd = resData.ClassifiedAdDetail.ClassifiedAd;
          this.classifiedAdDocumentList = resData.ClassifiedAdDetail.Documents;
        }
      });
    } else {
      this.router.navigate([AppRouteUrl.mainClassifiedAdsRouteUrl]);
    }
  }
  goToDashboard() {
    if (this.userData.Role === this.roleEnum.PropertyManager) {
      this.router.navigate([AppRouteUrl.mainRecentUpdatesRouteUrl]);
    } else {
      this.router.navigate([AppRouteUrl.mainDashboardRouteUrl]);
    }
    //  this.router.navigate([AppRouteUrl.mainDashboardRouteUrl]);
  }
  goBack() {
    window.history.go(-1);
  }
  gotToCorporate() {
    this.router.navigate([AppRouteUrl.corporateHomeRouteUrl]);
  }
  // Enquiry model
  createEnqiryModel(): Enquiry {
    let model: Enquiry = {
      UserName: this.addEnquiryForm.controls.name.value,
      Email: this.addEnquiryForm.controls.email.value,
      Phone: this.addEnquiryForm.controls.phone.value,
      Price: this.addEnquiryForm.controls.price.value,
      Message: this.addEnquiryForm.controls.message.value
    }
    return model;
  }
  addEnquiry() {
    const enquiryData = this.createEnqiryModel();
    const Id = this.service.classifiedAdId;
    if (this.addEnquiryForm.valid && this.showMinvalue === false) {
      this.isButtonDisable =true;
      this.service.addClassifiedEnquiry(enquiryData, Id).subscribe(
        (response: any) => {
          this.isButtonDisable = false;
          console.log('Inquiry', response);
          if (response.Success) {
            this.getDetail();
            this.reset();
            this.notificationService.showNotification('Enquiry Send SuccessFully');
          }
        }
      );
    }

  }
  goToHome() {
    this.router.navigate([AppRouteUrl.corporateHomeRouteUrl]);
    window.scrollTo(0, 0);
  }
  goToResaleCertificate() {
    let element = document.getElementById('resale-certificate');
    this.router.navigate([AppRouteUrl.corporateResaleCertificateRouteUrl]);
  }
  // redirect to corporate Demand Request
  goToDemandRequest() {
    let element = document.getElementById('demand-request');
    this.router.navigate([AppRouteUrl.corporateDemandRequestRouteUrl]);
  }
  // redirect to Condo Questionnaire
  goToCondoQuestionnaire() {
    let element = document.getElementById('condo-questionnaire');
    this.router.navigate([AppRouteUrl.corporateCondoQuestionnaireRouteUrl]);
  }
  // redirect to corporate blog
  goToBlog() {
    let element = document.getElementById('why-propvivo');
    this.router.navigate([AppRouteUrl.corporateBlogListRouteUrl]);
  }
  // redirect to corporate contact
  goToContact() {
    let element = document.getElementById('why-propvivo');
    this.router.navigate([AppRouteUrl.corporateContactUsRouteUrl]);
  }
  // uplad images
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            inputStream: event.target.result,
            name: evt.target.files[i].name,
            type: evt.target.files[i].type,
            mediaType: type[1],
            CreatedByUserId: this.userId,
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }

      this.uploadImages();
    }
  }
  uploadImages() {
    let modeldata = this.uploadImagesModel();
    this.associationService.uploadData(this.domain, this.associationId, this.fileData, this.documnetType).subscribe(
      (response: any) => {
        if (response.Success === true) {
          console.log('Images uploaded');
        }
        else {
          console.log('Some Error');
        }
      }
    );
  }
  uploadImagesModel() {
    let model: fileData = {
      Domain: this.domain,
      AssociationId: this.associationId,
      AssociationImages: this.fileData,
      DocumentType: this.documnetType
    }
    return model;
  }
}
