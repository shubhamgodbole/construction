import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { BmInspectionListComponent } from './bm-inspection-list/bm-inspection-list.component';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { BmInspectionListsComponent } from './bm-inspection-lists/bm-inspection-lists.component';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { MatInputModule, MatListModule, MatMenuModule, MatRippleModule, MatSelectModule, MatSnackBarModule, MatTooltipModule, MatTreeModule, MatAutocompleteModule, MatButtonModule, MatDatepickerModule, MatBottomSheetModule, MatCheckboxModule } from '@angular/material';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DisplayTimeElapsedModule } from 'src/app/shared/modules/display-time-elapsed.module';

const routes: Routes = [
  {
    path: '',// AppRouteUrl.bmInspectionListRouteUrl,
    component: BmInspectionListsComponent
  },
  {
    path: AppRouteUrl.bmInspectionDetailRouteUrl, //'bm-inspection-detail',
    component: BmInspectionListComponent
  },

];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRippleModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    NoCaseNoteFoundModule,
    MatTreeModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    DisplayTimeElapsedModule,
    MatButtonModule,
    MatDatepickerModule,
    MatBottomSheetModule,
    MatCheckboxModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  declarations: [BmInspectionListsComponent,
    BmInspectionListComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [RouterModule]
})
export class BmInspectionModule { }
