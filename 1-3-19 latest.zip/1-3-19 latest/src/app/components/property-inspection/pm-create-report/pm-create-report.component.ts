import { Component, OnInit, ViewChild } from '@angular/core';
import { MatAutocompleteTrigger, MatDialog, MatDialogRef } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { DropdownModelAssociationUnit } from 'src/app/shared/common/models';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { PropertyInspectionService } from 'src/app/services/property-inspection.service';
import { InsceptionType, updateInspectionModel, copyInspectionModel, AddressType, ViolationStatus } from '../property-inspection.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { NoDataFoundCaseFeatureName } from 'src/app/shared/Enums/commonEnums';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { CommonConstant } from 'src/app/shared/common/constant.model';

import { Location } from '@angular/common';
@Component({
  selector: 'app-pm-create-report',
  templateUrl: './pm-create-report.component.html',
  styleUrls: ['./pm-create-report.component.scss']
})
export class PmCreateReportComponent implements OnInit {
  // for get detail
  inspectionId: string;
  domain: string;
  userData: UserData;
  propertyInspection: any;
  propertyInspectionDocuments: any = [];
  pendingDocuments: any = [];
  cancelDocuments: any = [];
  inProgressDocuments: any = [];
  associationId: string;
  addressTypeEnum = AddressType;

  //delete dialog
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;


  //association unit drop down autocomplate
  associationUnitDdl: any[] = [];
  associationAutoCompleteUnitDdl: any[];

  /*Reset mat auto compelte*/
  @ViewChild('associationUnitAutoComplete', { read: MatAutocompleteTrigger })
  associationUnitTrigger: MatAutocompleteTrigger;

  //association unit drop down autocomplate
  associationAutoCompleteUnitPendingDdl: any[];
  /*Reset mat auto compelte*/
  @ViewChild('associationUnitPendingTrigger', { read: MatAutocompleteTrigger })
  associationUnitPendingTrigger: MatAutocompleteTrigger;


  //form create
  frmCreateReport: FormGroup;
  typeofViolations: any = [];

  //query string
  querySubcription: Subscription;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  isApiResponceCome = false;
  constructor(private service: PropertyInspectionService, private formBuilder: FormBuilder,
    private progressBarService: ProgeressBarService, private _matDialog: MatDialog,
    private route: ActivatedRoute,
    private _location: Location,
    private appConfig: AppConfig, private router: Router,
    private commonService: CommonService) {
    this.userData = this.appConfig.getCurrentUser();
    this.getTypeOfViolation();
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      let domain = params["domain"];
      if (id && domain) {
        this.inspectionId = id;
        this.domain = domain;
        this.getDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
    this.createReportForm();

  }

  formControlChanged(i) {
    if (this.checkValidity(i) === true) {
      let resData;
      let des = this.frmCreateReport.get('inProgressDocs').value[i].description;
      let ccrType = this.frmCreateReport.get('inProgressDocs').value[i].violationType;
      let area = this.frmCreateReport.get('inProgressDocs').value[i].addressType;
      let unit = this.frmCreateReport.get('inProgressDocs').value[i].associationUnit;
      let id = this.frmCreateReport.get('inProgressDocs').value[i].id;
      var model = this.updateModel(id, unit, i, des, ccrType, area);
      this.service.updateInspection(model).subscribe(res => {
        resData = res;
        if (resData.Success) {
          this.getDetail();
        }
      });
    }
  }

  formControlPendingChanged(i) {
    if (this.checkValidityPending(i) === true) {
      let resData;
      let des = this.frmCreateReport.get('pendingDocs').value[i].description;
      let ccrType = this.frmCreateReport.get('pendingDocs').value[i].violationType;
      let area = this.frmCreateReport.get('pendingDocs').value[i].addressType;
      let unit = this.frmCreateReport.get('pendingDocs').value[i].associationUnit;
      let id = this.frmCreateReport.get('pendingDocs').value[i].id;
      var model = this.updateModel(id, unit, i, des, ccrType, area);
      this.service.updateInspection(model).subscribe(res => {
        resData = res;
        if (resData.Success) {
          this.getDetail();
        }
      });
    }
  }


  formControlAddressTypeChanged(i) {
    var associationUnit = this.frmCreateReport.get("inProgressDocs")['controls'][i].controls.associationUnit;
    var mode = this.frmCreateReport.get("inProgressDocs")['controls'][i].controls.addressType.value;
    if (mode === AddressType.HomeUnit) {
      associationUnit.setValidators([Validators.required, Validators.minLength(13), Validators.maxLength(13)]);
    }
    else {
      associationUnit.clearValidators();
      associationUnit.setValue('');
    }
    associationUnit.updateValueAndValidity();
    this.formControlChanged(i);
  }

  formControlPendingAddressTypeChanged(i) {
    var associationUnit = this.frmCreateReport.get("pendingDocs")['controls'][i].controls.associationUnit;
    var mode = this.frmCreateReport.get("pendingDocs")['controls'][i].controls.addressType.value;
    if (mode === AddressType.HomeUnit) {
      associationUnit.setValidators([Validators.required, Validators.minLength(13), Validators.maxLength(13)]);
    }
    else {
      associationUnit.clearValidators();
      associationUnit.setValue('');
    }
    associationUnit.updateValueAndValidity();
    this.formControlChanged(i);
  }

  checkValidity(i) {
    var addressType = this.frmCreateReport.get("inProgressDocs")['controls'][i].controls.addressType.invalid;
    var associationUnit = this.frmCreateReport.get("inProgressDocs")['controls'][i].controls.associationUnit.invalid;
    var description = this.frmCreateReport.get("inProgressDocs")['controls'][i].controls.description.invalid;
    var violationType = this.frmCreateReport.get("inProgressDocs")['controls'][i].controls.violationType.invalid;
    //document.getElementById('submitBtn').click();
    if (addressType !== true && associationUnit !== true && description !== true && violationType !== true) {
      return true;
    }
    return false;
  }

  checkValidityPending(i) {
    var addressType = this.frmCreateReport.get("pendingDocs")['controls'][i].controls.addressType.invalid;
    var associationUnit = this.frmCreateReport.get("pendingDocs")['controls'][i].controls.associationUnit.invalid;
    var description = this.frmCreateReport.get("pendingDocs")['controls'][i].controls.description.invalid;
    var violationType = this.frmCreateReport.get("pendingDocs")['controls'][i].controls.violationType.invalid;
    if (addressType !== true && associationUnit !== true && description !== true && violationType !== true) {
      return true;
    }
    return false;
  }

  createReportForm() {
    this.frmCreateReport = this.formBuilder.group({
      inProgressDocs: this.formBuilder.array([]),
      pendingDocs: this.formBuilder.array([])
    });
  }

  getDetail() {
    let resData
    this.progressBarService.show();
    this.service.getDetail(this.inspectionId, this.domain).subscribe(res => {
      console.log('res ', res);
      this.isApiResponceCome = true;
      resData = res;
      this.progressBarService.hide();
      if (resData.Success == true) {
        this.propertyInspection = resData.PropertyInspection;
        if (this.propertyInspection !== null) {
          this.associationId = this.propertyInspection.AssociationId;
          this.getAssociationUnit();
          this.propertyInspectionDocuments = this.propertyInspection.PropertyInspectionDocuments;
          this.inProgressDocuments = this.propertyInspectionDocuments.filter(x => x.ViolationStatus === ViolationStatus.InProgress);
          if (this.inProgressDocuments.length > 0) {
            if (this.inProgressDocumentsArray.length > 0) {
              this.clearFormArray(this.inProgressDocumentsArray);
            }
            this.inProgressDocuments.map(a => {
              this.inProgressDocumentsArray.push(this.formBuilder.group({
                id: [a.id],
                associationUnit: [''],
                addressType: ['CommonArea', Validators.required],
                description: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
                violationType: ['', Validators.required],
                filePath: [a.FilePath]
              }));
            })
          } else {
            this.clearFormArray(this.inProgressDocumentsArray);
          }
          this.cancelDocuments = this.propertyInspectionDocuments.filter(x => x.ViolationStatus === ViolationStatus.Cancelled);
          this.pendingDocuments = this.propertyInspectionDocuments.filter(x => x.ViolationStatus === ViolationStatus.AwaitingBoardDecision);

        }
      }
    })
  }

  copyInspection(id) {
    let resData;
    let requestParam = this.createModel(id);
    this.service.copyInspection(requestParam).subscribe(res => {
      resData = res;
      if (resData.Success) {
        this.getDetail();
      }
    })
  }

  clearFormArray = (formArray: FormArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }

  cancelInspection(id) {
    let resData;
    let requestParam = this.createModel(id);
    this.service.cancelInspection(requestParam).subscribe(res => {
      resData = res;
      if (resData.Success) {
        this.getDetail();
      }
    })
  }

   //for delete 
   rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmTitle = "Violation";
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.cancelInspection(valueObject);
      }
    });
  }

  getTypeOfViolation() {
    let resData;
    this.service.typeOfViolations().subscribe(res => {
      resData = res;
      if (resData.Success) {
        this.typeofViolations = resData.TypeofViolations;
      }
    })
  }


  createModel(id) {
    let model: copyInspectionModel = {
      Domain: this.domain,
      PropertyInspection:
      {
        Id: this.propertyInspection.id,
        PropertyInspectionDocuments: [
          {
            id: id,
          }],
        ModifiedByUserId: this.userData.UserProfileId
      }
    }
    return model;
  }

  updateModel(id, unit, i, des, ccrType, area) {
    let model: updateInspectionModel = {
      Domain: this.domain,
      PropertyInspection:
      {
        Id: this.propertyInspection.id,
        PropertyInspectionDocuments: [
          {
            id: id,
            AssociationUnitId: unit !== '' ? unit.CreatedByUnitId : '',
            AssociationUnitNumber: unit !== '' ? unit.CreatedByUnitNumber : '',
            AssociationUnitAddress1: unit !== '' ? unit.CreatedByUnitAddress1 : '',
            AssociationUnitAddress2: unit !== '' ? unit.CreatedByUnitAddress2 : '',
            AssociationUnitCity: unit !== '' ? unit.CreatedByUnitCity : '',
            AssociationUnitState: unit !== '' ? unit.CreatedByUnitState : '',
            AssociationUnitZip: unit !== '' ? unit.CreatedByUnitZip : '',
            Description: des,
            CCRType: ccrType,
            Type: InsceptionType.InsceptionType,
            ViolationArea: area
          }],
        ModifiedByUserId: this.userData.UserProfileId
      }
    }
    return model;
  }


  // for array of inprogess Documnets
  get inProgressDocumentsArray() {
    return this.frmCreateReport.get('inProgressDocs') as FormArray;
  }

  get pendingDocumentsArray() {
    return this.frmCreateReport.get('pendingDocs') as FormArray;
  }


  getAssociationUnit() {
    let resData;
    this.service.getAssociationUnits(this.associationId).subscribe(res => {
      console.log(res);
      resData = res;
      if (resData.Success) {
        if (resData.AssociationUnits !== null && resData.AssociationUnits !== undefined && resData.AssociationUnits.length > 0) {
          let associationUnits = resData.AssociationUnits;
          associationUnits.map(associationUnit => {
            let unitAddress = this.commonService.getFullAssociationAddress(associationUnit);
            if (unitAddress !== null && unitAddress !== undefined) {
              let dropdownModelAssociationUnit = new DropdownModelAssociationUnit();
              dropdownModelAssociationUnit.CreatedByUnitAddress1 = associationUnit.AssociationUnitAddress1;
              dropdownModelAssociationUnit.CreatedByUnitAddress2 = associationUnit.AssociationUnitAddress2;
              dropdownModelAssociationUnit.CreatedByUnitCity = associationUnit.AssociationUnitCity;
              dropdownModelAssociationUnit.CreatedByUnitState = associationUnit.AssociationUnitState;
              dropdownModelAssociationUnit.CreatedByUnitId = associationUnit.id;
              dropdownModelAssociationUnit.CreatedByUnitZip = associationUnit.AssociationUnitZip;
              dropdownModelAssociationUnit.CreatedByUnitNumber = associationUnit.AssociationUnitNumber;
              dropdownModelAssociationUnit.Text = unitAddress;
              this.associationUnitDdl.push(dropdownModelAssociationUnit);
            }
          });
          this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
          if (this.pendingDocuments.length > 0) {
            if (this.pendingDocumentsArray.length > 0) {
              this.clearFormArray(this.pendingDocumentsArray);
            }
            this.pendingDocuments.map(a => {
              let associationUnit = '';
              let isReadOnly: boolean = false;
              if (a.AssociationUnitId) {
                associationUnit = this.associationUnitDdl.find(x => x.CreatedByUnitId === a.AssociationUnitId);
              }
              if (a.Votes !== null) {
                if (a.Votes.length > 0) {
                  isReadOnly = true;
                }
              }
              this.pendingDocumentsArray.push(this.formBuilder.group({
                id: [a.id],
                associationUnit: [associationUnit],
                addressType: [a.ViolationArea, Validators.required],
                description: [a.Description, [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]],
                violationType: [a.CCRType, Validators.required],
                filePath: [a.FilePath],
                isReadOnly: [isReadOnly]
              }));

            })
          }
        }
      }
    });
  }

  /**Auto complete association Unit Display Function**/
  displayFnAutoCompleteUnit(associationUnit) {
    if (associationUnit != null) {
      return associationUnit.Text;
    } else return associationUnit;
  }

  /**Auto complete association Unit filter change**/
  onInputUnitChanged(searchStr: string): void {
    this.associationAutoCompleteUnitDdl = [];
    this.associationAutoCompleteUnitDdl = this.associationUnitDdl.filter(option =>
      option.Text.toLowerCase().includes(searchStr.toLowerCase()));
  }

  onFocusOutUnit(searchStr, i) {
    this.associationAutoCompleteUnitDdl = this.associationUnitDdl.filter(option =>
      option.Text.toLowerCase().includes(searchStr.toLowerCase()));
    if (this.associationAutoCompleteUnitDdl.length === 0) {
      this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
      (<FormGroup>(<FormArray>this.frmCreateReport.controls.inProgressDocs).controls[i]).controls.associationUnit.setValue('');
    } else if (this.associationAutoCompleteUnitDdl.length > 0) {
      this.formControlChanged(i);
    }
  }


  /**Auto complete association Unit Display Function**/
  displayFnAutoCompleteUnitPending(associationUnit) {
    if (associationUnit != null) {
      return associationUnit.Text;
    } else return associationUnit;
  }

  /**Auto complete association Unit filter change**/
  onInputUnitChangedPending(searchStr: string): void {
    this.associationAutoCompleteUnitPendingDdl = [];
    this.associationAutoCompleteUnitPendingDdl = this.associationUnitDdl.filter(option =>
      option.Text.toLowerCase().includes(searchStr.toLowerCase()));
  }

  //for clear association Unit drop down
  onFocusOutUnitPending(searchStr, i) {
    this.associationAutoCompleteUnitPendingDdl = this.associationUnitDdl.filter(option =>
      option.Text.toLowerCase().includes(searchStr.toLowerCase()));
    if (this.associationAutoCompleteUnitPendingDdl.length === 0) {
      this.associationAutoCompleteUnitPendingDdl = this.associationUnitDdl;
      (<FormGroup>(<FormArray>this.frmCreateReport.controls.pendingDocs).controls[i]).controls.associationUnit.setValue('');
    } else if (this.associationAutoCompleteUnitPendingDdl.length > 0) {
      this.formControlPendingChanged(i);
    }
  }


 

  toGoBack() {
    this._location.back();
  }
}

