import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmInspectionListComponent } from './bm-inspection-list.component';

describe('BmInspectionListComponent', () => {
  let component: BmInspectionListComponent;
  let fixture: ComponentFixture<BmInspectionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmInspectionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmInspectionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
