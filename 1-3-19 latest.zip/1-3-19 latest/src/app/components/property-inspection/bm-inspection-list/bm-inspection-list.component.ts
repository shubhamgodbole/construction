import { Component, OnInit, ViewChild } from '@angular/core';
import { PropertyInspectionService } from 'src/app/services/property-inspection.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { AppConfig } from 'src/app/app.config';
import { CommonService } from 'src/app/services/common.service';
import { UserData } from 'src/app/shared/models/user-data-model';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { AddressType, ViolationVoteModel, RemarkModel, ViolationStatus } from '../property-inspection.model';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { Location } from '@angular/common';
@Component({
  selector: 'app-bm-inspection-list',
  templateUrl: './bm-inspection-list.component.html',
  styleUrls: ['./bm-inspection-list.component.scss']
})
export class BmInspectionListComponent implements OnInit {
  // for get detail
  inspectionId: string;
  domain: string;
  documentId: string;
  userData: UserData;
  userName: string = "";
  userId: string = "";
  associationId: string = "";
  userProfilePath: string = "";

  //query string
  querySubcription: Subscription;
  violationStatusEnum = ViolationStatus;
  violationAreaAddressType = AddressType;
  isDisplayVoteList: boolean = false;

  propertyInspectionDocumentDetail: any;
  associationUnitFullAddress: string = "";
  violationVoteCount: number = 0;
  violationVoterList: any[];
  isVote: boolean;

  /*Remark*/
  frmCreateRemark: FormGroup;
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  constructor(private propertyInspectionService: PropertyInspectionService,
    private progressBarService: ProgeressBarService,
    private readonly formBuilder: FormBuilder,
    private _router: Router,
    private _location: Location,
    private route: ActivatedRoute,
    private readonly appConfig: AppConfig,
    private commonService: CommonService) {
    this.userData = this.appConfig.getCurrentUser();
    this.userName = this.userData.UserName;
    this.userId = this.userData.UserProfileId;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.userProfilePath = this.userData.UserProfileBlobPath;
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let inspectionId = params["inspectionId"];
      let id = params["id"];
      let domain = params["domain"];
      if (id && domain) {
        this.inspectionId = inspectionId;
        this.documentId = id;
        this.domain = domain;
        this.getDetail();
      }
      else {
        this._router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });

    this.createRemarkForm();

  }

  getDetail() {
    let resData
    this.progressBarService.show();
    this.propertyInspectionService.getDocumentDetail(this.inspectionId, this.documentId, this.domain).subscribe(res => {
      resData = res;
      this.progressBarService.hide();
      if (resData.Success == true) {
        this.propertyInspectionDocumentDetail = resData.PropertyInspectionDocument;
        console.log("this.propertyInspection", this.propertyInspectionDocumentDetail);
        if (this.propertyInspectionDocumentDetail !== null && this.propertyInspectionDocumentDetail !== undefined) {
          this.associationUnitFullAddress = this.associationUnitAddress(this.propertyInspectionDocumentDetail.AssociationUnitNumber,
            this.propertyInspectionDocumentDetail.AssociationUnitAddress1, this.propertyInspectionDocumentDetail.AssociationUnitAddress2,
            this.propertyInspectionDocumentDetail.AssociationUnitCity, this.propertyInspectionDocumentDetail.AssociationUnitState,
            this.propertyInspectionDocumentDetail.AssociationUnitZip);

          if (this.propertyInspectionDocumentDetail.Votes !== null) {
            if (this.propertyInspectionDocumentDetail.Votes.length !== 0) {
              this.violationVoterList = this.propertyInspectionDocumentDetail.Votes;
              this.violationVoteCount = this.propertyInspectionDocumentDetail.Votes.length;
              let voteByUser = this.propertyInspectionDocumentDetail.Votes.find(v => v.CreatedByUserId === this.userId);
              if (voteByUser) {
                this.isVote = voteByUser.Votes;
              }
            }
          }
        }
      }
    })
  }

  associationUnitAddress(AssociationUnitNumber, AssociationUnitAddress1, AssociationUnitAddress2, AssociationUnitCity, AssociationUnitState, AssociationUnitZip): string {
    let associationUnit = {
      AssociationUnitNumber: AssociationUnitNumber,
      AssociationUnitAddress1: AssociationUnitAddress1,
      AssociationUnitAddress2: AssociationUnitAddress2,
      AssociationUnitCity: AssociationUnitCity,
      AssociationUnitZip: AssociationUnitZip,
      AssociationUnitState: AssociationUnitState,
    }
    let address = this.commonService.getFullAssociationAddress(associationUnit);
    return address;
  }
  /**Create Violation Vote */
  createViolationVote(voteStatus, documentId) {
    let model = this.createViolationVoteModel(documentId);
    console.log("model", model);
    this.progressBarService.show();
    let resData;
    if (voteStatus === "Approve") {
      this.propertyInspectionService.createViolationApprovalVote(model).subscribe(res => {
        this.progressBarService.hide();
        resData = res;
        if (resData.Success === true) {
          this.getDetail();
        }
        else if (resData.Success === false) {
          console.log("error");
        }
      });
    } else {
      this.propertyInspectionService.createViolationDeniedVote(model).subscribe(res => {
        this.progressBarService.hide();
        resData = res;
        if (resData.Success === true) {
          this.getDetail();
        }
        else if (resData.Success === false) {
          console.log("error");
        }
      });
    }
  }

  createViolationVoteModel(documentId) {
    const model: ViolationVoteModel = {
      AssociationId: this.associationId,
      InspectionId: this.inspectionId,
      UserProfileId: this.userId,
      UserName: this.userName,
      DocumentId: documentId,
    }
    return model;
  }

  /*Remark Add Module*/
  createRemarkForm() {
    this.frmCreateRemark = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  createRemark() {
    if (this.frmCreateRemark.valid) {
      let model = this.createRemarkModel();
      console.log("model", model);
      this.progressBarService.show();
      let resData;
      this.propertyInspectionService.createViolationRemark(model).subscribe(res => {
        this.progressBarService.hide();
        resData = res;
        if (resData.Success === true) {
          this.getDetail();
          this.resetRemarkForm();
        }
        else if (resData.Success === false) {
          console.log("error");
        }
      });
    }
  }

  createRemarkModel() {
    const model: RemarkModel = {
      AssociationId: this.associationId,
      InspectionId: this.inspectionId,
      UserProfileId: this.userId,
      UserName: this.userName,
      DocumentId: this.documentId,
      Remarks: this.frmCreateRemark.controls.comments.value,
    }
    return model;
  }

  resetRemarkForm() {
    this.frmCreateRemark.reset();
    this.formDirective.resetForm();
  }


  /*Display list of vote*/
  displayVoteListToggle() {
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }

  toGoBack() {
    this._location.back();
  }

}
