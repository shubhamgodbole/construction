export class AddInspection {
    Domain: string;
    AssociationName: string;
    CompanyCode: string;
    PropertyInspection: PropertyInspectionModel;
}
export class PropertyInspectionModel {
    PMCompanyAssociationMappingId: string;
    InspectionTitle: string;
    PropertyInspectionDocuments: PropertyInspectionDocumentsModel[];
    CreatedByUserId: string;
    AssociationId: string;
    CreatedByUserName: string;
    InspectionDate: string;
}
export class PropertyInspectionDocumentsModel {
    Name: string;
    FilePath: string;
    DisplayOrder: string
    AssociationUnitId: string;
    AssociationUnitNumber: string;
    AssociationUnitAddress1: string;
    AssociationUnitAddress2: string;
    AssociationUnitCity: string;
    AssociationUnitState: string;
    AssociationUnitZip: string;
}

export enum InspectionStatusEnum {
    All = "All",
    New = "New",
    InProgress = "InProgress",
    AwaitingBoardDecision = "AwaitingBoardDecision",
    Completed = "Completed",
    Cancelled = "Canceled",
    ApprovedByBoard = "ApprovedByBoard"
}

export class copyInspectionModel {
    Domain: string;
    PropertyInspection:
        {
            Id: string,
            PropertyInspectionDocuments: [
                {
                    id: string;
                }],
            ModifiedByUserId: string;
        }
}

export class updateInspectionModel {
    Domain: string;
    PropertyInspection:
        {
            Id: string,
            PropertyInspectionDocuments: [
                {
                    id: string;
                    AssociationUnitId: string;
                    AssociationUnitNumber: string;
                    AssociationUnitAddress1: string;
                    AssociationUnitAddress2: string;
                    AssociationUnitCity: string;
                    AssociationUnitState: string;
                    AssociationUnitZip: string;
                    Description: string;
                    CCRType: string;
                    Type: string;
                    ViolationArea: string;
                }],
            ModifiedByUserId: string;
        }
}




export enum AddressType {
    HomeUnit = "HomeUnit",
    CommonArea = "CommonArea"
}


export enum DisplayAddressTypeEnum {
    HomeUnit = "Home Units",
    CommonArea = "Common Area"
}


export const InsceptionType = {
    InsceptionType: "Association"
}

export class ViolationVoteModel {
    AssociationId: string;
    InspectionId: string;
    UserProfileId: string;
    UserName: string;
    DocumentId: string;
}

export class RemarkModel {
    AssociationId: string;
    InspectionId: string;
    UserProfileId: string;
    UserName: string;
    DocumentId: string;
    Remarks: string;
}

export enum ViolationStatus {
    Pending = "Pending",
    Cancelled = "Canceled",
    InProgress = "InProgress",
    AwaitingBoardDecision = "AwaitingBoardDecision",
    Approved = "Approved",
    Denied = "Denied",
    Processed = "Processed"
}