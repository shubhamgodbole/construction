import { Component, OnInit, ViewChild } from '@angular/core';
import { PropertyInspectionService } from 'src/app/services/property-inspection.service';
import { CommonService } from 'src/app/services/common.service';
import { MatAutocompleteTrigger, MatSnackBar } from '@angular/material';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { Guid } from 'guid-typescript';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { ImageNameEnums, TriggerType, AudienceType } from 'src/app/shared/Enums/commonEnums';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { AddInspection, PropertyInspectionDocumentsModel } from '../property-inspection.model';
import { Router, NavigationExtras } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-property-manager',
  templateUrl: './property-manager.component.html',
  styleUrls: ['./property-manager.component.scss']
})
export class PropertyManagerComponent implements OnInit {
  notificationService: NotificationService;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;

  //localStorage values
  userData: UserData;
  userName: string = "";
  createdByUserId: string = "";


  //Form Add inspection
  frmAddInspection: FormGroup;
  isSubmitBtnAddInspectionDisabled: boolean = false;
  fileData = [];
  inspectionImage: boolean = false;
  @ViewChild('inspectionDt') inspectionDt;
  @ViewChild('formDirectiveAddInspection') formDirectiveAddInspection: FormGroupDirective;

  //Bind Association Data
  @ViewChild('InspectionAddAssociationAutoComplete', { read: MatAutocompleteTrigger })
  addInspectionAssociationtrigger: MatAutocompleteTrigger;

  associationDdl: any[] = [];
  associationDdlAutocompleteList: any[] = [];

  constructor(private propertyInspectionService: PropertyInspectionService,
    private readonly formBuilder: FormBuilder,
    private progressbarService: ProgeressBarService,
    private _location: Location,
    private _router: Router,
    private readonly snb: MatSnackBar,
    private readonly appConfig: AppConfig,
    public commonService: CommonService) {
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    this.userName = this.userData.UserName;
    this.createdByUserId = this.userData.UserProfileId;
  }

  ngOnInit() {
    this.createForm();
    this.getAssociationDdl();
  }

  /*Reset mat auto compelte*/
  ngAfterViewInit() {
    this.addInspectionAssociationtrigger.panelClosingActions
      .subscribe(e => {
        if (!(e && e.source)) {
          this.frmAddInspection.controls.association.setValue('');
          this.addInspectionAssociationtrigger.closePanel();
          this.associationDdlAutocompleteList = this.associationDdl;
        }
      });
  }


  createForm() {
    this.frmAddInspection = this.formBuilder.group({
      association: ['', Validators.required],
      inspectionReportName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      inspectionImages: ['', Validators.required],
      inspectionDate: ['', Validators.required]
    });
  }

  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
      this.inspectionImage = false;
    } else {
      this.inspectionImage = true;
    }
    console.log(this.fileData);
  }

  // remove uploaded Documents
  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }

  getAssociationDdl() {
    let resData;
    this.commonService.getAssociation().subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.associationDdl = resData.AssociationList;
        this.associationDdlAutocompleteList = resData.AssociationList;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  onSubmit() {
    if (this.frmAddInspection.controls.inspectionImages.invalid || this.fileData.length < 0)
      this.inspectionImage = true;
    else
      this.inspectionImage = false;

    if (this.frmAddInspection.valid) {
      this.isSubmitBtnAddInspectionDisabled = true;
      let model = this.createAddInspectionFormModel();
      this.progressbarService.show();
      let resDataCreate;
      this.propertyInspectionService.createInspection(model).subscribe(res => {
        this.isSubmitBtnAddInspectionDisabled = false;
        resDataCreate = res;
        this.progressbarService.hide();
        if (resDataCreate.Success === true) {
          console.log("RequestId", resDataCreate.RequestId);
          this.notificationService.showNotification("Inspection saved successfully");
          var formSelectedAssociation = this.frmAddInspection.controls.association.value;
          let navigationExtras: NavigationExtras = {
            queryParams: {
              "id": resDataCreate.RequestId,
              "domain": formSelectedAssociation.Domain
            }
          };
          this._router.navigate([AppRouteUrl.mainPmCreateReportRouteUrl], navigationExtras);
          this.resetInspectionForm();
        }
        else if (resDataCreate.Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  createAddInspectionFormModel() {
    var formSelectedAssociation = this.frmAddInspection.controls.association.value;
    console.log("formSelectedAssociation", formSelectedAssociation);
    let propertyInspectionDocumentsModel = new Array<PropertyInspectionDocumentsModel>();
    for (let i = 0; i < this.fileData.length; i++) {
      let displayOrder = i + 1;
      let piModel: PropertyInspectionDocumentsModel = new PropertyInspectionDocumentsModel();
      piModel.FilePath = this.fileData[i].inputStream;
      piModel.Name = this.fileData[i].name;
      piModel.DisplayOrder = displayOrder.toString();
      piModel.AssociationUnitAddress1 = "";
      piModel.AssociationUnitAddress2 = "";
      piModel.AssociationUnitCity = "";
      piModel.AssociationUnitId = "";
      piModel.AssociationUnitNumber = "";
      piModel.AssociationUnitState = "";
      piModel.AssociationUnitZip = "";
      propertyInspectionDocumentsModel.push(piModel);
    }

    const model: AddInspection = {
      Domain: formSelectedAssociation.Domain,
      AssociationName: formSelectedAssociation.AssociationName,
      CompanyCode: formSelectedAssociation.CompanyCode,
      PropertyInspection: {
        InspectionDate: new Date(this.frmAddInspection.controls.inspectionDate.value).toUTCString(),
        AssociationId: formSelectedAssociation.id,
        PMCompanyAssociationMappingId: formSelectedAssociation.PMCompanyAssociationMappingId,
        InspectionTitle: this.frmAddInspection.controls.inspectionReportName.value,
        PropertyInspectionDocuments: propertyInspectionDocumentsModel,
        CreatedByUserId: this.createdByUserId,
        CreatedByUserName: this.userName
      }
    }
    console.log("model", model);
    return model;
  }

  resetInspectionForm() {
    this.frmAddInspection.reset();
    this.formDirectiveAddInspection.resetForm();
    this.isSubmitBtnAddInspectionDisabled = false;
    this.fileData = [];
  }

  /**Auto complete filter on change**/
  onInputChanged(searchStr: string): void {
    this.associationDdlAutocompleteList = [];
    this.associationDdlAutocompleteList = this.associationDdl.filter(option =>
      option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
  }

  /**Auto complete Display Function**/
  displayFnAutoCompleteAssociation(association) {
    if (association != null && association.AssociationName != null) {
      return association.AssociationName;
    } else association;
  }

  toGoBack() {
    this._location.back();
  }

   

}
