import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmInspectionLetterComponent } from './pm-inspection-letter.component';

describe('PmInspectionLetterComponent', () => {
  let component: PmInspectionLetterComponent;
  let fixture: ComponentFixture<PmInspectionLetterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmInspectionLetterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmInspectionLetterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
