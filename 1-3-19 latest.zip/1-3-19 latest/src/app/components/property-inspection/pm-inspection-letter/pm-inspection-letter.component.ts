import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pm-inspection-letter',
  templateUrl: './pm-inspection-letter.component.html',
  styleUrls: ['./pm-inspection-letter.component.scss']
})
export class PmInspectionLetterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
