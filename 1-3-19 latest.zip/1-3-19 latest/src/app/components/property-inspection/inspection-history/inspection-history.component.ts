import { Component, OnInit } from '@angular/core';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { Router, NavigationExtras } from '@angular/router';
import { PropertyInspectionService } from 'src/app/services/property-inspection.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { AppConfig } from 'src/app/app.config';
import { CommonService } from 'src/app/services/common.service';
import { TypeOfDocument, RoleEnum, NoDataFoundCaseFeatureName } from 'src/app/shared/Enums/commonEnums';
import { UserData } from 'src/app/shared/models/user-data-model';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { InspectionStatusEnum, DisplayAddressTypeEnum } from '../property-inspection.model';
import { CommonConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-inspection-history',
  templateUrl: './inspection-history.component.html',
  styleUrls: ['./inspection-history.component.scss']
})
export class InspectionHistoryComponent implements OnInit {
  propVivoName = CommonConstant.PropVivo;
  isApiResponseCome: boolean = false;
  inspectionHistoryList: any = [];
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  inspectionStatusEnum = InspectionStatusEnum;
  displayAddressTypeEnum = DisplayAddressTypeEnum;
  roleEnum = RoleEnum;
  status = "All";
  approvedByBoardCount: number = 0;
  awaitingBoardDecisionCount: number = 0;
  completedCount: number = 0;
  inProgressCount: number = 0;

  //localStorage values
  userData: UserData;
  userName: string = "";
  createdByUserId: string = "";
  role: string = "";

  //Gloabal Association
  globalAssociationModel: GlobalAssociationModel;


  isApiResponceCome = false;

  constructor(private _router: Router,
    private propertyInspectionService: PropertyInspectionService,
    private progressbarService: ProgeressBarService,
    private globalAssociationService: GlobalAssociationService,
    private readonly appConfig: AppConfig,
    private commanService: CommonService
  ) {
    this.userData = this.appConfig.getCurrentUser();
    this.role = this.userData.Role;
  }

  ngOnInit() {
    this.globalAssociationService.associationSubject.subscribe(res => {
      this.globalAssociationModel = res;
      if (res !== 1) {
        this.getData();
      }
    });
  }

  createInspection() {
    this._router.navigate([AppRouteUrl.mainAddInspectionRouteUrl]);
  }

  statusChange(s) {
    this.status = s;
    this.getData();
  }

  getData() {
    let resData;
    let resStatus = this.status === "All" ? "" : this.status;
    this.progressbarService.show();
    console.log("this.globalAssociationModel.AssociationId", this.globalAssociationModel.AssociationId);
    this.propertyInspectionService.getInspectionHistory(this.globalAssociationModel.AssociationId, resStatus).subscribe(res => {
      this.isApiResponceCome = true;
      this.isApiResponseCome = true;
      resData = res;
      console.log("inspectionHistoryListres", res);
      this.progressbarService.hide();
      if (resData.Success === true) {
        this.approvedByBoardCount = resData.ApprovedByBoardCount;
        this.awaitingBoardDecisionCount = resData.AwaitingBoardDecisionCount;
        this.completedCount = resData.CompletedCount;
        this.inProgressCount = resData.InProgressCount;
        if (this.role === RoleEnum.PropertyManager) {
          this.inspectionHistoryList = resData.PropertyInspectionDashboard;
        } else {
          this.inspectionHistoryList = resData.PropertyInspectionDashboard.filter(inspection => inspection.InspectionStatus !== InspectionStatusEnum.InProgress);
        }
        console.log("inspectionHistoryList", this.inspectionHistoryList);
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  getInspectionHistoryDetails(detailId, domain) {
    console.log(detailId, domain);
    if (detailId !== "" && detailId !== null && detailId !== undefined) {
      this.propertyInspectionService.inspectionHistoryDetailId = detailId;
      this.propertyInspectionService.domain = domain;//this.globalAssociationModel.Domain;
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": detailId,
          "domain": domain//this.globalAssociationModel.Domain
        }
      };
      console.log("InspectionHistoryDetailsNavigationExtras", navigationExtras);
      if (this.role === RoleEnum.PropertyManager) {
        this._router.navigate([AppRouteUrl.mainPmCreateReportRouteUrl], navigationExtras);
      } else {
        this._router.navigate([AppRouteUrl.mainbmInspectionListRouteUrl], navigationExtras);
      }

    }
  }
}
