import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router, ActivatedRoute } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { PropertyInspectionService } from 'src/app/services/property-inspection.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { AppConfig } from 'src/app/app.config';
import { CommonService } from 'src/app/services/common.service';
import { UserData } from 'src/app/shared/models/user-data-model';
import { Subscription } from 'rxjs';
import { AddressType, ViolationVoteModel, ViolationStatus } from '../property-inspection.model';
import { NoDataFoundCaseFeatureName } from 'src/app/shared/Enums/commonEnums';
import { Location } from '@angular/common';
import { CommonConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-bm-inspection-lists',
  templateUrl: './bm-inspection-lists.component.html',
  styleUrls: ['./bm-inspection-lists.component.scss']
})
export class BmInspectionListsComponent implements OnInit {
  propVivoName = CommonConstant.PropVivo;
  // for get detail
  inspectionId: string;
  domain: string;
  userData: UserData;
  userName: string = "";
  userId: string = ""
  associationId: string = "";
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  totalCount: number = 0;
  approvedCount: number = 0;
  declinedCount: number = 0;
  pendingCount: number = 0;

  violationStatusEnum = ViolationStatus;
  propertyInspection: any;
  propertyInspectionDocumentList: any = [];
  propertyInspectionCommonAreaDocumentList: any = [];
  propertyInspectionHomeUnitDocumentList: any = [];

  //query string
  querySubcription: Subscription;

  isApiResponceCome = false;
  constructor(private _router: Router,
    private route: ActivatedRoute,
    private propertyInspectionService: PropertyInspectionService,
    private progressBarService: ProgeressBarService,
    private _location: Location,
    private readonly appConfig: AppConfig,
    private commonService: CommonService) {
    this.userData = this.appConfig.getCurrentUser();
    this.userName = this.userData.UserName;
    this.userId = this.userData.UserProfileId;
    this.associationId = this.userData.UserAssociations[0].AssociationId;
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      let domain = params["domain"];
      if (id && domain) {
        this.inspectionId = id;
        this.domain = domain;
        this.getDetail();
      }
      else {
        this._router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
  }


  getDetail() {
    let resData
    this.progressBarService.show();
    this.propertyInspectionService.getDetail(this.inspectionId, this.domain).subscribe(res => {
      resData = res;
      this.isApiResponceCome = true;
      this.progressBarService.hide();
      if (resData.Success == true) {
        this.propertyInspection = resData.PropertyInspection;
        console.log("this.propertyInspection", this.propertyInspection);
        if (this.propertyInspection !== null) {
          this.propertyInspectionDocumentList = this.propertyInspection.PropertyInspectionDocuments;
          this.totalCount = this.propertyInspectionDocumentList.length;
          this.approvedCount = this.propertyInspection.PropertyInspectionDocuments.filter(x => x.ViolationStatus === ViolationStatus.Approved).length;
          this.declinedCount = this.propertyInspection.PropertyInspectionDocuments.filter(x => x.ViolationStatus === ViolationStatus.Denied).length;
          this.pendingCount = this.propertyInspection.PropertyInspectionDocuments.filter(x => x.ViolationStatus === ViolationStatus.AwaitingBoardDecision).length;
          // this.pendingCount = this.propertyInspection.PropertyInspectionDocuments.filter(x => x.Votes === null).length;
          // this.propertyInspectionDocumentList.map(a => {
          //   if (a.Votes !== null) {
          //     this.approvedCount = a.Votes.filter(v => v.Votes === true).length;
          //     this.declinedCount = a.Votes.filter(v => v.Votes === false).length;
          //   }
          // });

          this.propertyInspectionCommonAreaDocumentList = this.propertyInspection.PropertyInspectionDocuments.filter(x => x.ViolationArea === AddressType.CommonArea);
          this.propertyInspectionHomeUnitDocumentList = this.propertyInspection.PropertyInspectionDocuments.filter(x => x.ViolationArea === AddressType.HomeUnit);
          console.log("this.propertyInspectionDocuments", this.propertyInspectionDocumentList);
          console.log("this.propertyInspectionCommonAreaDocuments", this.propertyInspectionCommonAreaDocumentList);
          console.log("this.propertyInspectionHomeUnitDocuments", this.propertyInspectionHomeUnitDocumentList);
        }
      }
    })
  }

  associationUnitAddress(AssociationUnitNumber, AssociationUnitAddress1, AssociationUnitAddress2, AssociationUnitCity, AssociationUnitState, AssociationUnitZip): string {
    let associationUnit = {
      AssociationUnitNumber: AssociationUnitNumber,
      AssociationUnitAddress1: AssociationUnitAddress1,
      AssociationUnitAddress2: AssociationUnitAddress2,
      AssociationUnitCity: AssociationUnitCity,
      AssociationUnitZip: AssociationUnitZip,
      AssociationUnitState: AssociationUnitState,
    }
    let address = this.commonService.getFullAssociationAddress(associationUnit);
    return address;
  }

  countRemark(remarks) {
    let totalRemark = 0;
    if (remarks !== null) {
      return totalRemark = remarks.length;
    } else {
      return totalRemark;
    }
  }

  countVoteDenied(Votes) {
    let votes = 0;
    if (Votes !== null) {
      if (Votes.length > 0) {
        return votes = Votes.filter(v => v.Votes === false).length;
      }
    } else {
      return votes;
    }
  }
  countVoteApproved(Votes) {
    let votes = 0;
    if (Votes !== null) {
      if (Votes.length > 0) {
        return votes = Votes.filter(v => v.Votes === true).length;
      }
    } else {
      return votes;
    }
  }

  checkIsVote(propertyInspectionDocument) {
    if (propertyInspectionDocument !== null) {
      if (propertyInspectionDocument.length !== 0) {
        let voteByUser = propertyInspectionDocument.find(v => v.CreatedByUserId === this.userId);
        if (voteByUser) {
          return voteByUser.Votes;
        }
      }
    }
  }


  getInspectionDetails(detailId) {
    console.log(detailId);
    if (detailId !== "" && detailId !== null && detailId !== undefined) {
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "inspectionId": this.inspectionId,
          "id": detailId,
          "domain": this.domain
        }
      };
      console.log("navigationExtras", navigationExtras);
      this._router.navigate([AppRouteUrl.mainbmInspectionDetailRouteUrl], navigationExtras);
    }
  }

  /**Create Violation Vote */
  createViolationVote(voteStatus, documentId) {
    let model = this.createViolationVoteModel(documentId);
    console.log("model", model);
    this.progressBarService.show();
    let resData;
    if (voteStatus === "Approve") {
      this.propertyInspectionService.createViolationApprovalVote(model).subscribe(res => {
        this.progressBarService.hide();
        resData = res;
        if (resData.Success === true) {
          this.getDetail();
        }
        else if (resData.Success === false) {
          console.log("error");
        }
      });
    } else {
      this.propertyInspectionService.createViolationDeniedVote(model).subscribe(res => {
        this.progressBarService.hide();
        resData = res;
        if (resData.Success === true) {
          this.getDetail();
        }
        else if (resData.Success === false) {
          console.log("error");
        }
      });
    }

  }

  createViolationVoteModel(documentId) {
    const model: ViolationVoteModel = {
      AssociationId: this.associationId,
      InspectionId: this.propertyInspection.id,
      UserProfileId: this.userId,
      UserName: this.userName,
      DocumentId: documentId,
    }
    return model;
  }

  toGoBack() {
    this._location.back();
  }

}
