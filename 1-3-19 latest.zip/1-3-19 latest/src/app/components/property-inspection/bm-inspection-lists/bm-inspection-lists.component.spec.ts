import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmInspectionListsComponent } from './bm-inspection-lists.component';

describe('BmInspectionListsComponent', () => {
  let component: BmInspectionListsComponent;
  let fixture: ComponentFixture<BmInspectionListsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmInspectionListsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmInspectionListsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
