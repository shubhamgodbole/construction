import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCheckboxModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatRippleModule,
  MatSelectModule,
  MatSnackBarModule,
  MatTooltipModule,
  MatTreeModule,
  MatRadioModule,
  MatButtonModule,
  MatBottomSheetModule,
  MatDatepickerModule,
  MatAutocompleteModule,
} from '@angular/material';
import { CommonModule } from '@angular/common';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { RouterModule, Routes } from '@angular/router';
import { InspectionHistoryComponent } from './inspection-history/inspection-history.component';
import { BmInspectionListComponent } from './bm-inspection-list/bm-inspection-list.component';
import { PmCreateReportComponent } from './pm-create-report/pm-create-report.component';
import { PropertyManagerComponent } from './property-manager/property-manager.component';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { DisplayTimeElapsedModule } from 'src/app/shared/modules/display-time-elapsed.module';

//import { BmInspectionListsComponent } from './bm-inspection-lists/bm-inspection-lists.component';
//import { PmInspectionLetterComponent } from './pm-inspection-letter/pm-inspection-letter.component';

const routes: Routes = [
  {
    path: '',
    component: InspectionHistoryComponent
  },
  {
    path: AppRouteUrl.pmCreateReportRouteUrl,
    component: PmCreateReportComponent
  },
  {
    path: AppRouteUrl.addInspectionRouteUrl,
    component: PropertyManagerComponent
  },
  // {
  //   path: 'pm-inspection-letter',
  //   component: PmInspectionLetterComponent
  // }
  //For BM Role
  {
    path: AppRouteUrl.bmInspectionListRouteUrl,
    loadChildren: './bm-inspection.module#BmInspectionModule',
  },
  // {
  //   path: AppRouteUrl.mainbmInspectionDetailRouteUrl,  //'bm-inspection-detail',
  //   component: BmInspectionListComponent
  // },
  // {
  //   path: AppRouteUrl.bmInspectionListRouteUrl,
  //   component: BmInspectionListsComponent
  // },
];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRippleModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    NoCaseNoteFoundModule,
    MatTreeModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatDatepickerModule,
    MatBottomSheetModule,
    MatCheckboxModule,
    FormsModule,
    MatCheckboxModule,
    DisplayTimeElapsedModule,
    MatRadioModule,
    RouterModule.forChild(routes)
  ],
  declarations: [InspectionHistoryComponent,
    // BmInspectionListComponent,
    // BmInspectionListsComponent,    
    PropertyManagerComponent,
    PmCreateReportComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [RouterModule]
})
export class PropertyInspectionModule { }
