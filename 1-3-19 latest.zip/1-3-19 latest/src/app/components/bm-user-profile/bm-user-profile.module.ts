import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { BmUserProfileComponent } from './bm-user-profile.component';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
const routes: Routes = [
  {
    path: '',
    component: BmUserProfileComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    NumberOnlyDirectiveModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  declarations: [BmUserProfileComponent]
})
export class BmUserProfileModule { }
