import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bm-user-profile',
  templateUrl: './bm-user-profile.component.html',
  styleUrls: ['./bm-user-profile.component.scss']
})
export class BmUserProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
