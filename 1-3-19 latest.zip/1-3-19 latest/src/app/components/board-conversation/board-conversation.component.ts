import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-board-conversation',
  templateUrl: './board-conversation.component.html',
  styleUrls: ['./board-conversation.component.scss']
})
export class BoardConversationComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

}
