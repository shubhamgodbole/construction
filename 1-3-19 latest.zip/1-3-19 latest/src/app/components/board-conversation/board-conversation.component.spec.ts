import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BoardConversationComponent } from './board-conversation.component';

describe('BoardConversationComponent', () => {
  let component: BoardConversationComponent;
  let fixture: ComponentFixture<BoardConversationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BoardConversationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoardConversationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
