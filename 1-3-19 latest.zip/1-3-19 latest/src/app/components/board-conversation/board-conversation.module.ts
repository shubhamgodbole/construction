import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BoardConversationComponent } from './board-conversation.component';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule } from '@angular/material';
import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
const routes: Routes = [
  {
    path: '',
    component: BoardConversationComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    NumberOnlyDirectiveModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  declarations: [BoardConversationComponent]
})
export class BoardConversationModule { }
