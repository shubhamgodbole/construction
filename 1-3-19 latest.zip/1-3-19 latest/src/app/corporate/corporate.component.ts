import { Component, OnInit } from '@angular/core';
import { Title, Meta } from '@angular/platform-browser';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-corporate',
  templateUrl: './corporate.component.html',
  styleUrls: ['./corporate.component.css']
})
export class CorporateComponent implements OnInit {

  constructor(private titleService: Title, 
    private meta: Meta) {
    this.titleService.setTitle(environment.corporateTitle);
    this.meta.updateTag({ name: environment.metaDes, content: environment.desContent });
    this.meta.updateTag({ name: environment.metaKeywords, content: environment.keywordsDes })
   }

  ngOnInit() {
  }

}
