import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateRequestProposalComponent } from './corporate-request-proposal.component';

describe('CorporateRequestProposalComponent', () => {
  let component: CorporateRequestProposalComponent;
  let fixture: ComponentFixture<CorporateRequestProposalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporateRequestProposalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateRequestProposalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
