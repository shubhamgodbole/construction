import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CorporateBlogService } from 'src/app/services/corporate-blog.service';
import { EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { FeatureName, SourceType, TriggerType } from 'src/app/shared/Enums/commonEnums';
import { AudienceType } from 'src/app/components/board-tasks/board-task.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { ThankYouComponent } from 'src/app/shared/component/thank-you/thank-you.component';
import { MatDialogRef, MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { CommonConstant } from 'src/app/shared/common/constant.model';
import { CaptchaConfig } from '../corporate.model';
import { ReCaptchaComponent } from 'angular2-recaptcha';

@Component({
  selector: 'app-corporate-request-proposal',
  templateUrl: './corporate-request-proposal.component.html',
  styleUrls: ['./corporate-request-proposal.component.scss']
})
export class CorporateRequestProposalComponent implements OnInit {
  thanksDialogRef: MatDialogRef<ThankYouComponent>;
// home woner
requestProposalForm: FormGroup;
isButtonDisable: boolean = false;
isPhoneError: boolean = false;
siteKey= CaptchaConfig.SiteKey;
errorMsg: string ="";
@ViewChild('requestProposalDirective') requestProposalDirective: FormGroupDirective;
@ViewChild(ReCaptchaComponent) captcha: ReCaptchaComponent;
  constructor(private formBuilder: FormBuilder,private service: CorporateBlogService, private emailNotification : EmailNotificationService,
    private _matDialog: MatDialog,private router: Router, ) { }

  ngOnInit() {
    window.scroll(0,0);
    this.requestProposalForm = this.formBuilder.group({
      rfname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13)]],
      remail: ['', [Validators.required, ValidationService.emailValidator, ValidationService.notStartWhiteSpace]],
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      address1: ['', [Validators.required, Validators.maxLength(200), ValidationService.notStartWhiteSpace]],
      address2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      city: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      state: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2), ValidationService.notStartWhiteSpace]],
      zip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5), ValidationService.notStartWhiteSpace]],
      detail: [''],
      myRecaptcha: ['',Validators.required],
    });
     

   
   
      //this.requestProposalForm.get('address2').updateValueAndValidity();
  }
  // whiteSpacevalidation(event) {
 
  //     if (this.requestProposalForm.controls.address2.value === ' ')
  //       this.requestProposalForm.get('address2').setValidators([Validators.pattern('^[a-zA-Z][a-zA-Z\\s]+$')]);
  //      else  
  //      this.requestProposalForm.get('address2').clearValidators();
   
  // }
  setMobileNumber(event) {
    let ctrlValue = this.requestProposalForm.controls.rphone.value;
    let newCtrlValue;
    if(this.requestProposalForm.controls.rphone.value) {
      if(this.requestProposalForm.controls.rphone.value.length < 10 ) {
        this.isPhoneError = true;
      }
     
      else{
      ctrlValue = this.requestProposalForm.controls.rphone.value;
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.requestProposalForm.controls.rphone.setValue(newCtrlValue);
      this.isPhoneError = false;
      }
      if (event.inputType === 'deleteContentBackward') {
        this.requestProposalForm.controls.rphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }
  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }
  createNotificationModel(featureId,requestId) {
    
    var notificationModel = new Array<EmailNotificationModel>();;
    notificationModel = [{
      FeatureId: "",
      FeatureName:FeatureName.RequestForProposal,
      CreatedBy:"",
      SourceType:SourceType.Web,
      TriggerType:TriggerType.Create,
      PMCompanyAssociationMappingId:"",
      AudienceType:AudienceType.HomeOwner,
      Url:"",
      RequestId:requestId,
      CustomAttribute: {
        Request:FeatureName.RequestForProposal,
      	RequestSubType:TriggerType.Create

      }
   }];
   return notificationModel;
  }
  sendNotification(featureId,requestId) {
    //let emailNotificationModel = this.createNotificationModel("",response.RequestId);
    let emailNotificationModel = this.createNotificationModel(featureId,requestId);
            this.emailNotification.sendNotification(emailNotificationModel).subscribe(
              (emailresponse:any) =>{
                if (emailresponse.Success) {
                 // this.notificationService.showNotification('Notification Send SuccessFully');
                 }
              }
            );
  }
  requestModel() {
    let model = {
      FirstName: this.requestProposalForm.controls.rfname.value,
      LastName: this.requestProposalForm.controls.rlname.value,
      Email: this.requestProposalForm.controls.remail.value,
      Phone: this.requestProposalForm.controls.rphone.value,
      AssociationName: this.requestProposalForm.controls.associationName.value,
      AddressLine1: this.requestProposalForm.controls.address1.value,
      AddressLine2: this.requestProposalForm.controls.address2.value,
      City: this.requestProposalForm.controls.city.value,
      State: this.requestProposalForm.controls.state.value,
      Zip: this.requestProposalForm.controls.zip.value,
      //Detil:this.requestProposalForm.controls.detail.value,
    };
    return model;
  }
  addRequest() {
    if (this.requestProposalForm.controls.myRecaptcha.value === '') {
      this.errorMsg ="Please verify that you are not a robot.";
    }
    else {
      this.requestProposalForm.controls.myRecaptcha.setValue(true);
      this.errorMsg ="";
    }
    if (this.requestProposalForm.valid && !this.isPhoneError) { 
      this.isButtonDisable = true;
      let model = this.requestModel();
      this.service.requestProposal(model).subscribe(
        (response:any) =>{
          if (response.Success) {
            console.log("response",response);
            this.reseForm();
            //this.notificationService.showNotification(this.successMsg);
            this.sendNotification('',response.RequestId);
            this.paymentThankYou();
          }
        }
      );
      console.log('request',model);
     
    }
  }
  handleCorrectCaptcha(e) {
    this.requestProposalForm.controls.myRecaptcha.setValue(true);
    this.errorMsg ="";
  }
  reseForm() {
    this.requestProposalForm.reset();
    this.requestProposalDirective.resetForm();
    this.isButtonDisable = false;
    this.requestProposalForm.controls.myRecaptcha.setValue('');
    this.errorMsg ="";
    this.captcha.reset();
  }
  paymentThankYou() {
    let message = { header: 'Thank You!', content: ' Thank You for submitting the request. We will connect with you shortly. In case if this is urgent please contact us at +1 (888)392-3515. ', type: 'contactus' }
    this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
      width: '700px',
      disableClose: false
    });
    this.thanksDialogRef.componentInstance.data = message;
    this.thanksDialogRef.afterClosed().subscribe(result => {
      
        this.router.navigate(['/corporate']);
     
    });
  }
}
