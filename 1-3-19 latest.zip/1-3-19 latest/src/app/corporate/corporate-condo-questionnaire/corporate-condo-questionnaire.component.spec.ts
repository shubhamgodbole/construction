import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateCondoQuestionnaireComponent } from './corporate-condo-questionnaire.component';

describe('CorporateCondoQuestionnaireComponent', () => {
  let component: CorporateCondoQuestionnaireComponent;
  let fixture: ComponentFixture<CorporateCondoQuestionnaireComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporateCondoQuestionnaireComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateCondoQuestionnaireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
