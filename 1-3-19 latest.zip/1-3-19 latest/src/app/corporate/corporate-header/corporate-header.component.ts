import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { CommonService } from 'src/app/services/common.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { UserData } from 'src/app/shared/models/user-data-model';
import { RoleEnum } from 'src/app/shared/Enums/commonEnums';
import { CommonConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-corporate-header',
  templateUrl: './corporate-header.component.html',
  styleUrls: ['./corporate-header.component.scss']
})
export class CorporateHeaderComponent implements OnInit {

  mobNav = false;
  isLogin: boolean;
  userData: UserData;
  roleEnum = RoleEnum;
  role: string = "";
  backButtonTitle: string = '';
  constructor(private readonly appConfig: AppConfig, private router: Router, private commonService: CommonService, private route: ActivatedRoute, ) {
    this.appConfig.isLoggedIn.subscribe(
      (login) => {
        this.isLogin = login;
      }
    );
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData !== null) {
      if (this.userData.Role === this.roleEnum.PropertyManager) {
        this.backButtonTitle = CommonConstant.ForPmMyApp; //'My App';
      }
      else {
        this.backButtonTitle = CommonConstant.ForMyDashboard; //'My Dashboard';
      }
    }
  }

  ngOnInit() {
  }

  navToggle() {
    if (this.mobNav) {
      this.mobNav = false;
    }
    else
      this.mobNav = true;
  }
  goToDashboard() {
    if (this.userData.Role === this.roleEnum.PropertyManager) {
      this.router.navigate([AppRouteUrl.mainRecentUpdatesRouteUrl]);
    } else {
      this.router.navigate([AppRouteUrl.mainDashboardRouteUrl]);
    }
  }
  goToHome() {
    this.router.navigate([AppRouteUrl.corporateHomeRouteUrl]);
    window.scrollTo(0, 0);
  }
  goToWhyPropVivo() {
    let element = document.getElementById('why-propvivo');
    // element.classList.add("pv-active");
    this.router.navigate([AppRouteUrl.corporateWhyPropVivoRouteUrl]);
  }
  goToResaleCertificate() {
    let element = document.getElementById('resale-certificate');
    // element.classList.add("pv-active");
    this.router.navigate([AppRouteUrl.corporateResaleCertificateRouteUrl]);
  }
  // redirect to corporate Demand Request
  goToDemandRequest() {
    let element = document.getElementById('demand-request');
    // element.classList.add("pv-active");
    this.router.navigate([AppRouteUrl.corporateDemandRequestRouteUrl]);
  }
  // redirect to Condo Questionnaire
  goToCondoQuestionnaire() {
    let element = document.getElementById('condo-questionnaire');
    this.router.navigate([AppRouteUrl.corporateCondoQuestionnaireRouteUrl]);
  }
  // redirect to corporate blog
  goToBlog() {
    let element = document.getElementById('why-propvivo');
    this.router.navigate([AppRouteUrl.corporateBlogListRouteUrl]);
  }
  // redirect to corporate contact
  goToContact() {
    let element = document.getElementById('why-propvivo');
    this.router.navigate([AppRouteUrl.corporateContactUsRouteUrl]);
  }
  goToRequestProposal() {
    this.router.navigate([AppRouteUrl.corporateRequestProposalRouteUrl]);
  }

  logout() {
    if (this.isLogin) {
      this.appConfig.removeCurrentUser();
    } else {
      this.router.navigate(['/login']);
    }
  }

  goToService() {
    this.router.navigate([AppRouteUrl.corporateRequestServicesRouteUrl]);
  }
}
