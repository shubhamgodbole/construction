import { Component, OnInit, ViewChild } from '@angular/core';
import { DisplayRequester, DemandRequestHomeowners, DemandRequestEscro, DemandRequestInvestor, DemandRequestLender, DemandRequestPrespective, DemandRequestRealEastate, DemandRequestOther, ChangeMobileNumberType } from '../corporate.model';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { CorporateBlogService } from 'src/app/services/corporate-blog.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar, MatDialog, MatDialogRef } from '@angular/material';
import { ImageNameEnums, AudienceType, TriggerType, SourceType, FeatureName } from 'src/app/shared/Enums/commonEnums';
import { Guid } from 'guid-typescript';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { ThankYouComponent } from 'src/app/shared/component/thank-you/thank-you.component';
import { Router } from '@angular/router';
import { AcceptFilesConstant, CommonConstant } from 'src/app/shared/common/constant.model';
import { CaptchaConfig } from '../corporate.model';
import { ReCaptchaComponent } from 'angular2-recaptcha';
@Component({
  selector: 'app-corporate-demand-request',
  templateUrl: './corporate-demand-request.component.html',
  styleUrls: ['./corporate-demand-request.component.scss']
})
export class CorporateDemandRequestComponent implements OnInit {
 //Media Type
 acceptAllMediaType = AcceptFilesConstant.allMediaType;
  // Payment Thank you
  thanksDialogRef: MatDialogRef<ThankYouComponent>;

  requester: string;
  requesterList: any;
  selectedRequester: any;
  // home woner
  homeWonerForm: FormGroup;
  @ViewChild('homeWonereDirective') homeWonereDirective: FormGroupDirective;
  // Escro
  escroForm: FormGroup;
  @ViewChild('escroDirective') escroDirective: FormGroupDirective;

  // Investor
  investorForm: FormGroup;
  @ViewChild('investorDirective') investorDirective: FormGroupDirective;

  // Lender
  lenderForm: FormGroup;
  @ViewChild('lenderDirective') lenderDirective: FormGroupDirective;
  // perscpectiveForm
  perscpectiveForm: FormGroup;
  @ViewChild('perscpectiveDirective') perscpectiveDirective: FormGroupDirective;
  // realEstateForm
  realEstateForm: FormGroup;
  @ViewChild('realEstateDirective') realEstateDirective: FormGroupDirective;
  // otherForm
  otherForm: FormGroup;
  @ViewChild('otherDirective') otherDirective: FormGroupDirective;

  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  favoriteSeason: any;
  amount: string="-";
  showRadioError: boolean = false;
  fileData: any = [];
  errorMsg: string;
  notificationService: NotificationService;
  attachmentsErrorMsg: string = "Attachments is requeird";
  successMsg: string = "Request is add successfully";
  captchaErrorMsg: string ="Please verify that you are not a robot.";
  capthcaMessage:string = "";
  isRushOrder: boolean = false;
  isPostButton: boolean = false;
  isButtonDisable: boolean = false;
  today: Date = new Date();
  isrPhoneError: boolean = false;
  siteKey= CaptchaConfig.SiteKey;
  changeMobileNumberType = ChangeMobileNumberType;
  myRecaptcha: boolean = false;
  @ViewChild(ReCaptchaComponent) captcha: ReCaptchaComponent;
  constructor(private formBuilder: FormBuilder, 
    private service: CorporateBlogService,
    private router: Router,
    private _matDialog: MatDialog,
    private readonly snb: MatSnackBar,
    private emailNotification: EmailNotificationService) {
    this.notificationService = new NotificationService(snb);
    this.requesterList = DisplayRequester.Requester;
    this.requester = this.requesterList[0].value;
    this.selectedRequester = this.requesterList[0].value;
  }

  ngOnInit() {
    window.scroll(0,0);
    this.homeWonerForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50),ValidationService.notStartWhiteSpace]],
      fname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      lname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      phone: ['', [Validators.required, Validators.maxLength(14),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      email: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      address1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      address2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      city: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      state: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2), ValidationService.notStartWhiteSpace]],
      zip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5), ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.escroForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50),ValidationService.notStartWhiteSpace]],
      rfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      bfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      blname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      bphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      bemail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      companyName: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      escroNumber: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      sfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      slname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      sphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      semail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2), ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5), ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.investorForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      closingDate: [''],
      rfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      companyName: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      escroNumber: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      sfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      slname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      sphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      semail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2), ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10), Validators.minLength(5),ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.lenderForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      closingDate: [''],
      rfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      companyName: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      escroNumber: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      sfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      slname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      sphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      semail: ['', [Validators.required,ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2), ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5), ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.perscpectiveForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      closingDate: [''],
      sfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      slname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      sphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      semail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      bfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      blname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      bphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      bemail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2), ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5), ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.realEstateForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      closingDate: [''],
      rfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      sfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      slname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      sphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      semail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2), ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5), ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.otherForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      closingDate: [''],
      rfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      sfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      slname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      sphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      semail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2), ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5), ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
  }
  
  changeRequester(event) {
    this.requester = event.value;
    this.errorMsg = "";
    this.showRadioError = false;
    this.homeWonerForm.reset();
    this.escroForm.reset();
    this.investorForm.reset();
    this.lenderForm.reset();
    this.perscpectiveForm.reset();
    this.realEstateForm.reset();
    this.otherForm.reset();
    this.amount="-";
    this.capthcaMessage = "";

  }
  radioChange(event) {

    this.showRadioError = false;
    if (event.value === 'Normal') {
      this.amount = '0';
      this.isRushOrder = false;
    }
    else {
      this.amount = '100';
      this.isRushOrder = true;
    }
  }
  handleCorrectCaptcha(e) {
    this.myRecaptcha = true;
    this.capthcaMessage ="";
  }
  // on file upload
  onUploadChange(evt: any) {
    // this.imgFlag = false;
    // this.fileData = [];
    this.errorMsg = "";
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),

          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }

    }

  }
  // remove uploaded Documents
  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };
  setMobileNumber(event,type) {
    let ctrlValue;
    let newCtrlValue;
    
    if(this.homeWonerForm.controls.phone.value && type === this.changeMobileNumberType.Seller) {
      ctrlValue = this.homeWonerForm.controls.phone.value;
      if(this.homeWonerForm.controls.phone.value.length < 10 ) {}
      else {
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.homeWonerForm.controls.phone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val =this.homeWonerForm.controls.phone.value.replace(/[^0-9 ]/g, "");
          this.homeWonerForm.controls.phone.setValue(val);
        }
        //this.homeWonerForm.controls.phone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    // ecroForm
    if(this.escroForm.controls.rphone.value && type === this.changeMobileNumberType.Requester) {
      ctrlValue = this.escroForm.controls.rphone.value;
      if(this.escroForm.controls.rphone.value.length < 10 ) {}
      else {
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.escroForm.controls.rphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val =this.escroForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
          this.escroForm.controls.rphone.setValue(val);
        }
        //this.escroForm.controls.rphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if(this.escroForm.controls.bphone.value && type === this.changeMobileNumberType.Buyer) {
      ctrlValue = this.escroForm.controls.bphone.value;
      if(this.escroForm.controls.bphone.value.length < 10 ) {}
      else {
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.escroForm.controls.bphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val =this.escroForm.controls.bphone.value.replace(/[^0-9 ]/g, "");
          this.escroForm.controls.bphone.setValue(val);
        }
        //this.escroForm.controls.bphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if(this.escroForm.controls.sphone.value && type === this.changeMobileNumberType.Seller) {
      ctrlValue = this.escroForm.controls.sphone.value;
      if(this.escroForm.controls.sphone.value.length < 10 ) {}
      else {
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.escroForm.controls.sphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val =this.escroForm.controls.sphone.value.replace(/[^0-9 ]/g, "");
          this.escroForm.controls.sphone.setValue(val);
        }
      //  this.escroForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    // investor
    if(this.investorForm.controls.rphone.value && type === this.changeMobileNumberType.Requester) {
      ctrlValue = this.investorForm.controls.rphone.value;
      if(this.investorForm.controls.rphone.value.length < 10 ) {} 
      else {
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.investorForm.controls.rphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val =this.investorForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
          this.investorForm.controls.rphone.setValue(val);
        }
       // this.investorForm.controls.rphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if(this.investorForm.controls.sphone.value && type === this.changeMobileNumberType.Seller) {
      ctrlValue = this.investorForm.controls.sphone.value;
      if(this.investorForm.controls.sphone.value.length < 10 ) {} 
      else{
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.investorForm.controls.sphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val =this.investorForm.controls.sphone.value.replace(/[^0-9 ]/g, "");
          this.investorForm.controls.sphone.setValue(val);
        }
        //this.investorForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    // lender
    if(this.lenderForm.controls.rphone.value && type === this.changeMobileNumberType.Requester) {
      ctrlValue = this.lenderForm.controls.rphone.value;
      if(this.lenderForm.controls.rphone.value.length < 10 ) {} 
      else {
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.lenderForm.controls.rphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val =this.lenderForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
          this.lenderForm.controls.rphone.setValue(val);
        }
       // this.lenderForm.controls.rphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if(this.lenderForm.controls.sphone.value && type === this.changeMobileNumberType.Seller) {
      ctrlValue = this.lenderForm.controls.sphone.value;
      if(this.lenderForm.controls.sphone.value.length < 10 ) {} 
      else {
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.lenderForm.controls.sphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val =this.lenderForm.controls.sphone.value.replace(/[^0-9 ]/g, "");
          this.lenderForm.controls.sphone.setValue(val);
        }
       // this.lenderForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
     // perscpectiveForm
     if( this.perscpectiveForm.controls.sphone.value && type === this.changeMobileNumberType.Seller) {
      ctrlValue = this.perscpectiveForm.controls.sphone.value;
     if(this.perscpectiveForm.controls.sphone.value.length < 10 ) {} 
     else {
     newCtrlValue = this.convertMobileNumber(ctrlValue);
     this.perscpectiveForm.controls.sphone.setValue(newCtrlValue);
     }
     if (event.inputType === 'deleteContentBackward') {
       var format = "()-";
       if(ctrlValue.match(format)){
         let val =this.perscpectiveForm.controls.sphone.value.replace(/[^0-9 ]/g, "");
         this.perscpectiveForm.controls.sphone.setValue(val);
       }
     //  this.perscpectiveForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
     }
   }
   else if(this.perscpectiveForm.controls.bphone.value && type === this.changeMobileNumberType.Buyer ) {
    ctrlValue = this.perscpectiveForm.controls.bphone.value;
    if(this.perscpectiveForm.controls.bphone.value.length < 10 ) {} 
    else {
    newCtrlValue = this.convertMobileNumber(ctrlValue);
    this.perscpectiveForm.controls.bphone.setValue(newCtrlValue);
    }
    if (event.inputType === 'deleteContentBackward') {
      var format = "()-";
      if(ctrlValue.match(format)){
        let val = this.perscpectiveForm.controls.bphone.value.replace(/[^0-9 ]/g, "");
        this.perscpectiveForm.controls.bphone.setValue(val);
      }
      //this.perscpectiveForm.controls.bphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
    }
  }
    
    // realEstateForm
    if( this.realEstateForm.controls.sphone.value && type === this.changeMobileNumberType.Seller) {
      ctrlValue = this.realEstateForm.controls.sphone.value;
      if(this.realEstateForm.controls.sphone.value.length < 10 ) {} 
      else {
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.realEstateForm.controls.sphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val = this.realEstateForm.controls.sphone.value.replace(/[^0-9 ]/g, "");
          this.realEstateForm.controls.sphone.setValue(val);
        }
        //this.realEstateForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if(this.realEstateForm.controls.rphone.value && type === this.changeMobileNumberType.Requester ) {
      ctrlValue = this.realEstateForm.controls.rphone.value;
     if(this.realEstateForm.controls.rphone.value.length < 10 ) {} 
     else {
       newCtrlValue = this.convertMobileNumber(ctrlValue);
       this.realEstateForm.controls.rphone.setValue(newCtrlValue);
       }
       if (event.inputType === 'deleteContentBackward') {
         var format = "()-";
         if(ctrlValue.match(format)){
           let val = this.realEstateForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
           this.realEstateForm.controls.rphone.setValue(val);
         }
         //this.realEstateForm.controls.rphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
       }
     }
    // otherForm
    if( this.otherForm.controls.sphone.value && type === this.changeMobileNumberType.Seller) {
      ctrlValue = this.otherForm.controls.sphone.value;
      if(this.otherForm.controls.sphone.value.length < 10 ) {} 
      else {
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.otherForm.controls.sphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if(ctrlValue.match(format)){
          let val = this.otherForm.controls.sphone.value.replace(/[^0-9 ]/g, "");
          this.otherForm.controls.sphone.setValue(val);
        }
       
      }
    }
    if(this.otherForm.controls.rphone.value && type === this.changeMobileNumberType.Requester ) {
      ctrlValue = this.otherForm.controls.rphone.value;
     if(this.otherForm.controls.rphone.value.length < 10 ) {} 
     else {
       newCtrlValue = this.convertMobileNumber(ctrlValue);
       this.otherForm.controls.rphone.setValue(newCtrlValue);
     }
     if (event.inputType === 'deleteContentBackward') {
       var format = "()-";
       if(ctrlValue.match(format)){
         let val = this.otherForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
         this.otherForm.controls.rphone.setValue(val);
       }
      
     }
     }
  }
  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }
  homeWonerModel() {
    let model: DemandRequestHomeowners = {
      AssociationName: this.homeWonerForm.controls.associationName.value,
      SellerFirstName: this.homeWonerForm.controls.fname.value,
      SellerLastName: this.homeWonerForm.controls.lname.value,
      SellerEmail: this.homeWonerForm.controls.email.value,
      SellerPhone: this.homeWonerForm.controls.phone.value,
      PropertyAddressLine1: this.homeWonerForm.controls.address1.value,
      PropertyAddressLine2: this.homeWonerForm.controls.address2.value,
      City: this.homeWonerForm.controls.city.value,
      State: this.homeWonerForm.controls.state.value,
      Zip: this.homeWonerForm.controls.zip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester
    };
    return model;
  }
  createNotificationModel(featureId, requestId) {

    var notificationModel = new Array<EmailNotificationModel>();
    notificationModel = [{
      FeatureId: "",
      FeatureName: FeatureName.HOADemandRequest,
      CreatedBy: "",
      SourceType: SourceType.Web,
      TriggerType: TriggerType.Create,
      PMCompanyAssociationMappingId: "",
      AudienceType: AudienceType.HomeOwner,
      Url: "",
      RequestId: requestId,
      CustomAttribute: {
        Request: FeatureName.HOADemandRequest,
        RequestSubType: TriggerType.Create

      }
    }];
    return notificationModel;
  }
  sendNotification(featureId, requestId) {
    //let emailNotificationModel = this.createNotificationModel("",response.RequestId);
    let emailNotificationModel = this.createNotificationModel(featureId, requestId);
    this.emailNotification.sendNotification(emailNotificationModel).subscribe(
      (emailresponse: any) => {
        if (emailresponse.Success) {
          // this.notificationService.showNotification('Notification Send SuccessFully');
        }
      }
    );
  }
  addHomeWonwerRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    // if (this.fileData.length === 0) {
    //   this.errorMsg = this.attachmentsErrorMsg;
    // }
    if (this.homeWonerForm.valid && this.myRecaptcha) {
      this.isButtonDisable = true;
      let model = this.homeWonerModel();

      this.service.demandRequest(model, this.fileData).subscribe(
        (response: any) => {

          if (response.Success) {
            console.log("response", response);
            this.resetHomeWonerForm();
           // this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }

        }
      );
    }
  }
  resetHomeWonerForm() {
    this.homeWonerForm.reset();
    this.homeWonereDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
    this.amount="-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  escroModel() {
    let model: DemandRequestEscro = {
      RequesterFirstName: this.escroForm.controls.rfname.value,
      RequesterLastName: this.escroForm.controls.rlname.value,
      RequesterEmail: this.escroForm.controls.remail.value,
      RequesterPhone: this.escroForm.controls.rphone.value,
      EscrowCompanyName: this.escroForm.controls.companyName.value,
      EscrowNumber: this.escroForm.controls.escroNumber.value,
      BuyerFirstName: this.escroForm.controls.bfname.value,
      BuyerLastName: this.escroForm.controls.blname.value,
      BuyerEmail: this.escroForm.controls.bemail.value,
      BuyerPhone: this.escroForm.controls.bphone.value,
      AssociationName: this.escroForm.controls.associationName.value,
      SellerFirstName: this.escroForm.controls.sfname.value,
      SellerLastName: this.escroForm.controls.slname.value,
      SellerEmail: this.escroForm.controls.semail.value,
      SellerPhone: this.escroForm.controls.sphone.value,
      PropertyAddressLine1: this.escroForm.controls.paddress1.value,
      PropertyAddressLine2: this.escroForm.controls.paddress2.value,
      City: this.escroForm.controls.pcity.value,
      State: this.escroForm.controls.pstate.value,
      Zip: this.escroForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester
    };
    return model;
  }
  addescroRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.escroForm.valid && this.myRecaptcha) {
      this.isButtonDisable = true;
      let model = this.escroModel();
      this.service.demandRequest(model, this.fileData).subscribe(
        (response: any) => {

          if (response.Success) {
            this.resetEscroForm();
         //   this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }

        }
      );

    }

  }
  resetEscroForm() {
    this.escroForm.reset();
    this.escroDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
   this.amount="-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  investorModel() {
    let model = {
      RequesterFirstName: this.investorForm.controls.rfname.value,
      RequesterLastName: this.investorForm.controls.rlname.value,
      RequesterEmail: this.investorForm.controls.remail.value,
      RequesterPhone: this.investorForm.controls.rphone.value,
      EscrowCompanyName: this.investorForm.controls.companyName.value,
      EscrowNumber: this.investorForm.controls.escroNumber.value,
      AssociationName: this.investorForm.controls.associationName.value,
      EstimatedClosingDate: this.investorForm.controls.closingDate.value,
      SellerFirstName: this.investorForm.controls.sfname.value,
      SellerLastName: this.investorForm.controls.slname.value,
      SellerEmail: this.investorForm.controls.semail.value,
      SellerPhone: this.investorForm.controls.sphone.value,
      PropertyAddressLine1: this.investorForm.controls.paddress1.value,
      PropertyAddressLine2: this.investorForm.controls.paddress2.value,
      City: this.investorForm.controls.pcity.value,
      State: this.investorForm.controls.pstate.value,
      Zip: this.investorForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester
    };
    return model;
  }
  addInvestorRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }

    if (this.investorForm.valid  && this.myRecaptcha) {
      this.isButtonDisable = true;
      let model = this.investorModel();

      this.service.demandRequest(model, this.fileData).subscribe(
        (response: any) => {
          if (response.Success) {
            this.resetInvestorForm();
          //  this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }
        }
      );

    }
  }
  resetInvestorForm() {
    this.investorForm.reset();
    this.investorDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
   this.amount="-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  lenderModel() {
    let model: DemandRequestLender = {
      RequesterFirstName: this.lenderForm.controls.rfname.value,
      RequesterLastName: this.lenderForm.controls.rlname.value,
      RequesterEmail: this.lenderForm.controls.remail.value,
      RequesterPhone: this.lenderForm.controls.rphone.value,
      EscrowCompanyName: this.lenderForm.controls.companyName.value,
      AssociationName: this.lenderForm.controls.associationName.value,
      EstimatedClosingDate: this.lenderForm.controls.closingDate.value,
      SellerFirstName: this.lenderForm.controls.sfname.value,
      SellerLastName: this.lenderForm.controls.slname.value,
      SellerEmail: this.lenderForm.controls.semail.value,
      SellerPhone: this.lenderForm.controls.sphone.value,
      PropertyAddressLine1: this.lenderForm.controls.paddress1.value,
      PropertyAddressLine2: this.lenderForm.controls.paddress2.value,
      City: this.lenderForm.controls.pcity.value,
      State: this.lenderForm.controls.pstate.value,
      Zip: this.lenderForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester
    };
    return model;
  }
  addLendrRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.lenderForm.valid  && this.myRecaptcha) {
      this.isButtonDisable = true;
      let model = this.lenderModel();

      this.service.demandRequest(model, this.fileData).subscribe(
        (response: any) => {

          if (response.Success) {
            this.resetLenderForm();
          //  this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }
        }
      );

    }
  }
  resetLenderForm() {
    this.lenderForm.reset();
    this.lenderDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
   this.amount="-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  prespectiveModel() {
    let model: DemandRequestPrespective = {
      AssociationName: this.perscpectiveForm.controls.associationName.value,
      EstimatedClosingDate: this.perscpectiveForm.controls.closingDate.value,
      SellerFirstName: this.perscpectiveForm.controls.sfname.value,
      SellerLastName: this.perscpectiveForm.controls.slname.value,
      SellerEmail: this.perscpectiveForm.controls.semail.value,
      SellerPhone: this.perscpectiveForm.controls.sphone.value,
      BuyerFirstName: this.perscpectiveForm.controls.bfname.value,
      BuyerLastName: this.perscpectiveForm.controls.blname.value,
      BuyerEmail: this.perscpectiveForm.controls.bemail.value,
      BuyerPhone: this.perscpectiveForm.controls.bphone.value,
      PropertyAddressLine1: this.perscpectiveForm.controls.paddress1.value,
      PropertyAddressLine2: this.perscpectiveForm.controls.paddress2.value,
      City: this.perscpectiveForm.controls.pcity.value,
      State: this.perscpectiveForm.controls.pstate.value,
      Zip: this.perscpectiveForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester
    };
    return model;
  }
  addPrespectiveRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }

    if (this.perscpectiveForm.valid  && this.myRecaptcha) {
      this.isButtonDisable = true;
      let model = this.prespectiveModel();

      this.service.demandRequest(model, this.fileData).subscribe(
        (response: any) => {

          if (response.Success) {
            this.resetPrespectiveForm();
          //  this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }

        }
      );

    }
  }
  resetPrespectiveForm() {
    this.perscpectiveForm.reset();
    this.perscpectiveDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
   this.amount="-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  realEastateModel() {
    let model: DemandRequestRealEastate = {
      RequesterFirstName: this.realEstateForm.controls.rfname.value,
      RequesterLastName: this.realEstateForm.controls.rlname.value,
      RequesterEmail: this.realEstateForm.controls.remail.value,
      RequesterPhone: this.realEstateForm.controls.rphone.value,
      AssociationName: this.realEstateForm.controls.associationName.value,
      EstimatedClosingDate: this.realEstateForm.controls.closingDate.value,
      SellerFirstName: this.realEstateForm.controls.sfname.value,
      SellerLastName: this.realEstateForm.controls.slname.value,
      SellerEmail: this.realEstateForm.controls.semail.value,
      SellerPhone: this.realEstateForm.controls.sphone.value,
      PropertyAddressLine1: this.realEstateForm.controls.paddress1.value,
      PropertyAddressLine2: this.realEstateForm.controls.paddress2.value,
      City: this.realEstateForm.controls.pcity.value,
      State: this.realEstateForm.controls.pstate.value,
      Zip: this.realEstateForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester
    };
    return model;
  }
  addrealEstateRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.realEstateForm.valid  && this.myRecaptcha) {
      this.isButtonDisable = true;
      let model = this.realEastateModel();
      this.service.demandRequest(model, this.fileData).subscribe(
        (response: any) => {

          if (response.Success) {
            this.resetRealEstateForm();
          //  this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }

        }
      );



    }

  }
  resetRealEstateForm() {
    this.realEstateForm.reset();
    this.realEstateDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
   this.amount="-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  otherModel() {
    let model: DemandRequestOther = {
      RequesterFirstName: this.otherForm.controls.rfname.value,
      RequesterLastName: this.otherForm.controls.rlname.value,
      RequesterEmail: this.otherForm.controls.remail.value,
      RequesterPhone: this.otherForm.controls.rphone.value,
      AssociationName: this.otherForm.controls.associationName.value,
      EstimatedClosingDate: this.otherForm.controls.closingDate.value,
      SellerFirstName: this.otherForm.controls.sfname.value,
      SellerLastName: this.otherForm.controls.slname.value,
      SellerEmail: this.otherForm.controls.semail.value,
      SellerPhone: this.otherForm.controls.sphone.value,
      PropertyAddressLine1: this.otherForm.controls.paddress1.value,
      PropertyAddressLine2: this.otherForm.controls.paddress2.value,
      City: this.otherForm.controls.pcity.value,
      State: this.otherForm.controls.pstate.value,
      Zip: this.otherForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester
    };
    return model;
  }
  addOtherRequest() {

    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.otherForm.valid  && this.myRecaptcha) {
      this.isButtonDisable = true;
      let model = this.otherModel();
      this.service.demandRequest(model, this.fileData).subscribe(
        (response: any) => {

          if (response.Success) {
            this.resetOtherForm();
          //  this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }

        }
      );



    }

  }
  resetOtherForm() {
    this.otherForm.reset();
    this.otherDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
   this.amount="-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }



  paymentThankYou() {
    let message = { header: 'Thank You!', content: ' Thank You for submitting the request. We will connect with you shortly. In case if this is urgent please contact us at +1 (888)392-3515.', type: 'payment' }
    this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
      width: '700px',
      disableClose: false
    });
    this.thanksDialogRef.componentInstance.data = message;
    this.thanksDialogRef.afterClosed().subscribe(result => {
    //  if (result) {
        this.router.navigate(['/corporate']);
    //  }
    });
  }
}
