import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateDemandRequestComponent } from './corporate-demand-request.component';

describe('CorporateDemandRequestComponent', () => {
  let component: CorporateDemandRequestComponent;
  let fixture: ComponentFixture<CorporateDemandRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporateDemandRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateDemandRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
