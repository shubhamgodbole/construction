import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { CorporateComponent } from './corporate.component';
import { MatListModule, MatSelectModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatIconModule, MatInputModule, MatDialogModule, MatStepperModule, MatSliderModule, MatFormFieldModule, MatSlideToggleModule, MatSnackBarModule, MatTableModule, MatRadioModule, MatTooltipModule, MatDatepickerModule, MatMenuModule } from '@angular/material';
import { NoDataFoundModule } from '../shared/component/no-data-found/no-data-found.module';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { NumberOnlyDirectiveModule } from '../shared/directives/allow-only-number/only-number.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CorporateHomeComponent } from './corporate-home/corporate-home.component';
import { CorporateHeaderComponent } from './corporate-header/corporate-header.component';
import { CorporateFooterComponent } from './corporate-footer/corporate-footer.component';
import { CorporateResaleCertificateComponent } from './corporate-resale-certificate/corporate-resale-certificate.component';
import { CorporateCondoQuestionnaireComponent } from './corporate-condo-questionnaire/corporate-condo-questionnaire.component';
import { CorporateDemandRequestComponent } from './corporate-demand-request/corporate-demand-request.component';
import { CorporateContactUsComponent } from './corporate-contact-us/corporate-contact-us.component';
import { CorporateBlogListComponent } from './corporate-blog-list/corporate-blog-list.component';
import { CorporateBlogDetailComponent } from './corporate-blog-detail/corporate-blog-detail.component';
import { CorporateRequestProposalComponent } from './corporate-request-proposal/corporate-request-proposal.component';
import { CorporateWhyPropvivoComponent } from './corporate-why-propvivo/corporate-why-propvivo.component';
import { CorporatePaymentComponent } from './corporate-payment/corporate-payment.component';
import { CorporateProgressModule } from '../shared/component/corporate-progress/corporate-progress.module';
import { CorporatePaymentModule } from './corporate-payment/corporate-payment.module';
import { OnlyAlphabetsModule } from '../shared/directives/allow-only-alphabets/only-alphabets.module';
import { AllowOnlyDateModule } from '../shared/directives/allow-only-date/allow-only-date.module';
import { CorporateServicesComponent } from './corporate-services/corporate-services.component';
import { ReCaptchaModule } from 'angular2-recaptcha';

const routes: Routes = [
  {
    path: '',
    component: CorporateComponent,
    children: [
      { path: '', redirectTo: 'home' },
      { path: 'home', component: CorporateHomeComponent },
      { path: 'resale-certificate', component: CorporateResaleCertificateComponent },
      { path: 'corporate-services', component: CorporateServicesComponent },
      { path: 'condo-questionnaire', component: CorporateCondoQuestionnaireComponent },
      { path: 'demand-request', component: CorporateDemandRequestComponent },
      { path: 'contact-us', component: CorporateContactUsComponent },
      { path: 'blog-list', component: CorporateBlogListComponent },
      { path: 'blog-detail', component: CorporateBlogDetailComponent },
      { path: 'request-proposal', component: CorporateRequestProposalComponent },
      { path: 'why-propvivo', component: CorporateWhyPropvivoComponent }
    ]
  }

];
@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    MatListModule,
    MatSelectModule,
    MatBottomSheetModule,
    NoDataFoundModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatDatetimepickerModule,
    MatIconModule,
    CorporateProgressModule,
    MatInputModule,
    MatDialogModule,
    MatMenuModule,
    MatStepperModule,
    MatSliderModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatTableModule,
    MatRadioModule,
    MatTooltipModule,
    NumberOnlyDirectiveModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    FormsModule,
    CorporatePaymentModule,
    RouterModule.forChild(routes),
    OnlyAlphabetsModule,
    AllowOnlyDateModule,
    ReCaptchaModule,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  bootstrap: [CorporateComponent],
  declarations: [CorporateComponent,
    CorporateHomeComponent,
    CorporateHeaderComponent,
    CorporateCondoQuestionnaireComponent,
    CorporateDemandRequestComponent,
    CorporateResaleCertificateComponent,
    CorporateContactUsComponent,
    CorporateBlogListComponent,
    CorporateBlogDetailComponent,    
    CorporateRequestProposalComponent,
    CorporateWhyPropvivoComponent,
    CorporateServicesComponent,
    CorporateFooterComponent]
})
export class CorporateModule { }
