import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ServicesEnum } from '../corporate.model';
import { AppRouteUrl } from 'src/app/shared/app-module-route';

@Component({
  selector: 'app-corporate-services',
  templateUrl: './corporate-services.component.html',
  styleUrls: ['./corporate-services.component.scss']
})
export class CorporateServicesComponent implements OnInit {
  servicesEnum = ServicesEnum;
  activeService;
  //For Query string;
  querySubcription: Subscription;
  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    window.scrollTo(0,0);
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let activeService = params["service"];
      if (activeService) {
        this.activeService = activeService;
      } else {
        this.activeService = ServicesEnum.FullService;
      }
    });
  }

  goToRequestProposal() {
    this.router.navigate([AppRouteUrl.corporateRequestProposalRouteUrl]);
  }

}
