import { Component, OnInit, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { CorporateBlogService } from 'src/app/services/corporate-blog.service';
import { FormGroupDirective, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { ContactUs } from '../corporate.model';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { ThankYouComponent } from 'src/app/shared/component/thank-you/thank-you.component';
import { FeatureName, TriggerType, SourceType, AudienceType } from 'src/app/shared/Enums/commonEnums';
import { EmailNotificationService } from 'src/app/services/email-notification.service';

@Component({
  selector: 'app-corporate-blog-detail',
  templateUrl: './corporate-blog-detail.component.html',
  styleUrls: ['./corporate-blog-detail.component.scss']
})
export class CorporateBlogDetailComponent implements OnInit {
  isSubscribeDisabled: boolean = false;
  thanksDialogRef: MatDialogRef<ThankYouComponent>;
  //For Query string;
  querySubcription: Subscription;
  requestId: string;
  requestCatagory: string;
  blogData: any;
  blogCatagories: any;
  blaogTags: any;
  relatedBlogs: any;
  testCount = 2;
  slides: any = [[]];
  isComponentLoad: boolean = false;
  public chunk(arr, chunkSize) {
    let R = [];
    for (let i = 0, len = arr.length; i < len; i += chunkSize) {
      R.push(arr.slice(i, i + chunkSize));
    }
    return R;
  }
  @ViewChild('formDirective') formDirective: FormGroupDirective;
  // subscription
  subscriptionForm: FormGroup;
  notificationService: NotificationService;
  errorMsg: string;


  isApiResponceCome = false;

  constructor(private route: ActivatedRoute, private router: Router, private service: CorporateBlogService, private formBuilder: FormBuilder, private readonly snb: MatSnackBar, private progressbarService: ProgeressBarService,
    private _matDialog: MatDialog,
    private emailNotification: EmailNotificationService, ) {
    this.notificationService = new NotificationService(snb);
  }


  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      let catagory = params["blogCatagory"];
      if (id && catagory) {
        this.requestId = id;
        this.requestCatagory = catagory;
        this.getBlogDetailData(id, catagory);
      }
      else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
    this.subscriptionForm = this.formBuilder.group({
      email: ['', [Validators.required, ValidationService.emailValidator]],
    });
  }

  // get bolg's detail data
  getBlogDetailData(id, catagory) {
    this.progressbarService.show();
    this.service.blogDetailData(id, catagory).subscribe(
      (response: any) => {
        this.isApiResponceCome = true;
        if (response.Success) {
          this.progressbarService.hide();
          this.blogData = response.BlogInner.Article;
          this.blogCatagories = response.BlogInner.Categories;
          this.blaogTags = response.BlogInner.Keywords;
          this.relatedBlogs = response.BlogInner.Articles;
          this.slides = this.chunk(this.relatedBlogs, 3);
          this.isComponentLoad = true;
        }
      }
    );
  }
  // show related post detail on click
  goToDetail(id, catagory) {
    this.router.navigate([AppRouteUrl.corporateBlogDetailRouteUrl], { queryParams: { id: id, blogCatagory: catagory } });
    let a: any = this.getBlogDetailData(id, catagory);
    window.scrollTo(0, 500);
  }
  // redirect on list page while click on category or tag
  goToList(catagory, Keywords) {
    this.router.navigate([AppRouteUrl.corporateBlogListRouteUrl], { queryParams: { blogCatagory: catagory, Keywords: Keywords } });
  }
  subscriptionModel() {
    let model: ContactUs = {
      FirstName: '',
      LastName: '',
      EmailId: this.subscriptionForm.controls.email.value,
      Phone: '',
      Message: '',
    };
    return model;
  }
  emailChange() {
    if (this.subscriptionForm.controls.email.invalid && this.subscriptionForm.controls.email.value !== '') {
      this.errorMsg = "Invalid email ";
    }
    else {
      this.errorMsg = "";
    }
  }

  addSubscription() {
    let model = this.subscriptionModel();    
    if (this.subscriptionForm.controls.email.value === ''|| this.subscriptionForm.controls.email.invalid && this.subscriptionForm.controls.email.value === null) {
      this.errorMsg = "Email is required ";
    }
    if (this.subscriptionForm.valid) {
      this.isSubscribeDisabled = true;
      this.service.contactUs(model).subscribe(
        (response: any) => {
          this.isSubscribeDisabled = false;
          if (response.Success) {
            this.resetSubscriptionForm();
            this.emailNotification.sendNotifications('', response.RequestId, '', '', SourceType.Web, FeatureName.BlogSubscription, TriggerType.Create,
              AudienceType.HomeOwner).subscribe(res => {
                console.log('save Announcement ', res);
              });
            this.paymentThankYou();
          }
        });
    }
  }
  resetSubscriptionForm() {
    this.subscriptionForm.reset();
    this.formDirective.resetForm();
    this.errorMsg = "";
  }
  paymentThankYou() {
    let message = { header: 'Thank You!', content: ' for Subscribing. ', type: 'blog' }
    this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
      width: '700px',
      disableClose: false
    });
    this.thanksDialogRef.componentInstance.data = message;
    this.thanksDialogRef.afterClosed().subscribe(result => {
      if (result) {
          this.router.navigate(['/corporate']);
      }
    });
  }
}
