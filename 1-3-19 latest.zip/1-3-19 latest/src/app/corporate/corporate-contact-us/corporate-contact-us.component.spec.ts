import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateContactUsComponent } from './corporate-contact-us.component';

describe('CorporateContactUsComponent', () => {
  let component: CorporateContactUsComponent;
  let fixture: ComponentFixture<CorporateContactUsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporateContactUsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateContactUsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
