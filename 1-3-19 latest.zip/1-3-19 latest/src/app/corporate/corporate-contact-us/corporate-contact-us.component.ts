import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup,Validators, FormGroupDirective } from '@angular/forms';
import { CorporateBlogService } from 'src/app/services/corporate-blog.service';
import { ContactUs, CaptchaConfig } from '../corporate.model';
import { Subscriber } from '../corporate.model';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { FeatureName, SourceType, TriggerType, AudienceType, SubscriptionType } from 'src/app/shared/Enums/commonEnums';
import { Subscription } from 'rxjs';
import { ThankYouComponent } from 'src/app/shared/component/thank-you/thank-you.component';
import { Router } from '@angular/router';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { ReCaptchaComponent } from 'angular2-recaptcha';

@Component({
  selector: 'app-corporate-contact-us',
  templateUrl: './corporate-contact-us.component.html',
  styleUrls: ['./corporate-contact-us.component.scss']
})
export class CorporateContactUsComponent implements OnInit {
  thanksDialogRef: MatDialogRef<ThankYouComponent>;
  // contact us
  addContactUsForm: FormGroup;
  @ViewChild('formDirective') formDirective: FormGroupDirective;
  @ViewChild(ReCaptchaComponent) captcha: ReCaptchaComponent;
  // subscription
  subscriptionForm: FormGroup;
  notificationService: NotificationService;
  errorMsg:string;
  isButtonDisable: boolean = false;
  siteKey= CaptchaConfig.SiteKey;
  // myRecaptcha: boolean = false;
  constructor(private formBuilder: FormBuilder,
    private service:CorporateBlogService,
    private _matDialog: MatDialog,
    private router: Router, 
    private emailNotification : EmailNotificationService,
    private readonly snb: MatSnackBar,) {
    this.notificationService = new NotificationService(snb);
   }

  ngOnInit() {
    window.scroll(0,0);
    this.addContactUsForm = this.formBuilder.group({
      fname: ['', [Validators.required,Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      lname: ['', [Validators.required,Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      phone: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13)] ],
      email: ['',[Validators.required, ValidationService.emailValidator]],
      message: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      myRecaptcha: ['',Validators.required],
    });
    this.subscriptionForm = this.formBuilder.group({
      email: ['',[Validators.required, ValidationService.emailValidator]],
    });
    
  }
  
  createNotificationModel(featureId,requestId,featureName) {
    
    var notificationModel = new Array<EmailNotificationModel>();
    notificationModel = [{
      FeatureId: featureId,
      FeatureName:featureName,
      CreatedBy:"",
      SourceType:SourceType.Web,
      TriggerType:TriggerType.Create,
      PMCompanyAssociationMappingId:"",
      AudienceType:AudienceType.HomeOwner,
      Url:"",
      RequestId:requestId,
      CustomAttribute: {
        Request:featureName,
      	RequestSubType:TriggerType.Create

      }
   }];
   return notificationModel;
  }

  sendNotification(featureId,requestId,featureName) {
    //let emailNotificationModel = this.createNotificationModel("",response.RequestId);
    let emailNotificationModel = this.createNotificationModel(featureId,requestId,featureName);
            this.emailNotification.sendNotification(emailNotificationModel).subscribe(
              (emailresponse:any) =>{
                if (emailresponse.Success) {
                  //this.notificationService.showNotification('Notification Send SuccessFully');
                 }
              }
            );
  }
  
  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }
  setMobileNumber(event) {
    let ctrlValue = this.addContactUsForm.controls.phone.value;
    let newCtrlValue ;
    if(ctrlValue) {
      if(ctrlValue.length < 10 ) {
      }
      else{
      ctrlValue = this.addContactUsForm.controls.phone.value;
      newCtrlValue = this.convertMobileNumber(ctrlValue);
      this.addContactUsForm.controls.phone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.addContactUsForm.controls.phone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }
  contactUseModel() {
    let model: ContactUs = {
      FirstName:this.addContactUsForm.controls.fname.value,
      LastName:this.addContactUsForm.controls.lname.value,
      EmailId:this.addContactUsForm.controls.email.value,
      Phone:this.addContactUsForm.controls.phone.value,
      Message:this.addContactUsForm.controls.message.value,
    };
    return model;
  }
  handleCorrectCaptcha(e) {
    this.addContactUsForm.controls.myRecaptcha.setValue(true);
    this.errorMsg ="";
 }
  addContact() {  
   let model = this.contactUseModel();
   if (this.addContactUsForm.controls.myRecaptcha.value === '') {
    this.errorMsg ="Please verify that you are not a robot.";
  }
  else {
    this.addContactUsForm.controls.myRecaptcha.setValue(true);
    this.errorMsg ="";
  }
  
    if(this.addContactUsForm.valid) {
      this.isButtonDisable = true;
      this.service.contactUs(model).subscribe(
        (response: any) => {
          if(response.Success) {
            this.resetForm();
            console.log("Contact Us",response)
            //this.notificationService.showNotification('Contact is added successfully');
         //   this.sendNotification('',response.RequestId,FeatureName.ContactUs);
            this.paymentThankYou();
          }
          else {
            this.isButtonDisable = false;
          }
        });
    } 
  }
  resetForm() {
    this.errorMsg = "";
    this.addContactUsForm.reset();
    this.formDirective.resetForm();
    this.isButtonDisable = false;
    this.addContactUsForm.controls.myRecaptcha.setValue('');
    this.captcha.reset();
  }
  emailChange() {
    if(this.subscriptionForm.controls.email.invalid) {
      this.errorMsg ="Envalid email ";
    }
    else {
      this.errorMsg ="";
    }
  }
  subscriptionModel() {
    let model: Subscriber = {
      FirstName:'',
      LastName:'',
      Email:this.subscriptionForm.controls.email.value,    
      SubscriptionType:SubscriptionType.Blogs 
    };
    return model;
  }
  addSubscription() {
    let model = this.subscriptionModel();
    if (this.subscriptionForm.controls.email.value === '') {
      this.errorMsg ="Email is required ";
    }
    
    if(this.subscriptionForm.valid) {
      this.service.subscriber(model).subscribe(
        (response: any) => {
          if(response.Success) {
            this.resetSubscriptionForm();
           // this.notificationService.showNotification('Subscribe is successfully');
            this.sendNotification('',response.RequestId,FeatureName.BlogSubscription);
          }
        });
   }
  }
  resetSubscriptionForm() {
    this.subscriptionForm.reset();
    this.formDirective.resetForm();
    this.errorMsg = "";
  }

  paymentThankYou() {
    let message = { header: 'Thank You!', content: ' for Contacting Us. We will get back to you shortly. ', type: 'contactus' }
    this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
      width: '700px',
      disableClose: false
    });
    this.thanksDialogRef.componentInstance.data = message;
    this.thanksDialogRef.afterClosed().subscribe(result => {
      if (result) {
      //  this.router.navigate(['/corporate']);
      }
    });
  }
}
