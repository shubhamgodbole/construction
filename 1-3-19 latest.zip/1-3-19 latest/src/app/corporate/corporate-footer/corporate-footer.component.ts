import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ServicesEnum } from '../corporate.model';

@Component({
  selector: 'app-corporate-footer',
  templateUrl: './corporate-footer.component.html',
  styleUrls: ['./corporate-footer.component.scss']
})
export class CorporateFooterComponent implements OnInit {
  servicesEnum = ServicesEnum;
  constructor(private router:Router) { }

  ngOnInit() {
  }
   // redirect to corporate home
   goToHome() {
    this.router.navigate([AppRouteUrl.corporateHomeRouteUrl]);
    window.scrollTo(0, 0);
  } 
   // redirect to corporate why propvivo
   goToWhyPropVivo() {
    this.router.navigate([AppRouteUrl.corporateWhyPropVivoRouteUrl]);
  }
   // redirect to corporate blog
  goToBlog() {
    this.router.navigate([AppRouteUrl.corporateBlogListRouteUrl]);
  }
   // redirect to corporate contact
  goToContact() {
    this.router.navigate([AppRouteUrl.corporateContactUsRouteUrl]);
  }
   // redirect to corporate Resale Certificate
  goToResaleCertificate() {
    this.router.navigate([AppRouteUrl.corporateResaleCertificateRouteUrl]);
  }
   // redirect to corporate Demand Request
  goToDemandRequest() {
    this.router.navigate([AppRouteUrl.corporateDemandRequestRouteUrl]);
  }
   // redirect to Condo Questionnaire
  goToCondoQuestionnaire() {
    this.router.navigate([AppRouteUrl.corporateCondoQuestionnaireRouteUrl]);
  }
  goToServices(services) {
    let currServices = "";
    if (services === ServicesEnum.Financial)
      currServices = services;
    else if (services === ServicesEnum.SelfManagement)
      currServices = services;
    else
      currServices = services;
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "service": currServices
      }
    };
    this.router.navigate([AppRouteUrl.corporateRequestServicesRouteUrl], navigationExtras);
    window.scrollTo(0, 0);
  }
}
