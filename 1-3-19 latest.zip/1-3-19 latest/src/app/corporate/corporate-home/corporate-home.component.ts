import { Component, OnInit } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { Router, NavigationExtras } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ServicesEnum } from '../corporate.model';

@Component({
  selector: 'app-corporate-home',
  templateUrl: './corporate-home.component.html',
  styleUrls: ['./corporate-home.component.scss']
})
export class CorporateHomeComponent implements OnInit {
  servicesEnum = ServicesEnum;
  isLogin: boolean;

  constructor(private readonly appConfig: AppConfig, private router: Router) {
    this.appConfig.isLoggedIn.subscribe(
      (login) => {
        this.isLogin = login;
      }
    );
  }

  ngOnInit() {
    window.scroll(0, 0);
  }
  goToRequestProposal() {
    this.router.navigate(['/corporate/request-proposal']);
    window.scroll(0, 0);
  }

  scroll(el) {
    el.scrollIntoView();
  }

  goToWhyPropVivo() {
    this.router.navigate([AppRouteUrl.corporateWhyPropVivoRouteUrl]);
  }

  goToServices(services) {
    let currServices = "";
    if (services === ServicesEnum.Financial)
      currServices = services;
    else if (services === ServicesEnum.SelfManagement)
      currServices = services;
    else
      currServices = services;
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "service": currServices
      }
    };
    this.router.navigate([AppRouteUrl.corporateRequestServicesRouteUrl], navigationExtras);
  }

}
