import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corporate-why-propvivo',
  templateUrl: './corporate-why-propvivo.component.html',
  styleUrls: ['./corporate-why-propvivo.component.scss']
})
export class CorporateWhyPropvivoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scroll(0,0);
  }

}
