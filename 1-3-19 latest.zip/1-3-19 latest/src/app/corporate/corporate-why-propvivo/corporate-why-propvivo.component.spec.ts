import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateWhyPropvivoComponent } from './corporate-why-propvivo.component';

describe('CorporateWhyPropvivoComponent', () => {
  let component: CorporateWhyPropvivoComponent;
  let fixture: ComponentFixture<CorporateWhyPropvivoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporateWhyPropvivoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateWhyPropvivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
