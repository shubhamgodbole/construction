export enum RealStateDocumentTypeEnums {
    resaleCertificate = "Resale Certificate",
    demandRequest = "Demand Request",
    condoQuestionary = "Condo Questionnaire",
}
export enum CaptchaConfig {
    SiteKey = "6LcRYZMUAAAAAH9N1BwOUTFG2_ujL5i7t-h6ggw6",
    SecrectKey = "6LcRYZMUAAAAABUPoyCt6q9cyHG_SXQqySw3f7LV"
}

export class PaymentDetailModel {
    paymentAmount: string;
    realStateDocumentType: string;
    orderType: boolean;
    invoiceNumber: string;
    invoiceDescription: string;
}


export class ContactUs {
    FirstName: string
    LastName: string
    EmailId: string
    Phone: string
    Message: string
}

export class Subscriber {
    FirstName: string
    LastName: string
    Email: string
    SubscriptionType: string
}

export class DisplayRequester {
    public static Requester = [
        { value: "Homeowner", text: "Homeowner" },
        { value: "Escrow", text: "Escrow" },
        { value: "Investor", text: "Investor" },
        { value: "Lender", text: "Lender" },
        { value: "ProspectiveBuyer", text: "Prospective Buyer" },
        { value: "RealEstateProfessional", text: "Real Estate Manager" },
        { value: "Other", text: "Other" },
    ]
}

export enum RequesterEnum {
    Homeowner = "Homeowner",
    Escrow = "Escrow",
    Investor = "Investor",
    Lender = "Lender",
    ProspectiveBuyer = "ProspectiveBuyer",
    RealEstateProfessional = "RealEstateProfessional",
    Other = "Other"

}

export class CondoQuestionaryHomeowners {
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    IsRushOrder: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class CondoQuestionaryEscro {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    CompanyName: string
    EstimatedClosingDate: string
    BuyerFirstName: string
    BuyerLastName: string
    BuyerEmail: string
    BuyerPhone: string
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    IsRushOrder: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class CondoQuestionaryInvestor {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    CompanyName: string
    EstimatedClosingDate: string
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    IsRushOrder: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class CondoQuestionaryLender {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    CompanyName: string
    EstimatedClosingDate: string
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    IsRushOrder: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class CondoQuestionaryPrespective {
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    BuyerFirstName: string
    BuyerLastName: string
    BuyerEmail: string
    BuyerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    IsRushOrder: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class CondoQuestionaryRealEastate {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    AssociationName: string
    EstimatedClosingDate: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    IsRushOrder: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class CondoQuestionaryOther {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    AssociationName: string
    EstimatedClosingDate: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    IsRushOrder: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}


export class ResaleCertificatesHomeowners {
    AssociationName: string;
    OwnerFirstName: string;
    OwnerLastName: string;
    OwnerEmail: string;
    OwnerPhone: string;
    PropertyAddressLine1: string;
    PropertyAddressLine2: string;
    City: string;
    State: string;
    Zip: string;
    OrderType: boolean;
    AmountCharged: string;
    RequestedBy: string;
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class ResaleCertificatesEscro {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    CompanyName: string
    EstimatedClosingDate: string
    BuyerFirstName: string
    BuyerLastName: string
    BuyerEmail: string
    BuyerPhone: string
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class ResaleCertificatesInvestor {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    CompanyName: string
    EstimatedClosingDate: string
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class ResaleCertificatesLender {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    CompanyName: string
    EstimatedClosingDate: string
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class ResaleCertificatesPrespective {
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    BuyerFirstName: string
    BuyerLastName: string
    BuyerEmail: string
    BuyerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class ResaleCertificatesRealEastate {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    AssociationName: string
    EstimatedClosingDate: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}

export class ResaleCertificatesOther {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    AssociationName: string
    EstimatedClosingDate: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
    InvocieNumber: string;
    InvoiceDescription: string;
    InvoiceDate: string;
}


export class DemandRequestHomeowners {
    AssociationName: string
    SellerFirstName: string
    SellerLastName: string
    SellerEmail: string
    SellerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
}

export class DemandRequestEscro {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    EscrowCompanyName: string
    EscrowNumber: string
    BuyerFirstName: string
    BuyerLastName: string
    BuyerEmail: string
    BuyerPhone: string
    AssociationName: string
    SellerFirstName: string
    SellerLastName: string
    SellerEmail: string
    SellerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
}

export class DemandRequestInvestor {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    CompanyName: string
    EstimatedClosingDate: string
    AssociationName: string
    OwnerFirstName: string
    OwnerLastName: string
    OwnerEmail: string
    OwnerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
}

export class DemandRequestLender {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    EscrowCompanyName: string
    EstimatedClosingDate: string
    AssociationName: string
    SellerFirstName: string
    SellerLastName: string
    SellerEmail: string
    SellerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
}

export class DemandRequestPrespective {
    AssociationName: string
    EstimatedClosingDate: string
    SellerFirstName: string
    SellerLastName: string
    SellerEmail: string
    SellerPhone: string
    BuyerFirstName: string
    BuyerLastName: string
    BuyerEmail: string
    BuyerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
}

export class DemandRequestRealEastate {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    AssociationName: string
    EstimatedClosingDate: string
    SellerFirstName: string
    SellerLastName: string
    SellerEmail: string
    SellerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
}

export class DemandRequestOther {
    RequesterFirstName: string
    RequesterLastName: string
    RequesterEmail: string
    RequesterPhone: string
    AssociationName: string
    EstimatedClosingDate: string
    SellerFirstName: string
    SellerLastName: string
    SellerEmail: string
    SellerPhone: string
    PropertyAddressLine1: string
    PropertyAddressLine2: string
    City: string
    State: string
    Zip: string
    OrderType: boolean
    AmountCharged: string
    RequestedBy: string
}


export class PaymentCardModel {
    CardType: string;
    CardNumber: string;
    Month: string;
    Year: string;
    CVVNumber: string;
    FirstName: string;
    LastName: string;
    AddressLine1: string;
    AddressLine2: string;
    City: string;
    State: string;
    ZipCode: string;
    Country: string;
    EmailAddress: string;
    Amount: string;
}

export enum ChangeMobileNumberType {
    Homeowner = "Homeowner",
    Seller = "Seller",
    Requester = "Requester",
    Buyer = "Buyer"
}


export enum ServicesEnum {
    SelfManagement = "selfManagement",
    Financial = "financial",
    FullService = "fullService"
}