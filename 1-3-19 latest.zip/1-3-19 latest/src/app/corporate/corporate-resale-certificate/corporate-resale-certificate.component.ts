import { Component, OnInit, ViewChild } from '@angular/core';
import { DisplayRequester, CondoQuestionaryHomeowners, CondoQuestionaryEscro, CondoQuestionaryInvestor, CondoQuestionaryLender, CondoQuestionaryPrespective, CondoQuestionaryRealEastate, CondoQuestionaryOther, ResaleCertificatesHomeowners, ResaleCertificatesEscro, ResaleCertificatesInvestor, ResaleCertificatesLender, ResaleCertificatesPrespective, ResaleCertificatesRealEastate, ResaleCertificatesOther, ChangeMobileNumberType, RealStateDocumentTypeEnums, RequesterEnum, PaymentDetailModel } from '../corporate.model';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { CorporateBlogService } from 'src/app/services/corporate-blog.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { ImageNameEnums, SourceType, TriggerType, FeatureName } from 'src/app/shared/Enums/commonEnums';
import { Guid } from 'guid-typescript';
import { EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { AudienceType } from 'src/app/components/board-tasks/board-task.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { ThankYouComponent } from 'src/app/shared/component/thank-you/thank-you.component';
import { Router } from '@angular/router';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { CommonService } from 'src/app/services/common.service';
import { AcceptFilesConstant, CommonConstant } from 'src/app/shared/common/constant.model';
import { CaptchaConfig } from '../corporate.model';
import { ReCaptchaComponent } from 'angular2-recaptcha';

@Component({
  selector: 'app-corporate-resale-certificate',
  templateUrl: './corporate-resale-certificate.component.html',
  styleUrls: ['./corporate-resale-certificate.component.scss']
})
export class CorporateResaleCertificateComponent implements OnInit {
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  //Payment methods variables
  isPaymentMethodsValid: boolean = false;
  realStateDocumentTypeEnums = RealStateDocumentTypeEnums;
  requesterEnum = RequesterEnum;
  paymentDetailModel: PaymentDetailModel;
  // Payment Thank you
  thanksDialogRef: MatDialogRef<ThankYouComponent>;


  requester: string;
  requesterList: any;
  selectedRequester: any;
  // home woner
  homeWonerForm: FormGroup;
  @ViewChild('homeWonereDirective') homeWonereDirective: FormGroupDirective;
  // Escro
  escroForm: FormGroup;
  @ViewChild('escroDirective') escroDirective: FormGroupDirective;

  // Investor
  investorForm: FormGroup;
  @ViewChild('investorDirective') investorDirective: FormGroupDirective;

  // Lender
  lenderForm: FormGroup;
  @ViewChild('lenderDirective') lenderDirective: FormGroupDirective;
  // perscpectiveForm
  perscpectiveForm: FormGroup;
  @ViewChild('perscpectiveDirective') perscpectiveDirective: FormGroupDirective;
  // realEstateForm
  realEstateForm: FormGroup;
  @ViewChild('realEstateDirective') realEstateDirective: FormGroupDirective;
  // otherForm
  otherForm: FormGroup;
  @ViewChild('otherDirective') otherDirective: FormGroupDirective;

  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  favoriteSeason: any;
  amount: string = "-";
  showRadioError: boolean = false;
  fileData: any = [];
  errorMsg: string;
  notificationService: NotificationService;
  isRushOrder: boolean = false;
  attachmentsErrorMsg: string = "Attachments is requeird";
  successMsg: string = "Request is add successfully";
  isButtonDisable: boolean = false;
  today: Date = new Date();
  changeMobileNumberType = ChangeMobileNumberType;
  siteKey= CaptchaConfig.SiteKey;
captchaErrorMsg: string ="Please verify that you are not a robot.";
  capthcaMessage:string = "";
  myRecaptcha: boolean = false;

  @ViewChild(ReCaptchaComponent) captcha: ReCaptchaComponent;
  constructor(private formBuilder: FormBuilder,
    private _matDialog: MatDialog,
    private router: Router,
    private progressbarService: ProgeressBarService,
    private commonService: CommonService,
    private service: CorporateBlogService,
    private readonly snb: MatSnackBar, private emailNotification: EmailNotificationService) {
    this.notificationService = new NotificationService(snb);
    this.requesterList = DisplayRequester.Requester;
    this.requester = this.requesterList[0].value;
    this.selectedRequester = this.requesterList[0].value;
  }

  ngOnInit() {
    window.scroll(0, 0);
    this.homeWonerForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50),ValidationService.notStartWhiteSpace]],
      fname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      lname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      phone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      email: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      address1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      address2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      city: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      state: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2) ,ValidationService.notStartWhiteSpace]],
      zip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5),ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.escroForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      rfname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13), ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required, ValidationService.emailValidator, ValidationService.notStartWhiteSpace]],
      bfname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      blname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      bphone: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13), ValidationService.notStartWhiteSpace]],
      bemail: ['', [Validators.required, ValidationService.emailValidator, ValidationService.notStartWhiteSpace]],
      companyName: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      closingDate: [''],
      hfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      hemail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2),ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5),ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.investorForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50),ValidationService.notStartWhiteSpace]],
      rfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      companyName: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      closingDate: [''  ],
      hfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      hemail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2),ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5),ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.lenderForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      rfname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13), ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required, ValidationService.emailValidator, ValidationService.notStartWhiteSpace]],
      companyName: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      closingDate: [''],
      hfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      hemail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2),ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5),ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.perscpectiveForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      hfname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      hlname: ['', [Validators.required, Validators.maxLength(30), ValidationService.notStartWhiteSpace]],
      hphone: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13), ValidationService.notStartWhiteSpace]],
      hemail: ['', [Validators.required, ValidationService.emailValidator, ValidationService.notStartWhiteSpace]],
      bfname: ['', [Validators.required, Validators.maxLength(30)]],
      blname: ['', [Validators.required, Validators.maxLength(30)]],
      bphone: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13),]],
      bemail: ['', [Validators.required, ValidationService.emailValidator]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2),ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5),ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.realEstateForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      closingDate: [''],
      rfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required,ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      hfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      hemail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2),ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5),ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
    this.otherForm = this.formBuilder.group({
      associationName: ['', [Validators.required, Validators.maxLength(50), ValidationService.notStartWhiteSpace]],
      closingDate: [''],
      rfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      rphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      remail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      hfname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hlname: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      hphone: ['', [Validators.required, Validators.maxLength(13),Validators.minLength(13),ValidationService.notStartWhiteSpace]],
      hemail: ['', [Validators.required, ValidationService.emailValidator,ValidationService.notStartWhiteSpace]],
      paddress1: ['', [Validators.required, Validators.maxLength(200),ValidationService.notStartWhiteSpace]],
      paddress2: ['', [Validators.maxLength(200),Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      pcity: ['', [Validators.required, Validators.maxLength(30),ValidationService.notStartWhiteSpace]],
      pstate: ['', [Validators.required, Validators.maxLength(2),Validators.minLength(2),ValidationService.notStartWhiteSpace]],
      pzip: ['', [Validators.required, Validators.maxLength(10),Validators.minLength(5),ValidationService.notStartWhiteSpace]],
      orderType: ['', Validators.required],
    });
  }

  changeRequester(event) {
    this.requester = event.value;
    this.errorMsg = "";
    this.showRadioError = false;
    this.isButtonDisable = false;
    this.homeWonerForm.reset();
    this.escroForm.reset();
    this.investorForm.reset();
    this.lenderForm.reset();
    this.perscpectiveForm.reset();
    this.realEstateForm.reset();
    this.otherForm.reset();
    this.amount = "-";
    this.capthcaMessage ="";
  }

  handleCorrectCaptcha(e) {
    this.myRecaptcha = true;
    this.capthcaMessage ="";
  }
  radioChange(event) {

    this.showRadioError = false;
    if (event.value === 'Normal') {
      this.amount = '258';
      this.isRushOrder = false;
    }
    else {
      this.amount = '358';
      this.isRushOrder = true
    }
  }
  // on file upload
  onUploadChange(evt: any) {
    // this.imgFlag = false;
    // this.fileData = [];
    this.errorMsg = "";
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }

    }

  }
  // remove uploaded Documents
  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };
  createNotificationModel(featureId, requestId) {

    var notificationModel = new Array<EmailNotificationModel>();
    notificationModel = [{
      FeatureId: "",
      FeatureName: FeatureName.ResaleCertificate,
      CreatedBy: "",
      SourceType: SourceType.Web,
      TriggerType: TriggerType.Create,
      PMCompanyAssociationMappingId: "",
      AudienceType: AudienceType.HomeOwner,
      Url: "",
      RequestId: requestId,
      CustomAttribute: {
        Request: FeatureName.ResaleCertificate,
        RequestSubType: TriggerType.Create

      }
    }];
    return notificationModel;
  }
  sendNotification(featureId, requestId) {
    //let emailNotificationModel = this.createNotificationModel("",response.RequestId);
    let emailNotificationModel = this.createNotificationModel(featureId, requestId);
    this.emailNotification.sendNotification(emailNotificationModel).subscribe(
      (emailresponse: any) => {
        if (emailresponse.Success) {
          //this.notificationService.showNotification('Notification Send SuccessFully');
        }
      }
    );
  }
  homeOwnerModel() {
    let model: ResaleCertificatesHomeowners = {
      AssociationName: this.homeWonerForm.controls.associationName.value,
      OwnerFirstName: this.homeWonerForm.controls.fname.value,
      OwnerLastName: this.homeWonerForm.controls.lname.value,
      OwnerEmail: this.homeWonerForm.controls.email.value,
      OwnerPhone: this.homeWonerForm.controls.phone.value,
      PropertyAddressLine1: this.homeWonerForm.controls.address1.value,
      PropertyAddressLine2: this.homeWonerForm.controls.address2.value,
      City: this.homeWonerForm.controls.city.value,
      State: this.homeWonerForm.controls.state.value,
      Zip: this.homeWonerForm.controls.zip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester,
      InvocieNumber: '', //this.paymentDetailModel.invoiceNumber,
      InvoiceDate: '', //new Date().toLocaleDateString(),
      InvoiceDescription: '' //this.paymentDetailModel.invoiceDescription

    };
    return model;
  }
  setMobileNumber(event, type) {
    let ctrlValue;
    let newCtrlValue;
    if (this.homeWonerForm.controls.phone.value && type === this.changeMobileNumberType.Homeowner) {
      ctrlValue = this.homeWonerForm.controls.phone.value;
      if (this.homeWonerForm.controls.phone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.homeWonerForm.controls.phone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.homeWonerForm.controls.phone.value.replace(/[^0-9 ]/g, "");
          this.homeWonerForm.controls.phone.setValue(val);
        }
        //this.homeWonerForm.controls.phone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    // ecroForm
    if (this.escroForm.controls.rphone.value && type === this.changeMobileNumberType.Requester) {
      ctrlValue = this.escroForm.controls.rphone.value;
      if (this.escroForm.controls.rphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.escroForm.controls.rphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.escroForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
          this.escroForm.controls.rphone.setValue(val);
        }
        //this.escroForm.controls.rphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if (this.escroForm.controls.bphone.value && type === this.changeMobileNumberType.Buyer) {
      ctrlValue = this.escroForm.controls.bphone.value;
      if (this.escroForm.controls.bphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.escroForm.controls.bphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.escroForm.controls.bphone.value.replace(/[^0-9 ]/g, "");
          this.escroForm.controls.bphone.setValue(val);
        }
        //this.escroForm.controls.bphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if (this.escroForm.controls.hphone.value && type === this.changeMobileNumberType.Homeowner) {
      ctrlValue = this.escroForm.controls.hphone.value;
      if (this.escroForm.controls.hphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.escroForm.controls.hphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.escroForm.controls.hphone.value.replace(/[^0-9 ]/g, "");
          this.escroForm.controls.hphone.setValue(val);
        }
        //  this.escroForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    // investor
    if (this.investorForm.controls.rphone.value && type === this.changeMobileNumberType.Requester) {
      ctrlValue = this.investorForm.controls.rphone.value;
      if (this.investorForm.controls.rphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.investorForm.controls.rphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.investorForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
          this.investorForm.controls.rphone.setValue(val);
        }
        // this.investorForm.controls.rphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if (this.investorForm.controls.hphone.value && type === this.changeMobileNumberType.Homeowner) {
      ctrlValue = this.investorForm.controls.hphone.value;
      if (this.investorForm.controls.hphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.investorForm.controls.hphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.investorForm.controls.hphone.value.replace(/[^0-9 ]/g, "");
          this.investorForm.controls.hphone.setValue(val);
        }
        //this.investorForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    // lender
    if (this.lenderForm.controls.rphone.value && type === this.changeMobileNumberType.Requester) {
      ctrlValue = this.lenderForm.controls.rphone.value;
      if (this.lenderForm.controls.rphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.lenderForm.controls.rphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.lenderForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
          this.lenderForm.controls.rphone.setValue(val);
        }
        // this.lenderForm.controls.rphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if (this.lenderForm.controls.hphone.value && type === this.changeMobileNumberType.Homeowner) {
      ctrlValue = this.lenderForm.controls.hphone.value;
      if (this.lenderForm.controls.hphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.lenderForm.controls.hphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.lenderForm.controls.hphone.value.replace(/[^0-9 ]/g, "");
          this.lenderForm.controls.hphone.setValue(val);
        }
        // this.lenderForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    // perscpectiveForm
    if (this.perscpectiveForm.controls.hphone.value && type === this.changeMobileNumberType.Homeowner) {
      ctrlValue = this.perscpectiveForm.controls.hphone.value;
      if (this.perscpectiveForm.controls.hphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.perscpectiveForm.controls.hphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.perscpectiveForm.controls.hphone.value.replace(/[^0-9 ]/g, "");
          this.perscpectiveForm.controls.hphone.setValue(val);
        }
        //  this.perscpectiveForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    else if (this.perscpectiveForm.controls.bphone.value && type === this.changeMobileNumberType.Buyer) {
      ctrlValue = this.perscpectiveForm.controls.bphone.value;
      if (this.perscpectiveForm.controls.bphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.perscpectiveForm.controls.bphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.perscpectiveForm.controls.bphone.value.replace(/[^0-9 ]/g, "");
          this.perscpectiveForm.controls.bphone.setValue(val);
        }
        //this.perscpectiveForm.controls.bphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }

    // realEstateForm
    if (this.realEstateForm.controls.hphone.value && type === this.changeMobileNumberType.Homeowner) {
      ctrlValue = this.realEstateForm.controls.hphone.value;
      if (this.realEstateForm.controls.hphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.realEstateForm.controls.hphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.realEstateForm.controls.hphone.value.replace(/[^0-9 ]/g, "");
          this.realEstateForm.controls.hphone.setValue(val);
        }
        //this.realEstateForm.controls.hphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    if (this.realEstateForm.controls.rphone.value && type === this.changeMobileNumberType.Requester) {
      ctrlValue = this.realEstateForm.controls.rphone.value;
      if (this.realEstateForm.controls.rphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.realEstateForm.controls.rphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.realEstateForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
          this.realEstateForm.controls.rphone.setValue(val);
        }
        //this.realEstateForm.controls.rphone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    // otherForm
    if (this.otherForm.controls.hphone.value && type === this.changeMobileNumberType.Homeowner) {
      ctrlValue = this.otherForm.controls.hphone.value;
      if (this.otherForm.controls.hphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.otherForm.controls.hphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.otherForm.controls.hphone.value.replace(/[^0-9 ]/g, "");
          this.otherForm.controls.hphone.setValue(val);
        }

      }
    }
    if (this.otherForm.controls.rphone.value && type === this.changeMobileNumberType.Requester) {
      ctrlValue = this.otherForm.controls.rphone.value;
      if (this.otherForm.controls.rphone.value.length < 10) { }
      else {
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.otherForm.controls.rphone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        var format = "()-";
        if (ctrlValue.match(format)) {
          let val = this.otherForm.controls.rphone.value.replace(/[^0-9 ]/g, "");
          this.otherForm.controls.rphone.setValue(val);
        }

      }
    }
  }
  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }
  addHomeWonwerRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    // if (this.fileData.length === 0) {
    //   this.errorMsg = this.attachmentsErrorMsg;
    // }
    if (this.homeWonerForm.valid && this.myRecaptcha) {
      this.isButtonDisable = true;
      //this.setPaymentModel(RealStateDocumentTypeEnums.resaleCertificate, this.isRushOrder, this.amount);
      // this.isPaymentMethodsValid = true;
      let model = this.homeOwnerModel();
      this.service.resaleCertificate(model, this.fileData).subscribe(
        (response: any) => {
          if (response.Success) {
            this.resetHomeWonerForm();
            //this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }
        }
      );
    }
  }



  resetHomeWonerForm() {
    this.homeWonerForm.reset();
    this.homeWonereDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
    this.amount = "-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  escroModel() {
    let model: ResaleCertificatesEscro = {
      RequesterFirstName: this.escroForm.controls.rfname.value,
      RequesterLastName: this.escroForm.controls.rlname.value,
      RequesterEmail: this.escroForm.controls.remail.value,
      RequesterPhone: this.escroForm.controls.rphone.value,
      CompanyName: this.escroForm.controls.companyName.value,
      EstimatedClosingDate: this.escroForm.controls.closingDate.value,
      BuyerFirstName: this.escroForm.controls.bfname.value,
      BuyerLastName: this.escroForm.controls.blname.value,
      BuyerEmail: this.escroForm.controls.bemail.value,
      BuyerPhone: this.escroForm.controls.bphone.value,
      AssociationName: this.escroForm.controls.associationName.value,
      OwnerFirstName: this.escroForm.controls.hfname.value,
      OwnerLastName: this.escroForm.controls.hlname.value,
      OwnerEmail: this.escroForm.controls.hemail.value,
      OwnerPhone: this.escroForm.controls.hphone.value,
      PropertyAddressLine1: this.escroForm.controls.paddress1.value,
      PropertyAddressLine2: this.escroForm.controls.paddress2.value,
      City: this.escroForm.controls.pcity.value,
      State: this.escroForm.controls.pstate.value,
      Zip: this.escroForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester,
      InvocieNumber: '', //this.paymentDetailModel.invoiceNumber,
      InvoiceDate: '', //new Date().toLocaleDateString(),
      InvoiceDescription: '' //this.paymentDetailModel.invoiceDescription
    };
    return model;
  }
  addescroRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.escroForm.valid && this.myRecaptcha) {
      this.isButtonDisable = true;
     // this.setPaymentModel(RealStateDocumentTypeEnums.resaleCertificate, this.isRushOrder, this.amount);
     // this.isPaymentMethodsValid = true;
      let model = this.escroModel();
      this.service.resaleCertificate(model, this.fileData).subscribe(
        (response: any) => {
          if (response.Success) {
            this.resetEscroForm();
            //this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }
        }
      );
    }

  }
  resetEscroForm() {
    this.escroForm.reset();
    this.escroDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
    this.amount = "-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  investorModel() {
    let model: ResaleCertificatesInvestor = {
      RequesterFirstName: this.investorForm.controls.rfname.value,
      RequesterLastName: this.investorForm.controls.rlname.value,
      RequesterEmail: this.investorForm.controls.remail.value,
      RequesterPhone: this.investorForm.controls.rphone.value,
      CompanyName: this.investorForm.controls.companyName.value,
      EstimatedClosingDate: this.investorForm.controls.closingDate.value,
      AssociationName: this.investorForm.controls.associationName.value,
      OwnerFirstName: this.investorForm.controls.hfname.value,
      OwnerLastName: this.investorForm.controls.hlname.value,
      OwnerEmail: this.investorForm.controls.hemail.value,
      OwnerPhone: this.investorForm.controls.hphone.value,
      PropertyAddressLine1: this.investorForm.controls.paddress1.value,
      PropertyAddressLine2: this.investorForm.controls.paddress2.value,
      City: this.investorForm.controls.pcity.value,
      State: this.investorForm.controls.pstate.value,
      Zip: this.investorForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester,
      InvocieNumber: '', //this.paymentDetailModel.invoiceNumber,
      InvoiceDate: '', //new Date().toLocaleDateString(),
      InvoiceDescription: '' //this.paymentDetailModel.invoiceDescription
    };
    return model;
  }
  addInvestorRequest() {

    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.investorForm.valid && this.myRecaptcha) {
      this.isButtonDisable = true;
     // this.setPaymentModel(RealStateDocumentTypeEnums.resaleCertificate, this.isRushOrder, this.amount);
     // this.isPaymentMethodsValid = true;      
      let model = this.investorModel();
      this.service.resaleCertificate(model, this.fileData).subscribe(
        (response: any) => {
          if (response.Success) {
            this.resetInvestorForm();
            //this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }
        }
      );
    }
  }
  resetInvestorForm() {
    this.investorForm.reset();
    this.investorDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
    this.amount = "-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  lenderModel() {
    let model: ResaleCertificatesLender = {
      RequesterFirstName: this.lenderForm.controls.rfname.value,
      RequesterLastName: this.lenderForm.controls.rlname.value,
      RequesterEmail: this.lenderForm.controls.remail.value,
      RequesterPhone: this.lenderForm.controls.rphone.value,
      CompanyName: this.lenderForm.controls.companyName.value,
      EstimatedClosingDate: this.lenderForm.controls.closingDate.value,
      AssociationName: this.lenderForm.controls.associationName.value,
      OwnerFirstName: this.lenderForm.controls.hfname.value,
      OwnerLastName: this.lenderForm.controls.hlname.value,
      OwnerEmail: this.lenderForm.controls.hemail.value,
      OwnerPhone: this.lenderForm.controls.hphone.value,
      PropertyAddressLine1: this.lenderForm.controls.paddress1.value,
      PropertyAddressLine2: this.lenderForm.controls.paddress2.value,
      City: this.lenderForm.controls.pcity.value,
      State: this.lenderForm.controls.pstate.value,
      Zip: this.lenderForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester,
      InvocieNumber: '', //this.paymentDetailModel.invoiceNumber,
      InvoiceDate: '', //new Date().toLocaleDateString(),
      InvoiceDescription: '' //this.paymentDetailModel.invoiceDescription
    };
    return model;
  }
  addLendrRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.lenderForm.valid && this.myRecaptcha) {
      this.isButtonDisable = true;
      // this.setPaymentModel(RealStateDocumentTypeEnums.resaleCertificate, this.isRushOrder, this.amount);
      // this.isPaymentMethodsValid = true;
      let model = this.lenderModel();
      this.service.resaleCertificate(model, this.fileData).subscribe(
        (response: any) => {
          if (response.Success) {
            this.resetLenderForm();
            //this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }
        }
      );
    }
  }
  resetLenderForm() {
    this.lenderForm.reset();
    this.lenderDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
    this.amount = "-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  prespectiveModel() {
    let model: ResaleCertificatesPrespective = {
      AssociationName: this.perscpectiveForm.controls.associationName.value,
      OwnerFirstName: this.perscpectiveForm.controls.hfname.value,
      OwnerLastName: this.perscpectiveForm.controls.hlname.value,
      OwnerEmail: this.perscpectiveForm.controls.hemail.value,
      OwnerPhone: this.perscpectiveForm.controls.hphone.value,
      BuyerFirstName: this.perscpectiveForm.controls.bfname.value,
      BuyerLastName: this.perscpectiveForm.controls.blname.value,
      BuyerEmail: this.perscpectiveForm.controls.bemail.value,
      BuyerPhone: this.perscpectiveForm.controls.bphone.value,
      PropertyAddressLine1: this.perscpectiveForm.controls.paddress1.value,
      PropertyAddressLine2: this.perscpectiveForm.controls.paddress2.value,
      City: this.perscpectiveForm.controls.pcity.value,
      State: this.perscpectiveForm.controls.pstate.value,
      Zip: this.perscpectiveForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester,
      InvocieNumber: '', //this.paymentDetailModel.invoiceNumber,
      InvoiceDate: '', //new Date().toLocaleDateString(),
      InvoiceDescription: '' //this.paymentDetailModel.invoiceDescription
    };
    return model;
  }
  addPrespectiveRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.perscpectiveForm.valid && this.myRecaptcha) {
      // this.isButtonDisable = true;
      // this.setPaymentModel(RealStateDocumentTypeEnums.resaleCertificate, this.isRushOrder, this.amount);
      // this.isPaymentMethodsValid = true;
      this.isButtonDisable = true;
      let model = this.prespectiveModel();
      this.service.resaleCertificate(model, this.fileData).subscribe(
        (response: any) => {
          if (response.Success) {
            this.resetPrespectiveForm();
            //this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }
        }
      );
    }
  }
  resetPrespectiveForm() {
    this.perscpectiveForm.reset();
    this.perscpectiveDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
    this.amount = "-"
    this.isButtonDisable = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  realEastateMOdel() {
    let model: ResaleCertificatesRealEastate = {
      RequesterFirstName: this.realEstateForm.controls.rfname.value,
      RequesterLastName: this.realEstateForm.controls.rlname.value,
      RequesterEmail: this.realEstateForm.controls.remail.value,
      RequesterPhone: this.realEstateForm.controls.rphone.value,
      AssociationName: this.realEstateForm.controls.associationName.value,
      EstimatedClosingDate: this.realEstateForm.controls.closingDate.value,
      OwnerFirstName: this.realEstateForm.controls.hfname.value,
      OwnerLastName: this.realEstateForm.controls.hlname.value,
      OwnerEmail: this.realEstateForm.controls.hemail.value,
      OwnerPhone: this.realEstateForm.controls.hphone.value,
      PropertyAddressLine1: this.realEstateForm.controls.paddress1.value,
      PropertyAddressLine2: this.realEstateForm.controls.paddress2.value,
      City: this.realEstateForm.controls.pcity.value,
      State: this.realEstateForm.controls.pstate.value,
      Zip: this.realEstateForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester,
      InvocieNumber: '', //this.paymentDetailModel.invoiceNumber,
      InvoiceDate: '', //new Date().toLocaleDateString(),
      InvoiceDescription: '' //this.paymentDetailModel.invoiceDescription
    };
    return model;
  }
  addrealEstateRequest() {
    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.realEstateForm.valid && this.myRecaptcha) {
      this.showRadioError = true;
      this.isButtonDisable = true;
      // this.setPaymentModel(RealStateDocumentTypeEnums.resaleCertificate, this.isRushOrder, this.amount);
      // this.isPaymentMethodsValid = true;
      let model = this.realEastateMOdel();
      this.service.resaleCertificate(model, this.fileData).subscribe(
        (response: any) => {
          if (response.Success) {
            this.resetRealEstateForm();
            //this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }
        }
      );
    }
  }
  resetRealEstateForm() {
    this.realEstateForm.reset();
    this.realEstateDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
    this.amount = "-"
    this.showRadioError = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }
  otherModel() {
    let model: ResaleCertificatesOther = {
      RequesterFirstName: this.otherForm.controls.rfname.value,
      RequesterLastName: this.otherForm.controls.rlname.value,
      RequesterEmail: this.otherForm.controls.remail.value,
      RequesterPhone: this.otherForm.controls.rphone.value,
      AssociationName: this.otherForm.controls.associationName.value,
      EstimatedClosingDate: this.otherForm.controls.closingDate.value,
      OwnerFirstName: this.otherForm.controls.hfname.value,
      OwnerLastName: this.otherForm.controls.hlname.value,
      OwnerEmail: this.otherForm.controls.hemail.value,
      OwnerPhone: this.otherForm.controls.hphone.value,
      PropertyAddressLine1: this.otherForm.controls.paddress1.value,
      PropertyAddressLine2: this.otherForm.controls.paddress2.value,
      City: this.otherForm.controls.pcity.value,
      State: this.otherForm.controls.pstate.value,
      Zip: this.otherForm.controls.pzip.value,
      OrderType: this.isRushOrder,
      AmountCharged: this.amount,
      RequestedBy: this.requester,
      InvocieNumber: '', //this.paymentDetailModel.invoiceNumber,
      InvoiceDate: '', //new Date().toLocaleDateString(),
      InvoiceDescription: '' //this.paymentDetailModel.invoiceDescription
    };
    return model;
  }
  addOtherRequest() {

    if (this.favoriteSeason === '' || this.favoriteSeason === null || this.favoriteSeason === undefined) {
      this.showRadioError = true;

    }
    if(!this.myRecaptcha) {
      this.capthcaMessage = this.captchaErrorMsg;
    }
    if (this.otherForm.valid && this.myRecaptcha) {
      this.showRadioError = true;
      this.isButtonDisable = true;
      //  this.setPaymentModel(RealStateDocumentTypeEnums.resaleCertificate, this.isRushOrder, this.amount);
      // this.isPaymentMethodsValid = true;
      let model = this.otherModel();
      this.service.resaleCertificate(model, this.fileData).subscribe(
        (response: any) => {
          if (response.Success) {
            this.resetOtherForm();
            //this.notificationService.showNotification(this.successMsg);
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          }
        }
      );
    }
  }

  resetOtherForm() {
    this.otherForm.reset();
    this.otherDirective.resetForm();
    this.fileData = [];
    this.errorMsg = "";
    this.showRadioError = false;
    this.amount = "-"
    this.showRadioError = false;
    this.captcha.reset();
    this.capthcaMessage = "";
  }

  //Payment method
  paymentOutPut(value) {
    if (value == "Success") {
      this.progressbarService.show();
      console.log("this.requester", this.requester);
      let model;
      if (this.requester === this.requesterEnum.Homeowner)
        model = this.homeOwnerModel();
      else if (this.requester === this.requesterEnum.Escrow)
        model = this.escroModel();
      else if (this.requester === this.requesterEnum.Investor)
        model = this.investorModel();
      else if (this.requester === this.requesterEnum.Lender)
        model = this.lenderModel();
      else if (this.requester === this.requesterEnum.ProspectiveBuyer)
        model = this.prespectiveModel();
      else if (this.requester === this.requesterEnum.RealEstateProfessional)
        model = this.realEastateMOdel();
      else if (this.requester === this.requesterEnum.Other)
        model = this.otherModel();
      console.log("model requester", model);
      this.service.resaleCertificate(model, this.fileData).subscribe(
        (response: any) => {
          this.progressbarService.hide();
          if (response.Success) {
            //this.notificationService.showNotification(this.successMsg);       
            // if (this.requester === this.requesterEnum.Homeowner)
            //   this.resetHomeWonerForm();
            // else if (this.requester === this.requesterEnum.Escrow)
            //   this.resetEscroForm();
            // else if (this.requester === this.requesterEnum.Investor)
            //   this.resetInvestorForm();
            // else if (this.requester === this.requesterEnum.Lender)
            //   this.resetLenderForm();
            // else if (this.requester === this.requesterEnum.ProspectiveBuyer)
            //   this.resetPrespectiveForm();
            // else if (this.requester === this.requesterEnum.RealEstateProfessional)
            //   this.resetRealEstateForm();
            // else if (this.requester === this.requesterEnum.Other)
            //   this.resetOtherForm();
            this.sendNotification('', response.RequestId);
            this.paymentThankYou();
          } else {
            this.notificationService.showNotification("No saved");
          }
        }
      );
    }
  }

  paymentThankYou() {
    let message = { header: 'Thank You!', content: ' Thank You for submitting the request. We will connect with you shortly. In case if this is urgent please contact us at +1 (888)392-3515.', type: 'payment' }
    this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
      width: '700px',
      disableClose: false
    });
    this.thanksDialogRef.componentInstance.data = message;
    this.thanksDialogRef.afterClosed().subscribe(result => {
      // if (result) {
      this.router.navigate(['/corporate']);
      // }
    });
  }

  setPaymentModel(realStateDocumentType, orderType, paymentAmount) {
    var ot = orderType ? "Rush " : "Normal ";
    let generatedInvoiceNumber = this.commonService.getDateWithRandomNumber();
    this.paymentDetailModel = {
      orderType: orderType,
      paymentAmount: paymentAmount,
      realStateDocumentType: realStateDocumentType,
      invoiceNumber: "PV-RSL-" + generatedInvoiceNumber,
      invoiceDescription: realStateDocumentType + " - " + ot + this.commonService.getCurrDate()
    };
    console.log("this.paymentDetailModel", this.paymentDetailModel);
    this.service.paymentSubject.next(this.paymentDetailModel);
  }
}
