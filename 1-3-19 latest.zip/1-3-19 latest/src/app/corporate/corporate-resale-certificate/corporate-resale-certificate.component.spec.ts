import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateResaleCertificateComponent } from './corporate-resale-certificate.component';

describe('CorporateResaleCertificateComponent', () => {
  let component: CorporateResaleCertificateComponent;
  let fixture: ComponentFixture<CorporateResaleCertificateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporateResaleCertificateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateResaleCertificateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
