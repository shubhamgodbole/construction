import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CorporatePaymentComponent } from './corporate-payment.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatListModule, MatSelectModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatIconModule, MatInputModule, MatDialogModule, MatMenuModule, MatStepperModule, MatSliderModule, MatFormFieldModule, MatSlideToggleModule, MatSnackBarModule, MatTableModule, MatRadioModule, MatTooltipModule, MatDatepickerModule } from '@angular/material';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { CorporateProgressModule } from 'src/app/shared/component/corporate-progress/corporate-progress.module';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { OnlyAlphabetsModule } from 'src/app/shared/directives/allow-only-alphabets/only-alphabets.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonModule,
    MatListModule,
    MatSelectModule,
    MatBottomSheetModule,
    NoDataFoundModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatDatetimepickerModule,
    MatIconModule,
    CorporateProgressModule,
    MatInputModule,
    MatDialogModule,
    MatMenuModule,
    MatStepperModule,
    MatSliderModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatTableModule,
    MatRadioModule,
    MatTooltipModule,
    NumberOnlyDirectiveModule,
    OnlyAlphabetsModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    FormsModule,    
  ],
  exports:[CorporatePaymentComponent],
  declarations: [CorporatePaymentComponent]  
})
export class CorporatePaymentModule { }
