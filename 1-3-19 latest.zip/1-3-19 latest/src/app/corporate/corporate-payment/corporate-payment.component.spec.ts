import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporatePaymentComponent } from './corporate-payment.component';

describe('CorporatePaymentComponent', () => {
  let component: CorporatePaymentComponent;
  let fixture: ComponentFixture<CorporatePaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporatePaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporatePaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
