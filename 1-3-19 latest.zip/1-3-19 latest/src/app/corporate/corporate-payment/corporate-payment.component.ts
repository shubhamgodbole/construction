import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { FormGroupDirective, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ValidationService, ConfirmAccountNumberValidator } from 'src/app/shared/services/validation.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { DisplayPaymentCardType, DisplayMonth, DisplayMonthForPayment, DisplayState } from 'src/app/shared/common/constant.model';
import { CorporateBlogService } from 'src/app/services/corporate-blog.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar } from '@angular/material';
import { PaymentCardModel, PaymentDetailModel } from '../corporate.model';
import { Router } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { paymentCardTypeEnum } from 'src/app/shared/Enums/commonEnums';

@Component({
  selector: 'app-corporate-payment',
  templateUrl: './corporate-payment.component.html',
  styleUrls: ['./corporate-payment.component.scss']
})

export class CorporatePaymentComponent implements OnInit {
  apiErrorsComes = "";
  hide: boolean = false;
  notificationService: NotificationService;
  @Output() paymentSuccess: EventEmitter<any> = new EventEmitter();

  //For Static Content display
  todateDate = new Date();

  paymentDetailsModel: PaymentDetailModel;

  //Bank Payment Form
  frmCreateBankPayment: FormGroup;
  isSubmitBtnDisabledBankPayment: boolean = false;
  @ViewChild('formDirectiveBankPayment') formDirectiveBankPayment: FormGroupDirective;

  //Credit Card Payment Form
  cardType: string = "";
  paymentCardTypeEnum = paymentCardTypeEnum;
  cardTypeDdl: any;
  monthDdl: any;
  yearDdl: any;
  stateDdl: any;
  frmCreateCardPayment: FormGroup;
  isSubmitBtnDisabledCardPayment: boolean = false;
  @ViewChild('formDirectiveCardPayment') formDirectiveCardPayment: FormGroupDirective;

  // Private
  private unsubscribeAll: Subject<any>;

  constructor(private readonly formBuilder: FormBuilder,
    private router: Router,
    private corporatePaymentsApiService: CorporateBlogService,
    private readonly snb: MatSnackBar,

  ) {
    this.unsubscribeAll = new Subject();
    this.cardTypeDdl = DisplayPaymentCardType.paymentCardTypeList;
    this.monthDdl = DisplayMonthForPayment.monthMonthForPaymentList;
    this.stateDdl = DisplayState.stateList;
    this.yearDdl = this.corporatePaymentsApiService.getYearDropDownList();
    this.notificationService = new NotificationService(snb);
    this.corporatePaymentsApiService.paymentSubject.subscribe(res => {
      console.log('corporatePaymentsApiService ', res);
      this.paymentDetailsModel = res;
    })
  }

  ngOnInit() {
    this.createPaymentForm();
  }

  createPaymentForm() {
    this.frmCreateBankPayment = this.formBuilder.group({
      paymentId: [''],
      accountHolderName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
      routingNumber: ['', Validators.required],
      accountNumber: ['', Validators.required],
      confirmAccountNumber: ['', [Validators.required, ConfirmAccountNumberValidator]],
      bankName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
    });

    // Update the validity of the 'accountNumberConfirm' field
    // when the 'accountNumber' field changes
    this.frmCreateBankPayment.get('accountNumber').valueChanges
      .pipe(takeUntil(this.unsubscribeAll))
      .subscribe(() => {
        this.frmCreateBankPayment.get('confirmAccountNumber').updateValueAndValidity();
      });


    this.frmCreateCardPayment = this.formBuilder.group({
      cardType: ['', [Validators.required]],
      cardNumber: ['', [Validators.required, Validators.minLength(14), Validators.maxLength(17), ValidationService.noWhiteSpace, ValidationService.cardNumberValidator]],
      month: ['', Validators.required],
      year: ['', Validators.required],
      CVVNumber: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3), ValidationService.noWhiteSpace]],
      firstName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(19), ValidationService.noWhiteSpace]],
      lastName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(19), ValidationService.noWhiteSpace]],
      addressLine1: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(39), ValidationService.noWhiteSpace]],
      addressLine2: [''],
      city: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(39), ValidationService.noWhiteSpace]],
      state: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      zipCode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10), ValidationService.noWhiteSpace]],
      country: ['',],//[Validators.required, Validators.minLength(2), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      emailAddress: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(39), ValidationService.emailValidator]],
    });

  }

  onSubmitBankPayment() {
    if (this.frmCreateBankPayment.valid) {
      this.isSubmitBtnDisabledBankPayment = true;
      let model = this.createBankFormModel();
      console.log("Bank", model);
      let resDataCreateBank;
      this.corporatePaymentsApiService.createBankPayment(model).subscribe(res => {
        this.isSubmitBtnDisabledBankPayment = false;
        resDataCreateBank = res;
        if (resDataCreateBank.Success === true) {
          this.notificationService.showNotification("Payment saved successfully.");
          this.resetBankForm();
        }
        else if (resDataCreateBank.Success === false) {
          this.notificationService.showNotification("Not Saved");
        }
      });
    }
  }

  createBankFormModel() {

  }

  resetBankForm() {
    this.frmCreateBankPayment.reset();
    this.formDirectiveBankPayment.resetForm();
    this.isSubmitBtnDisabledBankPayment = false;
  }

  onSubmitCardPayment() {
    if (this.frmCreateCardPayment.valid) {
      let model = this.createCardFormModel();
      console.log("Card", model);
      let resDataCreateCard;
      this.isSubmitBtnDisabledCardPayment = true;
      this.apiErrorsComes = "";
      this.corporatePaymentsApiService.createCardPayment(model).subscribe(res => {
        this.isSubmitBtnDisabledCardPayment = false;
        resDataCreateCard = res;
        if (resDataCreateCard.Success === true) {
          //this.notificationService.showNotification("Payment saved successfully.");
          this.paymentSuccess.emit("Success");
          this.resetCardForm();
        }
        else if (resDataCreateCard.Success === false) {
          this.apiErrorsComes = resDataCreateCard.Message;
          //this.notificationService.showNotification(resDataCreateCard.Message);
        }
      });
    }
  }

  createCardFormModel() {
    const model: PaymentCardModel = {
      CardType: this.frmCreateCardPayment.controls.cardType.value,
      CardNumber: this.frmCreateCardPayment.controls.cardNumber.value,
      Month: this.frmCreateCardPayment.controls.month.value,
      Year: this.frmCreateCardPayment.controls.year.value,
      CVVNumber: this.frmCreateCardPayment.controls.CVVNumber.value,
      FirstName: this.frmCreateCardPayment.controls.firstName.value,
      LastName: this.frmCreateCardPayment.controls.lastName.value,
      AddressLine1: this.frmCreateCardPayment.controls.addressLine1.value,
      AddressLine2: this.frmCreateCardPayment.controls.addressLine2.value,
      City: this.frmCreateCardPayment.controls.city.value,
      State: this.frmCreateCardPayment.controls.state.value,
      ZipCode: this.frmCreateCardPayment.controls.zipCode.value,
      Country: "",//this.frmCreateCardPayment.controls.country.value,
      Amount: this.paymentDetailsModel.paymentAmount,
      EmailAddress: this.frmCreateCardPayment.controls.emailAddress.value,
    }
    return model;
  }

  resetCardForm() {
    this.frmCreateCardPayment.reset();
    this.formDirectiveCardPayment.resetForm();
    this.isSubmitBtnDisabledCardPayment = false;
    this.apiErrorsComes = "";
  }

   // For Check card type
   checkCardType() {
    let cardNumber = this.frmCreateCardPayment.controls.cardNumber.value;
    if (cardNumber.match(/^4[0-9]{0,}$/)) {
      this.cardType = this.paymentCardTypeEnum.VISA;
    } else if (cardNumber.match(/^(5[1-5]|222[1-9]|22[3-9]|2[3-6]|27[01]|2720)[0-9]{0,}$/)) {
      this.cardType = this.paymentCardTypeEnum.MSTR;
    } else if (cardNumber.match(/^(6011|65|64[4-9]|62212[6-9]|6221[3-9]|622[2-8]|6229[01]|62292[0-5])[0-9]{0,}$/)) {
      this.cardType = this.paymentCardTypeEnum.DISC;
    } else if (cardNumber.match(/^3[47][0-9]{0,}$/)) {
      this.cardType = this.paymentCardTypeEnum.AMEX;
    } else {
      this.cardType = "";
    }
    if (this.cardType !== "") {
      let selectedCardType = this.cardTypeDdl.find(x => x.text === this.cardType);
      this.frmCreateCardPayment.controls.cardType.setValue(selectedCardType.value);
    } else {
      this.frmCreateCardPayment.controls.cardType.setValue('');
    }
  }


  onCancel() {
    this.router.navigate([AppRouteUrl.corporateHomeRouteUrl]);
  }

}


