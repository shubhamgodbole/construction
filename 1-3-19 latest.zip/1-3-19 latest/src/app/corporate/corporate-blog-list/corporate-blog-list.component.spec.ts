import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateBlogListComponent } from './corporate-blog-list.component';

describe('CorporateBlogListComponent', () => {
  let component: CorporateBlogListComponent;
  let fixture: ComponentFixture<CorporateBlogListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporateBlogListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateBlogListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
