import { Component, OnInit, ViewChild } from '@angular/core';
import { CorporateBlogService, } from 'src/app/services/corporate-blog.service';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { FormGroupDirective, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { ContactUs, Subscriber } from '../corporate.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { EmailNotificationModel } from 'src/app/shared/models/user-data-model';
import { SourceType, TriggerType, FeatureName, SubscriptionType } from 'src/app/shared/Enums/commonEnums';
import { AudienceType } from 'src/app/components/board-tasks/board-task.model';
import { ThankYouComponent } from 'src/app/shared/component/thank-you/thank-you.component';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ValidationService } from 'src/app/shared/services/validation.service';

@Component({
  selector: 'app-corporate-blog-list',
  templateUrl: './corporate-blog-list.component.html',
  styleUrls: ['./corporate-blog-list.component.scss']
})
export class CorporateBlogListComponent implements OnInit {
  isSubscribeDisabled: boolean = false;
  thanksDialogRef: MatDialogRef<ThankYouComponent>;
  blogList: any = [];
  blogCatagories: any;
  blaogTags: any;
  querySubcription: Subscription;
  requestId: string;
  requestCatagory: string;
  @ViewChild('formDirective') formDirective: FormGroupDirective;
  // subscription
  subscriptionForm: FormGroup;
  notificationService: NotificationService;
  errorMsg: string;
  isComponentLoad: boolean = false;

  isApiResponceCome = false;
  constructor(private service: CorporateBlogService,
    private router: Router,
    private _matDialog: MatDialog,
    private emailNotification: EmailNotificationService,
    private route: ActivatedRoute, private formBuilder: FormBuilder, private readonly snb: MatSnackBar, ) {
    this.notificationService = new NotificationService(snb);
  }

  ngOnInit() {
    window.scroll(0, 0);
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let Keywords = params["Keywords"];
      let catagory = params["blogCatagory"];
      if (catagory || Keywords) {
        this.requestCatagory = catagory;
        this.getBlogBtCategory(catagory, Keywords);
      }
      else {
        this.getBlogList();
      }
    });
    this.subscriptionForm = this.formBuilder.group({
      email: ['', [Validators.required, ValidationService.emailValidator]],
    });
  }

  createNotificationModel(featureId, requestId, featureName) {

    var notificationModel = new Array<EmailNotificationModel>();
    notificationModel = [{
      FeatureId: featureId,
      FeatureName: featureName,
      CreatedBy: "",
      SourceType: SourceType.Web,
      TriggerType: TriggerType.Create,
      PMCompanyAssociationMappingId: "",
      AudienceType: AudienceType.HomeOwner,
      Url: "",
      RequestId: requestId,
      CustomAttribute: {
        Request: featureName,
        RequestSubType: TriggerType.Create

      }
    }];
    return notificationModel;
  }

  sendNotification(featureId, requestId, featureName) {
    //let emailNotificationModel = this.createNotificationModel("",response.RequestId);
    let emailNotificationModel = this.createNotificationModel(featureId, requestId, featureName);
    this.emailNotification.sendNotification(emailNotificationModel).subscribe(
      (emailresponse: any) => {
        if (emailresponse.Success) {
          //this.notificationService.showNotification('Notification Send SuccessFully');
        }
      }
    );
  }
  // get list of blogs
  getBlogList() {
    this.service.getBlogList().subscribe(
      (response: any) => {
        this.isApiResponceCome = true;
        if (response.Success) {
          this.blogList = response.Blog.Articles;
          this.blogCatagories = response.Blog.Categories;
          this.blaogTags = response.Blog.Keywords;
          this.isComponentLoad = true;
        } 
      }
    );
  }
  // redirect on detail
  goToDetail(id, catagory) {
    this.router.navigate([AppRouteUrl.corporateBlogDetailRouteUrl], { queryParams: { id: id, blogCatagory: catagory } });
  }
  // get blogs by category or tags
  getBlogBtCategory(catagory, Keywords) {
    this.service.getBlogByCategory(catagory, Keywords).subscribe(
      (response: any) => {
        if (response.Success) {
          this.isComponentLoad = true;
          this.blogList = response.Blog.Articles;
          this.blogCatagories = response.Blog.Categories;
          this.blaogTags = response.Blog.Keywords;
        }
      }
    );

  }

  subscriptionModel() {
    let model: Subscriber = {
      FirstName: '',
      LastName: '',
      Email: this.subscriptionForm.controls.email.value,
      SubscriptionType: SubscriptionType.Blogs
    };
    return model;
  }
  emailChange() {

    if (this.subscriptionForm.controls.email.invalid && this.subscriptionForm.controls.email.value !== '') {
      this.errorMsg = "Invalid email ";
    }
    else {
      this.errorMsg = "";
    }
  }
  addSubscription() {
    let model = this.subscriptionModel();
    if (this.subscriptionForm.controls.email.value === '' || this.subscriptionForm.controls.email.invalid && this.subscriptionForm.controls.email.value === null) {
      this.errorMsg = "Email is required ";
    }
    if (this.subscriptionForm.valid) {
      this.isSubscribeDisabled = true;
      this.service.subscriber(model).subscribe(
        (response: any) => {
          this.isSubscribeDisabled = false;
          if (response.Success) {
            this.resetSubscriptionForm();
            //this.notificationService.showNotification('Subscriptions is  successfully');
            this.sendNotification('', response.RequestId, FeatureName.BlogSubscription);
            this.paymentThankYou();
          }
        });
    }
  }
  resetSubscriptionForm() {
    this.subscriptionForm.reset();
    this.formDirective.resetForm();
    this.errorMsg = "";
  }

  paymentThankYou() {
    let message = { header: 'Thank You!', content: ' for Subscribing. ', type: 'blog' }
    this.thanksDialogRef = this._matDialog.open(ThankYouComponent, {
      width: '700px',
      disableClose: false
    });
    this.thanksDialogRef.componentInstance.data = message;
    this.thanksDialogRef.afterClosed().subscribe(result => {
      if (result) {
          this.router.navigate(['/corporate']);
      }
    });
  }

}
