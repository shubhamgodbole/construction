import { Headers, RequestOptions } from '@angular/http';
import { UserData, UserAssociations, UserUnits, FeatureMenuPermissions } from './shared/models/user-data-model';
import { Subject, BehaviorSubject } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})

export class AppConfig {

    userData;
    private subject = new Subject<any>();
    private loggedIn = new BehaviorSubject<boolean>(false); // {1}
    private langingPage = new BehaviorSubject<boolean>(false);
    associationListSbject = new BehaviorSubject<any>([]);
    userDataSbject = new BehaviorSubject<any>([]);

    constructor(private cookieService: CookieService) {

    }

    get isLoggedIn() {
        return this.loggedIn.asObservable(); // {2}
    }

    get isLanding() {
        return this.langingPage.asObservable();
    }

    public getCurrentUser(): UserData {
        let currentUserObj = JSON.parse(String(localStorage.getItem('userData')));
        //let currentUserObj = this.userData;
        if (currentUserObj) {
            var currUser = new UserData();
            var userAssociations = new Array<UserAssociations>();
            var userUnits = new Array<UserUnits>();
            var featureMenuPermissions = new Array<FeatureMenuPermissions>();
            currUser.Role = currentUserObj.Role;
            currUser.AccountNumber = currentUserObj.AccountNumber;
            currUser.UserName = currentUserObj.UserName === null ? currentUserObj.FirstName + ' ' + currentUserObj.LastName : currentUserObj.UserName;
            currUser.UserProfileId = currentUserObj.UserProfileId;
            currUser.UserProfilePath = currentUserObj.UserProfilePath;
            currUser.UserProfileBlobPath = currentUserObj.UserProfileBlobPath;
            currUser.LastLogin = currentUserObj.LastLogin;
            currUser.Token = currentUserObj.Token;
            if (currentUserObj.UserAssociations != null) {
                currentUserObj.UserAssociations.forEach(element => {
                    let userAssociation: UserAssociations = {
                        AssociationId: element.AssociationId,
                        Name: element.Name,
                        Domain: element.Domain,
                        PMCompanyId: element.PMCompanyId,
                        PMCompanyAssociationMappingId: element.PMCompanyAssociationMappingId,
                        CompanyCode: element.CompanyCode
                    }
                    userAssociations.push(userAssociation);
                });
                // this.associationListSbject.next(userAssociations);
            }
            if (currentUserObj.UserUnits != null) {
                currentUserObj.UserUnits.forEach(element => {
                    let userUnit: UserUnits = {
                        UnitId: element.UnitId,
                        UnitNumber: element.UnitNumber
                    }
                    userUnits.push(userUnit);
                });
            }

            if (currentUserObj.FeatureMenuPermissions != null) {
                currentUserObj.FeatureMenuPermissions.forEach(element => {
                    let featureMenuPermission: FeatureMenuPermissions = {
                        UnitId: element.UnitId,
                        MenuOrder: element.MenuOrder,
                        IsMenuItem: element.IsMenuItem,
                        FeatureParentId: element.FeatureParentId,
                        Name: element.Name,
                        PMCompanyId: element.PMCompanyId,
                        AssociationId: element.AssociationId,
                        FeatureMenuImage: element.FeatureMenuImage,
                        FeatureId: element.FeatureId,
                        CanUpdate: element.CanUpdate,
                        CanDelete: element.CanDelete,
                        CanRead: element.CanRead,
                        CanCreate: element.CanCreate,
                        WebPage: element.WebPage,
                        CustomName: element.CustomName
                    }
                    featureMenuPermissions.push(featureMenuPermission);
                });
            }
            currUser.FeatureMenuPermissions = featureMenuPermissions;
            currUser.UserUnits = userUnits;
            currUser.UserAssociations = userAssociations;
            //this.userDataSbject.next(currUser);
            return currUser;
        }
        else {
            return null;
        }
    }

    public setCurrentUser(model: any) {
        localStorage.removeItem('email');
        localStorage.removeItem('userData');
        localStorage.setItem('userData', JSON.stringify(model));
        this.subject.next({ data: model });
        this.loggedIn.next(true);
        this.userData = model;
    }

    public setLanding(value) {
        this.langingPage.next(value);
    }

    public isAuthenticated(): boolean {
        const currentToken = localStorage.getItem('token') !== null && localStorage.getItem('token') !== undefined ? localStorage.getItem('token') : '';
        const currentUserdata = this.getCurrentUser();
        if (currentUserdata !== null && currentUserdata !== undefined) {
            console.log("currentUserdata", currentUserdata);
            console.log(window.location.hostname.startsWith(currentUserdata.UserAssociations[0].Domain));
            console.log("PM", window.location.hostname.startsWith(environment.pmDomain));
            if (currentToken !== '' && window.location.hostname.startsWith(environment.pmDomain) === true) {
                this.loggedIn.next(true);
                return true;
            } else if (currentToken !== '' && window.location.hostname.startsWith(currentUserdata.UserAssociations[0].Domain) === true) {
                this.loggedIn.next(true);
                return true;
            }
            else {
                this.loggedIn.next(false);
                return false;
            }
        } else {
            this.loggedIn.next(false);
            return false;
        }
    }


    public isAuthenticatedLocal(): boolean {
        const currentUser = localStorage.getItem('token');
        if (currentUser !== null && currentUser !== undefined && currentUser !== '') {
            this.loggedIn.next(true);
            return true;
        }
        else {
            this.loggedIn.next(false);
            return false;
        }
    }



    getData() {
        return this.subject.asObservable()
    }

    public removeCurrentUser() {
        localStorage.clear();
        document.cookie = "userId=;expires= Thu, 21 Aug 2014 20:00:00 UTC" + ";domain=" + environment.domain + ";path=/";
        document.cookie = "token=;expires= Thu, 21 Aug 2014 20:00:00 UTC" + ";domain=" + environment.domain + ";path=/";
        this.subject.next();
        this.loggedIn.next(false);
    }

};
