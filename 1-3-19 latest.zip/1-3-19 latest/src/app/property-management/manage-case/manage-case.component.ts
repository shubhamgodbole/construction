import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-case',
  templateUrl: './manage-case.component.html',
  styleUrls: ['./manage-case.component.scss']
})
export class ManageCaseComponent implements OnInit {

  status = "All";
  filter = false;
  constructor() { }

  ngOnInit() {
  }

  addClass()
  {
    if(this.filter)
      this.filter = false;
    else 
      this.filter = true;
  }

  statusChange(s) {
    this.status = s;
  }

}
