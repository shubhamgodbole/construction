import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-requests',
  templateUrl: './manage-requests.component.html',
  styleUrls: ['./manage-requests.component.scss']
})
export class ManageRequestsComponent implements OnInit {
  status = "All";
  filter = false;
  constructor() { }

  ngOnInit() {
  }

  addClass()
  {
    if(this.filter)
      this.filter = false;
    else 
      this.filter = true;
  }

  statusChange(s) {
    this.status = s;
  }


}
