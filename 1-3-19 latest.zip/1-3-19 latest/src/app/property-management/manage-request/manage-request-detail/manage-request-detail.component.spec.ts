import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageRequestDetailComponent } from './manage-request-detail.component';

describe('ManageRequestDetailComponent', () => {
  let component: ManageRequestDetailComponent;
  let fixture: ComponentFixture<ManageRequestDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageRequestDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageRequestDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
