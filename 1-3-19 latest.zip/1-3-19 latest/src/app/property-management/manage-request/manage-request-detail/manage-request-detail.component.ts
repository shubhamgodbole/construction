import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-request-detail',
  templateUrl: './manage-request-detail.component.html',
  styleUrls: ['./manage-request-detail.component.scss']
})
export class ManageRequestDetailComponent implements OnInit {

  BoardTask = false;
  ServiceRequest = false;
  Violation = false;

  constructor() { }

  ngOnInit() {
  }

  BoardTaskToggle() {
    if (this.BoardTask)
      this.BoardTask = false;
    else
      this.BoardTask = true;
  }

  ServiceRequestToggle() {
    if (this.ServiceRequest)
      this.ServiceRequest = false;
    else
      this.ServiceRequest = true;
  }

  ViolationToggle() {
    if (this.Violation)
      this.Violation = false;
    else
      this.Violation = true;
  }

}
