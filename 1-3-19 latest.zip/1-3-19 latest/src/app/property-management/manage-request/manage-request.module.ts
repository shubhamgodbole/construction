import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ManageRequestsComponent } from './manage-requests/manage-requests.component';
import { ManageRequestDetailComponent } from './manage-request-detail/manage-request-detail.component';
import { MatInputModule, MatListModule, MatSelectModule, MatCheckboxModule, MatRadioModule, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule } from '@angular/material';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: '',
    component: ManageRequestsComponent
  },
  {
    path: 'manage-request-detail',
    component: ManageRequestDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatCheckboxModule,
    NumberOnlyDirectiveModule,
    MatRadioModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ManageRequestsComponent, ManageRequestDetailComponent]
})
export class ManageRequestModule { }
