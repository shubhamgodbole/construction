import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csr-meeting',
  templateUrl: './csr-meeting.component.html',
  styleUrls: ['./csr-meeting.component.scss']
})
export class CsrMeetingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
