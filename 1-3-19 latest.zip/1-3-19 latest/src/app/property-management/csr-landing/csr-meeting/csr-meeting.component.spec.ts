import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CsrMeetingComponent } from './csr-meeting.component';

describe('CsrMeetingComponent', () => {
  let component: CsrMeetingComponent;
  let fixture: ComponentFixture<CsrMeetingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CsrMeetingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CsrMeetingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
