import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csr-task-todo',
  templateUrl: './csr-task-todo.component.html',
  styleUrls: ['./csr-task-todo.component.scss']
})
export class CsrTaskTodoComponent implements OnInit {

  sidebar = false;
  
  constructor() { }

  ngOnInit() {
  }

  sidebarToggle() {
    if (this.sidebar)
      this.sidebar = false;
    else
      this.sidebar = true;
  }

}
