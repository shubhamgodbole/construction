import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CsrTaskTodoComponent } from './csr-task-todo.component';

describe('CsrTaskTodoComponent', () => {
  let component: CsrTaskTodoComponent;
  let fixture: ComponentFixture<CsrTaskTodoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CsrTaskTodoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CsrTaskTodoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
