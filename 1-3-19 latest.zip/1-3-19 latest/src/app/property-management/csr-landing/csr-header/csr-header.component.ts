import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';

@Component({
  selector: 'app-csr-header',
  templateUrl: './csr-header.component.html',
  styleUrls: ['./csr-header.component.scss']
})
export class CsrHeaderComponent implements OnInit {
  //Route Url
  emailsUrl: string = AppRouteUrl.mainEmailsRouteUrl;
  recentUpdatesUrl: string = AppRouteUrl.mainRecentUpdatesRouteUrl;

  filter = false;

  constructor(private _router: Router) { }

  ngOnInit() {
  }

  addClass() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  goToEmail() {
    this._router.navigate([AppRouteUrl.mainEmailsRouteUrl]);
  }

}
