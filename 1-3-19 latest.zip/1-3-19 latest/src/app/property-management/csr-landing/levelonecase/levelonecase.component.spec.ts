import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LevelonecaseComponent } from './levelonecase.component';

describe('LevelonecaseComponent', () => {
  let component: LevelonecaseComponent;
  let fixture: ComponentFixture<LevelonecaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LevelonecaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LevelonecaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
