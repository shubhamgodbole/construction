import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-levelonecase',
  templateUrl: './levelonecase.component.html',
  styleUrls: ['./levelonecase.component.scss']
})
export class LevelonecaseComponent implements OnInit {

  BoardTask = false;
  ServiceRequest = false;
  Violation = false;
  CaseNote = false;

  constructor() { }

  ngOnInit() {
  }

  AttachCaseNote(){
    if (this.CaseNote)
      this.CaseNote = false;
    else
      this.CaseNote = true;
  }
  BoardTaskToggle() {
    if (this.BoardTask)
      this.BoardTask = false;
    else
      this.BoardTask = true;
  }

  ServiceRequestToggle() {
    if (this.ServiceRequest)
      this.ServiceRequest = false;
    else
      this.ServiceRequest = true;
  }

  ViolationToggle() {
    if (this.Violation)
      this.Violation = false;
    else
      this.Violation = true;
  }

}
