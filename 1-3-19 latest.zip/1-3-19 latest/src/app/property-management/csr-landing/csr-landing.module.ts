import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CsrLandingComponent } from './csr-landing.component';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { RecentUpdateComponent } from './recent-update/recent-update.component';
import { CsrHeaderModule } from './csr-header/csr-header.module';
import { MatSelectModule, MatToolbarModule, MatTooltipModule, MatButtonModule, MatDatepickerModule } from '@angular/material';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { DisplayTimeElapsedModule } from 'src/app/shared/modules/display-time-elapsed.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { TransformBlankValueModule } from 'src/app/shared/pipes/blankValue/transform-blank-value.module';
import { EmailsComponent } from './emails/emails.component';
import { ServicesEmailModule } from '../services-email/services-email.module';
const routes: Routes = [
  {
    path: '',
    component: CsrLandingComponent,
    children: [
      { path: '', redirectTo: AppRouteUrl.recentUpdatesRouteUrl },
      { path: AppRouteUrl.recentUpdatesRouteUrl, component: RecentUpdateComponent },
      { path: AppRouteUrl.emailsRouteUrl, component: EmailsComponent },
    ]
  }
];
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MatSelectModule,
    CsrHeaderModule,
    RouterModule.forChild(routes),
    BsDatepickerModule,
    MatToolbarModule,
    MatDatepickerModule,
    MatTooltipModule,
    MatButtonModule,
    DisplayTimeElapsedModule,
    NoDataFoundModule,
    TransformBlankValueModule,
    ServicesEmailModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [CsrLandingComponent, RecentUpdateComponent, EmailsComponent]
})
export class CsrLandingModule { }
