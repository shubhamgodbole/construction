import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csr-landing',
  templateUrl: './csr-landing.component.html',
  styleUrls: ['./csr-landing.component.scss']
})
export class CsrLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


}
