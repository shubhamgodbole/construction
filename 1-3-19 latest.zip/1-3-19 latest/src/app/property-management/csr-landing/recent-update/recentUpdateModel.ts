/**For Manage Columns for PM*/
export class DisplayColumnsPM {
    public static ColumnsList = [
        { value: "Title", text: "Title" },
        { value: "Association", text: "Association" },
        { value: "Channel", text: "Channel" },
        { value: "Request Type", text: "Request Type" },
        { value: "Created On", text: "Created On" },
    ]

    public static AllColumnsList = [
        "Title", "Association", "Channel", "Request Type", "Created On", "Updated On", "Last Updated By", "Time Elapsed", "Assign To", "Status", "Priority"
    ]

    public static SelectedColumnsList = [
        { value: "Updated On", text: "Updated On" },
        { value: "Last Updated By", text: "Last Updated By" },
        { value: "Time Elapsed", text: "Time Elapsed" },
        { value: "Assign To", text: "Assign To" },
        { value: "Status", text: "Status" },
        { value: "Priority", text: "Priority" },
    ]
}

export class FilterRecentUpdate {
    public static StatusList = [
        {value: '', text: "All"},
        { value: "InProgress", text: "In Progress" },
        { value: "AwaitingBoardDecision", text: "Awaiting Board Decision" },
      //  { value: "Canceled", text: "Canceled" },
       // { value: "Completed", text: "Completed" },
        // { value: "Contested", text: "Contested" },
        // { value: "Letter Sent", text: "Letter Sent" },
        // { value: "Submitted", text: "Submitted" },
    ]

    public static RequestTypeList = [
        {value: '', text: "All"},
        { value: "ServiceRequest", text: "Service Requests" },
        { value: "BoardTask", text: "Board Tasks" },
        // { value: "Violations", text: "Violations" },
        // { value: "ARC Requests", text: "ARC Requests" },
    ]
    
    public static UpdateByUser = [
        { value: "Board Member", text: "Board Member" },
        { value: "Home Owner", text: "Home Owner" },
        { value: "CSR", text: "CSR" },
    ]


}