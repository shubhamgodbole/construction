import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecentUpdateComponent } from './recent-update.component';

describe('RecentUpdateComponent', () => {
  let component: RecentUpdateComponent;
  let fixture: ComponentFixture<RecentUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecentUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecentUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
