import { Component, OnInit } from '@angular/core';
import { DisplayColumnsPM, FilterRecentUpdate } from './recentUpdateModel';
import { RecentUpdatesService } from 'src/app/services/recent-updates.service';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { ServiceRequestStatus } from 'src/app/components/service-request/service-request.model';
import { NoDataFoundCaseFeatureName, SubCaseTypeEnum } from 'src/app/shared/Enums/commonEnums';
import { NavigationExtras, Router } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-recent-update',
  templateUrl: './recent-update.component.html',
  styleUrls: ['./recent-update.component.scss']
})
export class RecentUpdateComponent implements OnInit {
  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  /**End For Manage Columns*/
  //status List
  statusList: any = [];
  selectedStatus: string = "";

  //Request Type List
  requestTypeList: any = [];
  selectedRequestType: string = "";

  globalAssociationModel: GlobalAssociationModel;

  //for date filter
  dateTo: any;
  dateFrom: any;
  bsRangeValue: Date[] = [];

  updateByUser: any = []
  selectedUpdatedBy: string;

  recentUpdateList = [];

  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  isList: boolean = false;

  constructor(private service: RecentUpdatesService, private progressbarService: ProgeressBarService,
    private globalAssociationService: GlobalAssociationService, private commonService: CommonService,
    private _router: Router) {
    /**For Manage Columns*/
    this.seletedColumns = DisplayColumnsPM.AllColumnsList;
    this.displayColumnsDdl = DisplayColumnsPM.SelectedColumnsList;
    //this.displayColumnsDdl = DisplayColumnsPM.AllSelectedColumnsList;
    this.statusList = FilterRecentUpdate.StatusList;
    this.requestTypeList = FilterRecentUpdate.RequestTypeList;
    this.updateByUser = FilterRecentUpdate.UpdateByUser;
  }

  ngOnInit() {
    this.globalAssociationService.associationSubject.subscribe(res => {
      this.globalAssociationModel = res;
      if (res !== 1) {
        this.getAllCases();
      }
    });
  }

  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/

  getAllCases() {
    let resData;
    let resStatus = this.selectedStatus === ServiceRequestStatus.All ? "" : this.selectedStatus;
    let caseType = this.selectedRequestType === ServiceRequestStatus.All ? "" : this.selectedRequestType;
    this.isList = false;
    this.progressbarService.show();
    this.service.getCases(this.globalAssociationModel.AssociationId, resStatus, caseType, this.dateTo, this.dateFrom).
      subscribe(res => {
        this.progressbarService.hide();
        this.isList = true;
        resData = res;
        console.log('resdata', res);
        if (resData.Success) {
          this.recentUpdateList = resData.RecentUpdateList;
        } else {
          this.recentUpdateList = [];
        }
      });
  }

  //for filter by date
  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.dateTo = new Date(event[1]).toUTCString();
        this.getAllCases();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getAllCases();
    }
  }

  clearFilter() {
    if ((this.bsRangeValue === null || this.bsRangeValue === [] || this.bsRangeValue.length === 0) && this.selectedRequestType === '' && this.selectedStatus === "") {
      return
    }
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    this.selectedRequestType = "";
    this.selectedStatus = "";
    this.getAllCases();
  }


  goToDetail(caseData) {
    if (caseData.DetailId !== "" && caseData.DetailId !== null && caseData.DetailId !== undefined) {
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": caseData.DetailId,
        }
      };
      // console.log("requestType", requestType);
      this.commonService.setDataInLocalStorge(AppRouteUrl.mainRecentUpdatesRouteUrl);
      if (SubCaseTypeEnum.ServiceRequest === caseData.SubCaseType) {
        this._router.navigate([AppRouteUrl.mainServiceRequestDetailPMRouteUrl], navigationExtras);
      } else if (SubCaseTypeEnum.BoardTask === caseData.SubCaseType) {
        this._router.navigate([AppRouteUrl.mainBoardTasksDeatilPMRouteUrl], navigationExtras);
      } else if (SubCaseTypeEnum.ARCRequest === caseData.SubCaseType) {
        this._router.navigate([AppRouteUrl.mainArcPMRouteUrl], navigationExtras);
      } else if (SubCaseTypeEnum.Violation === caseData.SubCaseType) {
        this._router.navigate([AppRouteUrl.mainViolationsPMRouteUrl], navigationExtras);
      }
    }
  }
}
