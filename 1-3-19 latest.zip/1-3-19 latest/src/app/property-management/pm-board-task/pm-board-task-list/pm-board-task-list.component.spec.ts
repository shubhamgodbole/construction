import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmBoardTaskListComponent } from './pm-board-task-list.component';

describe('PmBoardTaskListComponent', () => {
  let component: PmBoardTaskListComponent;
  let fixture: ComponentFixture<PmBoardTaskListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmBoardTaskListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmBoardTaskListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
