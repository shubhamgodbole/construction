import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { UserData } from 'src/app/shared/models/user-data-model';
import { FormGroup, FormGroupDirective, FormBuilder, Validators, AbstractControl, FormControl } from '@angular/forms';
import { CaseNoteModel, CaseFeatureType, BoardTaskStatus, NoteType, AudienceType, UpdateBoardTaskStatus, CaseSubCategory, DisplayPriority, BoardTaskModel } from '../../../components/board-tasks/board-task.model';
import { TypeOfDocument, RoleEnum, CaseOriginatingType, IsAuthorized, StatusReason, ImageNameEnums, DownloadfeatureName, DocumentFeatureName, CustomerTypeEnum, CaseTypeEnum, SubCaseTypeEnum, FeatureName, SourceType, TriggerType, VoteStatus, PlaceHolderText, CallType, ActivityType, FeaturePermissions, EmailAudience } from '../../../shared/Enums/commonEnums';
import { Router, ActivatedRoute } from '@angular/router';
import { BoardTaskApiService } from 'src/app/services/board-task-api.service';
import { AppConfig } from 'src/app/app.config';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { MatSnackBar, MatDialogRef, MatDialog, MatAutocompleteTrigger } from '@angular/material';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take, flatMap } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { CommonService } from 'src/app/services/common.service';
import { Guid } from 'guid-typescript';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { Location } from '@angular/common';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { DisplayCaseOriginatingType, CommonConstant, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { AssignedPartyType } from 'src/app/components/arc/arc-model';
import { CallModel, EmailModel, AssignToModel } from 'src/app/components/service-request/service-request.model';
import { roLocale } from 'ngx-bootstrap';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import * as _ from 'lodash';


@Component({
  selector: 'app-pm-boardtask-detail',
  templateUrl: './pm-boardtask-detail.component.html',
  styleUrls: ['./pm-boardtask-detail.component.scss']
})
export class PmBoardtaskDetailComponent implements OnInit {
  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentDetails: boolean = false;

  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;

  //for assign to 
  assignToDdl: any;

  notificationService: NotificationService;
  //ImageNameEnums
  imageNameEnums = ImageNameEnums;
  //Confirm Dialog
  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;

  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;
  isEditCaseNoteButtonDisabled: boolean = false;

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;

  sidebar = false;
  userData: UserData;
  roleEnum = RoleEnum;
  currRole: string = "";
  isAuthorized = IsAuthorized;
  caseOriginatingType = CaseOriginatingType;
  typeOfDocument = TypeOfDocument.CaseDocuments;
  associationName: string;
  associationId: string;
  createdByUserName: string;
  createdByUserId: string;
  boardTaskStatus: string = "";
  isApiResponseCome: boolean = false;
  boardTaskStatusEnum = BoardTaskStatus;
  isCommentAndReopen: boolean = true;
  //Enum
  noteType = NoteType;
  //For Query string;
  querySubcription: Subscription;
  domain: string;
  /*Case Note Form*/
  frmCreateCaseNote: FormGroup;
  fileData = [];
  isSubmitBtnDisabled: boolean = false;
  resDataCreate: any;
  fileDataICCase = [];
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  /*BoardMember Case Note Form*/
  frmBoardMemberCreateCaseNote: FormGroup;
  //fileData = [];
  isBoardMemberSubmitBtnDisabled: boolean = false;
  resDataCreateBoardMember: any;
  fileDataBMCase = [];
  @ViewChild('formDirectiveBoardMember') formDirectiveBoardMember: FormGroupDirective;


  /*Board Cast Status Form*/
  frmCancel: FormGroup;
  isSubmitBtnDisabledCancel: boolean = false;
  audienceType = AudienceType;
  @ViewChild('formDirectiveCancel') formDirectiveCancel: FormGroupDirective;

  /*Motion Form*/
  motionLimit: number = 160;
  frmCreateMotion: FormGroup;
  isSubmitBtnDisabledMotion: boolean = false;
  resDataCreateMotion: any;
  @ViewChild('formDirectiveMotion') formDirectiveMotion: FormGroupDirective;

  /*Reopen Form*/
  frmCreateReopen: FormGroup;
  isSubmitBtnDisabledReopen: boolean = false;
  resDataCreateReopen: any;
  @ViewChild('formDirectiveReopen') formDirectiveReopen: FormGroupDirective;

  /*Completed Form*/
  frmCreateComplete: FormGroup;
  isSubmitBtnDisabledComplete: boolean = false;
  resDataCreateComplete: any;
  @ViewChild('formDirectiveComplete') formDirectiveComplete: FormGroupDirective;

  /*ReviewAndRating Form*/
  frmCreateReviewAndRating: FormGroup;
  isSubmitBtnDisabledReviewAndRating: boolean = false;
  resDataCreateReviewAndRating: any;
  rate = 0;
  @ViewChild('formDirectiveReviewAndRating') formDirectiveReviewAndRating: FormGroupDirective;
  countRating: number = 0;
  resData: any;
  boardTaskDetailList: any;
  documentList: any;
  caseNoteList: any;
  motionList: any;
  decisionReason = [];
  boardMemberCaseNoteList: any;
  propertyManagerCaseNoteList: any;
  motionVoteCount: number = 0;
  /**Motion vote */
  resDataCreateMotionVote: any;
  isDisplayVoteList: boolean = false;
  profilePath: string;
  shoNDocs: any = 3;
  viewDocs: boolean = false;
  viwAllDocBtnMsg: string = "View All Attachments";
  readMoreBtn: boolean = false;
  readMoreDescBtnMsg: string = "Read More";
  desLimit: number = 160;


  //display motion
  motionMsg: string;
  motionIcon: string;
  voteReceiveMsg: string;
  //Read More motion
  readMoreMotionBtn: boolean;
  readMoreMotionBtnMsg: string = "Read More";
  desMotionLimit: number = 160;

  addEsclateForm: FormGroup;
  isSubmitBtnDisabledEscalate: boolean;
  @ViewChild('esclateFormDiractive') esclateFormDiractive: FormGroupDirective;

  escalteCaseNoteList: any;
  escalteVoteCount: number = 0;
  esclateVoterList: any[];

  addTaskForm: FormGroup;
  @ViewChild('addTaskFormDiractive') addTaskFormDiractive: FormGroupDirective;

  /**Edit Board Task */
  editSidebar: boolean = false;
  customerType = CustomerTypeEnum.Association;
  caseType = CaseTypeEnum.BoardMembers;
  subCaseType = SubCaseTypeEnum.BoardTask;
  //For Association
  associationData: any[] = [];
  associationDdlAutocompleteList: any[] = [];
  @ViewChild('boardtaskAssociationAutoComplete', { read: MatAutocompleteTrigger })
  boardtaskAssociationtrigger: MatAutocompleteTrigger;

  caseSubCategoryDdlList = new Array<CaseSubCategory>();
  caseCategoryDdl: any;
  firstName: string;
  lastName: string
  priorityDdl: any;
  frmEditBoardTask: FormGroup;
  caseSubCategoryDdl: any;
  caseOriginatingTypeDdl: any;
  isSubmitBtnEditDisabled: boolean = false;
  editFileData = [];
  isPhoneNumberVisiable: boolean = false;
  phoneValidation: boolean = false;
  @ViewChild('formEditBoardTaskformDirective') formEditBoardTaskformDirective: FormGroupDirective;

  //For Send Notification
  featureName: any;
  featureId: any;
  pmCompanyAssociationMappingId: string;



  //replyTo
  VoteStatusEnum = VoteStatus;
  allCaseNoteList: any;
  selectedReplyTo: string;
  placeHolderText = PlaceHolderText;

  selectedConversionType: string = "All";
  caseNotes: any = [];

  noteTypeEnums = NoteType;
  callTypeEnum = CallType;
  activityTypeEnum = ActivityType;

  selectedActivityType: string;

  //for add call
  frmCreatePhone: FormGroup;
  phoneFileData = [];
  isSubmitBtnDisabledPhone: boolean;
  @ViewChild('formDirectivePhone') formDirectivePhone: FormGroupDirective;

  //for send email
  frmCreateEmail: FormGroup;
  emailFileData = [];
  isSubmitBtnDisabledEmail: boolean;
  @ViewChild('formDirectiveEmail') formDirectiveEmail: FormGroupDirective;

  statusReasonEnum = StatusReason;
  reasonType: string;

  //Email tag
  placeholdertext = "";
  public validators = [ValidationService.emailValidator];
  public errorMessages = {
    'invalidEmailAddress': 'Invalid Email',
  };

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  //for Email Audience
  emailAudienceEnum = EmailAudience;

  // editor Formating Option
  public editorOptions = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote'],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'script': 'sub' }, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
      [{ 'font': [] }],
      [{ 'align': [] }],
      ['clean'],                                         // remove formatting button
    ]
  };  
  constructor(private _router: Router,
    private ngZone: NgZone,
    private readonly formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private emailNotification: EmailNotificationService,
    private _location: Location,
    private progressbarService: ProgeressBarService,
    private globalAssociationService: GlobalAssociationService,
    private boardTaskApiService: BoardTaskApiService,
    public commonService: CommonService,
    private _matDialog: MatDialog,
    private readonly appConfig: AppConfig,
    private readonly snb: MatSnackBar, ) {
    this.getAssociation();
    this.getCaseCategoryDdl();
    this.caseOriginatingTypeDdl = DisplayCaseOriginatingType.CaseOriginatingTypeDdlList;
    this.priorityDdl = DisplayPriority.PriorityList;
    this.userData = this.appConfig.getCurrentUser();
    this.currRole = this.userData.Role;
    //this.associationId = this.userData.UserAssociations[0].AssociationId;
    //this.domain = this.userData.UserAssociations[0].Domain;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.createdByUserId = this.userData.UserProfileId;
    this.createdByUserName = this.userData.UserName;
    this.firstName = this.createdByUserName.split(' ')[0];
    this.lastName = this.createdByUserName.split(' ')[1];
    this.profilePath = this.userData.UserProfileBlobPath;
    //Notification
    this.pmCompanyAssociationMappingId = "";
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.Board_Task) {
          this.featureName = feature.Name
          this.featureId = feature.FeatureId
        }
      });
    this.notificationService = new NotificationService(snb);
    this.createBoardTaskForm();
    this.createCaseNoteForm();
    this.createTaskForm();
    this.createReopenForm();
    this.createAddCallForm();
    this.createAddEmailForm();
    this.createCompleteForm();
    this.createBoardTaskStatusForm();
  }

  //For onchange of association go to the list page
  currentAssociation: string = "";
  isAssociationChange : boolean = false;

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {
    //For onchange of association go to the list page
    this.globalAssociationService.associationSubject.subscribe(res => {
      console.log('from association data ', res);      
      if (res !== 1) {
        if(this.currentAssociation === '' && !this.isAssociationChange) {
          this.currentAssociation = res.AssociationId; 
          this.isAssociationChange = true;
        }
        else {
          this.isAssociationChange = false;
          this._router.navigate([AppRouteUrl.mainBoardTasksPMRouteUrl]);
        }
      }
    });

    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.boardTaskApiService.boardTaskDetailId = id;
        this.domain = this.boardTaskApiService.domain;
        this.getData();
      }
      else {
        this._router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });

    this.addEsclateForm = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]],
      isVotingRequired: [true]
    });

    this.getAssignToUser()
  }

  //for assign to user
  getAssignToUser() {
    let resData;
    this.commonService.getPMList().subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.assignToDdl = resData.PMUser;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }


  /*Display list of vote*/
  displayVoteListToggle() {
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }
  // get boardtask detail
  getData() {
    this.progressbarService.show();
    this.boardTaskApiService.getBoardTaskDetails(this.boardTaskApiService.boardTaskDetailId, this.domain).subscribe(res => {
      this.progressbarService.hide();
      this.resData = res;
      console.log("===============", res);
      if (this.resData.RequestDetail.Success === true) {
        this.isApiResponseCome = true;
        this.boardTaskDetailList = this.resData.RequestDetail.BoardTask;
        if (this.resData.RequestDetail.BoardTask !== null) {
          this.associationId = this.resData.RequestDetail.BoardTask.AssociationId;
          this.isShowNextAndPreviewsButton();
          this.setBoardTaskDetails();
        } else {
          console.log("Details Not found");
          this._router.navigate([AppRouteUrl.errorRouteUrl]);
        }
        this.documentList = this.resData.RequestDetail.Document;
        this.motionList = this.resData.RequestDetail.Motion;
        this.setMotionValueInCaseNote(this.resData.RequestDetail.CaseNoteDetails);

      } else if (this.resData.Errors.length === 0) {
        this.isApiResponseCome = true;
        if (this.resData.RequestDetail.BoardTask === null) {
          console.log("Details Not found");
          this._router.navigate([AppRouteUrl.errorRouteUrl]);
        }
      }
      else {
        this.notificationService.showNotification("Details Not Found");
        this._router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  setMotionValueInCaseNote(CaseNoteDetails) {
    if (this.motionList !== null) {
      // Add motion in to case note
      if (this.motionList.length > 0) {
        this.motionList.map(m => {
          var motion = this.commonService.convertMotionToCaseNote(m);
          CaseNoteDetails.unshift(motion);
        });
      }
    }
    if (CaseNoteDetails !== null && CaseNoteDetails.length > 0) {
      this.setCaseNoteData(CaseNoteDetails);
    } else {
      this.removeListValue();
    }
  }

  isShowNextAndPreviewsButton() {
    let BTlocalStorageData = JSON.parse(localStorage.getItem('PmBTList'));
    if (BTlocalStorageData === null || BTlocalStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.boardTaskApiService.boardTaskDetailId;
      var btAr = JSON.parse(localStorage.getItem('PmBTList'));
      this.totalPages = btAr.length - 1;
      var el = btAr.find(a => { return a.id === current });
      var currentEl = btAr.indexOf(el);
      this.currentPage = currentEl;
    }
  }

  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.desLimit = 160;
    }
    else {
      this.readMoreBtn = true;
      this.readMoreDescBtnMsg = "Read Less";
      this.desLimit = this.boardTaskDetailList.Description.length;

    }
  }

  // view more Motions
  viewMoreMotions() {
    if (this.readMoreMotionBtn) {
      this.readMoreMotionBtn = false;
      this.readMoreMotionBtnMsg = "Read More";
      this.motionLimit = 160;
    }
    else {
      this.readMoreMotionBtn = true;
      this.readMoreMotionBtnMsg = "Read Less";
      this.motionLimit = this.motionList.Description.length;
    }
  }

  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.documentList.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }
  /*Case Note Add Module*/
  createCaseNoteForm() {
    this.frmBoardMemberCreateCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });

    this.frmCreateCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }
  // Create Task Form
  createTaskForm() {
    this.addTaskForm = this.formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      taskDate: ['', Validators.required],
      remainderDate: ['', Validators.required],
      assignTo: ['', Validators.required]
    });
  }

  // upload docs
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.createdByUserName
          });
        }
        if (this.selectedReplyTo === NoteType.BoardMember) {
          this.fileDataBMCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.PropertyManager) {
          this.fileDataICCase = this.fileData;
        } else if (this.selectedActivityType === ActivityType.Email) {
          this.emailFileData = this.fileData;
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }


  removeImage(imageId) {
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
    if (this.selectedReplyTo === NoteType.BoardMember) {
      this.fileDataBMCase = this.fileDataBMCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.PropertyManager) {
      this.fileDataICCase = this.fileDataICCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedActivityType === ActivityType.Email) {
      this.emailFileData = this.emailFileData.filter(a => a.imageId !== imageId);
    }
  }
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  setFileDataNull() {
    this.fileData = [];
  }


  // add case note
  onSubmitCaseNote(NotesType) {
    if (this.frmCreateCaseNote.valid) {
      this.isSubmitBtnDisabled = true;
      let model = this.createBoardTaskFormModel(NotesType);
      this.boardTaskApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabled = false;
        this.resDataCreate = res;
        if (this.resDataCreate.caseRequestListResults[0].Success === true) {
          if (this.fileDataICCase.length > 0) {
            this.getData();
          }
          else {
            this.setMotionValueInCaseNote(this.resDataCreate.caseRequestListResults[0].CaseNoteDetails);
            // if (this.resDataCreate.caseRequestListResults[0].CaseNoteDetails !== null) {

            //   this.setCaseNoteData(this.resDataCreate.caseRequestListResults[0].CaseNoteDetails);
            // } else {
            //   this.removeListValue();
            // }
          }
          this.resetCaseNoteForm(NotesType);
          this.emailNotification.sendNotifications(this.featureId, this.resDataCreate.caseRequestListResults[0].RequestId, this.createdByUserId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Board_Task, TriggerType.Update,
            AudienceType.PropertyManager).subscribe(res => {
              console.log(res);
            });
        }
        else if (this.resDataCreate.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save.");
        }
      });
    }
  }

  onSubmitBoardMemberCaseNote(NotesType) {
    if (this.frmBoardMemberCreateCaseNote.valid) {
      this.isBoardMemberSubmitBtnDisabled = true;
      let model = this.createBoardTaskFormModel(NotesType);
      let resDataCreate;
      this.boardTaskApiService.createCaseNote(model).subscribe(res => {
        this.isBoardMemberSubmitBtnDisabled = false;
        resDataCreate = res;
        if (resDataCreate.caseRequestListResults[0].Success === true) {
          if (this.fileDataBMCase.length > 0) {
            this.getData();
          }
          else {
            this.setMotionValueInCaseNote(resDataCreate.caseRequestListResults[0].CaseNoteDetails);
            // if (resDataCreate.caseRequestListResults[0].CaseNoteDetails !== null) {
            //   this.setCaseNoteData(resDataCreate.caseRequestListResults[0].CaseNoteDetails);
            // } else {
            //   this.removeListValue();
            // }
          }
          this.resetCaseNoteForm(NotesType);
        }
        else if (resDataCreate.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save.");
        }
      });
    }
  }

  // board task model
  createBoardTaskFormModel(notesType) {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: this.typeOfDocument,
      Document: notesType === NoteType.BoardMember ? this.fileDataBMCase : this.fileDataICCase,
      Domain: this.domain,
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: notesType === NoteType.BoardMember ? this.frmBoardMemberCreateCaseNote.controls.comments.value : this.frmCreateCaseNote.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: notesType,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.currRole,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }
  // reset casenote form
  resetCaseNoteForm(btNotesType) {
    if (btNotesType === this.noteType.BoardMember) {
      this.frmBoardMemberCreateCaseNote.reset();
      this.formDirectiveBoardMember.resetForm();
      this.isBoardMemberSubmitBtnDisabled = false;
      this.fileDataBMCase = [];
    } else {
      this.frmCreateCaseNote.reset();
      this.formDirective.resetForm();
      this.isSubmitBtnDisabled = false;
      this.fileDataICCase = [];
    }

    this.selectedReplyTo = "";
  }

  sidebarToggle() {
    if (this.sidebar) {
      this.resetTaskForm();
      this.sidebar = false;
    }
    else
      this.sidebar = true;
  }

  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
  }

  updateCaseNote(noteType) {
    if (this.editComments === "") {
      this.isEditValidation = true;
      return;
    }
    this.isEditCaseNoteButtonDisabled = true;
    this.isEditValidation = false;
    let model = this.editCaseNoteModel(noteType);
    this.commonService.updateCaseNote(model).subscribe(res => {
      let resData;
      this.isEditCaseNoteButtonDisabled = false;
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.resetEditCaseNote();
        if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
          if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
            //this.setCaseNoteData(resData.caseRequestListResults[0].CaseNoteDetails);
            this.setMotionValueInCaseNote(resData.caseRequestListResults[0].CaseNoteDetails);
          }
        }
        console.log("Case note updated successfully.");
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        this.notificationService.showNotification("Not update.");
      }
    });
  }

  editCaseNoteModel(noteType) {
    const model: CaseNoteEditModel = {
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: noteType,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        RoleType: this.currRole,
      }
    }
    return model;
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
  }


  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }

  /*Delete case note*/
  delete(id) {
    let resData;
    this.commonService.deleteCaseNote(id, this.boardTaskApiService.caseId, this.associationId, this.domain).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.setMotionValueInCaseNote(resData.caseRequestListResults[0].CaseNoteDetails);
        // if (resData.caseRequestListResults[0].CaseNoteDetails != null) {
        //   if (resData.caseRequestListResults[0].CaseNoteDetails.length > 0) {
        //     this.setCaseNoteData(resData.caseRequestListResults[0].CaseNoteDetails);
        //   }
        //   else {
        //     this.removeListValue();
        //   }
        // }
        // else {
        //   this.removeListValue();
        // }
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })

  }



  // Esclate Model
  createEsclateModel() {
    const model = {
      AssociationId: this.associationId,
      TypeOfDocument: this.typeOfDocument,
      Domain: this.domain,
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.addEsclateForm.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: null,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.currRole,
        IsVotingRequired: this.addEsclateForm.controls.isVotingRequired.value,
        ActivityType: this.selectedActivityType,
        IsAssignedToBoard: true
      }
    }
    return model;
  }

  // Add Esclate
  addEsclate() {
    if (this.addEsclateForm.valid) {
      this.isSubmitBtnDisabledEscalate = true;
      let model = this.createEsclateModel();
      this.boardTaskApiService.createEsclate(model).subscribe(res => {
        this.isSubmitBtnDisabledEscalate = false;
        this.resDataCreate = res;
        if (this.resDataCreate.caseRequestListResults[0].Success === true) {
          // this.notificationService.showNotification("Escalate saved successfully");
          this.getData();
          this.resetEsclateForm();
        }
        else if (this.resDataCreate.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  // reset Esclate form
  resetEsclateForm() {
    this.addEsclateForm.reset();
    this.esclateFormDiractive.resetForm();
    this.selectedActivityType = '';
    this.addEsclateForm.controls.isVotingRequired.setValue(true);

  }

  // reset Task form
  resetTaskForm() {
    this.addTaskForm.reset();
    this.addTaskFormDiractive.resetForm();
    this.sidebar = false;
  }
  addTask() {
    let model = {
      Title: this.addTaskForm.controls.title.value,
      Detail: this.addTaskForm.controls.description.value,
      TaskDate: this.addTaskForm.controls.taskDate.value,
      Remainder: this.addTaskForm.controls.remainderDate.value,
      AssignTo: this.addTaskForm.controls.assignTo.value
    }
    console.log(model);
  }

  /*Create Reopen of board task */
  createReopenForm() {
    this.frmCreateReopen = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitReopen() {
    if (this.frmCreateReopen.valid) {
      this.isSubmitBtnDisabledReopen = true;
      let model = this.createReopenFormModel();
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledReopen = false;
        this.resDataCreateReopen = res;
        if (this.resDataCreateReopen.caseRequestListResults[0].Success === true) {
          this.getData();
          this.resetReopenForm();
        }
        else if (this.resDataCreateReopen.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createReopenFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.InProgress,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateReopen.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: null,// NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: StatusReason.Reopen,
        ProfilePath: this.profilePath,
        RoleType: this.currRole,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }


  resetReopenForm() {
    this.frmCreateReopen.reset();
    this.formDirectiveReopen.resetForm();
    this.reasonType = '';
  }



  /*Create Complete of board task */
  createCompleteForm() {
    this.frmCreateComplete = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitComplete() {
    if (this.frmCreateComplete.valid) {
      this.isSubmitBtnDisabledComplete = true;
      let model = this.createCompleteFormModel();
      console.log(model);
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledComplete = false;
        this.resDataCreateComplete = res;
        if (this.resDataCreateComplete.Errors.length > 0) {
          console.log("Error from api");
        } else {
          if (this.resDataCreateComplete.caseRequestListResults[0].Success === true) {
            this.getData();
            this.resetCompleteForm();
            this.emailNotification.sendNotifications(this.featureId, this.resDataCreateComplete.caseRequestListResults[0].RequestId, this.createdByUserId, this.pmCompanyAssociationMappingId,
              SourceType.Web, FeatureName.Board_Task, TriggerType.Update_Completed,
              AudienceType.PropertyManager).subscribe(res => {
                console.log(res);
              });
          }
          else if (this.resDataCreateComplete.caseRequestListResults[0].Success === false) {
            console.log("error");
          }
        }
      });
    }
  }

  createCompleteFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.Completed,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateComplete.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: null, //NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: StatusReason.Completed,
        ProfilePath: this.profilePath,
        RoleType: this.currRole,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }


  resetCompleteForm() {
    this.frmCreateComplete.reset();
    this.formDirectiveComplete.resetForm();
    this.reasonType = '';
  }


  /*Update status of board task*/

  createBoardTaskStatusForm() {
    this.frmCancel = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitCancel() {
    if (this.frmCancel.valid) {
      this.isSubmitBtnDisabledCancel = true;
      let model = this.createBoardTaskStatusFormModel();
      let resDataCreateBoardTaskStatus;
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledCancel = false;
        resDataCreateBoardTaskStatus = res;
        if (resDataCreateBoardTaskStatus.caseRequestListResults[0].Success === true) {
          this.notificationService.showNotification("Board task status updated successfully.");
          this.getData();
          this.resetStatusCancelForm();
          this.emailNotification.sendNotifications(this.featureId, resDataCreateBoardTaskStatus.caseRequestListResults[0].RequestId, this.createdByUserId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Board_Task, TriggerType.Update_Cancelled,
            AudienceType.PropertyManager).subscribe(res => {
              console.log(res);
            });
        }
        else if (resDataCreateBoardTaskStatus.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Board task not status updated.");
        }
      });
    }
  }

  resetStatusCancelForm() {
    this.frmCancel.reset();
    this.formDirectiveCancel.resetForm();
    this.reasonType = '';
  }

  createBoardTaskStatusFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.Cancelled,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCancel.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: null, //NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: StatusReason.Cancelled,
        ProfilePath: this.profilePath,
        RoleType: this.currRole,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  // resetBoardTaskStatusForm() {
  //   this.frmCancel.reset();
  //   this.formDirectiveCancel.resetForm();
  //   document.getElementById('closeModelCreateBoardTaskStatus').click();
  // }

  setCaseNoteData(caseNoteDetail) {
    this.allCaseNoteList = [];
    console.log(caseNoteDetail);
    if (caseNoteDetail !== null) {

      this.allCaseNoteList = caseNoteDetail.filter(note => (note.CaseNotes.IsAssignedToBoard === false));

      var assignToBoardAfterVote = caseNoteDetail.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus !== null));
      if (assignToBoardAfterVote.length > 0) {
        this.allCaseNoteList = this.allCaseNoteList.concat(assignToBoardAfterVote);
      }

      // get motion with final status
      var motionCaseNoteWithStatus = caseNoteDetail.filter(m => {
        return m.CaseNotes.VoteStatus !== null && m.CaseNotes.DocumentType === 'Motion';
      });
      //concat motion
      if (motionCaseNoteWithStatus.length > 0) {
        this.allCaseNoteList = this.allCaseNoteList.concat(motionCaseNoteWithStatus);
      }

      // sort data with motion data
      this.allCaseNoteList = _.sortBy(this.allCaseNoteList, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();


      //get before data
      var caseNoteBeforeVote = caseNoteDetail.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null || note.CaseNotes.DocumentType === "Motion" && note.CaseNotes.VoteStatus === null));

      if (caseNoteBeforeVote.length > 0) {
        caseNoteBeforeVote.sort(function (a, b) {
          return +new Date(a.CreatedOrModifiedOn) - +new Date(b.CreatedOrModifiedOn);
        });
        caseNoteBeforeVote = _.sortBy(caseNoteBeforeVote, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();

        this.allCaseNoteList = caseNoteBeforeVote.concat(this.allCaseNoteList);
      }
      this.changeConversion();
      // let escalteCaseNote = caseNoteDetail.find(x => x.IsAssignedToBoard == true);
      // if (escalteCaseNote != undefined && escalteCaseNote !== null) {
      //   this.escalteCaseNoteList = escalteCaseNote;
      //   if (escalteCaseNote.Votes !== null) {
      //     if (escalteCaseNote.Votes.length !== 0) {
      //       this.escalteVoteCount = escalteCaseNote.Votes.length;
      //     }
      //   }
      // }
    }
  }

  //For Download document
  downloadDocument(filename, domain) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(domain, filename, DocumentFeatureName.BoardTask,
      DownloadfeatureName.Download).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Document not found.");
        }
      });
  }
  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(document.Domain, document.FilePath, DocumentFeatureName.BoardTask, DownloadfeatureName.Download).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image.");
      }
    });
  }

  //**Next AND Preview */
  PreviousCase() {
    var current = this.boardTaskApiService.boardTaskDetailId;
    var btAr = JSON.parse(localStorage.getItem('PmBTList'));
    this.totalPages = btAr.length - 1;
    var el = btAr.find(a => { return a.id === current });
    var currentEl = btAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = btAr[currentEl - 1].id;
      this.boardTaskApiService.boardTaskDetailId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getData();
    }
  }

  NextCase() {
    var current = this.boardTaskApiService.boardTaskDetailId;
    var btAr = JSON.parse(localStorage.getItem('PmBTList'));
    this.totalPages = btAr.length - 1;
    var el = btAr.find(a => { return a.id === current });
    var currentEl = btAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < btAr.length) {
      let prevIndex = btAr[currentEl + 1].id;
      this.boardTaskApiService.boardTaskDetailId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getData();
    }
  }


  /*On Edit Board Task*/

  getAssociation() {
    this.commonService.getAssociation().subscribe(
      (response: any) => {
        if (response.Success) {
          this.associationData = response.AssociationList;
          this.associationDdlAutocompleteList = response.AssociationList;
        }
      }
    );
  }

  getCaseCategoryDdl() {
    this.boardTaskApiService.getCaseCategoryDdl(this.customerType, this.caseType).subscribe(res => {
      this.resData = res;
      this.caseCategoryDdl = this.resData.CaseType.CaseCategory;
      if (this.caseCategoryDdl.length > 0) {
        for (let i = 0; i < this.caseCategoryDdl.length; i++) {
          let model: CaseSubCategory = new CaseSubCategory();
          model.caseCategoryName = this.caseCategoryDdl[i].Name;
          model.caseSubCategoryNames = this.caseCategoryDdl[i].CaseSubCategories;
          this.caseSubCategoryDdlList.push(model);
        }
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  onChangeCaseCategory(event) {
    this.frmEditBoardTask.controls.caseSubCategory.setValue('');
    let caseSubcat = this.caseSubCategoryDdlList.find(x => x.caseCategoryName === event.value);
    this.caseSubCategoryDdl = caseSubcat.caseSubCategoryNames;
  }

  createBoardTaskForm() {
    this.frmEditBoardTask = this.formBuilder.group({
      caseId: [''],
      title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      caseCategory: ['', Validators.required],
      association: ['', Validators.required],
      caseOriginatingType: ['', Validators.required],
      caseSubCategory: ['', Validators.required],
      dueDate: ['', Validators.required],
      priority: ['', Validators.required],
      comment: ['', [Validators.required, Validators.minLength(1), ValidationService.noWhiteSpace]],
      phoneNumber: ['', [Validators.maxLength(13), Validators.minLength(13)]],
      assignTo: [''],
      attachment: ['']
    });
    this.formControlOritingValueChanged();
  }

  formControlOritingValueChanged() {
    const phoneNumber = this.frmEditBoardTask.get('phoneNumber');
    this.frmEditBoardTask.get('caseOriginatingType').valueChanges.subscribe(
      (mode: string) => {
        if (mode === CaseOriginatingType.Phone) {
          this.isPhoneNumberVisiable = true;
          phoneNumber.setValidators([Validators.required, Validators.minLength(13), Validators.minLength(13)]);
        }
        else {
          this.isPhoneNumberVisiable = false;
          phoneNumber.clearValidators();
          this.frmEditBoardTask.controls.phoneNumber.setValue('');
        }
        phoneNumber.updateValueAndValidity();
      });
  }


  /*Edit service request toggle*/
  editSidebarToggle() {
    if (this.editSidebar) {
      this.editSidebar = false;
    }
    else
      this.editSidebar = true;
    this.resetBoardTaskForm();
  }

  onClickEditIcon() {
    this.editSidebar = true;
    console.log('detail ', this.boardTaskDetailList);
    this.frmEditBoardTask.controls.caseId.setValue(this.boardTaskDetailList.CaseId);
    this.frmEditBoardTask.controls.title.setValue(this.boardTaskDetailList.Title);
    this.frmEditBoardTask.controls.comment.setValue(this.boardTaskDetailList.Description);
    if (this.boardTaskDetailList.DueDate !== "" || this.boardTaskDetailList.DueDate !== null || this.boardTaskDetailList.DueDate !== undefined)
      this.frmEditBoardTask.controls.dueDate.setValue(this.boardTaskDetailList.DueDate);
    else
      this.frmEditBoardTask.controls.dueDate.setValue('');
    var phoneNumber = this.frmEditBoardTask.get('phoneNumber');
    if (this.boardTaskDetailList.CaseOriginatingType === CaseOriginatingType.Phone) {
      this.isPhoneNumberVisiable = true;
      phoneNumber.setValidators([Validators.required, Validators.minLength(13), Validators.maxLength(13)]);
      this.frmEditBoardTask.controls.phoneNumber.setValue(this.boardTaskDetailList.Phone);
    }
    else {
      this.isPhoneNumberVisiable = false;
      phoneNumber.clearValidators();
      this.frmEditBoardTask.controls.phoneNumber.setValue('');
    }

    phoneNumber.updateValueAndValidity();

    var priority = this.priorityDdl.find(c => c.value === this.boardTaskDetailList.CasePriority);
    this.frmEditBoardTask.controls.priority.setValue(priority.value);

    if (this.boardTaskDetailList.AssignedTo !== undefined && this.boardTaskDetailList.AssignedTo !== null && this.boardTaskDetailList.AssignedTo !== '') {
      var assignToUser = this.assignToDdl.find(c => c.UserName === this.boardTaskDetailList.AssignedTo);
      this.frmEditBoardTask.controls.assignTo.setValue(assignToUser);
    }


    var caseOriginatingType = this.caseOriginatingTypeDdl.find(c => c.value === this.boardTaskDetailList.CaseOriginatingType);
    this.frmEditBoardTask.controls.caseOriginatingType.setValue(caseOriginatingType.value);

    var association = this.associationData.find(a => a.id === this.boardTaskDetailList.AssociationId);
    this.frmEditBoardTask.controls.association.setValue(association);

    var category = this.caseCategoryDdl.find(c => c.Name === this.boardTaskDetailList.CaseCategory);
    this.frmEditBoardTask.controls.caseCategory.setValue(category.Name);

    this.caseSubCategoryDdl = category.CaseSubCategories;
    var subCategory = this.caseSubCategoryDdl.find(c => c === this.boardTaskDetailList.CaseSubCategory);
    this.frmEditBoardTask.controls.caseSubCategory.setValue(subCategory);

    this.editFileData = [];

    let arrDoc = this.commonService.filterTwoDocumentArray(this.boardTaskDetailList.BoardTaskDocuments, this.documentList);
    if (arrDoc !== undefined && arrDoc !== null && arrDoc.length > 0) {
      arrDoc.forEach(document => {
        let doc = {
          imageId: Guid.create().toString(),
          name: document.DocumentName,
          fileSize: document.FileSize,
          inputStream: document.ThumbnailPath,
          mediaType: document.MediaType,
          documentId: document.id,
          createdByUserName: this.createdByUserName
        }
        this.editFileData.push(doc);
      });
    }
  }

  // upload Documents
  onUploadEditTaskChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          let type = evt.target.files[i].name.split(".");
          this.editFileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.createdByUserName
          });
          console.log(this.frmEditBoardTask);
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }
  removeImageEditTask(imageId) {
    this.editFileData = this.editFileData.filter(a => a.imageId !== imageId);
    this.frmEditBoardTask.controls.attachment.markAsDirty();
  }

  onSubmitEditBoardTask() {
    if (this.isPhoneNumberVisiable === true) {
      let phNo = this.frmEditBoardTask.controls.phoneNumber.value;
      if (phNo === '' || phNo === null || phNo === undefined) {
        this.phoneValidation = true;
        return;
      }
    }
    this.phoneValidation = false;
    if (this.frmEditBoardTask.valid) {
      this.isSubmitBtnEditDisabled = true;
      let model = this.editBoardTaskFormModel();
      console.log("model", model);
      this.boardTaskApiService.updateBoardTask(model).subscribe(res => {
        this.isSubmitBtnEditDisabled = false;
        this.resDataCreate = res;
        if (this.resDataCreate.caseRequestListResults[0].Success === true) {
          this.notificationService.showNotification("Board Task updated successfully");
          this.editSidebar = false;
          this.getData();
          this.resetBoardTaskForm();
          this.emailNotification.sendNotifications(this.featureId, this.resDataCreate.caseRequestListResults[0].RequestId, this.createdByUserId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Board_Task, TriggerType.Update,
            AudienceType.PropertyManager).subscribe(res => {
              console.log(res);
            });
        }
        else if (this.resDataCreate.caseRequestListResults[0].Success === false) {
          this.notificationService.showNotification("Not Save");
        }
      });
    }
  }

  editBoardTaskFormModel() {
    var formSelectedAssociation = this.frmEditBoardTask.controls.association.value;
    const model: BoardTaskModel = {
      Domain: formSelectedAssociation.Domain,
      TypeOfDocument: this.typeOfDocument,
      Document: this.editFileData,
      RequestId: this.boardTaskApiService.boardTaskDetailId,//this.boardTaskDetailList.id,
      Case:
      {
        id: this.frmEditBoardTask.controls.caseId.value,
        AssociationId: formSelectedAssociation.id,
        Title: this.frmEditBoardTask.controls.title.value,
        AssociationName: formSelectedAssociation.AssociationName,
        CompanyCode: formSelectedAssociation.CompanyCode,
        CaseType: this.caseType,
        SubCaseType: this.subCaseType,
        CaseCategory: this.frmEditBoardTask.controls.caseCategory.value,
        CaseSubCategory: this.frmEditBoardTask.controls.caseSubCategory.value,
        Comments: this.frmEditBoardTask.controls.comment.value,
        CustomerType: this.customerType,
        CasePriority: this.frmEditBoardTask.controls.priority.value,
        DueDate: new Date(this.frmEditBoardTask.controls.dueDate.value).toUTCString(),
        FirstName: this.firstName,
        LastName: this.lastName,
        CaseOriginatingType: this.frmEditBoardTask.controls.caseOriginatingType.value,
        IsAuthorized: IsAuthorized.Yes,
        StatusReason: "",
        Phone: this.frmEditBoardTask.controls.phoneNumber.value,
        AssignedTo: this.frmEditBoardTask.controls.assignTo.value !== null || '' ? this.frmEditBoardTask.controls.assignTo.value.UserName : null, //this.frmEditBoardTask.controls.assignTo.value.UserName,
        AssignedPartyType: AssignedPartyType.PROPVIVO,
        CaseDocuments: null,
        CreatedByUserName: '',
        CreatedByUserId: '',
        ModifiedByUserId: this.createdByUserId,
        ModifiedByUserName: this.createdByUserName
      }
    }
    return model;

  }

  resetBoardTaskForm() {
    this.frmEditBoardTask.reset();
    this.formEditBoardTaskformDirective.resetForm();
    this.isSubmitBtnEditDisabled = false;
    this.editFileData = [];
    this.isPhoneNumberVisiable = false;
  }

  onChangeCaseOriginating() {
    this.frmEditBoardTask.controls.caseOriginatingType.value === 'Phone' ? this.isPhoneNumberVisiable = true : this.isPhoneNumberVisiable = false;
    this.phoneValidation = false;
  }
  setPhoneNumberForBoardTask(event) {
    let ctrlValue = this.frmEditBoardTask.controls.phoneNumber.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmEditBoardTask.controls.phoneNumber.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmEditBoardTask.controls.phoneNumber.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmEditBoardTask.controls.phoneNumber.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
    this.phoneValidation = false;
  }

  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }

  /*:Check Current Date*/
  getToday(): string {
    return new Date().toISOString().split('T')[0]
  }
  /*End Edit Board Task */



  toGoBack() {
    // let url = document.referrer;
    // if (url.search(AppRouteUrl.motionsRouteUrl) >= 0) {
    //   this._router.navigate([AppRouteUrl.mainMotionsRouteUrl]);
    // } else {
    //   this._router.navigate([AppRouteUrl.mainBoardTasksPMRouteUrl]);
    // }
    let page = localStorage.getItem("previousPage");
    if (page === AppRouteUrl.mainMotionsRouteUrl) {
      this._router.navigate([AppRouteUrl.mainMotionsRouteUrl]);
    } else if (page === AppRouteUrl.mainRecentUpdatesRouteUrl) {
      this._location.back();
    } else {
      this._router.navigate([AppRouteUrl.mainBoardTasksPMRouteUrl]);
    }
  }

  ngOnDestroy(): void {
    // Unsubscribe from localStorage
    localStorage.removeItem('PmBTList');
  }

  /*Reset mat auto compelte*/
  ngAfterViewInit() {
    this.boardtaskAssociationtrigger.panelClosingActions
      .subscribe(e => {
        if (!(e && e.source)) {
          this.frmEditBoardTask.controls.association.setValue('');
          this.boardtaskAssociationtrigger.closePanel();
          this.associationDdlAutocompleteList = this.associationData;
        }
      });
  }

  /*auto complete*/
  /**Auto complete Display Function**/
  displayFnAutoCompleteAssociation(association) {
    if (association != null && association.AssociationName != null) {
      return association.AssociationName;
    } else association;
  }

  /**Auto complete filter on change**/
  onInputChanged(searchStr: string): void {
    this.associationDdlAutocompleteList = [];
    this.associationDdlAutocompleteList = this.associationData.filter(option =>
      option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
  }

  //New methods Reply to 
  //change reply to 
  changeReplyTo() {
    this.selectedActivityType = '';
    this.fileData = [];
  }

  //change conversion
  changeConversion() {

    if (this.selectedConversionType === "All") {
      this.caseNotes = this.allCaseNoteList;
    }
    else if (this.selectedConversionType === NoteType.BoardMember) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager) || (note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.BoardMember));
    }
    // } else if (this.selectedConversionType === NoteType.BoardMember) {
    //   this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType === NoteType.BoardMember);

    else if (this.selectedConversionType === NoteType.PropertyManager) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType == RoleEnum.PropertyManager && note.CaseNotes.IsAssignedToBoard === false && (note.CaseNotes.ActivityType !== this.activityTypeEnum.Phone && note.CaseNotes.ActivityType !== this.activityTypeEnum.Email));
    } else if (this.selectedConversionType === this.activityTypeEnum.Phone) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Phone);
    } else if (this.selectedConversionType === this.activityTypeEnum.Email) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Email);
    } else if (this.selectedConversionType === this.activityTypeEnum.AssignToBoard) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.AssignToBoard);
    }
  }

  removeListValue() {
    this.allCaseNoteList = [];
    this.caseNoteList = [];
    this.boardMemberCaseNoteList = [];
    this.decisionReason = [];
    // assign to board HTML(escalteCaseNoteList === null ||  escalteCaseNoteList  === undefined || escalteCaseNoteList.length === 0)
    //this.escalteCaseNoteList = [];
  }

  onClickReason(reasonType) {
    this.reasonType = reasonType;
    this.selectedActivityType = '';
    this.selectedReplyTo = '';
  }

  //change activivty type 
  selectActivityType(type) {
    this.selectedActivityType = type;
    this.selectedReplyTo = '';
    this.fileData = [];
    this.reasonType = "";
    this.emailFileData = [];
  }


  //call form
  createAddCallForm() {
    this.frmCreatePhone = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]],
      callNumber: ['', [Validators.required, Validators.minLength(13), Validators.maxLength(13)]],
      callType: [this.callTypeEnum.InComming],
      callerName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      isShowCallConversation: [false],
      isVotingRequired: [false]
    });
  }

  onSubmitCall() {
    let resData;
    if (this.frmCreatePhone.valid) {
      this.isSubmitBtnDisabledPhone = true;
      let model = this.createCallModel();
      console.log("model", model);
      this.boardTaskApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledPhone = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          //this.setMotionValueInCaseNote(resData.caseRequestListResults[0].CaseNoteDetails);
          this.getData();
          this.resetCallForm();
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.createdByUserId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Board_Task, TriggerType.Update,
            AudienceType.PropertyManager).subscribe(res => {
              console.log(res);
            });
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createCallModel() {
    const model: CallModel = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreatePhone.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: NoteType.PropertyManager,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.currRole,
        CallType: this.frmCreatePhone.controls.callType.value,
        CallNumber: this.frmCreatePhone.controls.callNumber.value,
        CallerName: this.frmCreatePhone.controls.callerName.value,
        IsShowCallConversation: this.frmCreatePhone.controls.isShowCallConversation.value,
        IsVotingRequired: this.frmCreatePhone.controls.isVotingRequired.value,
        CallDuration: null,
        PhoneCallRecord: null,
        ActivityType: this.selectedActivityType
      }
    }
    return model;
  }


  resetCallForm() {
    this.frmCreatePhone.reset();
    this.formDirectivePhone.resetForm();
    this.selectedActivityType = '';
    this.frmCreatePhone.controls.callType.setValue(this.callTypeEnum.InComming);
  }

  setMobileNumberForCallNumber(event) {
    let ctrlValue = this.frmCreatePhone.controls.callNumber.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmCreatePhone.controls.callNumber.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);


        this.frmCreatePhone.controls.callNumber.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmCreatePhone.controls.callNumber.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }

  //Email Form
  createAddEmailForm() {
    this.frmCreateEmail = this.formBuilder.group({
      To: ['', [Validators.required]],
      BCC: [''],
      CC: [''],
      Message: [''],
      Subject: [''],
      EmailAudience: [EmailAudience.None]
    });
  }

  onSubmitEmail() {
    let resData;
    if (this.frmCreateEmail.valid) {
      this.isSubmitBtnDisabledEmail = true;
      let model = this.createEmailModel();
      this.boardTaskApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledEmail = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          //this.setCaseNoteData(resData.caseRequestListResults[0].CaseNoteDetails);
          if (this.emailFileData.length > 0) {
            this.getData();
          } else {
            this.setMotionValueInCaseNote(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetEmailForm();
          this.emailNotification.sendNotifications(this.featureId, this.resDataCreateComplete.caseRequestListResults[0].RequestId, this.createdByUserId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.Board_Task, TriggerType.Update,
            AudienceType.PropertyManager).subscribe(res => {
              console.log(res);
            });

        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createEmailModel() {
    var ToEmail = "";
    var CCEmail = "";
    var BCCEmail = "";
    if (this.frmCreateEmail.controls.To.value !== null && this.frmCreateEmail.controls.To.value !== '') {
      ToEmail = this.frmCreateEmail.value.To.map(function (a) { return a.value }).join(', ')
    }
    if (this.frmCreateEmail.controls.BCC.value !== null && this.frmCreateEmail.controls.BCC.value !== '') {
      BCCEmail = this.frmCreateEmail.value.BCC.map(function (a) { return a.value }).join(', ')
    }
    if (this.frmCreateEmail.controls.CC.value !== null && this.frmCreateEmail.controls.CC.value !== '') {
      CCEmail = this.frmCreateEmail.value.CC.map(function (a) { return a.value }).join(', ')
    }
    const model: EmailModel = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.emailFileData,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: '',
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: NoteType.PropertyManager,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.currRole,
        ActivityType: this.selectedActivityType,
        To: ToEmail,
        CC: CCEmail,
        BCC: BCCEmail,
        Message: this.frmCreateEmail.controls.Message.value,
        Subject: this.frmCreateEmail.controls.Subject.value,
        EmailAudience: this.frmCreateEmail.controls.EmailAudience.value,
      }
    }
    return model;
  }


  resetEmailForm() {
    this.frmCreateEmail.reset();
    this.formDirectiveEmail.resetForm();
    this.selectedActivityType = '';
    this.emailFileData = [];
    this.frmCreateEmail.controls.Subject.setValue(this.boardTaskDetailList.CaseNumber + ":" + this.boardTaskDetailList.Title);
    this.frmCreateEmail.controls.EmailAudience.setValue(EmailAudience.None);
  }


  setMotionValue() {
    var passVotes;
    var failVotes;
    if (this.motionList !== null && this.motionList !== undefined) {
      if (this.motionList.Votes !== null && this.motionList.Votes !== undefined) {
        this.motionVoteCount = this.motionList.Votes.length;
        passVotes = this.motionList.Votes.filter(v => v.Vote === true).length;
        failVotes = this.motionList.Votes.filter(v => v.Vote === false).length;
      }
      if (this.motionList.VoteStatus === null || this.motionList.VoteStatus === undefined) {
        //this.motionMsg = CommonConstant.MotionMoved;
        this.motionIcon = CommonConstant.MotionMovedIcon;
        if (this.motionList.Votes.length > 1)
          this.voteReceiveMsg = this.motionVoteCount + " Votes Received"
        else
          this.voteReceiveMsg = this.motionVoteCount + " Vote Received"
      }
      if (this.motionList.VoteStatus !== null && this.motionList.VoteStatus === this.VoteStatusEnum.Approved) {
        this.motionMsg = CommonConstant.MotionPassed;
        this.motionIcon = CommonConstant.MotionPassedIcon;
        this.voteReceiveMsg = "(" + passVotes + "-" + failVotes + ")"
      }
      if (this.motionList.VoteStatus !== null && this.motionList.VoteStatus === this.VoteStatusEnum.Denied) {
        this.motionMsg = CommonConstant.MotionFailed;
        this.motionIcon = CommonConstant.MotionFailedIcon;
        this.voteReceiveMsg = "(" + passVotes + "-" + failVotes + ")"

      }
    }
  }
  //change Assign to
  selectedAssignTo = '';
  onChangeAssignTo() {
    var resData;
    var model = this.createAssignToModel();
    this.boardTaskApiService.changeAssignTo(model).subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.boardTaskDetailList = resData.boardTaskRequestDetail;
        if (this.boardTaskDetailList !== null) {
          this.setBoardTaskDetails();
        }
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        console.log("error");
      }
    });
  }

  createAssignToModel() {
    var model: AssignToModel = {
      RequestId: this.boardTaskDetailList.id,
      CaseId: this.boardTaskDetailList.CaseId,
      Case: {
        AssignedTo: this.selectedAssignTo,
        ModifiedByUserId: this.createdByUserId,
        ModifiedByUserName: this.createdByUserName
      }
    }
    return model;
  }
  setBoardTaskDetails() {
    if (this.boardTaskDetailList.IsComment === true) {
      this.isCommentAndReopen = false;
    }
    this.selectedAssignTo = this.boardTaskDetailList.AssignedTo;
    this.boardTaskStatus = this.boardTaskDetailList.BoardTaskStatus;
    this.frmCreateEmail.controls.Subject.setValue(this.boardTaskDetailList.CaseNumber + ":" + this.boardTaskDetailList.Title);
    this.boardTaskApiService.caseId = this.boardTaskDetailList.CaseId;
  }

  //change assign to board text
  // checkIconAssignToBoard(assignTOBoard) {
  //   if (assignTOBoard !== null && assignTOBoard !== undefined) {
  //     if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined) {
  //       return CommonConstant.MotionMovedIcon;
  //     }
  //     if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
  //       return CommonConstant.MotionPassedIcon;
  //     }
  //     if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
  //       return CommonConstant.MotionFailedIcon;
  //     }
  //   }
  // }
  //change assign to board icon
  // checkTextAssignToBoard(assignTOBoard) {
  //   if (assignTOBoard !== null && assignTOBoard !== undefined) {
  //     if (assignTOBoard.Votes.length > 0) {
  //       var voteCount = assignTOBoard.Votes.length;
  //     }
  //     if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined) {
  //       if (assignTOBoard.Votes.length > 0)
  //         return voteCount + " Votes Received"
  //     }
  //     if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
  //       return VoteStatus.Approved
  //     }
  //     if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
  //       return VoteStatus.Denied
  //     }
  //   }
  // }

  // checkTextAssignToBoard(assignTOBoard) {
  //   var voteCount = 0;
  //   if (assignTOBoard !== null && assignTOBoard !== undefined) {
  //     if (assignTOBoard.Votes !== null) {
  //       voteCount = assignTOBoard.Votes.length;
  //     }
  //     if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined) {
  //       if (assignTOBoard.Votes.length > 1)
  //         return voteCount + " Votes Received"
  //       else
  //         return voteCount + " Vote Received"
  //     }
  //     if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
  //       return VoteStatus.Approved
  //     }
  //     if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
  //       return VoteStatus.Denied
  //     }
  //   }
  // }

  // //assign to board text 
  // assignToBoardText(caseNote) {
  //   if (caseNote) {
  //     if (caseNote.IsAssignedToBoard) {
  //       if (caseNote.Votes.length > 0 && caseNote.VoteStatus !== null) {
  //         return CommonConstant.BoardDecision
  //       } else if (caseNote.VoteStatus === null) {
  //         return CommonConstant.DecisionRequired
  //       }
  //     }
  //   }
  // }
}


