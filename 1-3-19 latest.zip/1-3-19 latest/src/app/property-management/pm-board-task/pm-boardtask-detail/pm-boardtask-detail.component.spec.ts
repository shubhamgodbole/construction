import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmBoardtaskDetailComponent } from './pm-boardtask-detail.component';

describe('PmBoardtaskDetailComponent', () => {
  let component: PmBoardtaskDetailComponent;
  let fixture: ComponentFixture<PmBoardtaskDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmBoardtaskDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmBoardtaskDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
