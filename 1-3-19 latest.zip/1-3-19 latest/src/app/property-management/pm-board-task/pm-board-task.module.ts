import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatTooltipModule, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatPaginatorModule, MatMenuModule, MatCheckboxModule, MatAutocompleteModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { Routes, RouterModule } from '@angular/router';
import { PmBoardTaskListComponent } from './pm-board-task-list/pm-board-task-list.component';
import { PmBoardtaskDetailComponent } from './pm-boardtask-detail/pm-boardtask-detail.component';
import { RatingModule } from 'src/app/shared/component/rating/rating.module';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { QuillModule } from 'ngx-quill';
import { TagInputModule } from 'ngx-chips';
import { SpaceNotAllowModule } from 'src/app/shared/directives/space-not-allow/space-not-allow.module';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';
import { DisplayTimeElapsedModule } from 'src/app/shared/modules/display-time-elapsed.module';
import { OnlyAlphabetsModule } from 'src/app/shared/directives/allow-only-alphabets/only-alphabets.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
import { TransformBlankValueModule } from 'src/app/shared/pipes/blankValue/transform-blank-value.module';
const routes: Routes = [
  {
    path: '',
    component: PmBoardTaskListComponent
  },
  {
    path: 'pm-boardtask-detail',
    component: PmBoardtaskDetailComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    RatingModule,
    NoCaseNoteFoundModule,
    SafeModule,
    NoDataFoundModule,
    MatInputModule,
    MatBottomSheetModule,
    MatCheckboxModule,
    MatMenuModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatListModule,
    NumberOnlyDirectiveModule,
    MatSelectModule,
    MatRadioModule,
    MatPaginatorModule,
    MatTooltipModule,
    FilterUniqueArrayModule,
    DisplayTimeElapsedModule,
    MatAutocompleteModule,
    OnlyAlphabetsModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes),
    BsDatepickerModule.forRoot(),
    QuillModule,
    TagInputModule,
    SpaceNotAllowModule,
    HideIfUnauthorizedModule,
    TransformBlankValueModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [PmBoardTaskListComponent, PmBoardtaskDetailComponent]
})
export class PmBoardTaskModule { }
