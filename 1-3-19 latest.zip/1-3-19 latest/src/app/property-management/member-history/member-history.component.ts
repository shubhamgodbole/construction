import { Component, OnInit, ViewChild } from '@angular/core';
import { MemberHistoryService } from 'src/app/services/member-history.service';
import { MemberHistryStatus, DisplayColumnsAllRequest, DisplayColumnsArcRequest, DisplayColumnsServiceRequest, DisplayColumnsPaymentHistory, DisplayColumnsNotice, DisplayColumnsViolation, AllRequest } from './memberHistory-model';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { NoDataFoundCaseFeatureName, MasterPaginationEnum, Pagination, CaseFeatureType, RoleEnum, CaseTypeEnum } from 'src/app/shared/Enums/commonEnums';
import { MatPaginator } from '@angular/material';
import { NavigationExtras, Router, ActivatedRoute } from '@angular/router';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { CommonService } from 'src/app/services/common.service';
import { Subscription } from 'rxjs';
import { PaymentsApiService } from 'src/app/services/payments-api.service';


@Component({
  selector: 'app-member-history',
  templateUrl: './member-history.component.html',
  styleUrls: ['./member-history.component.scss']
})
export class MemberHistoryComponent implements OnInit {

  associationId: string;
  associationUnitId: string
  userId: string;
  list: any;

  ViolationsCount: number;
  ARCRequestsCount: number;
  ServiceRequestsCount: number;
  allCount: number;


  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  requestType: string;
  MemberHistryStatusEnum = MemberHistryStatus;


  /**End For Manage Columns*/
  caseFeatureType = CaseFeatureType;
  isListShow: boolean = false;

  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  //left panel Detail 
  associationUnit: any;
  ownerDetail: any;
  unitUserDetail: any;
  ownerProfile: any;
  userProfileDetail: any;
  propertyAddress: any;
  mailingAddress: any;
  unitRole: any;
  unitRoleStartDate: string;
  unitRoleEndDate: string;
  isUnitDetailShow: boolean;
  associationRole: any;
  associationRoles: any = [];
  roleEnum = RoleEnum;
  accountNumber: string;
  companyCode: string;
  //For Query string;
  querySubcription: Subscription;  

  constructor(private service: MemberHistoryService, private router: Router,
    public commonService: CommonService, private route: ActivatedRoute,
    private paymentsApiService: PaymentsApiService,
    private progressBarService: ProgeressBarService) {
    this.requestType = MemberHistryStatus.ServiceRequest;
    this.seletedColumns = DisplayColumnsServiceRequest.AllColumnsList;
    /**For Manage Columns*/
    this.displayColumnsDdl = DisplayColumnsServiceRequest.ColumnsList;
    this.defaultColumnsList = DisplayColumnsServiceRequest.DefaultColumnsList;
    /**End For Manage Columns*/

    //this.associationId = '';

    this.getAssociationUnitDetail();
  }

  requestChange(s) {
    this.requestType = s;
    /**For Manage Columns*/
    if (this.MemberHistryStatusEnum.AllRequest === s) {
      this.displayColumnsDdl = DisplayColumnsAllRequest.ColumnsList;
      this.defaultColumnsList = DisplayColumnsAllRequest.DefaultColumnsList;
      this.seletedColumns = DisplayColumnsAllRequest.AllColumnsList;
      this.getAllRequest();
    } else if (this.MemberHistryStatusEnum.ArcRequest === s) {
      this.displayColumnsDdl = DisplayColumnsArcRequest.ColumnsList;
      this.defaultColumnsList = DisplayColumnsArcRequest.DefaultColumnsList;
      this.seletedColumns = DisplayColumnsArcRequest.AllColumnsList;
      this.getArcRequestList();
    } else if (this.MemberHistryStatusEnum.ServiceRequest === s) {
      this.displayColumnsDdl = DisplayColumnsServiceRequest.ColumnsList;
      this.defaultColumnsList = DisplayColumnsServiceRequest.DefaultColumnsList;
      this.seletedColumns = DisplayColumnsServiceRequest.AllColumnsList;
      this.getServiceRequestList();
    }
    else if (this.MemberHistryStatusEnum.Violation === s) {
      this.displayColumnsDdl = DisplayColumnsViolation.ColumnsList;
      this.defaultColumnsList = DisplayColumnsViolation.DefaultColumnsList;
      this.seletedColumns = DisplayColumnsViolation.AllColumnsList;
      this.getViolationList();
    }
    else if (this.MemberHistryStatusEnum.PaymentLetterPrePayment === s) {
      this.displayColumnsDdl = DisplayColumnsPaymentHistory.ColumnsList;
      this.defaultColumnsList = DisplayColumnsPaymentHistory.DefaultColumnsList;
      this.seletedColumns = DisplayColumnsPaymentHistory.AllColumnsList;
    } else if (this.MemberHistryStatusEnum.Notice === s) {
      this.displayColumnsDdl = DisplayColumnsNotice.ColumnsList;
      this.defaultColumnsList = DisplayColumnsNotice.DefaultColumnsList;
      this.seletedColumns = DisplayColumnsNotice.AllColumnsList;
    }
    /**End For Manage Columns*/
  }

  ngOnInit() {
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let userId = params["userId"];
      let unitId = params["unitId"];
      let associationId = params["associationId"];
      if (userId && unitId) {
        this.associationUnitId = unitId;
        this.userId = userId;
        this.associationId = associationId;
        this.getAssociationUnitDetail();
      }
      else {
        this.router.navigate([AppRouteUrl.errorRouteUrl]);
      }
    });
  }

  getServiceRequestList() {
    this.isListShow = false;
    this.setMasterOfPagination();
    let resData;
    this.list = [];
    this.progressBarService.show();
    this.service.getUnitServiceRequests(this.associationId, this.associationUnitId).subscribe(res => {
      resData = res;
      this.progressBarService.hide();
      this.isListShow = true;
      if (resData.Success) {
        this.setValue(resData);
        if (resData.ServiceRequests !== null) {
          this.list = resData.ServiceRequests;
          this.setPaginationData(this.list);
        }
      }
    });
  }

  setValue(resData) {
    this.ARCRequestsCount = resData.ARCRequestsCount;
    this.ServiceRequestsCount = resData.ServiceRequestsCount;
    this.ViolationsCount = resData.ViolationsCount;
    this.allCount = this.ARCRequestsCount + this.ServiceRequestsCount + this.ViolationsCount;
  }

  getArcRequestList() {
    this.setMasterOfPagination();
    let resData;
    this.list = [];
    this.isListShow = false;
    this.progressBarService.show();
    this.service.getUnitArcRequests(this.associationId, this.associationUnitId).subscribe(res => {
      resData = res;
      this.isListShow = true;
      this.progressBarService.hide();
      if (resData.Success) {
        this.setValue(resData);
        if (resData.ARCRequests !== null) {
          this.list = resData.ARCRequests;
          this.setPaginationData(this.list);
        }
      }
    });
  }

  getViolationList() {
    this.setMasterOfPagination();
    this.list = [];
    let resData;
    this.isListShow = false;
    this.progressBarService.show();
    this.service.getUnitViolations(this.associationId, this.associationUnitId).subscribe(res => {
      resData = res;
      this.isListShow = true;
      this.progressBarService.hide();
      if (resData.Success) {
        this.setValue(resData);
        if (resData.Violations !== null) {
          this.list = resData.Violations;
          this.setPaginationData(this.list);
        }
      }
    });
  }

  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(list) {
    this.TotalRecord = list.length;
    var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    this.FilterArray = list.slice(pageStartIndex - 1, pageEndIndex);
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    var pageStartIndex = (clickObj.pageIndex * clickObj.pageSize) + 1;
    var pageEndIndex = (clickObj.pageIndex * clickObj.pageSize) + clickObj.pageSize;
    this.FilterArray = this.list.slice(pageStartIndex - 1, pageEndIndex);
  }


  //go to detail page
  getRequestDetails(detailId, caseFeatureName) {
    console.log(detailId);
    if (detailId !== "" && detailId !== null && detailId !== undefined) {
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": detailId,
        }
      };
      if (CaseFeatureType.ServiceRequest === caseFeatureName) {
        this.router.navigate([AppRouteUrl.mainServiceRequestDetailPMRouteUrl], navigationExtras);
      }
      else if (CaseFeatureType.Violation === caseFeatureName) {
        this.router.navigate([AppRouteUrl.mainViolationsDeatilPMRouteUrl], navigationExtras);
      }
      else if (CaseFeatureType.ARCRequest === caseFeatureName) {
        this.router.navigate([AppRouteUrl.mainArcDetailPMRouteUrl], navigationExtras);
      }
    }
  }

  getAssociationUnitDetail() {
    let resData;
    this.progressBarService.show();
    this.isUnitDetailShow = false;
    this.service.getUnitDetail(this.userId, this.associationId, this.associationUnitId).subscribe(res => {
      resData = res;      
      this.isUnitDetailShow = true;
      this.mailingAddress = "";
      if (resData.Success) {
        console.log(resData);
        this.associationUnit = resData.AssociationUnit;
        this.ownerProfile = resData.OwnerUserProfile;
        this.unitUserDetail = resData.UnitBasicDetail;
        this.userProfileDetail = resData.UserProfile;
        this.unitRole = this.userProfileDetail.UnitRoleProfiles[0].UnitRoleProfiles[0].UnitRoleIdName;
        this.unitRoleStartDate = this.userProfileDetail.UnitRoleProfiles[0].UnitRoleProfiles[0].StartDate;
        this.unitRoleEndDate = this.userProfileDetail.UnitRoleProfiles[0].UnitRoleProfiles[0].EndDate !== null ? this.userProfileDetail.UnitRoleProfiles[0].UnitRoleProfiles[0].EndDate : 'Present';
        this.associationRole = this.userProfileDetail.AssociationRoleProfiles[0].AssociationRoleProfiles.find(r => r.AssociationRoleIdName === RoleEnum.BoardMember);
        this.companyCode = "";
        this.accountNumber = this.userProfileDetail.AccountNumber;
        this.getAssociationRoles();
        this.getPropertyAddress();
        this.getServiceRequestList();
        if (resData.OwnerUserProfileDetail !== null) {
          this.getMailingAddress(resData.OwnerUserProfileDetail);
        }
      }
    })
  }

  getAllRequest() {
    this.setMasterOfPagination();
    let resData;
    this.isListShow = false;
    this.progressBarService.show();
    this.service.getAllRequest(this.associationId, this.associationUnitId).subscribe(res => {
      
      resData = res;
      this.isListShow = true;
      this.progressBarService.hide();
      if (resData.Success) {
        this.setValue(resData);
        this.setListValue(resData)
      }
    });
  }


  setListValue(resData) {
    var arcRequests = resData.ARCRequests;
    var violations = resData.Violations;
    var serviceRequests = resData.ServiceRequests;
    this.list = [];
    if (arcRequests !== null && arcRequests.length > 0) {
      arcRequests.map(a => {
        var request: AllRequest = {
          Title: a.ARCRequestTitle,
          Origin: a.CaseOriginatingType,
          Type: CaseTypeEnum.ARCRequest,
          CreatedOn: a.CreatedOn,
          LastUpdatedOn: a.ModifiedOn,
          LastUpdatedBy: a.ModifiedByUserName,
          TimeElapsed: a.CreatedOn,
          Comments: "",
          Priority: a.CasePriority,
          id: a.id,
          CaseFeatureType: CaseFeatureType.ARCRequest
        }
        this.list.push(request);
      });
    }

    if (violations !== null && violations.length > 0) {
      violations.map(a => {
        var request: AllRequest = {
          Title: a.Title,
          Origin: a.CaseOriginatingType,
          Type: CaseTypeEnum.Violations,
          CreatedOn: a.CreatedOn,
          LastUpdatedOn: a.ModifiedOn,
          LastUpdatedBy: a.ModifiedByUserName,
          TimeElapsed: a.CreatedOn,
          Comments: "",
          Priority: a.CasePriority,
          id: a.id,
          CaseFeatureType: CaseFeatureType.Violation
        }
        this.list.push(request);
      });
    }
    if (serviceRequests !== null && serviceRequests.length > 0) {
      serviceRequests.map(a => {
        var request: AllRequest = {
          Title: a.Title,
          Origin: a.CaseOriginatingType,
          Type: CaseTypeEnum.ServiceRequest,
          CreatedOn: a.CreatedOn,
          LastUpdatedOn: a.UpdatedOn,
          LastUpdatedBy: a.ModifiedByUserName,
          TimeElapsed: a.CreatedOn,
          Comments: "",
          Priority: a.CasePriority,
          id: a.id,
          CaseFeatureType: CaseFeatureType.ServiceRequest
        }
        this.list.push(request);
      });
    }

    if (this.list.length > 0) {
      this.list.sort(function (a, b) {
        return +new Date(a.CreatedOn) - +new Date(b.CreatedOn);
      });
    }
    this.setPaginationData(this.list);
  }

  getAssociationRoles() {
    this.associationRoles = [];
    var a = this.userProfileDetail.AssociationRoleProfiles[0].AssociationRoleProfiles.filter(r => {
      var today = new Date().getTime();
      var startDate = new Date(r.StartDate).getTime();
      if (startDate <= today && (r.EndDate === null || new Date(r.EndDate).getTime() >= today)) {
        return r;
      }
    });
    var flags = [], l = a.length, i;
    for (i = 0; i < l; i++) {
      if (flags[a[i].AssociationRoleIdName]) continue;
      flags[a[i].AssociationRoleIdName] = true;
      this.associationRoles.push(a[i]);
    }
  }

  getEndDate(role) {
    return role.EndDate !== null ? role.EndDate : 'Present';
  }

  getPropertyAddress() {
    var associationUnit = {
      AssociationUnitNumber: this.associationUnit.AssociationUnitNumber,
      AssociationUnitAddress1: this.associationUnit.AssociationUnitAddress1,
      AssociationUnitAddress2: this.associationUnit.AssociationUnitAddress2,
      AssociationUnitCity: this.associationUnit.AssociationUnitCity,
      AssociationUnitState: this.associationUnit.AssociationUnitState,
      AssociationUnitZip: this.associationUnit.AssociationUnitZip,
    }
    this.propertyAddress = this.commonService.getFullAssociationAddress(associationUnit);
  }


  getMailingAddress(OwnerUserProfileDetail) {
    var address = {
      AssociationUnitNumber: "",
      AssociationUnitAddress1: OwnerUserProfileDetail.Addresses[0].Address1,
      AssociationUnitAddress2: OwnerUserProfileDetail.Addresses[0].Address2,
      AssociationUnitCity: OwnerUserProfileDetail.Addresses[0].City,
      AssociationUnitState: OwnerUserProfileDetail.Addresses[0].State,
      AssociationUnitZip: OwnerUserProfileDetail.Addresses[0].ZIP
    }
    this.mailingAddress = this.commonService.getFullAssociationAddress(address);
  }

  getPaymentSheet() {
    let paymentReport = {
      "Count": "0",
      "LastCount": "0",
      "AccountNum": this.accountNumber,
      "NextRecordCount": "10",
      "Association": this.companyCode
    };
    this.setMasterOfPagination();
    let resData;
    this.progressBarService.show();
    this.paymentsApiService.getPaymentSheet(paymentReport).subscribe(res => {
      this.progressBarService.hide();
      console.log("res", res);
      resData = res;
      if (resData.PaymentReport !== null && resData.PaymentReport !== undefined) {
        if (resData.PaymentReport.PaymentHeaderList !== null && resData.PaymentReport.PaymentHeaderList !== undefined) {
          this.list = resData.PaymentReport.PaymentHeaderList[0].PaymentDetailsList;
          this.accountNumber = resData.PaymentReport.PaymentHeaderList[0].AccountNum;
          this.setPaginationData(this.list);
        }
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }


  ngOnDestroy(): void {
    // Unsubscribe
    this.querySubcription.unsubscribe();
  }


}
