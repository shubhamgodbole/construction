export class DisplayColumnsAllRequest {
    public static ColumnsList = [
        { value: "Last Updated By", text: "Last Updated By"},	
        { value: "Last Updated On", text: "Last Updated On"},	
        { value: "Time Elapsed", text: "Time Elapsed"},
       // { value: "Comments", text: "Comments"},
        { value: "Priority", text: "Priority"},
    ]

    public static DefaultColumnsList = [
        { value: "Title", text:"Title"},
        { value: "Origin", text:"Origin"},
        { value: "Type", text: "Type"},	
        { value: "Created On", text: "Created On"},	
    ]

    public static AllColumnsList = [
        "Title", "Origin","Type", "Created On", "Last Updated By", "Last Updated On",,"Time Elapsed", "Comment", "Priority"
    ]
}

export class DisplayColumnsServiceRequest {
    public static ColumnsList = [
        { value: "Time Elapsed", text: "Time Elapsed"},
        //{ value: "Comments", text: "Comments"},
        { value: "Priority", text: "Priority"},
        { value: "Last Updated On", text: "Last Updated On"},	
    ]

    public static DefaultColumnsList = [
        { value: "Title", text:"Title"},
        { value: "Origin", text:"Origin"},
        { value: "Created On", text: "Created On"},	
        { value: "Last Updated By", text: "Last Updated By"},	
    ]

    public static AllColumnsList = [
        "Title", "Origin", "Created On","Time Elapsed", "Last Updated By", "Comment", "Last Updated On"
    ]
}

export class DisplayColumnsArcRequest {
    public static ColumnsList = [
        { value: "Status", text: "Status"},
       // { value: "Comments", text: "Comments"},
    ]

    public static DefaultColumnsList = [
        { value: "Title", text:"Title"},
        { value: "Origin", text:"Origin"},
        { value: "Created On", text: "Created On"},	
        { value: "Anticipated Start Date", text: "Anticipated Start Date"},	
    ]

    public static AllColumnsList = [
        "Title", "Origin", "Created On", "Anticipated Start Date", "Comment", "Status"
    ]
}

export class DisplayColumnsViolation {
    public static ColumnsList = [
        { value: "Occurance", text: "Occurance"},
        { value: "Fine", text: "Fine"},
        { value: "Fine Status", text: "Fine Status"},
        { value: "Status", text: "Status"},
    ]

    public static DefaultColumnsList = [
        { value: "Title", text: "Title"},	
        { value: "Origin", text: "Origin"},	
        { value: "Created On", text: "Created On"},
        { value: "Reported By", text: "Reported By"},
    ]

    public static AllColumnsList = [
        "Title", "Origin", "Created On", "Reported By", "Status", "Occurance", "Fine", "Fine Status"
    ]
}

export class DisplayColumnsNotice {
    public static ColumnsList = [
        { value: "Preview", text: "Preview"}
    ]

    public static DefaultColumnsList = [
        { value: "Letter Type", text: "Letter Type"},	
        { value: "Date", text: "Date"},	
        { value: "Document Link", text: "Document Link"},
    ]
    public static AllColumnsList = [
        "Letter Type", "Date", "Document Type", "Preview"
    ]
}

export class DisplayColumnsPaymentHistory {
    public static ColumnsList = [
     
        { value: "Balance", text: "Balance"},
        { value: "Remarks", text: "Remarks"},
    ]

    public static DefaultColumnsList = [
        { value: "Date", text: "Date"},	
        { value: "Transaction Detail", text: "Transaction Detail"},	
        { value: "Amount", text: "Amount"},
    ]

    public static AllColumnsList = [
        "Date", "Transaction Detail", "Remarks", "Balance", "Amount"
    ]
}

export enum MemberHistryStatus {
    AllRequest = "AllRequest",
    ServiceRequest = "ServiceRequest",
    Violation = "Violation",
    ArcRequest = "ArcRequest",
    PaymentLetterPrePayment = "PaymentLetterPrePayment",
    Notice = "Notice"
}

export class AllRequest{
    Title: string;
    Origin: string;	
    Type: string;
    CreatedOn: string;
    LastUpdatedOn: string;
    LastUpdatedBy: string;
    TimeElapsed: string;
    Comments: string;
    Priority: string;
    id: string;
    CaseFeatureType: string;
}