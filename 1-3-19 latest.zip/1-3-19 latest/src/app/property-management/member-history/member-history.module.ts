import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MemberHistoryComponent } from './member-history.component';
import { MatInputModule, MatListModule, MatSelectModule, MatCheckboxModule, MatRadioModule, MatDatepickerModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatTooltipModule, MatPaginatorModule } from '@angular/material';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DisplayTimeElapsedModule } from 'src/app/shared/modules/display-time-elapsed.module';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';

const routes: Routes = [
  {
    path: '',
    component: MemberHistoryComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    MatCheckboxModule,
    NumberOnlyDirectiveModule,
    MatRadioModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    DisplayTimeElapsedModule,
    MatTooltipModule,
    FormsModule,
    NoDataFoundModule,
    MatPaginatorModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  declarations: [MemberHistoryComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class MemberHistoryModule { }
