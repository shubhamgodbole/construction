import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatAutocompleteModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule } from '@angular/material';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { PmBoardMembersComponent } from './pm-board-members/pm-board-members.component';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { AllowOnlyDateModule } from 'src/app/shared/directives/allow-only-date/allow-only-date.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
const routes: Routes = [
  {
    path: '',
    component: PmBoardMembersComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    MatInputModule,
    MatButtonModule,
    MatBottomSheetModule,
    MatListModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatBottomSheetModule,
    AllowOnlyDateModule,
    MatButtonModule,
    NumberOnlyDirectiveModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    FormsModule,
    NoDataFoundModule,
    RouterModule.forChild(routes),
    HideIfUnauthorizedModule
  ],
  declarations: [PmBoardMembersComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class PmBoardMemberModule { }
