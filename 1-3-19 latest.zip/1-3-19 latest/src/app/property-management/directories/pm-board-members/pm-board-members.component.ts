import { Component, OnInit, ViewChild } from '@angular/core';
import { BoardMemberDirectoryApiService } from 'src/app/services/board-member-directory-api.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective, FormArray } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { BoardMemberPosition, BoardMember } from 'src/app/components/directries/board-member-directory/board-member-directory-model';
import { MatAutocompleteTrigger, MatSnackBar } from '@angular/material';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { NoDataFoundCaseFeatureName, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-pm-board-members',
  templateUrl: './pm-board-members.component.html',
  styleUrls: ['./pm-board-members.component.scss']
})
export class PmBoardMembersComponent implements OnInit {
  notificationService: NotificationService;
  apiResponceErrorMsg: string = "";
  resData: any;
  boardMembersList: any;
  userList: any;
  filteredUsers: any;
  editMode: boolean = false;
  associationBoardTitles: any[] = [];
  userName: string;
  boardMember;
  userData: UserData;
  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  associationId: string;
  associationName: string;
  userId: string;
  domain: string;
  today = new Date();
  /**Add Board Member */
  frmBoardMember: FormGroup;
  addboardmember: boolean = false;
  btnDisable: boolean = false;
  addRes: any;
  btStartDate: Date;
  btEndDate: Date;
  @ViewChild('btend') btend;
  @ViewChild('btstart') btstart;
  @ViewChild('ptstart') ptstart;
  @ViewChild('ptend') ptend;
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  /*Edit Board member validation*/
  frmEditBoardMember: FormGroup;
  editboardmember: boolean = false;
  editBoardMemberName: string = "";
  editAssociationName: string = "";
  editRes: any;
  btnEditDisable: boolean = false;
  btEditStartDate: Date;
  btEditEndDate: Date;
  @ViewChild('formEditDirective') formEditDirective: FormGroupDirective;

  /*Reset mat auto compelte*/
  @ViewChild('homeOwnerAutoComplete', { read: MatAutocompleteTrigger })
  homeOwnertrigger: MatAutocompleteTrigger;


  @ViewChild('boardMemberAssociationAutoComplete', { read: MatAutocompleteTrigger })
  boardMemberAssociationtrigger: MatAutocompleteTrigger;
  minSdate: string = null;
  isCustomTitleShow: boolean = false;
  id: string;
  positionList: any = [];
  /*For Association Dropdown list*/
  selectedAssociation: any = "All";
  associationDdl: any[] = [];
  associationDdlAutocompleteList: any[] = [];
  positionStartDte: Date;
  cPosition: any;
  globalAssociationModel: GlobalAssociationModel;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  
  isApiResponceCome = false;

  constructor(private service: BoardMemberDirectoryApiService,
    private globalAssociationService: GlobalAssociationService,
    private progressbarService: ProgeressBarService,
    public commonService: CommonService,
    private readonly formBuilder: FormBuilder, private readonly snb: MatSnackBar,
    private readonly appConfig: AppConfig) {
    this.userData = appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.notificationService = new NotificationService(snb);

    //this.getMasterData();
  }

  /*Reset mat auto compelte*/
  ngAfterViewInit() {
    this.homeOwnertrigger.panelClosingActions
      .subscribe(e => {
        if (!(e && e.source)) {
          this.userList = this.userList;
          this.frmBoardMember.controls.homeOwner.setValue('');
          this.homeOwnertrigger.closePanel();
        }
      });

    this.boardMemberAssociationtrigger.panelClosingActions
      .subscribe(e => {
        if (!(e && e.source)) {
          this.frmBoardMember.controls.association.setValue('');
          this.boardMemberAssociationtrigger.closePanel();
          this.associationDdlAutocompleteList = this.associationDdl;
        }
      });
  }

  //Hide For now in html
  filterByAssociation(association) {
    if (association.value === "All") {
      this.associationId = "";
    } else {
      this.associationId = association.value.id;
      this.associationName = association.value.AssociationName;
      this.domain = association.value.Domain;
      //this.getMasterData();
      //this.getBoardMemberDirectory();
    }
  }

  getAssociationDdl() {
    this.service.getAssociation().subscribe(res => {
      this.resData = res;
      if (this.resData.Success === true) {
        this.associationDdl = this.resData.AssociationList;
        this.associationDdlAutocompleteList = this.resData.AssociationList;
        // if (this.associationDdl !== null || this.associationDdl !== undefined) {
        //   this.selectedAssociation = this.associationDdl.find(x => x.id.toLowerCase() === this.associationId.toLowerCase());
        // }
      }
      // this.getMasterData();
      //this.getBoardMemberDirectory();
    },
      (err) => {
        console.log(err);
      }
    )
  }




  ngOnInit() {
    this.createForm();
    this.editForm();
    this.getAssociationDdl();
    this.globalAssociationService.associationSubject.subscribe(res => {
      this.globalAssociationModel = res;
      //this.getMasterData();
      if (res !== 1) {
        this.getBoardMemberDirectory();
      }
    });
  }

  private _filterUsers(value: string) {
    const filterValue = value;
    return this.userList.filter(user => user.UserName.toLowerCase().indexOf(filterValue) === 0);
  }


  displayFn(user) {
    return user ? user.UserName : null;
  }

  changeSDate() {

    if (this.frmBoardMember.controls.boardTermStartDate.value) {
      this.btStartDate = this.frmBoardMember.controls.boardTermStartDate.value;
    }
    if (this.frmEditBoardMember.controls.boardTermStartDate.value) {
      this.btStartDate = this.frmEditBoardMember.controls.boardTermStartDate.value;
      if (this.frmEditBoardMember.controls.boardTermStartDate.value > new Date(this.frmEditBoardMember.controls.boardTermEndDate.value)) {
        this.frmEditBoardMember.controls.boardTermEndDate.setValue('');
      }
      const formPositions = this.frmEditBoardMember.controls.positions.value;
      for (let i = 0; i < formPositions.length; i++) {

        let positionStartDte = new Date(formPositions[i].positionStartDate);
        let positionEndDte = new Date(formPositions[i].positionEndDate);

        if (this.frmEditBoardMember.controls.boardTermStartDate.value > positionStartDte) {
          (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.positionEndDate.reset();
          (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.positionStartDate.reset();
        }

      }
    }
  }

  changeEditSDate() {
    this.btEditStartDate = this.frmEditBoardMember.controls.boardTermStartDate.value;
    let editStDate: any = new Date(this.btEditStartDate);
    let editEndDate: any = new Date(this.btEditEndDate);
    if (editStDate > editEndDate) {
      this.frmEditBoardMember.controls.boardTermEndDate.setValue('');
    }
    this.resetPosition();
  }

  changeEditEDate() {
    this.btEditEndDate = this.frmEditBoardMember.controls.boardTermEndDate.value;
    this.minSdate = this.frmEditBoardMember.controls.boardTermEndDate.value;
    this.resetPosition();
  }

  resetPosition() {
    let editStDate: any = new Date(this.btEditStartDate);
    let editEndDate: any = new Date(this.btEditEndDate);
    const formPositions = this.frmEditBoardMember.controls.positions.value;
    for (let i = 0; i < formPositions.length; i++) {
      let positionStartDte = new Date(formPositions[i].positionStartDate);
      let positionEndDte = new Date(formPositions[i].positionEndDate);
      if (editStDate > positionStartDte) {
        //  console.log('posSdate',(<FormArray>this.frmEditBoardMember.controls.positions).controls[i].value.positionStartDate);
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.positionStartDate.reset();
      }
      if (editEndDate > positionEndDte) {
        // console.log('posSdate',(<FormArray>this.frmEditBoardMember.controls.positions).controls[i].value.positionEndDate);
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.positionEndDate.reset();
      }
    }
  }

  changePositionSDate(pos) {
    this.cPosition = null;
    this.positionStartDte = null;
    let formPositions;
    if (this.frmBoardMember.controls.positions.value) {
      formPositions = this.frmBoardMember.controls.positions.value;
      for (let i = 0; i < formPositions.length; i++) {
        if (i === pos) {
          this.cPosition = pos;
          this.positionStartDte = new Date(formPositions[i].positionStartDate);
        }
      }
    }
    if (this.frmEditBoardMember.controls.positions.value) {
      formPositions = this.frmEditBoardMember.controls.positions.value;
      for (let i = 0; i < formPositions.length; i++) {
        if (i === pos) {
          this.cPosition = pos;
          this.positionStartDte = new Date(formPositions[i].positionStartDate);
        }
      }
    }
  }
  changeEDate() {
    // this.btEndDate = this.frmBoardMember.controls.boardTermEndDate.value;
    // this.frmBoardMember.controls.boardTermStartDate.reset('');
    this.btEndDate = this.frmBoardMember.controls.boardTermEndDate.value;
    let stDate = this.frmBoardMember.controls.boardTermStartDate.value;
    if (stDate > this.btEndDate) {
      this.frmBoardMember.controls.boardTermStartDate.reset('');
    }
  }

  createForm() {
    this.frmBoardMember = this.formBuilder.group({
      descriptions: ['', Validators.maxLength(2000)],
      association: ['', Validators.required],
      boardTermStartDate: ['', Validators.required],
      boardTermEndDate: ['', Validators.required],
      homeOwner: ['', Validators.required],
      positions: this.formBuilder.array([])
    });
  }

  // use for show and hide model
  addboardmemberToggle() {
    if (this.addboardmember) {
      this.addboardmember = false;
    }
    else {
      this.addboardmember = true;
    }
    this.removeAllPositionControl();
    this.addPosition();
  }

  //use for remove position control
  removeAllPositionControl() {
    for (let i = 0; i < this.boardMemberPositions.length; i++) {
      console.log('assd ', i);
      this.removePosition(i);
    }
  }

  //Get List of board member
  getBoardMemberDirectory() {
    this.progressbarService.show();
    this.service.getBoardMembers(this.globalAssociationModel.AssociationId).subscribe((response) => {
      this.progressbarService.hide();
      this.resData = response;
      this.boardMembersList = this.resData.BoardMembersList;
      this.isApiResponceCome = true;
    },
      (error) => {
      }
    );
  }

  onChangeAssociation(event) {
    if (event.source.selected) {
      this.frmBoardMember.controls.homeOwner.setValue('');
      this.getMasterData(event.source.value.id);
    }
  }

  // onChangeAssociation(association) {
  //   this.frmBoardMember.controls.documentCategoryId.setValue('');
  //   this.associationId 
  //   //this.getDocumentCategoryDdl(association.value.id);
  // }


  // use for get master data that is use for bind data in form
  getMasterData(associationId) {
    console.log(associationId);
    //this.progressbarService.show();
    this.service.getMasterData(associationId).subscribe(
      (response) => {
        this.progressbarService.hide();
        console.log(response);
        this.resData = response;
        if (this.resData.Success) {
          this.userList = this.resData.BoardMemberMasters.UserProfiles;
          this.associationBoardTitles = this.resData.BoardMemberMasters.AssociationBoardTitles;
          //this.getBoardMemberDirectory();
          this.filteredUsers = this.frmBoardMember.controls.homeOwner.valueChanges
            .pipe(
              startWith(''),
              map((data) => data ? this._filterUsers(data) : this.userList.slice())
            );
          this.getAssociationTitle();
          if (this.editboardmember === true) {
            let countPosition = this.boardMember.BoardMemberPositions.length;
            if (countPosition > 0) {
              for (let i = 0; i < countPosition; i++) {
                this.editPosition(this.boardMember.BoardMemberPositions[i]);
              }
            }
          }
        }
      },
      (error) => {

      }
    );
  }

  //Use for get association title
  getAssociationTitle() {
    this.associationBoardTitles.map(
      (a) => {
        if (a.BoardTitle === 'Other')
          a.BoardTitle = a.CustomBoardTitleName;
        else
          a.BoardTitle = a.BoardTitle;
        return a;
      });
  }


  // Call after click on add or Edit button
  onSubmit() {
    if (!this.frmBoardMember.valid) {
      console.log('fail');
      return;
    }
    const boardMemberModel = this.createModel();
    console.log("boardMemberModel", boardMemberModel);
    this.btnDisable = true;
    // if (this.editMode)
    //   this.editBoardMember(boardMemberModel);
    // else
    this.addBoardMember(boardMemberModel);
    // }
  }

  //use for Create Board Member model
  createModel() {
    var formSelectedAssociation = this.frmBoardMember.controls.association.value;
    let boardMemberPositions = new Array<BoardMemberPosition>();
    const formPositions = this.frmBoardMember.controls.positions.value;
    for (let i = 0; i < formPositions.length; i++) {
      let boardPosition: BoardMemberPosition = new BoardMemberPosition();
      boardPosition.PositionTitleName = formPositions[i].positionTitle.BoardTitle;
      boardPosition.CustomBoardTitleName = formPositions[i].CustomBoardTitleName;
      boardPosition.PositionTitleId = formPositions[i].positionTitle.AssociationBoardTitleId;
      boardPosition.PositionEndDate = formPositions[i].positionEndDate !== '' ? new Date(formPositions[i].positionEndDate).toUTCString() : '';
      boardPosition.PositionStartDate = new Date(formPositions[i].positionStartDate).toUTCString();
      boardPosition.BoardMemberPositionId = formPositions[i].positionTitle.BoardMemberPositionId;
      boardMemberPositions.push(boardPosition);
    }

    const model: BoardMember = {
      id: this.editMode ? this.boardMember.id : '',
      BoardMemberCoverImagepath: '',
      BoardMemberProfileImagepath: '',
      Description: this.frmBoardMember.controls.descriptions.value,
      BoardMemberUserProfileId: this.editMode ? this.boardMember.BoardMemberUserProfileId : this.frmBoardMember.value.homeOwner.UserProfileId.toString(),
      BoardMemberName: this.editMode ? this.boardMember.BoardMemberName : this.frmBoardMember.value.homeOwner.UserName,
      BoardMemberStartDate: new Date(this.frmBoardMember.value.boardTermStartDate).toUTCString(),
      BoardMemberEndDate: new Date(this.frmBoardMember.value.boardTermEndDate).toUTCString(),
      AssociationId: formSelectedAssociation.id,
      AssociationName: formSelectedAssociation.AssociationName,
      CreatedOn: new Date().toUTCString(),
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      BoardMemberPositions: boardMemberPositions,
      ModifiedByUserId: "",
      ModifiedByUserName: ""
    }
    console.log("model", model);
    return model;
  }

  // use for add board member
  addBoardMember(boardMemberModel: BoardMember) {
    this.service.addBoardMember(boardMemberModel, this.frmBoardMember.controls.association.value.Domain).subscribe(
      (res) => {
        this.btnDisable = false;
        this.addRes = res;
        if (this.addRes.Success === true) {
          this.notificationService.showNotification("Board member saved successfully");
          this.addboardmember = false;
          this.resetForm();
          //this.getMasterData();
          this.getBoardMemberDirectory();
        }
        if (this.addRes.Success === false && this.addRes.Message !== "") {
          this.apiResponceErrorMsg = this.addRes.Message;
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }

  resetForm() {
    this.frmBoardMember.reset();
    this.formDirective.resetForm();
    this.addboardmember = false;
    this.btEndDate = null;
    this.btStartDate = null;
    this.btnDisable = false;
    this.isCustomTitleShow = false;
    this.positionList = [];
    this.associationBoardTitles = [];
    this.removeAllPositionControl();
  }

  get boardMemberPositions() {
    return this.frmBoardMember.get('positions') as FormArray;
  }

  addPosition() {
    this.boardMemberPositions.push(this.formBuilder.group({
      positionTitle: ['', Validators.required],
      positionStartDate: ['', Validators.required],
      positionEndDate: [''],
      CustomBoardTitleName: ['']
    }));
  }

  removePosition(index) {
    this.boardMemberPositions.removeAt(index);
  }

  /**Edit Form */
  editForm() {
    this.frmEditBoardMember = this.formBuilder.group({
      descriptions: ['', Validators.maxLength(2000)],
      boardTermStartDate: ['', Validators.required],
      boardTermEndDate: ['', Validators.required],
      homeOwner: [''],
      positions: this.formBuilder.array([])
    });
  }

  resetEditForm() {
    this.frmEditBoardMember.reset();
    this.formEditDirective.resetForm();
    this.editboardmember = false;
    this.btnEditDisable = false;
    this.btEditEndDate = null;
    this.btEditStartDate = null;
    this.isCustomTitleShow = false;
    this.minSdate = null;
    this.positionList = [];
    this.removeAllEditPositionControl();
  }

  onEditSubmit() {
    // if (!this.frmEditBoardMember.valid) {
    //   return;
    // }
    const boardMemberModel = this.createEditModel();
    this.editBoardMember(boardMemberModel);
  }

  // use for bind data for edit
  boardMemberEdit(boardMember) {
    this.removeAllEditPositionControl();
    this.editboardmember = true;
    this.boardMember = boardMember;
    this.editBoardMemberName = boardMember.BoardMemberName;
    this.editAssociationName = boardMember.AssociationName;
    this.btEditEndDate = boardMember.BoardMemberEndDate
    this.btEditStartDate = boardMember.BoardMemberStartDate// new Date(boardMember.BoardMemberStartDate).toString().split('T')[0];
    this.frmEditBoardMember.controls.boardTermEndDate.setValue(boardMember.BoardMemberEndDate);
    this.frmEditBoardMember.controls.boardTermStartDate.setValue(boardMember.BoardMemberStartDate);
    this.frmEditBoardMember.controls.descriptions.setValue(boardMember.Description);
    this.getMasterData(boardMember.AssociationId);

  }

  editPosition(model: any) {
    console.log("model.BoardMemberPositionId", model.BoardMemberPositionId);
    const position = this.associationBoardTitles.find(a => a.AssociationBoardTitleId.toLowerCase() == model.PositionTitleId.toLowerCase());
    this.editBoardMemberPositions.push(this.formBuilder.group({
      positionStartDate: [model.PositionStartDate, Validators.required],
      positionEndDate: [model.PositionEndDate],
      positionTitle: [position, Validators.required],
      boardMemberPositionId: [model.BoardMemberPositionId],
      CustomBoardTitleName: ['']
    }));
  }

  get editBoardMemberPositions() {
    return this.frmEditBoardMember.get('positions') as FormArray;
  }

  addPositionForEdit() {
    this.editBoardMemberPositions.push(this.formBuilder.group({
      positionTitle: ['', Validators.required],
      positionStartDate: ['', Validators.required],
      positionEndDate: [''],
      CustomBoardTitleName: ['']
    }));
  }

  removePositionForEdit(index) {
    this.editBoardMemberPositions.removeAt(index);
  }

  //use for remove position control
  removeAllEditPositionControl() {
    if (this.editBoardMemberPositions.length > 0) {
      for (let i = 0; i < this.editBoardMemberPositions.length; i++) {
        this.editBoardMemberPositions.removeAt(i);
      }
    }
  }

  //use for edit board member


  editBoardMember(boardMemberModel: BoardMember) {
    if (!this.frmEditBoardMember.valid) {
      console.log(this.frmEditBoardMember);
      return;
    }
    console.log(boardMemberModel);
    let isValid: boolean = true;
    const formEditPositions = this.frmEditBoardMember.controls.positions.value;
    for (let i = 0; i < formEditPositions.length; i++) {
      if (formEditPositions[i].positionTitle.BoardTitle === 'other' && formEditPositions[i].CustomBoardTitleName === '') {
        isValid = false;
      }
    }
    this.btnEditDisable = true;
    if (isValid) {
      this.service.editBoardMember(boardMemberModel).subscribe(
        (res) => {
          this.editRes = res;
          this.btnEditDisable = false;
          if (this.editRes.Success === true) {
            this.notificationService.showNotification("Board member updated successfully");
            this.resetEditForm();
            this.getBoardMemberDirectory();
          } else if (this.editRes.Success === false) {
            this.notificationService.showNotification("Board member not updated");
          }
        }, (error) => {
          console.log(error);
        }
      );
    }
  }

  //use for Create Board Member model
  createEditModel() {
    let editBoardMemberPositions = new Array<BoardMemberPosition>();
    const formEditPositions = this.frmEditBoardMember.controls.positions.value;
    for (let i = 0; i < formEditPositions.length; i++) {
      let boardPosition: BoardMemberPosition = new BoardMemberPosition();
      boardPosition.PositionTitleName = formEditPositions[i].positionTitle.BoardTitle;
      boardPosition.CustomBoardTitleName = formEditPositions[i].positionTitle.CustomBoardTitleName;
      boardPosition.PositionTitleId = formEditPositions[i].positionTitle.AssociationBoardTitleId;
      boardPosition.PositionEndDate = formEditPositions[i].positionEndDate ? new Date(formEditPositions[i].positionEndDate).toUTCString() : null;
      boardPosition.PositionStartDate = new Date(formEditPositions[i].positionStartDate).toUTCString();
      boardPosition.BoardMemberPositionId = formEditPositions[i].boardMemberPositionId;
      editBoardMemberPositions.push(boardPosition);
    }
    console.log("editBoardMemberPositions", editBoardMemberPositions);

    const model: BoardMember = {
      id: this.boardMember.id,
      BoardMemberCoverImagepath: '',
      BoardMemberProfileImagepath: '',
      Description: this.frmEditBoardMember.controls.descriptions.value,
      BoardMemberUserProfileId: this.boardMember.BoardMemberUserProfileId,
      BoardMemberName: this.boardMember.BoardMemberName,
      BoardMemberStartDate: new Date(this.frmEditBoardMember.value.boardTermStartDate).toUTCString(),
      BoardMemberEndDate: new Date(this.frmEditBoardMember.value.boardTermEndDate).toUTCString(),
      AssociationId: this.boardMember.AssociationId,
      AssociationName: this.boardMember.AssociationName,
      CreatedOn: new Date().toUTCString(),
      CreatedByUserId: "",
      CreatedByUserName: "",
      BoardMemberPositions: editBoardMemberPositions,
      ModifiedByUserId: this.userId,
      ModifiedByUserName: this.userName,

    }
    return model;
  }

  /**Auto complete Display Function**/
  displayFnAutoCompleteAssociation(association) {
    if (association != null && association.AssociationName != null) {
      return association.AssociationName;
    } else association;
  }

  /**Auto complete filter on change**/
  onInputChanged(searchStr: string): void {
    this.associationDdlAutocompleteList = [];
    this.associationDdlAutocompleteList = this.associationDdl.filter(option =>
      option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
  }

  changepositionTitle(event, position) {
    this.id = event.value.id;
    if (event.value.BoardTitle === 'other') {
      this.isCustomTitleShow = true;
      this.positionList.push({ 'ID': event.value.id });
      const formPositions = this.frmBoardMember.controls.positions.value;
      for (let i = 0; i < formPositions.length; i++) {
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.setValidators([Validators.required, Validators.maxLength(20)]);
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.updateValueAndValidity();
      }
      const formEditPositions = this.frmEditBoardMember.controls.positions.value;
      for (let i = 0; i < formEditPositions.length; i++) {
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.setValidators([Validators.required, Validators.maxLength(20)]);
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.updateValueAndValidity();
      }
    }
    else {
      this.isCustomTitleShow = false;
      this.positionList.pop({ 'ID': event.value.id });
      const formPositions = this.frmBoardMember.controls.positions.value;
      for (let i = 0; i < formPositions.length; i++) {
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.clearValidators();
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.setValue('');
        (<FormGroup>(<FormArray>this.frmBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.updateValueAndValidity();
      }
      const formEditPositions = this.frmEditBoardMember.controls.positions.value;
      for (let i = 0; i < formEditPositions.length; i++) {
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.clearValidators();
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.setValue('');
        (<FormGroup>(<FormArray>this.frmEditBoardMember.controls.positions).controls[i]).controls.CustomBoardTitleName.updateValueAndValidity();
      }
    }
  }

  getCurrrentPosition(PositionStartDate, PositionEndDate) {
    if (PositionStartDate !== null && PositionEndDate !== null) {
      if (this.today.getTime() >= new Date(PositionStartDate).getTime() || this.today.getTime() <= new Date(PositionEndDate).getTime()) {
        return true;
      }
      else {
        return false;
      }
    } else if (PositionEndDate === null && PositionStartDate !== null) {
      if (new Date(PositionStartDate).getTime() <= this.today.getTime()) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

}
