import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmBoardMembersComponent } from './pm-board-members.component';

describe('PmBoardMembersComponent', () => {
  let component: PmBoardMembersComponent;
  let fixture: ComponentFixture<PmBoardMembersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmBoardMembersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmBoardMembersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
