import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmArcListComponent } from './pm-arc-list.component';

describe('PmArcListComponent', () => {
  let component: PmArcListComponent;
  let fixture: ComponentFixture<PmArcListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmArcListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmArcListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
