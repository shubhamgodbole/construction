import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { fromEvent } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { ARCStatus, DisplayColumnsPM } from 'src/app/components/arc/arc-model';
import { Router, NavigationExtras } from '@angular/router';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { MatPaginator } from '@angular/material';
import { MasterPaginationEnum, Pagination, NoDataFoundCaseFeatureName, DocumentFeatureName, requestSubTypeCount, FeatureName, FeaturePermissions } from 'src/app/shared/Enums/commonEnums';
import { FilterListValues, FeatureNameLocalStorage } from 'src/app/shared/common/models';

@Component({
  selector: 'app-pm-arc-list',
  templateUrl: './pm-arc-list.component.html',
  styleUrls: ['./pm-arc-list.component.scss']
})
export class PmArcListComponent implements OnInit {

  userData: UserData;
  userId: string;
  userName: string;
  role: string;

  //for association dropdown
  associationId: string;
  domain: string;
  associationName: string;
  associationData: any;
  selectedAssociation: string;

  //For filter by key word
  filterByKeyWords: string = "";
  @ViewChild('searchData') searchData: any;
  filter = false;
  isList: boolean;

  //For arc list
  arcList: any;
  arcStatusCount: any;
  count: number;
  arcRequestStatus = ARCStatus;
  //status: string = ARCStatus.All;

  /**For Manage Columns*/
  displayColumnsDdl: any;
  seletedColumns: any[];
  defaultColumnsList: any[];
  /**End For Manage Columns*/

  //for date filter
  dateTo: any;
  dateFrom: any;
  bsRangeValue: Date[] = [];


  globalAssociationModel: GlobalAssociationModel;

  //For Pagination 
  masterPaginationEnum = MasterPaginationEnum;
  TotalRecord: any = MasterPaginationEnum.TotalRecord;
  PageIndex: any = MasterPaginationEnum.PageIndex;
  PageSize: any = MasterPaginationEnum.PageSize;
  pageSkip: number = MasterPaginationEnum.PageIndex;
  pageTake: number = MasterPaginationEnum.PageSize;
  FilterArray: any = [];
  pageOptions = Pagination.PageOptions;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  allCount: number;

  noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;

  //for save data in localstorage
  localStorageFromDate;
  localStorageToDate;
  selectedAssignTo: string = "All";
  assignToDdl = [];

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;
  isApiResponceCome = false;
  constructor(public commonService: CommonService,
    private globalAssociationService: GlobalAssociationService,
    private readonly appConfig: AppConfig, private router: Router, private progressbarService: ProgeressBarService,
    public service: ArcRequestApiService) {
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.role = this.userData.Role;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.getAssociation();
  }

  ngOnInit() {
    this.globalAssociationService.associationSubject.subscribe(res => {
      this.globalAssociationModel = res;
      if (res !== 1) {
        this.getLocalStorageData();
      }
    });

    this.getAssignToUser();

    /**For Manage Columns*/
    this.seletedColumns = DisplayColumnsPM.AllColumnsList;
    this.displayColumnsDdl = DisplayColumnsPM.AllSelectedColumnsList;
    //Filter By Key word
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.getData();
      });
    //this.getData();
  }

  getLocalStorageData() {
    //get local storage filter data
    var data: FilterListValues = this.commonService.getFilterDataFromLocalStorge();
    if (data !== null && data !== undefined) {
      if (data.FeatureName === FeatureNameLocalStorage.ARCPM) {
        this.service.listStatus = data.Status;
        this.filterByKeyWords = data.SearchKey;
        this.dateFrom = data.DateFrom !== null && data.DateFrom !== undefined && data.DateFrom !== '' ? new Date(data.DateFrom).toUTCString() : '';
        this.dateTo = data.DateTo !== null && data.DateTo !== undefined && data.DateTo !== '' ? new Date(data.DateTo).toUTCString() : '';
        this.filter = data.Filter;
        if (this.dateFrom !== "" && this.dateFrom !== null && this.dateFrom !== undefined && this.dateTo !== "" && this.dateTo !== null && this.dateTo !== undefined) {
          this.bsRangeValue = [new Date(data.DateFrom), new Date(data.DateTo)];
        } else {
          this.bsRangeValue = [];
        }
      }
    } else {
      this.service.listStatus = this.arcRequestStatus.All;
    }

    this.statusChange(this.service.listStatus);
  }

  filterDataLocalstorage() {
    var filtersModel: FilterListValues = {
      SearchKey: this.filterByKeyWords,
      DateTo: this.localStorageToDate,
      DateFrom: this.localStorageFromDate,
      Category: '',
      Priority: '',
      AssignTo: this.selectedAssignTo,
      Status: this.service.listStatus,
      ViolationFieldType: "",
      Filter: this.filter,
      FeatureName: FeatureNameLocalStorage.ARCPM
    }
    return filtersModel;
  }

  //for assign to user
  getAssignToUser() {
    let resData;
    this.commonService.getPMList().subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.assignToDdl = resData.PMUser;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  //for clear filter
  clearFilter() {
    if (this.filterByKeyWords === "" && (this.bsRangeValue === null || this.bsRangeValue === [] || this.bsRangeValue.length === 0)) {
      return
    }
    this.filterByKeyWords = "";
    this.bsRangeValue = [];
    this.dateTo = "";
    this.dateFrom = "";
    this.localStorageFromDate = "";
    this.localStorageToDate = "";
    this.selectedAssignTo = "All";
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.getData();
  }

  addClass() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  statusChange(s) {
    this.service.listStatus = s;
    /**For Manage Columns*/
    if (this.arcRequestStatus.Submitted === s) {
      this.seletedColumns = DisplayColumnsPM.SubmittedColumnsList;
      this.displayColumnsDdl = DisplayColumnsPM.SubmittedSelectedColumnsList;
    } else if (this.arcRequestStatus.All === s) {
      this.seletedColumns = DisplayColumnsPM.AllColumnsList;
      this.displayColumnsDdl = DisplayColumnsPM.AllSelectedColumnsList;
    } else if (this.arcRequestStatus.Approved === s) {
      this.seletedColumns = DisplayColumnsPM.ApprovedColumnsList;
      this.displayColumnsDdl = DisplayColumnsPM.ApprovedSelectedColumnsList;
    } else if (this.arcRequestStatus.Cancelled === s) {
      this.seletedColumns = DisplayColumnsPM.CancelledColumnsList;
      this.displayColumnsDdl = DisplayColumnsPM.CancelledSelectedColumnsList;
    } else if (this.arcRequestStatus.WorkCompleted === s) {
      this.seletedColumns = DisplayColumnsPM.CompletedColumnsList;
      this.displayColumnsDdl = DisplayColumnsPM.CompletedSelectedColumnsList;
    } else if (this.arcRequestStatus.Denied === s) {
      this.seletedColumns = DisplayColumnsPM.DeniedColumnsList;
      this.displayColumnsDdl = DisplayColumnsPM.DeniedSelectedColumnsList;
    }
    /**End For Manage Columns*/
    this.setPaginationVariables();
    this.getData();
    //get list count
    this.getListCount();
  }

  
  onClickChangeStatus(s) {
    if (this.service.listStatus === s) {
      return;
    } else {
      this.statusChange(s);
    }
  }

  //Get Count of list
  getListCount() {
    var model = this.commonService.getListModel(this.globalAssociationModel.AssociationId, this.userId, this.role);
    let resData
    this.commonService.getListcount(model, DocumentFeatureName.ARCRequest, requestSubTypeCount.Count).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success) {
        this.arcStatusCount = resData.caseRequestListResults[0].ARCStatusCount;
        console.log('this.arcStatusCount ', this.arcStatusCount);
      } else {
        this.arcStatusCount = resData.caseRequestListResults[0].ARCStatusCount;
      }
    });
  }

  getData() {
    this.isList = false;
    let resData;
    let resFilterByKeyWords = this.filterByKeyWords;
    let resStatus = this.service.listStatus === ARCStatus.All ? "" : this.service.listStatus;
    let resAssignTo = this.selectedAssignTo === "All" ? "" : this.selectedAssignTo;
    this.progressbarService.show();
    this.service.getFilteredARCRequestForPM(this.globalAssociationModel.AssociationId, this.role, resStatus, resFilterByKeyWords, this.dateTo, this.dateFrom, resAssignTo, this.pageSkip, this.pageTake).subscribe(res => {
      resData = res;
      this.isApiResponceCome = true;
      this.progressbarService.hide();
      console.log('cm res ', res);
      if (resData.Errors.length == 0) {
        this.isList = true;
        this.arcList = resData.caseRequestListResults[0].arcRequestList;
        this.allCount = resData.caseRequestListResults[0].ResultCount;
        if (this.arcList !== null) {
          this.setPaginationData(this.arcList);
          this.SetDetailsOfNextPreviousOnDetailsPage();
        }
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  //for filter by date
  geDatafilterByDateRange(event) {
    if (event !== null && event !== undefined && event.length > 0) {
      if (event[0] !== null && event[0] !== undefined && event[1] !== null && event[1] !== undefined) {
        this.dateFrom = new Date(event[0]).toUTCString();
        this.localStorageFromDate = event[0];
        this.dateTo = new Date(event[1]).toUTCString();
        this.localStorageToDate = event[1];
        this.getData();
      }
    } else if (event === null && this.bsRangeValue.length !== 0) {
      this.bsRangeValue = [];
      this.dateFrom = "";
      this.dateTo = "";
      this.getData();
    }
  }

  
  getAssociationAddressForList(request) {
    var associationUnit = {
      AssociationUnitAddress1: request.CreatedByUnitAddress1,
      AssociationUnitAddress2: request.CreatedByUnitAddress2,
      AssociationUnitCity: request.CreatedByUnitCity,
      AssociationUnitState: request.CreatedByUnitState,
      AssociationUnitZip: request.CreatedByUnitZip
    }
    return this.commonService.getAssociationAddressForList(associationUnit);
  }




  arcDetail(id, caseId) {
    this.service.caseId = caseId;
    this.service.arcRequestId = id;
    let navigationExtras: NavigationExtras = {
      queryParams: {
        "id": id
      }
    };
    //set localstorage data
    this.commonService.setFilterDataInLocalStorge(this.filterDataLocalstorage());
    this.router.navigate([AppRouteUrl.mainArcDetailPMRouteUrl], navigationExtras);
  }

  //Hide For now in html
  //for association dropdown
  changeAssociation(event) {
    this.associationId = event.value.id;
    this.associationName = event.value.AssociationName;
    this.domain = event.value.Domain;
    this.getData();
  }

  getAssociation() {
    let res;
    this.commonService.getAssociation().subscribe(response => {
      res = response;
      if (res.Success) {
        this.associationData = res.AssociationList;
        //Hide For now in html
        //this.selectedAssociation = this.associationData.find(x => x.id === this.associationId.toLowerCase());
      }
      else
        console.log(res.Errors[0].message);
    },
      (err) => {
        console.log(err);
      });
  }

  /**For Manage Columns*/
  isVisible(col) {
    return this.seletedColumns.indexOf(col) >= 0
  }
  /**End For Manage Columns*/

  //For Pagination
  setMasterOfPagination() {
    this.PageIndex = MasterPaginationEnum.PageIndex;
    this.PageSize = MasterPaginationEnum.PageSize;
    if (this.paginator !== undefined) {
      this.paginator.pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._pageIndex = MasterPaginationEnum.PageIndex;
      this.paginator._changePageSize(MasterPaginationEnum.PageSize);
    }
  }
  //For Pagination
  setPaginationData(arcList) {
    this.TotalRecord = this.allCount;
    this.FilterArray = arcList;
    // var pageStartIndex = (this.PageIndex * this.PageSize) + 1;
    // var pageEndIndex = (this.PageIndex * this.PageSize) + this.PageSize;
    // this.FilterArray = arcList.slice(pageStartIndex - 1, pageEndIndex);
  }

  setPaginationVariables() {
    this.pageSkip = MasterPaginationEnum.PageIndex;
    this.pageTake = MasterPaginationEnum.PageSize;
    this.setMasterOfPagination();
  }

  //For Pagination
  pageChangeEvent(clickObj: any): void {
    this.pageSkip = clickObj.pageIndex * clickObj.pageSize
    this.pageTake = clickObj.pageSize;
    console.log("pageSkip", this.pageSkip);
    console.log("pageTake", this.pageTake);
    this.getData();
    var elmnt: any = document.getElementById("contentTable");
    if (elmnt !== null) {
      elmnt.scrollTo(0, 0);
    }
  }

  //For Next Previous
  SetDetailsOfNextPreviousOnDetailsPage() {
    localStorage.removeItem('ARCList');
    var temp: any = [];
    this.arcList.forEach(element => {
      temp.push({
        id: element.id,
        caseid: element.CaseId,
        status: element.ARCStatus
      });
    });
    localStorage.setItem('ARCList', JSON.stringify(temp));
  }

  createARC() {
    this.router.navigate([AppRouteUrl.mainCreateArcPMRouteUrl]);
  }

}
