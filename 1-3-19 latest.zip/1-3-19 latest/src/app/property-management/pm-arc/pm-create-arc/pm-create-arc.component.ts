import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { FormBuilder, FormGroupDirective, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { arcCase, ARCRquestVendorDetail, ARCRequest, CaseOriginatingType, IsAuthorized, AssignedPartyType } from 'src/app/components/arc/arc-model';
import { TypeOfDocument, StatusReason, ImageNameEnums, DownloadfeatureName, SubCaseTypeEnum, CasePriority, DocumentFeatureName, CaseTypeEnum, FeatureName, FeaturePermissions, SourceType, TriggerType, AudienceType } from 'src/app/shared/Enums/commonEnums';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CommonService } from 'src/app/services/common.service';
import { Guid } from 'guid-typescript';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { RequestDocument } from 'src/app/components/meeting/meeting-model';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
import { MatAutocompleteTrigger, MatSnackBar } from '@angular/material';
import { DropdownModelAssociationUnit } from 'src/app/shared/common/models';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { Subscription } from 'rxjs';
import { UserData } from 'src/app/shared/models/user-data-model';
import { EmailtocaseService } from 'src/app/services/emailtocase.service';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { Location } from '@angular/common';
import { AcceptFilesConstant, CommonConstant } from 'src/app/shared/common/constant.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';

@Component({
  selector: 'app-pm-create-arc',
  templateUrl: './pm-create-arc.component.html',
  styleUrls: ['./pm-create-arc.component.scss']
})
export class PmCreateArcComponent implements OnInit {

  isDisplayVendor: boolean = false;
  btStartDate: any;
  isBtnDisabled: boolean = false;
  userData: UserData;
  associationId: string;
  userId: string;
  associationName: string;
  associationUnitData: any;
  userName: string;
  domain: string;
  FirstName: string;
  LastName: string;
  fileData: RequestDocument[] = new Array<RequestDocument>();
  planDocuments: RequestDocument[] = new Array<RequestDocument>();
  specificationDocuments: RequestDocument[] = new Array<RequestDocument>();
  detailDocuments: RequestDocument[] = new Array<RequestDocument>();
  role: string;
  frmCreateARCRequest: FormGroup;
  frmCreateVendor: FormGroup;
  isArcGuideLine: boolean = true;
  arcGuideLineDocument: any;
  apiResponseErrorMessage: string = "";
  @ViewChild('startdate') startdate;
  @ViewChild('enddate') enddate;
  @ViewChild('arcFormDirective') arcFormDirective: FormGroupDirective;
  @ViewChild('vendorFormDirective') vendorFormDirective: FormGroupDirective;
  assignToDdl: any = [];

  //For Query string;
  querySubcription: Subscription;

  arcListUrl = AppRouteUrl.mainArcHORouteUrl;
  //for image enum
  imageNameEnums = ImageNameEnums;

  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentDetails: boolean = false;

  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;

  //global association
  globalAssociationModel: GlobalAssociationModel;
  //association drop down autocomplate
  associationDdl: any[] = [];
  associationAutoCompleteDdl: any[];
  /*Reset mat auto compelte*/

  @ViewChild('associationAutoComplete', { read: MatAutocompleteTrigger })
  associationTrigger: MatAutocompleteTrigger;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  // associationTrigger: MatAutocompleteTrigger;
  // @ViewChild('associationAutoComplete') set content(content: MatAutocompleteTrigger) {
  //   associationTrigger: content
  // }


  //association unit drop down autocomplate
  associationUnitDdl: any[] = [];
  associationAutoCompleteUnitDdl: any[];
  /*Reset mat auto compelte*/
  @ViewChild('associationUnitAutoComplete', { read: MatAutocompleteTrigger })
  associationUnitTrigger: MatAutocompleteTrigger;
  selectedAssociationId: string;

  /*Reset mat auto compelte member */
  memberListDdl: any[] = [];
  memberListDdlAutocompleteList: any[] = [];
  @ViewChild('serviceRequestmemberListDdlAutoComplete', { read: MatAutocompleteTrigger })
  serviceRequestmemberListDdlUnittrigger: MatAutocompleteTrigger;

  message = "No ARC GuideLine Document";
  notificationService: any;
  companyCode: string;


  /*dg for email to case */
  documents: any;
  emailMessage: any;
  cases: any;
  isEmailToCase: boolean = false;
  isApiResponceCome = false;

  //For Send Notification
  featureId: string;
  pmCompanyAssociationMappingId: string = "";
  featureName: string;

  isAddForGlobalCreate: boolean = false;

  constructor(private globalAssociationService: GlobalAssociationService,
    public commonService: CommonService,
    private formBuilder: FormBuilder,
    private service: ArcRequestApiService,
    private emailNotification: EmailNotificationService,
    private emailtocaseService: EmailtocaseService,
    private progressbarService: ProgeressBarService,
    private serviceRequestService: ServiceRequestService,
    private readonly snb: MatSnackBar,
    private _location: Location,
    private route: ActivatedRoute,
    private router: Router,
    private readonly appConfig: AppConfig) {
    this.notificationService = new NotificationService(snb);
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain = this.userData.UserAssociations[0].Domain;
    this.FirstName = this.userName.split(' ')[0];
    this.LastName = this.userName.split(' ')[1];
    this.role = this.userData.Role;
    this.companyCode = this.userData.UserAssociations[0].CompanyCode;
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.ARC) {
          this.featureName = feature.Name
          this.featureId = feature.FeatureId
        }
      });
  }

  ngOnInit() {
    this.createARCForm();
    this.createVenderForm();
    this.globalAssociationService.associationSubject.subscribe(res => {
      this.globalAssociationModel = res;
      if (res !== 1) {
        this.getARCGuideLine();
        this.companyCode = this.globalAssociationModel.CompanyCode;
      }
    });
    //to open add dialog
    this.querySubcription = this.route.queryParams.subscribe(params => {
      let caseId = params["caseId"];
      if (caseId) {
        this.isEmailToCase = true;
        this.isArcGuideLine = false;
        setTimeout(() => {
          this.getCaseDetails(caseId);
        }, 50);

      } else {
        this.isEmailToCase = false;
        let isAdd = params["isAdd"];
        if (isAdd === "true") {
          this.isAddForGlobalCreate = true;
          this.isArcGuideLine = false;
        } else {
          this.isAddForGlobalCreate = false;
        }
      }
    });
    this.getAssociationDdl();
    this.getAssignToUser();
  }



  createARCForm() {
    this.frmCreateARCRequest = this.formBuilder.group({
      association: ['', Validators.required],
      associationUnit: ['', Validators.required],
      title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      cost: ['', [Validators.required, Validators.maxLength(15), ValidationService.noWhiteSpace]],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(1), ValidationService.noWhiteSpace]],
      workType: ['homeOwner'],
      memberName: ['', Validators.required],
      assignTo: ['', Validators.required]
    });

    //this.getAllAssociationUnit();
  }

  createVenderForm() {
    this.frmCreateVendor = this.formBuilder.group({
      vendorName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
      address1: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(100), ValidationService.noWhiteSpace]],
      address2: ['', [Validators.minLength(1), Validators.maxLength(100), Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      email: ['', [Validators.required, ValidationService.emailValidator]],
      phone: ['', [Validators.required, Validators.minLength(13), Validators.maxLength(13), ValidationService.noWhiteSpace]],
      city: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(15), ValidationService.noWhiteSpace]],
      state: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2), ValidationService.noWhiteSpace]],
      zipCode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10), ValidationService.noWhiteSpace]],
    });
  }

  setMobileNumber(event) {
    let ctrlValue = this.frmCreateVendor.controls.phone.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmCreateVendor.controls.phone.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmCreateVendor.controls.phone.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmCreateVendor.controls.phone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }
  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }


  arcGuildLineToggle() {
    if (this.isArcGuideLine) {
      this.isArcGuideLine = false;
    }
    else {
      this.isArcGuideLine = true;
    }
    this.resetFrom();
  }


  changeDiv(text) {
    if (text === 'vendor') {
      this.isDisplayVendor = true;
    }
    else {
      this.isDisplayVendor = false;
      this.frmCreateVendor.reset();
      if (this.vendorFormDirective !== undefined) {
        this.vendorFormDirective.resetForm();
      }
    }

  }


  validateDate() {
    const startDate = new Date(this.frmCreateARCRequest.controls.startDate.value);
    const endDate = new Date(this.frmCreateARCRequest.controls.endDate.value);
    if (startDate.getTime() > endDate.getTime()) {
      this.apiResponseErrorMessage = "End date must be greater than start date.";
      return;
    }
  }

  onSubmit() {
    let resData;
    if (!this.frmCreateARCRequest.valid) {
      this.validateDate();
      return;
    }
    if (this.isDisplayVendor && !this.frmCreateVendor.valid) {
      this.validateDate();
      document.getElementById('uploadbtn').click();
      return;
    }
    var Case = this.createCaseModel();
    var arc = this.createARCModel();
    this.fileData = this.fileData.concat(this.planDocuments);
    this.fileData = this.fileData.concat(this.detailDocuments);
    this.fileData = this.fileData.concat(this.specificationDocuments);
    this.isBtnDisabled = true;
    if (this.isEmailToCase === true) {
      let CaseRequest = {
        Case: Case,
        ARCRequests: arc,
        TypeOfDocument: TypeOfDocument.CaseDocuments,
        AssociationId: this.frmCreateARCRequest.value.association.id,
        Domain: this.frmCreateARCRequest.value.association.Domain,
        Document: null,
      };
      console.log("CaseRequest", CaseRequest);
      this.emailtocaseService.createEmailToCase(CaseRequest).subscribe(
        (response: any) => {
          this.isBtnDisabled = false;
          if (response.success === true) {
            this.resetFrom();
            this.notificationService.showNotification("ARC saved Successfully");
            this._location.back();
            //this.router.navigate([AppRouteUrl.mainEmailToCaseRouteUrl]);
          } else if (response.Success === false) {
            this.notificationService.showNotification("Not Save");
          } else {
            this.notificationService.showNotification("Not Save");
          }
        });
    } else {
      this.service.createARCRequest(Case, this.fileData, arc, TypeOfDocument.CaseDocuments, this.domain).subscribe(response => {
        resData = response;
        this.isBtnDisabled = false;
        if (resData.caseRequestListResults[0].Success === true) {
          this.notificationService.showNotification("ARC Request Saved Successfully");
          this.arcDetail(resData.caseRequestListResults[0].RequestId, "");
          //this.router.navigate([AppRouteUrl.mainArcPMRouteUrl]);
        }
        this.resetFrom();
        this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
          SourceType.Web, FeatureName.ARC, TriggerType.Create,
          AudienceType.PropertyManager).subscribe(res => {
            console.log(res);
          });
      });
    }
  }

  // on file upload for Plan
  onUploadPlan(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.planDocuments.push({
            ImageId: Guid.create().toString(),
            InputStream: event.target.result,
            Name: evt.target.files[i].name,
            MediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            FileSize: evt.target.files[i].size.toString(),
            DocumentId: '',
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  // remove uploaded doc for plan
  removePlanDoc(imageId) {
    this.planDocuments = this.planDocuments.filter(a => a.ImageId !== imageId);
  }

  // on file upload for Specification
  onUploadSpecification(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.specificationDocuments.push({
            ImageId: Guid.create().toString(),
            InputStream: event.target.result,
            Name: evt.target.files[i].name,
            MediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")).toString(),
            FileSize: evt.target.files[i].size.toString(),
            DocumentId: '',
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  // remove uploaded doc for Specification
  removeSpecificationDoc(id) {
    this.specificationDocuments = this.specificationDocuments.filter(a => a.ImageId !== id);
  }


  // on file upload for Detail
  onUploadDetail(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.detailDocuments.push({
            ImageId: Guid.create().toString(),
            InputStream: event.target.result,
            Name: evt.target.files[i].name,
            MediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")).toString(),
            FileSize: evt.target.files[i].size.toString(),
            DocumentId: '',
            CreatedByUserName: this.userName
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  // remove uploaded doc for Detail
  removeDetailDoc(id) {
    this.detailDocuments = this.detailDocuments.filter(a => a.ImageId !== id);
  }


  createCaseModel() {
    let model: arcCase = {
      id: this.isEmailToCase === true ? this.cases.id : '',
      Title: this.frmCreateARCRequest.controls.title.value,
      Description: this.frmCreateARCRequest.controls.description.value,
      CreatedByUserId: this.userId,
      CaseType: CaseTypeEnum.Homeowners,
      SubCaseType: SubCaseTypeEnum.ARCRequest,
      CasePriority: CasePriority.Medium,
      CaseCategory: CaseTypeEnum.ARC,
      CaseSubCategory: CaseTypeEnum.ARC,
      CaseOriginatingType: CaseOriginatingType.Website,
      AssociationId: this.frmCreateARCRequest.value.association.id,
      AssociationName: this.frmCreateARCRequest.value.association.AssociationName,
      AssociationUnitId: this.frmCreateARCRequest.value.associationUnit.CreatedByUnitId,
      CreatedByUserName: this.userName,
      StatusReason: StatusReason.Submitted,
      AssignedPartyType: AssignedPartyType.PROPVIVO,
      AssignedTo: this.frmCreateARCRequest.value.assignTo.UserName,
      IsAuthorized: IsAuthorized.Yes,
      CompanyCode: this.frmCreateARCRequest.value.association.CompanyCode,//this.companyCode,
      UserProfileId: this.frmCreateARCRequest.value.memberName.UserProfileId,
      UserName: this.frmCreateARCRequest.value.memberName.UserName,
      CaseDocuments: this.isEmailToCase === true ? this.cases.CaseDocuments : null
    }
    return model;
  }

  createARCModel() {
    const arcRquestVendorDetail: ARCRquestVendorDetail = {
      VendorName: this.frmCreateVendor.controls.vendorName.value,
      VendorEmail: this.frmCreateVendor.controls.email.value,
      VendorPhone: this.frmCreateVendor.controls.phone.value,
      VendorAddress1: this.frmCreateVendor.controls.address1.value,
      VendorAddress2: this.frmCreateVendor.controls.address2.value,
      VendorState: this.frmCreateVendor.controls.state.value,
      VendorCity: this.frmCreateVendor.controls.city.value,
      VendorZip: this.frmCreateVendor.controls.zipCode.value
    };

    let model: ARCRequest = {
      ProjectStartDate: new Date(this.frmCreateARCRequest.controls.startDate.value).toUTCString(),
      ProjectEndDate: new Date(this.frmCreateARCRequest.controls.endDate.value).toUTCString(),
      ProjectEstimatedCost: this.frmCreateARCRequest.controls.cost.value,
      CreatedByUnitAddress1: this.frmCreateARCRequest.value.associationUnit.CreatedByUnitAddress1,
      CreatedByUnitAddress2: this.frmCreateARCRequest.value.associationUnit.CreatedByUnitAddress2,
      CreatedByUnitCity: this.frmCreateARCRequest.value.associationUnit.CreatedByUnitCity,
      CreatedByUnitState: this.frmCreateARCRequest.value.associationUnit.CreatedByUnitState,
      CreatedByUnitZip: this.frmCreateARCRequest.value.associationUnit.CreatedByUnitZip,
      CreatedByUnitNumber: this.frmCreateARCRequest.value.associationUnit.CreatedByUnitNumber,
      ARCRquestVendorDetail: this.isDisplayVendor ? arcRquestVendorDetail : null
    }
    return model;
  }

  resetFrom() {
    this.frmCreateARCRequest.reset();
    this.frmCreateVendor.reset();
    if (this.arcFormDirective !== undefined) {
      this.arcFormDirective.resetForm();
    }
    this.fileData = [];
    this.planDocuments = [];
    this.detailDocuments = [];
    this.specificationDocuments = [];
    this.frmCreateARCRequest.controls.workType.setValue('homeOwner');
    this.isDisplayVendor = false;
    if (this.vendorFormDirective !== undefined) {
      this.vendorFormDirective.resetForm();
    }

  }

  getARCGuideLine() {
    let resData;
    this.service.getARCGuideLine(this.globalAssociationModel.AssociationId, this.globalAssociationModel.Domain).subscribe(response => {
      resData = response;
      this.isApiResponceCome = true;
      this.arcGuideLineDocument = resData.RequestDetail.Document;
    })
  }

  //for assign to user
  getAssignToUser() {
    let resData;
    this.commonService.getPMList().subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.assignToDdl = resData.PMUser;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  changeSDate() {
    this.btStartDate = this.frmCreateARCRequest.controls.startDate.value;
  }

  downloadDocument(filename, domain) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(domain, filename, DocumentFeatureName.ARCRequest,
      DownloadfeatureName.ARCGuidLineDownload).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          this.commonService.downloadFile(resData.DocumentPath).subscribe(
            (response) => {
              let dataType = response.type;
              let binaryData = [];
              binaryData.push(response);
              let downloadLink = document.createElement('a');
              downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
              if (filename)
                downloadLink.setAttribute('download', filename);
              document.body.appendChild(downloadLink);
              downloadLink.click();
            }
          );
        }
        else if (resData.Success === false) {
          this.notificationService.showNotification("Document not found");
        }
      });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(document.Domain, document.DocumentName, DocumentFeatureName.ARCRequest, DownloadfeatureName.ARCGuidLineDownload).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image");
      }
    });
  }

  //For Association DDL
  getAssociationDdl() {
    let resData;
    this.commonService.getAssociation().subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.associationDdl = resData.AssociationList;
        this.associationAutoCompleteDdl = resData.AssociationList;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  /**Auto complete Display Function**/
  displayFnAutoComplete(association) {
    if (association != null && association.AssociationName != null) {
      return association.AssociationName;
    } else return association;
  }

  /**Auto complete filter on change**/
  onInputChanged(searchStr: string): void {
    this.associationAutoCompleteDdl = [];
    this.associationAutoCompleteDdl = this.associationDdl.filter(option =>
      option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
  }

  //for clear association drop down
  onFocusOut(searchStr) {
    console.log(event);
    if (this.associationTrigger !== undefined) {
      this.associationTrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.associationAutoCompleteDdl = this.associationDdl;
            this.frmCreateARCRequest.controls.association.setValue('');
            this.associationTrigger.closePanel();

            this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
            this.frmCreateARCRequest.controls.associationUnit.setValue('');
            this.associationUnitTrigger.closePanel();

            this.memberListDdl = [];
            this.memberListDdlAutocompleteList = this.memberListDdl;
            this.frmCreateARCRequest.controls.memberName.setValue('');
            this.serviceRequestmemberListDdlUnittrigger.closePanel();
          }


        });
      this.associationAutoCompleteDdl = this.associationDdl.filter(option =>
        option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
      if (this.associationAutoCompleteDdl.length === 0) {
        this.associationAutoCompleteDdl = this.associationDdl;
        this.frmCreateARCRequest.controls.association.setValue('');

        this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
        this.frmCreateARCRequest.controls.associationUnit.setValue('');

        this.frmCreateARCRequest.controls.memberName.setValue('');
        this.memberListDdlAutocompleteList = this.memberListDdl;
      }
    }
  }

  onChangeAssociation(event) {
    console.log("event", event);
    let resData;
    if (event.isUserInput === true) {
      this.selectedAssociationId = event.source.value.id;
      // else if (this.isEmailToCase) {
      //   this.selectedAssociationId = event;
      // }
      this.associationUnitDdl = [];
      this.associationAutoCompleteUnitDdl = [];
      this.frmCreateARCRequest.controls.associationUnit.setValue('');

      this.memberListDdl = [];
      this.memberListDdlAutocompleteList = [];
      this.frmCreateARCRequest.controls.memberName.setValue('');

      this.getAllAssociationUnitByAssociationId(this.selectedAssociationId)

      // this.commonService.getAllAssociationUnitByAssociation(this.selectedAssociationId).subscribe(res => {
      //   resData = res;
      //   if (resData.AssociationUnit !== null && resData.AssociationUnit !== undefined && resData.AssociationUnit.length > 0) {
      //     let associationUnits = resData.AssociationUnit;
      //     associationUnits.map(associationUnit => {
      //       let unitAddress = this.commonService.getFullAssociationAddress(associationUnit);
      //       if (unitAddress !== null && unitAddress !== undefined) {
      //         let dropdownModelAssociationUnit = new DropdownModelAssociationUnit();
      //         dropdownModelAssociationUnit.CreatedByUnitAddress1 = associationUnit.AssociationUnitAddress1;
      //         dropdownModelAssociationUnit.CreatedByUnitAddress2 = associationUnit.AssociationUnitAddress2;
      //         dropdownModelAssociationUnit.CreatedByUnitCity = associationUnit.AssociationUnitCity;
      //         dropdownModelAssociationUnit.CreatedByUnitState = associationUnit.AssociationUnitState;
      //         dropdownModelAssociationUnit.CreatedByUnitId = associationUnit.id;
      //         dropdownModelAssociationUnit.CreatedByUnitZip = associationUnit.AssociationUnitZip;
      //         dropdownModelAssociationUnit.CreatedByUnitNumber = associationUnit.AssociationUnitNumber;
      //         dropdownModelAssociationUnit.Text = unitAddress;
      //         this.associationUnitDdl.push(dropdownModelAssociationUnit);
      //       }
      //     });
      //     this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
      //   }
      // })
    }
  }
  /*dg for email to case and also use for Create ARC*/
  getAllAssociationUnitByAssociationId(associationId) {
    let resData;
    this.commonService.getAllAssociationUnitByAssociation(associationId).subscribe(res => {
      resData = res;
      if (resData.AssociationUnit !== null && resData.AssociationUnit !== undefined && resData.AssociationUnit.length > 0) {
        let associationUnits = resData.AssociationUnit;
        associationUnits.map(associationUnit => {
          let unitAddress = this.commonService.getFullAssociationAddress(associationUnit);
          if (unitAddress !== null && unitAddress !== undefined) {
            let dropdownModelAssociationUnit = new DropdownModelAssociationUnit();
            dropdownModelAssociationUnit.CreatedByUnitAddress1 = associationUnit.AssociationUnitAddress1;
            dropdownModelAssociationUnit.CreatedByUnitAddress2 = associationUnit.AssociationUnitAddress2;
            dropdownModelAssociationUnit.CreatedByUnitCity = associationUnit.AssociationUnitCity;
            dropdownModelAssociationUnit.CreatedByUnitState = associationUnit.AssociationUnitState;
            dropdownModelAssociationUnit.CreatedByUnitId = associationUnit.id;
            dropdownModelAssociationUnit.CreatedByUnitZip = associationUnit.AssociationUnitZip;
            dropdownModelAssociationUnit.CreatedByUnitNumber = associationUnit.AssociationUnitNumber;
            dropdownModelAssociationUnit.Text = unitAddress;
            this.associationUnitDdl.push(dropdownModelAssociationUnit);
          }
        });
        this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
      }
    })
  }


  /**Auto complete association Unit Display Function**/
  displayFnAutoCompleteUnit(associationUnit) {
    if (associationUnit != null) {
      return associationUnit.Text;
    } else return associationUnit;
  }

  /**Auto complete association Unit filter change**/
  onInputUnitChanged(searchStr: string): void {
    this.associationAutoCompleteUnitDdl = [];
    this.associationAutoCompleteUnitDdl = this.associationUnitDdl.filter(option =>
      option.Text.toLowerCase().includes(searchStr.toLowerCase()));
  }

  //for clear association Unit drop down
  onFocusOutUnit(searchStr) {
    if (this.associationUnitTrigger !== undefined) {
      this.associationUnitTrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
            this.frmCreateARCRequest.controls.associationUnit.setValue('');
            this.associationUnitTrigger.closePanel();

            this.memberListDdl = [];
            console.log("onFocusOutUnitassociationUnitTrigger");
            this.memberListDdlAutocompleteList = [];
            this.memberListDdlAutocompleteList = this.memberListDdl;
            this.frmCreateARCRequest.controls.memberName.setValue('');
            this.serviceRequestmemberListDdlUnittrigger.closePanel();
          }
        });
      this.associationAutoCompleteUnitDdl = this.associationUnitDdl.filter(option =>
        option.Text.toLowerCase().includes(searchStr.toLowerCase()));
      if (this.associationAutoCompleteUnitDdl.length === 0) {
        console.log("onFocusOutUnit");
        this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
        this.frmCreateARCRequest.controls.associationUnit.setValue('');

        this.frmCreateARCRequest.controls.memberName.setValue('');
        this.memberListDdlAutocompleteList = this.memberListDdl;
      }


    }
  }

  onChangeAssociationUnit(event) {
    let resData;
    if (event.isUserInput === true) {
      console.log("call change");
      this.memberListDdl = [];
      this.memberListDdlAutocompleteList = [];
      this.frmCreateARCRequest.controls.memberName.setValue('');
      console.log('selectedAssociationId ', this.selectedAssociationId);
      console.log("event.source.value.CreatedByUnitId", event.source.value.CreatedByUnitId);
      //this.getMemberList(this.selectedAssociationId, event.source.value.CreatedByUnitId);
      this.serviceRequestService.getAssociationMember(this.selectedAssociationId, event.source.value.CreatedByUnitId).subscribe(res => {
        resData = res;
        if (resData.Success === true) {
          console.log('memberList ', resData.Users);
          this.memberListDdl = resData.Users;
          this.memberListDdlAutocompleteList = resData.Users;
        } else {
          this.memberListDdl = [];
          this.memberListDdlAutocompleteList = [];
        }
      });
    }
  }

  getMemberList(associationId, unitid) {
    // let resData;
    // console.log('asid ', associationId);
    // console.log('55 ', unitid);
    // this.serviceRequestService.getAssociationMember(associationId, unitid).subscribe(res => {
    //   resData = res;
    //   this.memberListDdl = [];
    //   this.memberListDdlAutocompleteList = [];
    //   this.frmCreateARCRequest.controls.memberName.setValue('');
    //   if (resData.Success === true) {
    //     console.log('memberList ', resData.Users);
    //     this.memberListDdl = resData.Users;
    //     this.memberListDdlAutocompleteList = resData.Users;
    //   }
    // });

    // console.log("event", event);
    // if (event.isUserInput === true) {
    //   let resData;
    //   this.memberListDdl = [];
    //   this.memberListDdlAutocompleteList = [];
    //   this.addRequestForm.controls.memberName.setValue('');
    //   this.serviceRequest.getAssociationMember(this.selectedAssociationId, event.source.value.CreatedByUnitId).subscribe(res => {
    //     resData = res;
    //     if (resData.Success === true) {
    //       this.memberListDdl = resData.Users;
    //       this.memberListDdlAutocompleteList = resData.Users;
    //     }
    //   });
    // }

  }

  //for clear association Unit drop down
  onFocusOutMember(searchStr) {
    if (this.serviceRequestmemberListDdlUnittrigger !== undefined) {
      this.serviceRequestmemberListDdlUnittrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.memberListDdlAutocompleteList = this.memberListDdl;
            this.frmCreateARCRequest.controls.memberName.setValue('');
            this.serviceRequestmemberListDdlUnittrigger.closePanel();

          }
        });
      this.memberListDdlAutocompleteList = this.memberListDdl.filter(option =>
        option.UserName.toLowerCase().includes(searchStr.toLowerCase()));
      if (this.memberListDdlAutocompleteList.length === 0) {
        this.memberListDdlAutocompleteList = this.memberListDdl;
        this.frmCreateARCRequest.controls.memberName.setValue('');
      }
    }
  }

  /**Auto complete Display Function**/
  displayFnAutoCompleteMember(member) {
    if (member != null && member.UserName != null) {
      return member.UserName;
    } else member;
  }

  /**Auto complete filter on change**/
  onInputChangedMember(searchStr: string): void {
    this.memberListDdlAutocompleteList = [];
    this.memberListDdlAutocompleteList = this.memberListDdl.filter(option =>
      option.UserName.toLowerCase().includes(searchStr.toLowerCase()));
  }

  ngOnDestroy(): void {
    this.querySubcription.unsubscribe();
  }

  /*dg for email to case */
  getCaseDetails(caseId) {
    this.progressbarService.show();
    let resData;
    this.emailtocaseService.getEmailToCaseDetails(caseId).subscribe((response) => {
      this.progressbarService.hide();
      resData = response;
      console.log("getEmailToCaseDetails", response);
      if (resData.success === true) {
        if (resData.GetCaseDetail !== null && resData.GetCaseDetail !== undefined) {
          this.documents = resData.GetCaseDetail.Documents;
          this.emailMessage = resData.GetCaseDetail.EmailMessage;
          this.cases = resData.GetCaseDetail.Cases;
          this.setARCData();
        } else {
          this.router.navigate([AppRouteUrl.mainEmailToCaseRouteUrl]);
        }
      } else {
        this.router.navigate([AppRouteUrl.mainEmailToCaseRouteUrl]);
      }
    },
      (error) => {
        console.log(error);
      }
    );
  }

  setARCData() {
    this.frmCreateARCRequest.controls.title.setValue(this.cases.Title);
    this.frmCreateARCRequest.controls.description.setValue(this.emailMessage.Body);
    if (this.cases.AssociationId) {
      var association = this.associationDdl.find(a => a.id === this.cases.AssociationId);
      this.frmCreateARCRequest.controls.association.setValue(association);
      this.selectedAssociationId = "";
      this.selectedAssociationId = this.cases.AssociationId;
      this.getAllAssociationUnitByAssociationId(this.cases.AssociationId);
    }
  }

  toGoBack() {
    if (this.isAddForGlobalCreate === true) {
      this.router.navigate([AppRouteUrl.mainArcPMRouteUrl]);
    } else {
      this._location.back();
    }
  }

  ngAfterViewInit() {
    if (this.associationTrigger !== undefined) {
      this.associationTrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.associationAutoCompleteDdl = this.associationDdl;
            this.frmCreateARCRequest.controls.association.setValue('');
            this.associationTrigger.closePanel();

            this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
            this.frmCreateARCRequest.controls.associationUnit.setValue('');
            this.associationUnitTrigger.closePanel();

            this.memberListDdlAutocompleteList = this.memberListDdl;
            this.frmCreateARCRequest.controls.memberName.setValue('');
            this.serviceRequestmemberListDdlUnittrigger.closePanel();
          }
        });
    }

    if (this.associationUnitTrigger !== undefined) {
      this.associationUnitTrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.associationAutoCompleteUnitDdl = this.associationUnitDdl;
            this.frmCreateARCRequest.controls.associationUnit.setValue('');
            this.associationUnitTrigger.closePanel();


            this.memberListDdlAutocompleteList = this.memberListDdl;
            this.frmCreateARCRequest.controls.memberName.setValue('');
            this.serviceRequestmemberListDdlUnittrigger.closePanel();
          }
        });
    }

    if (this.serviceRequestmemberListDdlUnittrigger !== undefined) {
      this.serviceRequestmemberListDdlUnittrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.memberListDdlAutocompleteList = this.memberListDdl;
            this.frmCreateARCRequest.controls.memberName.setValue('');
            this.serviceRequestmemberListDdlUnittrigger.closePanel();
          }
        });
    }

  }

  arcDetail(id, caseId) {
    if (id !== null && id !== undefined && id !== '') {
      this.service.caseId = caseId;
      this.service.arcRequestId = id;
      let navigationExtras: NavigationExtras = {
        queryParams: {
          "id": id
        }
      };
      this.router.navigate([AppRouteUrl.mainArcDetailPMRouteUrl], navigationExtras);
    } else {
      console.log("DetailId not comming", id);
      this.router.navigate([AppRouteUrl.mainArcPMRouteUrl]);
    }
  }

}
