import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmCreateArcComponent } from './pm-create-arc.component';

describe('PmCreateArcComponent', () => {
  let component: PmCreateArcComponent;
  let fixture: ComponentFixture<PmCreateArcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmCreateArcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmCreateArcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
