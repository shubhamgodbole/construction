import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PmArcDetailComponent } from './pm-arc-detail/pm-arc-detail.component';
import { PmArcListComponent } from './pm-arc-list/pm-arc-list.component';
import { Routes, RouterModule } from '@angular/router';
import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
import { MatInputModule, MatListModule, MatMenuModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule, MatRippleModule, MatSelectModule, MatSnackBarModule, MatTooltipModule, MatTreeModule, MatCheckboxModule, MatDatepicker, MatDatepickerModule, MatRadioModule, MatRadioGroup, MatPaginatorModule, MatAutocompleteModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NoCaseNoteFoundComponent } from 'src/app/shared/component/no-case-note-found/no-case-note-found.component';
import { NoCaseNoteFoundModule } from 'src/app/shared/component/no-case-note-found/no-case-note-found.module';
import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
import { PmCreateArcComponent } from './pm-create-arc/pm-create-arc.component';
import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { AllowOnlyPriceModule } from 'src/app/shared/directives/allow-only-price/allow-only-price.module';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { DisplayTimeElapsedModule } from 'src/app/shared/modules/display-time-elapsed.module';
import { TransformBlankValueModule } from 'src/app/shared/pipes/blankValue/transform-blank-value.module';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { QuillModule } from 'ngx-quill';
import { TagInputModule } from 'ngx-chips';
import { SpaceNotAllowModule } from 'src/app/shared/directives/space-not-allow/space-not-allow.module';
import { FilterUniqueArrayModule } from 'src/app/shared/pipes/filterUniqueArray/filter-unique-array.module';
import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
const routes: Routes = [
  {
    path: '',
    component: PmArcListComponent
  },
  {
    path: AppRouteUrl.arcDetailPMRouteUrl,
    component: PmArcDetailComponent
  },
  {
    path: 'create-arc',
    component: PmCreateArcComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NoDataFoundModule,
    NoCaseNoteFoundModule,
    MatAutocompleteModule,
    MatInputModule,
    MatListModule,
    SafeModule,
    MatPaginatorModule,
    NumberOnlyDirectiveModule,
    MatMenuModule,
    MatBottomSheetModule,
    TransformBlankValueModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatRippleModule,
    DisplayTimeElapsedModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatTreeModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatRadioModule,
    AllowOnlyPriceModule,
    NumberOnlyDirectiveModule,
    FormsModule,
    RouterModule.forChild(routes),
    BsDatepickerModule.forRoot(),
    QuillModule,
    TagInputModule,
    SpaceNotAllowModule,
    FilterUniqueArrayModule,
    HideIfUnauthorizedModule,
  ],
  declarations: [PmArcDetailComponent, PmArcListComponent, PmCreateArcComponent]
})
export class PmArcModule { }
