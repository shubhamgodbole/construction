import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmArcDetailComponent } from './pm-arc-detail.component';

describe('PmArcDetailComponent', () => {
  let component: PmArcDetailComponent;
  let fixture: ComponentFixture<PmArcDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmArcDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmArcDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
