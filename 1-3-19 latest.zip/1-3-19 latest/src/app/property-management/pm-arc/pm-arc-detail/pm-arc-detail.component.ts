import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { Validators, FormGroup, FormGroupDirective, FormBuilder, AbstractControl, FormControl } from '@angular/forms';
import { requestARCVoteModel, ARCStatus } from 'src/app/components/arc/arc-model';
//import { CaseFeatureType, NoteType } from 'src/app/components/service-request/bm-service-request-detail/bm-service-request.model';

import { EscalteModel, CaseNoteModel, AudienceType } from 'src/app/components/board-tasks/board-task.model';
import { TypeOfDocument, IsAuthorized, CaseOriginatingType, NoteType, CaseFeatureType, ImageNameEnums, DownloadfeatureName, DocumentFeatureName, PlaceHolderText, CallType, ActivityType, StatusReason, VoteStatus, FeatureName, TriggerType, SourceType, RoleEnum, FeaturePermissions, EmailAudience } from 'src/app/shared/Enums/commonEnums';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { AppConfig } from 'src/app/app.config';
import { Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { take } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { Guid } from 'guid-typescript';
import { CommonService } from 'src/app/services/common.service';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { Location } from '@angular/common';
import { CaseNoteEditModel } from 'src/app/shared/common/models';
import { MatDialogRef, MatDialog } from '@angular/material';
import { ConfirmDialogComponent } from 'src/app/shared/component/confirm-dialog/confirm-dialog.component';
import { CommonConstant, AcceptFilesConstant } from 'src/app/shared/common/constant.model';
import { AppRouteUrl } from 'src/app/shared/app-module-route';
import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
import { CallModel, EmailModel, AssignToModel, RequestMsg } from 'src/app/components/service-request/service-request.model';
import { EmailNotificationService } from 'src/app/services/email-notification.service';
import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-pm-arc-detail',
  templateUrl: './pm-arc-detail.component.html',
  styleUrls: ['./pm-arc-detail.component.scss']
})
export class PmArcDetailComponent implements OnInit {
  //Media Type
  acceptAllMediaType = AcceptFilesConstant.allMediaType;
  sidebar = false;
  unitaddress = false;
  userData: UserData;
  userId: string;
  profilePath: string;
  domain: string;
  userName: string;
  arcRequest: any;
  arcRequestDocuments: any[];
  committeeMemberCaseNotes: any[];
  caseNoteList: any[];
  caseNotes: any;
  caseNoteDocuments: any[];
  isAuthorized = IsAuthorized;

  hocaseNotes: any;
  pmCaseNotes: any;

  noteType = NoteType;
  displayDiv: boolean = false;
  associationId: string;
  decisionReason: any;
  pendingDecision: any;
  voteRemarks: any;
  voteCount: number;
  isVote: boolean;
  arcStatus = ARCStatus
  boardMemberCaseNotes: any;


  /*Case Note Form*/
  cmCaseNoteForm: FormGroup;
  hoCaseNoteForm: FormGroup;
  pmCaseNoteForm: FormGroup;
  bmCaseNoteForm: FormGroup;

  fileData = [];
  isHoBtnDisabled: boolean = false;
  isCMBtnDisabled: boolean = false;
  isPMBtnDisabled: boolean = false;
  isBMBtnDisabled: boolean = false;


  /*Edit CaseNote*/
  editComments: string = "";
  caseNoteId: string = "";
  isEditValidation: boolean = false;
  caseNoteType: string;

  caseOriginatingType = CaseOriginatingType;
  projectCompletionDocuments: any[];
  role: string;
  // view more 
  shoNDocs: number = 3;
  viewDocs: boolean;
  viwAllDocBtnMsg: string = "View All Attachments";
  // view more work completed Doc
  shoNDocsCompleted: number = 3;
  viewDocsCompleted: boolean;
  viwAllDocBtnMsgCompleted: string = "View All Attachments";

  readMoreBtn: boolean;
  readMoreDescBtnMsg: string = "Read More";
  desLimit: number = 160;


  //for Preview
  fileURL: string;
  documentDetails;
  isDocumentDetails: boolean = false;

  /*For next and previouse buttons*/
  isNextAndPreviousBtnShow: boolean = true;
  currentPage: number;
  totalPages: number;

  //display motion
  motionMsg: string;
  motionIcon: string;
  voteReceiveMsg: string;
  motionList: any;
  motionVoteCount: number;

  //requestMsg enum 
  requestMsgEnum = RequestMsg


  //for image enum
  imageNameEnums = ImageNameEnums;

  confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;

  @ViewChild('formDirectiveCm') formDirectiveCm: FormGroupDirective;
  @ViewChild('formDirectiveHo') formDirectiveHo: FormGroupDirective;
  @ViewChild('formDirectivePm') formDirectivePm: FormGroupDirective;
  @ViewChild('formDirectiveBm') formDirectiveBm: FormGroupDirective;


  /*Escalte form*/
  frmCreateEscalte: FormGroup;
  isSubmitBtnDisabledEscalte: boolean = false;
  @ViewChild('formDirectiveEscalte') formDirectiveEscalte: FormGroupDirective;


  /*ARC Vote*/
  vote: boolean = true;
  frmCreateVote: FormGroup;
  isSubmitBtnDisabledVote: boolean = false;
  @ViewChild('formDirectiveVote') formDirectiveVote: FormGroupDirective;
  isDisplayVoteList: boolean = false;
  querySubcription: Subscription;

  //replyTo
  selectedReplyTo: string;
  placeHolderText = PlaceHolderText;

  allCaseNoteList = [];
  //vote status enum 
  VoteStatusEnum = VoteStatus;

  selectedConversionType: string = "All";

  noteTypeEnums = NoteType;
  callTypeEnum = CallType;
  activityTypeEnum = ActivityType;

  selectedActivityType: string;

  //for add call
  frmCreatePhone: FormGroup;
  phoneFileData = [];
  isSubmitBtnDisabledPhone: boolean;
  @ViewChild('formDirectivePhone') formDirectivePhone: FormGroupDirective;

  //for send email
  frmCreateEmail: FormGroup;
  emailFileData = [];
  isSubmitBtnDisabledEmail: boolean;
  @ViewChild('formDirectiveEmail') formDirectiveEmail: FormGroupDirective;

  statusReasonEnum = StatusReason;

  reasonType: string;

  //file data for case note
  fileDataHoCase = [];
  fileDataBMCase = [];
  fileDataICCase = [];
  fileDataCMCase = [];

  //Email tag
  placeholdertext = "";
  public validators = [ValidationService.emailValidator];
  public errorMessages = {
    'invalidEmailAddress': 'Invalid Email',
  };

  arcStatusEnum = ARCStatus;
  assignToDdl = [];
  selectedAssignTo = '';

  //For Send Notification
  featureId: string;
  pmCompanyAssociationMappingId: string;
  featureName: string;

  //For Permission
  permissionFeatureName = FeatureName;
  permission = FeaturePermissions;

  //for Email Audience
  emailAudienceEnum = EmailAudience;

   // editor Formating Option
   public editorOptions = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote'],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'script': 'sub' }, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
      [{ 'font': [] }],
      [{ 'align': [] }],
      ['clean'],                                         // remove formatting button
    ]
  };

  //For onchange of association go to the list page
  currentAssociation: string = "";
  isAssociationChange : boolean = false;

  constructor(private service: ArcRequestApiService,
    private ngZone: NgZone,
    private route: ActivatedRoute,
    private progressbarService: ProgeressBarService,
    private emailNotification: EmailNotificationService,
    private _location: Location,
    public commonService: CommonService,
    private globalAssociationService: GlobalAssociationService,
    private _matDialog: MatDialog,
    private notificationService: NotificationService,
    private readonly appConfig: AppConfig,
    private router: Router, private formBuilder: FormBuilder) {
    this.userData = this.appConfig.getCurrentUser();
    this.domain = this.userData.UserAssociations[0].Domain;
    this.userName = this.userData.UserName;
    this.userId = this.userData.UserProfileId;
    this.role = this.userData.Role;
    this.profilePath = this.userData.UserProfilePath;
    this.createCMCaseNoteForm();
    this.createPMCaseNoteForm();
    this.createBMCaseNoteForm();
    this.createHOCaseNoteForm();
    this.createVoteForm();
    this.userData.FeatureMenuPermissions.forEach(
      (feature) => {
        if (feature.Name === FeatureName.ARC) {
          this.featureName = feature.Name
          this.featureId = feature.FeatureId
        }
      });
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {

    //For onchange of association go to the list page
    this.globalAssociationService.associationSubject.subscribe(res => {
      console.log('from association data ', res);      
      if (res !== 1) {
        if(this.currentAssociation === '' && !this.isAssociationChange) {
          this.currentAssociation = res.AssociationId; 
          this.isAssociationChange = true;
        }
        else {
          this.isAssociationChange = false;
          this.router.navigate([AppRouteUrl.mainArcPMRouteUrl]);
        }
      }
    });

    this.querySubcription = this.route.queryParams.subscribe(params => {
      let id = params["id"];
      if (id) {
        this.service.arcRequestId = id;
        this.getDetail();
      }
      else {
        this.router.navigate(['/bm-arc-requests']);
      }
    });
    this.createAddCallForm();
    this.getAssignToUser();
    this.createAddEmailForm();
  }
  //caseNoteDocList: any;
  getDetail() {
    let resData;
    this.arcRequestDocuments = [];
    this.projectCompletionDocuments = [];
    this.caseNoteDocuments = [];
    this.displayDiv = false;
    this.progressbarService.show();
    this.service.getARCRequestDetail(this.service.arcRequestId, this.domain).subscribe(response => {
      resData = response;
      this.progressbarService.hide();
      this.displayDiv = true;
      console.log('response detail ', response);
      this.arcRequest = resData.RequestDetail.ARCRequest;
      this.motionList = resData.RequestDetail.Motion;
      if (this.arcRequest !== null) {
        this.frmCreateEmail.controls.Subject.setValue(this.arcRequest.CaseNumber + ":" + this.arcRequest.ARCRequestTitle);
        this.isShowNextAndPreviewsButton();
        this.selectedAssignTo = this.arcRequest.AssignedTo;
        this.service.caseId = this.arcRequest.CaseId;
        this.associationId = this.arcRequest.AssociationId;
        this.arcRequestDocuments = resData.RequestDetail.Document;
        this.projectCompletionDocuments = resData.RequestDetail.ProjectCompletionDocuments;
        if (this.projectCompletionDocuments.length > 0) {
          this.caseNoteDocuments = this.projectCompletionDocuments.filter(d => d.TypeOfDocument === TypeOfDocument.CaseDocuments);
        }
        this.voteRemarks = this.arcRequest.ARCRequestCommitteeVotes;
        this.setVoteRemark(resData.RequestDetail.CaseNoteDetails);
      }
    });
  }

  setVoteRemark(caseNoteDetails) {
    if (this.arcRequest.ARCRequestCommitteeVotes !== null && this.arcRequest.ARCRequestCommitteeVotes.length > 0) {
      this.arcRequest.ARCRequestCommitteeVotes.map(a => {
        var caseNote = this.service.convertVoteRemarkToCaseNote(a);
        caseNoteDetails.push(caseNote);
      });
    }
    if (caseNoteDetails !== null) {
      if (caseNoteDetails.length > 0) {
        this.setListValue(caseNoteDetails);
      }
    } else {
      this.removeListValue()
    }
  }

  //for assign to user
  getAssignToUser() {
    let resData;
    this.commonService.getPMList().subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.assignToDdl = resData.PMUser;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  onChangeAssignTo() {
    var resData;
    var model = this.createAssignToModel();
    this.service.changeAssignTo(model).subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.arcRequest = resData.arcRequestDetail;
        this.selectedAssignTo = this.arcRequest.AssignedTo;
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        console.log("error");
      }
    });
  }


  createAssignToModel() {
    var model: AssignToModel = {
      RequestId: this.arcRequest.id,
      CaseId: this.arcRequest.CaseId,
      Case: {
        AssignedTo: this.selectedAssignTo,
        ModifiedByUserId: this.userId,
        ModifiedByUserName: this.userName
      }
    }
    return model;
  }

  sidebarToggle() {
    if (this.sidebar)
      this.sidebar = false;
    else
      this.sidebar = true;
  }

  unitaddressToggle() {
    if (this.unitaddress)
      this.unitaddress = false;
    else
      this.unitaddress = true;
  }

  /*Case Note Add Module*/
  createCMCaseNoteForm() {
    this.cmCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  // upload Document
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          //let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            imageId: Guid.create(),
            inputStream: event.target.result,
            name: evt.target.files[i].name.toLowerCase(),
            type: evt.target.files[i].type,
            fileSize: evt.target.files[i].size.toString(),
            mediaType: evt.target.files[i].name.toLowerCase().substring(evt.target.files[i].name.indexOf(".")),
            CreatedByUserName: this.userName
          });
        }
        if (this.selectedReplyTo === NoteType.Homeowner) {
          this.fileDataHoCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.BoardMember) {
          this.fileDataBMCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.PropertyManager) {
          this.fileDataICCase = this.fileData;
        } else if (this.selectedReplyTo === NoteType.CommitteeMember) {
          this.fileDataCMCase = this.fileData;
        } else if (this.selectedActivityType === ActivityType.Email) {
          this.emailFileData = this.fileData;
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  removeImage(imageId) {
    if (this.selectedReplyTo === NoteType.Homeowner) {
      this.fileDataHoCase = this.fileDataHoCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.BoardMember) {
      this.fileDataBMCase = this.fileDataBMCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.PropertyManager) {
      this.fileDataICCase = this.fileDataICCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedReplyTo === NoteType.CommitteeMember) {
      this.fileDataICCase = this.fileDataCMCase.filter(a => a.imageId !== imageId);
    } else if (this.selectedActivityType === ActivityType.Email) {
      this.emailFileData = this.emailFileData.filter(a => a.imageId !== imageId);
    }
    this.fileData = this.fileData.filter(a => a.imageId !== imageId);
  }

  onSubmitCaseNoteForCM() {
    let resData;
    if (this.cmCaseNoteForm.valid) {
      this.isCMBtnDisabled = true;
      let model = this.createCMFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isCMBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARCRequests, TriggerType.Update,
            AudienceType.PropertyManager);
          if (this.fileDataCMCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetCaseNoteCMForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log('error');
        }
      });
    }
  }

  createCMFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.arcRequest.AssociationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataCMCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.cmCaseNoteForm.controls.caseNoteId.value,
        Note: this.cmCaseNoteForm.controls.comments.value,
        CaseId: this.arcRequest.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.CommitteeMember,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetCaseNoteCMForm() {
    this.cmCaseNoteForm.reset();
    this.formDirectiveCm.resetForm();
    this.isCMBtnDisabled = false;
    this.selectedReplyTo = '';
    this.fileDataCMCase = [];
    this.fileData = [];
  }


  /*Case Note BM Add Module*/
  createBMCaseNoteForm() {
    this.bmCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }


  onSubmitCaseNoteForBM() {
    let resData;
    if (this.bmCaseNoteForm.valid) {
      this.isBMBtnDisabled = true;
      let model = this.createBMFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isBMBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARCRequests, TriggerType.Update,
            AudienceType.PropertyManager);
          if (this.fileDataBMCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetCaseNoteBMForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("Not Save");
        }
      });
    }
  }

  createBMFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.arcRequest.AssociationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataBMCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.bmCaseNoteForm.controls.caseNoteId.value,
        Note: this.bmCaseNoteForm.controls.comments.value,
        CaseId: this.arcRequest.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.BoardMember,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetCaseNoteBMForm() {
    this.bmCaseNoteForm.reset();
    this.formDirectiveBm.resetForm();
    this.isBMBtnDisabled = false;
    this.fileDataBMCase = [];
    this.selectedReplyTo = "";
    this.fileData = [];
  }

  /*Case Note Add Module*/
  createHOCaseNoteForm() {
    this.hoCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }


  onSubmitCaseNoteForHO() {
    let resData;
    if (this.hoCaseNoteForm.valid) {
      this.isHoBtnDisabled = true;
      let model = this.createHoFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isHoBtnDisabled = false;
        resData = res;
        this.resetCaseNoteHOForm();
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARCRequests, TriggerType.Update,
            AudienceType.PropertyManager);
          if (this.fileDataHoCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("Not Save");
        }
      });
    }
  }

  createHoFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.arcRequest.AssociationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataHoCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.hoCaseNoteForm.controls.caseNoteId.value,
        Note: this.hoCaseNoteForm.controls.comments.value,
        CaseId: this.arcRequest.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.Homeowner,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false
      }
    }
    return model;
  }

  resetCaseNoteHOForm() {
    this.hoCaseNoteForm.reset();
    this.formDirectiveHo.resetForm();
    this.isHoBtnDisabled = false;
    this.fileDataHoCase = [];
    this.selectedReplyTo = "";
    this.fileData = [];
  }

  /*Case Note Add  Module For Internal Chat*/
  createPMCaseNoteForm() {
    this.pmCaseNoteForm = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]]
    });
  }

  onSubmitCaseNoteForPM() {
    let resData;
    if (this.pmCaseNoteForm.valid) {
      this.isPMBtnDisabled = true;
      let model = this.createPMFormModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isPMBtnDisabled = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARCRequests, TriggerType.Update,
            AudienceType.PropertyManager);
          if (this.fileDataICCase.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetCaseNotePMForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log('error');
        }
      });
    }
  }


  //for call
  setMobileNumberForEditBasic(event) {
    let ctrlValue = this.frmCreatePhone.controls.callNumber.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmCreatePhone.controls.callNumber.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmCreatePhone.controls.callNumber.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmCreatePhone.controls.callNumber.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }


  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }


  createPMFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.arcRequest.AssociationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileDataICCase,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: this.pmCaseNoteForm.controls.caseNoteId.value,
        Note: this.pmCaseNoteForm.controls.comments.value,
        CaseId: this.arcRequest.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.PropertyManager,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        IsVotingRequired: false,
        ActivityType: null,
        IsAssignedToBoard: false,
      }
    }
    return model;
  }

  resetCaseNotePMForm() {
    this.pmCaseNoteForm.reset();
    this.formDirectivePm.resetForm();
    this.isPMBtnDisabled = false;
    this.fileDataICCase = [];
    this.selectedReplyTo = "";
    this.fileData = [];
  }


  /*Display list of vote*/
  displayVoteListToggle() {
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }


  /*Create ARC Vote */

  createVoteForm() {
    this.frmCreateVote = this.formBuilder.group({
      reasonText: ['', Validators.required]
    });
  }

  createARCVote() {
    let model = this.createVoteModel();
    this.service.createVote(model).subscribe(res => {
      console.log('vote res ', res);
      this.resetVoteForm();
      this.getDetail();
    });
  }

  createVoteModel() {
    const model: requestARCVoteModel = {
      associationId: this.associationId,
      requestId: this.service.arcRequestId,
      ARCRequestCommitteeVote: {
        Vote: this.vote,
        CreatedByUserId: this.userId,
        CreatedByUserName: this.userName,
        Remarks: this.frmCreateVote.value.reasonText,
        ProfilePath: this.profilePath
      }
    }
    return model;
  }

  resetVoteForm() {
    this.frmCreateVote.reset();
    this.formDirectiveVote.resetForm();
    document.getElementById('closeModelVote').click();
  }

  // view more description
  viewMoreDesc() {
    if (this.readMoreBtn) {
      this.readMoreBtn = false;
      this.readMoreDescBtnMsg = "Read More";
      this.desLimit = 160;

    }
    else {
      this.readMoreBtn = true;
      this.readMoreDescBtnMsg = "Read Less";
      this.desLimit = this.arcRequest.ARCDescription.length;

    }
  }

  //view more documents
  viewMoreDocs() {
    if (this.viewDocs) {
      this.shoNDocs = 3;
      this.viewDocs = false;
      this.viwAllDocBtnMsg = "View All Attachments";
    }
    else {
      this.shoNDocs = this.arcRequestDocuments.length;
      this.viewDocs = true;
      this.viwAllDocBtnMsg = "View Less Attachments";
    }
  }

  //view more documents
  viewMoreCompletedDocs() {
    if (this.viewDocsCompleted) {
      this.shoNDocsCompleted = 3;
      this.viewDocsCompleted = false;
      this.viwAllDocBtnMsgCompleted = "View All Attachments";
    }
    else {
      this.shoNDocsCompleted = this.projectCompletionDocuments.length;
      this.viewDocsCompleted = true;
      this.viwAllDocBtnMsgCompleted = "View Less Attachments";
    }
  }


  //convert size in to byte
  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  }



  removeListValue() {
    this.caseNoteList = [];
    this.committeeMemberCaseNotes = [];
    this.boardMemberCaseNotes = [];
    this.pmCaseNotes = [];
    this.hocaseNotes = [];
    this.pendingDecision = [];
    this.decisionReason = [];
    this.voteRemarks = this.arcRequest.ARCRequestCommitteeVotes;
    if (this.voteRemarks) {
      this.voteCount = this.arcRequest.ARCRequestCommitteeVotes.length;
      let voteByUser = this.arcRequest.ARCRequestCommitteeVotes.find(v => v.CreatedByUserId === this.userId);
      if (voteByUser) {
        this.isVote = voteByUser.Vote;
      }
    }
  }

  toGoBack() {
    // let url = document.referrer;
    // if (url.search(AppRouteUrl.memberHistoryRouteUrl) >= 0) {
    //   this.router.navigate([AppRouteUrl.mainMemberHistoryRouteUrl]);
    // } else {
    //   this.router.navigate([AppRouteUrl.mainArcPMRouteUrl]);
    // }
    let page = localStorage.getItem("previousPage");
    if (page === AppRouteUrl.memberHistoryRouteUrl) {
      this.router.navigate([AppRouteUrl.mainMemberHistoryRouteUrl]);
    } else if (page === AppRouteUrl.mainHoaMembersDetailRouteUrl) {
      this._location.back();
    } else if (page === AppRouteUrl.mainRecentUpdatesRouteUrl) {
      this._location.back();
    } else {
      this.router.navigate([AppRouteUrl.mainArcPMRouteUrl]);
    }
  }

  //for download
  downloadDocument(filename, domain) {
    console.log(filename);
    let resData;
    this.commonService.getDownloadDocumentUrl(domain, filename, DocumentFeatureName.ARCRequest, DownloadfeatureName.Download).subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.commonService.downloadFile(resData.DocumentPath).subscribe(
          (response) => {
            let dataType = response.type;
            let binaryData = [];
            binaryData.push(response);
            let downloadLink = document.createElement('a');
            downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
            if (filename)
              downloadLink.setAttribute('download', filename);
            document.body.appendChild(downloadLink);
            downloadLink.click();
          }
        );
      }
      else if (resData.Success === false) {
        this.notificationService.showNotification("Not get");
      }
    });
  }

  //For Preview document
  previewDocument(document) {
    this.isDocumentDetails = true;
    this.documentDetails = document;
    let resDoumentData;
    this.fileURL = "";
    this.commonService.getDownloadDocumentUrl(document.Domain, document.FilePath, DocumentFeatureName.ARCRequest, DownloadfeatureName.Download).subscribe(res => {
      resDoumentData = res;
      console.log('res ', res);
      if (resDoumentData.Success === true) {
        if (this.documentDetails.MediaType !== '.pdf') {
          this.fileURL = resDoumentData.DocumentPath;
        }
        else {
          this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
            (response) => {
              this.fileURL = URL.createObjectURL(response);
            }
          );
        }
      }
      else if (resDoumentData.Success === false) {
        this.notificationService.showNotification("Not get image");
      }
    });
  }

  /*Edit Casenote*/
  editCaseNote(caseNotes) {
    this.editComments = caseNotes.Note;
    this.caseNoteId = caseNotes.id;
    this.caseNoteType = caseNotes.NotesType
  }

  updateCaseNote() {
    if (this.editComments === "") {
      this.isEditValidation = true;
      return;
    }
    this.isEditValidation = false;
    let model = this.editCaseNoteModel();
    this.commonService.updateCaseNote(model).subscribe(res => {
      let resData;
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.resetEditCaseNote();
        this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
        console.log("Case note updated successfully.");
      }
      else if (resData.caseRequestListResults[0].Success === false) {
        this.notificationService.showNotification("Not Update");
      }
    });
  }

  editCaseNoteModel() {
    const model: CaseNoteEditModel = {
      AssociationId: this.arcRequest.AssociationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.fileData,
      Domain: this.domain,
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        id: this.caseNoteId,
        Note: this.editComments,
        CaseId: this.service.caseId,
        CreatedByUserId: this.userId,
        NotesType: this.caseNoteType,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        RoleType: this.role
      }
    }
    return model;
  }

  resetEditCaseNote() {
    this.caseNoteId = "";
    this.editComments = "";
    this.isEditValidation = false;
  }


  /*Delete case note*/
  delete(id) {
    let resData;
    this.commonService.deleteCaseNote(id, this.service.caseId, this.associationId, this.domain).subscribe(res => {
      resData = res;
      if (resData.caseRequestListResults[0].Success === true) {
        this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
        console.log("Case note deleted successfully.");
      }

    },
      (err) => {
        console.log(err);
      })

  }

  rowDeleteConfirm(valueObject) {
    this.confirmDialogRef = this._matDialog.open(ConfirmDialogComponent, {
      width: '530px',
      disableClose: false
    });
    this.confirmDialogRef.componentInstance.confirmMessage = CommonConstant.DeleteMsg;
    this.confirmDialogRef.componentInstance.confirmTitle = CommonConstant.DeleteComment;
    this.confirmDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(valueObject);
      }
    });
  }

  //**Next AND Preview */
  PreviousCase() {
    var current = this.service.arcRequestId;
    var serviceRequestAr = JSON.parse(localStorage.getItem('ARCList'));
    this.totalPages = serviceRequestAr.length - 1;
    var el = serviceRequestAr.find(a => { return a.id === current });
    var currentEl = serviceRequestAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl - 1 >= 0) {
      let prevIndex = serviceRequestAr[currentEl - 1].id;
      this.service.arcRequestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  NextCase() {
    var current = this.service.arcRequestId;
    var serviceRequestAr = JSON.parse(localStorage.getItem('ARCList'));
    this.totalPages = serviceRequestAr.length - 1;
    var el = serviceRequestAr.find(a => { return a.id === current });
    var currentEl = serviceRequestAr.indexOf(el);
    this.currentPage = currentEl;
    if (currentEl + 1 < serviceRequestAr.length) {
      let prevIndex = serviceRequestAr[currentEl + 1].id;
      this.service.arcRequestId = prevIndex;
      history.pushState({}, null, window.location.pathname + "?id=" + prevIndex);
      this.getDetail();
    }
  }

  isShowNextAndPreviewsButton() {
    let localStorageData = JSON.parse(localStorage.getItem('ARCList'));
    if (localStorageData === null || localStorageData === undefined)
      this.isNextAndPreviousBtnShow = false;
    else {
      var current = this.service.arcRequestId;
      var serviceRequestAr = JSON.parse(localStorage.getItem('ARCList'));
      this.totalPages = serviceRequestAr.length - 1;
      var el = serviceRequestAr.find(a => { return a.id === current });
      var currentEl = serviceRequestAr.indexOf(el);
      this.currentPage = currentEl;
    }
  }

  checkIconAssignToBoard(assignTOBoard) {
    if (assignTOBoard !== null && assignTOBoard !== undefined) {
      if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined || assignTOBoard.VoteStatus === VoteStatus.Withdraw) {
        return CommonConstant.MotionMovedIcon;
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
        return CommonConstant.MotionPassedIcon;
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
        return CommonConstant.MotionFailedIcon;
      }
    }
  }

  checkTextAssignToBoard(assignTOBoard) {
    if (assignTOBoard !== null && assignTOBoard !== undefined) {
      if (assignTOBoard.Votes.length > 0) {
        var voteCount = assignTOBoard.Votes.length;
      }
      if (assignTOBoard.VoteStatus === null || assignTOBoard.VoteStatus === undefined) {
        if (assignTOBoard.Votes.length > 0)
          return voteCount + " Votes Received"
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Approved) {
        return VoteStatus.Approved
      }
      if (assignTOBoard.VoteStatus !== null && assignTOBoard.VoteStatus === this.VoteStatusEnum.Denied) {
        return VoteStatus.Denied
      }
    }
  }

  //assign to board text 
  assignToBoardText(caseNote) {
    if (caseNote !== null) {
      if (caseNote.IsAssignedToBoard) {
        if (caseNote.Votes.length > 0 && caseNote.VoteStatus !== null) {
          return CommonConstant.BoardDecision
        } else if (caseNote.VoteStatus === null) {
          return CommonConstant.DecisionRequired
        }
      }
    }
  }

  //change conversion
  changeConversion() {
    if (this.selectedConversionType === "All") {
      this.caseNotes = this.allCaseNoteList;
    } else if (this.selectedConversionType === NoteType.Homeowner) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType === this.noteType.Homeowner)
    } else if (this.selectedConversionType === NoteType.BoardMember) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === NoteType.BoardMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager) || (note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.BoardMember));
    } else if (this.selectedConversionType === NoteType.PropertyManager) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.NotesType === NoteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.PropertyManager && note.CaseNotes.IsAssignedToBoard === false && (note.CaseNotes.ActivityType !== this.activityTypeEnum.Phone && note.CaseNotes.ActivityType !== this.activityTypeEnum.Email));
    } else if (this.selectedConversionType === this.activityTypeEnum.Phone) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Phone);
    } else if (this.selectedConversionType === this.activityTypeEnum.Email) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.Email);
    } else if (this.selectedConversionType === this.activityTypeEnum.AssignToBoard) {
      this.caseNotes = this.allCaseNoteList.filter(note => note.CaseNotes.ActivityType === this.activityTypeEnum.AssignToBoard);
    } else if (this.selectedConversionType === NoteType.CommitteeMember) {
      this.caseNotes = this.allCaseNoteList.filter(note => (note.CaseNotes.NotesType === this.noteType.CommitteeMember && note.CaseNotes.RoleType === RoleEnum.PropertyManager) || (note.CaseNotes.NotesType === this.noteType.PropertyManager && note.CaseNotes.RoleType === RoleEnum.CommitteeMember))
    }
  }

  setListValue(caseNoteDetails) {
    this.allCaseNoteList = caseNoteDetails;
    // Add motion in to case note
    if (this.motionList.length > 0) {
      this.motionList.map(m => {
        var motion = this.commonService.convertMotionToCaseNote(m);
        caseNoteDetails.push(motion);
      });
    }
    // get motion with final status
    var motionCaseNoteWithStatus = caseNoteDetails.filter(m => {
      return m.CaseNotes.VoteStatus !== null && m.CaseNotes.DocumentType === 'Motion';
    });
    //concat motion
    if (motionCaseNoteWithStatus.length > 0) {
      this.allCaseNoteList = this.allCaseNoteList.concat(motionCaseNoteWithStatus);
    }

    // sort data with motion data
    this.allCaseNoteList = _.sortBy(this.allCaseNoteList, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();


    //get before data
    var caseNoteBeforeVote = caseNoteDetails.filter(note => (note.CaseNotes.IsAssignedToBoard === true && note.CaseNotes.VoteStatus === null || note.CaseNotes.DocumentType === "Motion" && note.CaseNotes.VoteStatus === null));

    if (caseNoteBeforeVote.length > 0) {
      caseNoteBeforeVote = _.sortBy(caseNoteBeforeVote, item => new Date(item.CaseNotes.CreatedOrModifiedOn)).reverse();

      this.allCaseNoteList = caseNoteBeforeVote.concat(this.allCaseNoteList);
    }

    this.changeConversion();

  }

  //change activivty type 
  selectActivityType(type) {
    this.selectedActivityType = type;
    this.selectedReplyTo = '';
    this.fileData = [];
    this.reasonType = "";
    this.emailFileData = [];
  }

  //change reply to 
  changeReplyTo() {
    this.selectedActivityType = '';
    this.fileData = [];
  }

  //Email Form
  createAddEmailForm() {
    this.frmCreateEmail = this.formBuilder.group({
      To: ['', [Validators.required]],
      BCC: [''],
      CC: [''],
      Message: [''],
      Subject: [''],
      EmailAudience: [EmailAudience.None]
    });
  }


  onSubmitEmail() {
    let resData;
    if (this.frmCreateEmail.valid) {
      this.isSubmitBtnDisabledEmail = true;
      let model = this.createEmailModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledEmail = false;
        resData = res;
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARCRequests, TriggerType.Update,
            AudienceType.PropertyManager);
          if (this.emailFileData.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
          this.resetEmailForm();
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createEmailModel() {
    var ToEmail = "";
    var CCEmail = "";
    var BCCEmail = "";
    if (this.frmCreateEmail.controls.To.value !== null && this.frmCreateEmail.controls.To.value !== '') {
      ToEmail = this.frmCreateEmail.value.To.map(function (a) { return a.value }).join(', ')
    }
    if (this.frmCreateEmail.controls.BCC.value !== null && this.frmCreateEmail.controls.BCC.value !== '') {
      BCCEmail = this.frmCreateEmail.value.BCC.map(function (a) { return a.value }).join(', ')
    }
    if (this.frmCreateEmail.controls.CC.value !== null && this.frmCreateEmail.controls.CC.value !== '') {
      CCEmail = this.frmCreateEmail.value.CC.map(function (a) { return a.value }).join(', ')
    }
    const model: EmailModel = {
      RequestId: this.arcRequest.id,
      AssociationId: this.arcRequest.AssociationId,
      TypeOfDocument: TypeOfDocument.CaseDocuments,
      Document: this.emailFileData,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreatePhone.controls.comments.value,
        CaseId: this.arcRequest.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.PropertyManager,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        ActivityType: this.selectedActivityType,
        To: ToEmail,
        CC: CCEmail,
        BCC: BCCEmail,
        Message: this.frmCreateEmail.controls.Message.value,
        Subject: this.frmCreateEmail.controls.Subject.value,
        EmailAudience: this.frmCreateEmail.controls.EmailAudience.value,
      }
    }
    return model;
  }


  resetEmailForm() {
    this.frmCreateEmail.reset();
    this.formDirectiveEmail.resetForm();
    this.selectedActivityType = '';
    this.emailFileData = [];
    this.fileData = [];
    this.frmCreateEmail.controls.Subject.setValue(this.arcRequest.CaseNumber + ":" + this.arcRequest.ARCRequestTitle);
    this.frmCreateEmail.controls.EmailAudience.setValue(EmailAudience.None);
  }



  //call form
  createAddCallForm() {
    this.frmCreatePhone = this.formBuilder.group({
      comments: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(2000), ValidationService.noWhiteSpace]],
      callNumber: ['', [Validators.required, Validators.minLength(13), Validators.maxLength(13)]],
      callType: [this.callTypeEnum.InComming],
      callerName: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]],
      isShowCallConversation: [false],
      isVotingRequired: [false]
    });
  }

  onSubmitCall() {
    let resData;
    if (this.frmCreatePhone.valid) {
      this.isSubmitBtnDisabledPhone = true;
      let model = this.createCallModel();
      this.service.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabledPhone = false;
        resData = res;
        this.resetCallForm();
        if (resData.caseRequestListResults[0].Success === true) {
          this.emailNotification.sendNotifications(this.featureId, resData.caseRequestListResults[0].RequestId, this.userId, this.pmCompanyAssociationMappingId,
            SourceType.Web, FeatureName.ARCRequests, TriggerType.Update,
            AudienceType.PropertyManager);
          if (this.phoneFileData.length > 0)
            this.getDetail();
          else {
            this.setVoteRemark(resData.caseRequestListResults[0].CaseNoteDetails);
          }
        }
        else if (resData.caseRequestListResults[0].Success === false) {
          console.log("error");
        }
      });
    }
  }

  createCallModel() {
    const model: CallModel = {
      RequestId: this.arcRequest.id,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreatePhone.controls.comments.value,
        CaseId: this.arcRequest.CaseId,
        CreatedByUserId: this.userId,
        NotesType: NoteType.PropertyManager,
        CreatedByUserName: this.userName,
        CaseFeatureType: CaseFeatureType.ARCRequest,
        StatusReason: null,
        ProfilePath: this.profilePath,
        RoleType: this.role,
        CallType: this.frmCreatePhone.controls.callType.value,
        CallNumber: this.frmCreatePhone.controls.callNumber.value,
        CallerName: this.frmCreatePhone.controls.callerName.value,
        IsShowCallConversation: this.frmCreatePhone.controls.isShowCallConversation.value,
        IsVotingRequired: this.frmCreatePhone.controls.isVotingRequired.value,
        CallDuration: null,
        PhoneCallRecord: null,
        ActivityType: this.selectedActivityType
      }
    }
    return model;
  }


  resetCallForm() {
    this.frmCreatePhone.reset();
    this.formDirectivePhone.resetForm();
    this.selectedActivityType = '';
    this.frmCreatePhone.controls.callType.setValue(this.callTypeEnum.InComming);
  }

  //get vote msg
  getVoteARCMsg(ARCRequestCommitteeVotes) {
    var voteCount = 0;
    var passVotes;
    var failVotes;
    console.log('ARCRequestCommitteeVotes ', ARCRequestCommitteeVotes);
    var arcArcVotes;
    if(ARCRequestCommitteeVotes === null || ARCRequestCommitteeVotes === undefined){
      arcArcVotes = []
    } else {
      arcArcVotes = ARCRequestCommitteeVotes;
    }
    if (arcArcVotes !== null && arcArcVotes !== undefined) {
      voteCount = arcArcVotes.length;
      passVotes = arcArcVotes.filter(v => v.Vote === true).length;
      failVotes = arcArcVotes.filter(v => v.Vote === false).length;
      if (this.arcRequest.ARCRequestStatus !== VoteStatus.Approved || this.arcRequest.ARCRequestStatus !== VoteStatus.Denied) {
        if (arcArcVotes.length === 1 || arcArcVotes.length === 0)
          return voteCount + " Vote received on ARC Request";
        else if (arcArcVotes.length > 1)
          return voteCount + " Votes received on ARC Request";
      }
      if (this.arcRequest.ARCRequestStatus === VoteStatus.Approved) {
        return "ARC Request has been Approved (" + passVotes + "-" + failVotes + ")";
      }
      if (this.arcRequest.ARCRequestStatus === VoteStatus.Denied) {
        return "ARC Request has been Denied (" + passVotes + "-" + failVotes + ")";
      }
    }

  }

  
  getUnitAddress() {
    var associationUnit = {
      AssociationUnitNumber: this.arcRequest.CreatedByUnitNumber,
      AssociationUnitAddress1: this.arcRequest.CreatedByUnitAddress1,
      AssociationUnitAddress2: this.arcRequest.CreatedByUnitAddress2,
      AssociationUnitCity: this.arcRequest.CreatedByUnitCity,
      AssociationUnitState: this.arcRequest.CreatedByUnitState,
      AssociationUnitZip: this.arcRequest.CreatedByUnitZip,
    }
    return this.commonService.getFullAssociationAddress(associationUnit);
  }

  
  getVenderAddress(venderDetail) {
    var associationUnit = {
      AssociationUnitAddress1: venderDetail.VendorAddress1,
      AssociationUnitAddress2: venderDetail.VendorAddress2,
      AssociationUnitCity: venderDetail.VendorCity,
      AssociationUnitState: venderDetail.VendorState,
      AssociationUnitZip: venderDetail.VendorZip,
    }
    return this.commonService.getAssociationAddressForList(associationUnit);
  }

  ngOnDestroy() {
    this.querySubcription.unsubscribe();
    localStorage.removeItem('ARCList');
  }

}
