import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailtocaseComponent } from './emailtocase.component';

describe('EmailtocaseComponent', () => {
  let component: EmailtocaseComponent;
  let fixture: ComponentFixture<EmailtocaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmailtocaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailtocaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
