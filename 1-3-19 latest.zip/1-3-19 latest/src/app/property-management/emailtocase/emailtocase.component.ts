import { Component, OnInit, ViewChild } from '@angular/core';
// import { ProgeressBarService } from 'src/app/shared/services/progeress-bar.service';
// import { EmailtocaseService } from 'src/app/services/emailtocase.service';
// import { GlobalAssociationModel } from 'src/app/shared/component/global-association/global-association.model';
// import { GlobalAssociationService } from 'src/app/shared/component/global-association/global-association.service';
// import { NoDataFoundCaseFeatureName, FeatureName, FeaturePermissions, ImageNameEnums, CustomerTypeEnum, CaseTypeEnum, TypeOfDocument, SubCaseTypeEnum, IsAuthorized, CasePriority, StatusReason, DocumentFeatureName, DownloadfeatureName } from 'src/app/shared/Enums/commonEnums';
// import { CommonService } from 'src/app/services/common.service';
// import { MatAutocompleteTrigger, MatSnackBar } from '@angular/material';
// import { CaseSubCategory, DisplayPriority, BoardTaskModel } from 'src/app/components/board-tasks/board-task.model';
// import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
// import { ValidationService } from 'src/app/shared/services/validation.service';
// import { Guid } from 'guid-typescript';
// import { UserData } from 'src/app/shared/models/user-data-model';
// import { AppConfig } from 'src/app/app.config';
// import { BoardTaskApiService } from 'src/app/services/board-task-api.service';
// import { NotificationService } from 'src/app/shared/services/notification.service';
// import { AssignedPartyType, CaseOriginatingType } from 'src/app/components/arc/arc-model';
// import { DropdownModelAssociationUnit } from 'src/app/shared/common/models';
// import { ViolationApiService } from 'src/app/services/violation-api.service';
// import { ViolationCase, Violation, FineStatus, ViolationStatus } from 'src/app/components/violation/violation.model';
// import { CaseUnitModel, CaseRequestModel, CustomerType, CaseTypes, CaseCategory, CaseSubCategories } from 'src/app/components/service-request/service-request.model';
// import { ServiceRequestService } from 'src/app/services/service-request.service';
// import { Router, NavigationExtras } from '@angular/router';
// import { AppRouteUrl } from 'src/app/shared/app-module-route';

@Component({
  selector: 'app-emailtocase',
  templateUrl: './emailtocase.component.html',
  styleUrls: ['./emailtocase.component.scss']
})
export class EmailtocaseComponent implements OnInit {
  // notificationService: NotificationService;
  // //localstorage
  // userData: UserData;
  // userName: string;
  // userId: string;
  // lastName: string = "";
  // firstName: string = "";

  // BoardTask = false;
  // ServiceRequest = false;
  // Violation = false;
  // Motion = false;
  // selectedRequest: string = "";
  // noDataFoundCaseFeatureName = NoDataFoundCaseFeatureName;
  // //ImageNameEnums
  // imageNameEnums = ImageNameEnums;

  // /*For global association*/
  // globalAssociationModel: GlobalAssociationModel;

  // /*Page Variables*/
  // emailToCaseList: any = [];
  // emailToCaseDetails: any;
  // caseDetailId: string = "";
  // documents: any;
  // emailMessage: any;
  // cases: any;
  // bccStrings: string;
  // ccStrings: string;
  // fromStrings: string;
  // isCaseDetailShow: boolean = false;

  // //For Permission
  // permissionFeatureName = FeatureName;
  // permission = FeaturePermissions;

  // //For Association
  // associationDdl: any[] = [];
  // associationDdlAutocompleteList: any[] = [];
  // @ViewChild('emailToCaseAssociationAutoComplete', { read: MatAutocompleteTrigger })
  // emailToCaseAssociationtrigger: MatAutocompleteTrigger;

  // @ViewChild('emailToCaseAssociationServiceAutoComplete', { read: MatAutocompleteTrigger })
  // emailToCaseAssociationServicetrigger: MatAutocompleteTrigger;

  // @ViewChild('emailToCaseAssociationViolationAutoComplete', { read: MatAutocompleteTrigger })
  // emailToCaseAssociationViolationtrigger: MatAutocompleteTrigger;

  // //for assign to
  // assignToDdl: any;

  // /*BoardTask Form*/
  // caseCategoryDdl: any;
  // priorityDdl: any;
  // customerType = CustomerTypeEnum.Association;
  // caseType = CaseTypeEnum.BoardMembers;
  // caseSubCategoryDdlList = new Array<CaseSubCategory>();
  // subCaseType = SubCaseTypeEnum.BoardTask;
  // frmCreateBoardTask: FormGroup;
  // caseSubCategoryDdl: any;
  // isSubmitBtnDisabledBoardTask: boolean = false;
  // typeOfDocument = TypeOfDocument.CaseDocuments;
  // @ViewChild('boardTaskFormDirective') boardTaskFormDirective: FormGroupDirective;
  // /*End BoardTask Form*/

  // /*Violation Form*/
  // @ViewChild('violationFormDirective') violationFormDirective: FormGroupDirective;
  // @ViewChild('violationDate') violationDate;
  // frmCreateViolation: FormGroup;
  // isSubmitBtnDisabledViolation: boolean;
  // //association unit Reported By drop down autocomplate
  // reportedByDdl: any[] = [];
  // reportedByAutoCompleteDdl: any[];
  // /*Reset mat auto compelte*/
  // @ViewChild('reportedByAutoComplete', { read: MatAutocompleteTrigger })
  // reportedByTrigger: MatAutocompleteTrigger;
  // selectedAssociationId: string;
  // //association unit Reported By drop down autocomplate
  // violatedByAssociationUnitDdl: any[] = [];
  // violatedByAssociationAutoCompleteUnitDdl: any[];
  // /*Reset mat auto compelte*/
  // @ViewChild('violatedByAssociationUnitAutoComplete', { read: MatAutocompleteTrigger })
  // violatedByAssociationUnitTrigger: MatAutocompleteTrigger;
  // /*End Violation Form*/

  // /*Service Request Form*/
  // selectedAssociationServiceRequestId: string;
  // addRequestForm: FormGroup;
  // @ViewChild('serivceRequestFormDirective') serivceRequestFormDirective: FormGroupDirective;
  // isSubmitBtnDisabledServiceRequest: boolean;

  // customerTypeDdl: any;
  // customerTypeDdlList = new Array<CustomerType>();

  // caseTypeDdl: any;
  // caseTypeDdlList = new Array<CaseTypes>();

  // caseCategoryServiceRequestDdl: any;
  // caseCategoryServiceRequestDdlList = new Array<CaseCategory>();

  // caseSubCategoryServiceRequestDdl: any;
  // caseSubCategoryServiceRequestDdlList = new Array<CaseSubCategories>();

  // associationUnitDdl = new Array<DropdownModelAssociationUnit>();
  // associationUnitDdlAutocompleteList: any[] = [];
  // @ViewChild('serviceRequestAssociationUnitAutoComplete', { read: MatAutocompleteTrigger })
  // serviceRequestAssociationUnittrigger: MatAutocompleteTrigger;

  // memberListDdl: any[] = [];
  // memberListDdlAutocompleteList: any[] = [];
  // @ViewChild('serviceRequestmemberListDdlAutoComplete', { read: MatAutocompleteTrigger })
  // serviceRequestmemberListDdlUnittrigger: MatAutocompleteTrigger;

  // associationUnitDataList: any = [];

  // isAuthorized: boolean = true;
  // isAuthorizedDisplay: boolean = true;

  // unitRoleDdl: any;

  // /*End Service Request Form*/

  // //for Preview
  // fileURL: string;
  // documentDetails;
  // isDocumentDetails: boolean = false;

  // /*ARC request*/
  // setCaseId: string = "";


  // isApiResponceCome = false;

  constructor(
    // private progressbarService: ProgeressBarService,
    // private readonly formBuilder: FormBuilder,
    // private globalAssociationService: GlobalAssociationService,
    // private readonly appConfig: AppConfig,
    // private router: Router,
    // private boardTaskApiService: BoardTaskApiService,
    // private violationApiService: ViolationApiService,
    // private serviceRequestService: ServiceRequestService,
    // public commonService: CommonService,
    // private readonly snb: MatSnackBar,
    // private emailtocaseService: EmailtocaseService
  ) {
    // this.priorityDdl = DisplayPriority.PriorityList;
    // this.notificationService = new NotificationService(snb);
    // this.userData = this.appConfig.getCurrentUser();
    // this.userName = this.userData.UserName;
    // this.userId = this.userData.UserProfileId;
    // this.firstName = this.userName.split(' ')[0];
    // this.lastName = this.userName.split(' ')[1];
  }

  ngOnInit() {
    // this.createForms();
    // this.formControlValueChanged();
    // this.getUnitRole();
    // this.globalAssociationService.associationSubject.subscribe(res => {
    //   this.globalAssociationModel = res;
    //   if (res !== 1) {
    //     this.getData();
    //   }
    // });
  }

  // BoardTaskToggle() {
  //   if (this.BoardTask)
  //     this.BoardTask = false;
  //   else
  //     this.BoardTask = true;
  //   this.resetBoardTaskForm();
  //   if (this.BoardTask === true) {
  //     var elmnt: any = document.getElementById("boardtask-req-sidebar");
  //     if (elmnt !== null) {
  //       elmnt.scrollTo(0, 0);
  //     }
  //     this.getCaseCategoryDdl();
  //     this.setBoardTaskData();
  //   }
  // }

  // ServiceRequestToggle() {
  //   if (this.ServiceRequest)
  //     this.ServiceRequest = false;
  //   else
  //     this.ServiceRequest = true;
  //   this.resetServiceRequestForm();
  //   if (this.ServiceRequest === true) {
  //     var elmnt: any = document.getElementById("service-req-sidebar");
  //     if (elmnt !== null) {
  //       elmnt.scrollTo(0, 0);
  //     }
  //     this.customerTypeDdl = [];
  //     this.customerTypeDdlList = new Array<CustomerType>();
  //     this.caseTypeDdl = [];
  //     this.caseTypeDdlList = new Array<CaseTypes>();
  //     this.caseCategoryServiceRequestDdl = [];
  //     this.caseCategoryServiceRequestDdlList = new Array<CaseCategory>();
  //     this.caseSubCategoryServiceRequestDdl = [];
  //     this.caseSubCategoryServiceRequestDdlList = new Array<CaseSubCategories>();
  //     this.getMasterData();
  //     this.setServiceRequestData();
  //   }
  // }

  // ViolationToggle() {
  //   if (this.Violation)
  //     this.Violation = false;
  //   else
  //     this.Violation = true;
  //   this.resetViolationForm();
  //   if (this.Violation === true) {
  //     var elmnt: any = document.getElementById("violation-req-sidebar");
  //     if (elmnt !== null) {
  //       elmnt.scrollTo(0, 0);
  //     }
  //     this.setViolationData();
  //   }
  // }

  // MotionToggle() {
  //   if (this.Motion)
  //     this.Motion = false;
  //   else
  //     this.Motion = true;
  // }

  // getData() {
  //   this.progressbarService.show();
  //   let resData;
  //   this.emailtocaseService.getEmailToCaseList(this.globalAssociationModel.AssociationId).subscribe((response) => {
  //     this.progressbarService.hide();
  //     this.isApiResponceCome = true;
  //     resData = response;
  //     console.log("EmailToCaseListResponce", response);
  //     if (resData.success) {
  //       this.emailToCaseList = resData.Cases;
  //       if (this.emailToCaseList !== undefined && this.emailToCaseList !== null && this.emailToCaseList.length > 0) {
  //         console.log(this.emailToCaseList);
  //         this.getCaseDetails(this.emailToCaseList[0].id);
  //       }
  //     }
  //   },
  //     (error) => {
  //       console.log(error);
  //     }
  //   );
  // }

  // getCaseDetails(caseId) {
  //   this.caseDetailId = caseId;
  //   this.progressbarService.show();
  //   this.selectedRequest = "";
  //   let resData;
  //   this.isDocumentDetails = false;
  //   this.setCaseId = caseId;
  //   this.emailtocaseService.getEmailToCaseDetails(caseId).subscribe((response) => {
  //     this.progressbarService.hide();
  //     resData = response;
  //     this.isCaseDetailShow = true;
  //     console.log("getEmailToCaseDetails", response);
  //     if (resData.success) {
  //       this.emailToCaseDetails = resData.GetCaseDetail;
  //       this.documents = this.emailToCaseDetails.Documents;
  //       this.emailMessage = this.emailToCaseDetails.EmailMessage;
  //       this.cases = this.emailToCaseDetails.Cases;
  //       var bccs = "";
  //       if (this.emailMessage.Bcc.length > 0 && this.emailMessage.Bcc !== null && this.emailMessage.Bcc !== undefined) {
  //         this.emailMessage.Bcc.map((bcc) => {
  //           bccs = bccs + bcc.Email + ";";
  //         });
  //         if (this.emailMessage.Bcc.length = 1) {
  //           this.bccStrings = bccs.substring(0, ccs.length - 1);
  //         } else {
  //           this.bccStrings = bccs;
  //         }
  //       }
  //       var ccs = "";
  //       if (this.emailMessage.Cc.length > 0 && this.emailMessage.Cc !== null && this.emailMessage.Cc !== undefined) {
  //         this.emailMessage.Cc.map((cc) => {
  //           ccs = ccs + cc.Email + ";";
  //         });
  //         if (this.emailMessage.Cc.length = 1) {
  //           this.ccStrings = ccs.substring(0, ccs.length - 1);
  //         } else {
  //           this.ccStrings = ccs;
  //         }
  //       }
  //       if (this.emailMessage.From !== null && this.emailMessage.From !== undefined) {
  //         this.fromStrings = this.emailMessage.From.Email;
  //       }
  //     }
  //     this.getAssociationDdl();
  //   },
  //     (error) => {
  //       console.log(error);
  //     }
  //   );
  // }

  // //For Preview document
  // previewDocument(document) {
  //   this.isDocumentDetails = true;
  //   this.documentDetails = document;
  //   let resDoumentData;
  //   this.fileURL = "";
  //   this.commonService.getDownloadDocumentUrl(document.Domain, document.FilePath, DocumentFeatureName.BoardTask, DownloadfeatureName.Download).subscribe(res => {
  //     resDoumentData = res;
  //     if (resDoumentData.Success === true) {
  //       if (document.MediaType !== '.pdf') {
  //         this.fileURL = resDoumentData.DocumentPath;
  //       }
  //       else {
  //         this.commonService.downloadFile(resDoumentData.DocumentPath).subscribe(
  //           (response) => {
  //             this.fileURL = URL.createObjectURL(response);
  //           }
  //         );
  //       }
  //     }
  //     else if (resDoumentData.Success === false) {
  //       this.notificationService.showNotification("Not get image.");
  //     }
  //   });
  // }

  // downloadDocument(filename, domain) {
  //   console.log(filename);
  //   let resData;
  //   this.commonService.getDownloadDocumentUrl(domain, filename, DocumentFeatureName.BoardTask,
  //     DownloadfeatureName.Download).subscribe(res => {
  //       resData = res;
  //       if (resData.Success === true) {
  //         this.commonService.downloadFile(resData.DocumentPath).subscribe(
  //           (response) => {
  //             let dataType = response.type;
  //             let binaryData = [];
  //             binaryData.push(response);
  //             let downloadLink = document.createElement('a');
  //             downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
  //             if (filename)
  //               downloadLink.setAttribute('download', filename);
  //             document.body.appendChild(downloadLink);
  //             downloadLink.click();
  //           }
  //         );
  //       }
  //       else if (resData.Success === false) {
  //         this.notificationService.showNotification("Document not found.");
  //       }
  //     });
  // }

  // getAssociationDdl() {
  //   let resData;
  //   this.commonService.getAssociation().subscribe(res => {
  //     resData = res;
  //     if (resData.Success === true) {
  //       this.associationDdl = resData.AssociationList;
  //       this.associationDdlAutocompleteList = resData.AssociationList;
  //     }
  //     this.getAssignToUser();
  //   },
  //     (err) => {
  //       console.log(err);
  //     }
  //   )
  // }

  // //for assign to user
  // getAssignToUser() {
  //   let resData;
  //   this.commonService.getPMList().subscribe(res => {
  //     resData = res;
  //     if (resData.Success === true) {
  //       this.assignToDdl = resData.PMUser;
  //     }
  //   },
  //     (err) => {
  //       console.log(err);
  //     }
  //   )
  // }

  // /*auto complete*/
  // /*Reset mat auto compelte*/
  // ngAfterViewInit() {
  //   if (this.emailToCaseAssociationtrigger !== undefined) {
  //     this.emailToCaseAssociationtrigger.panelClosingActions
  //       .subscribe(e => {
  //         if (!(e && e.source)) {
  //           if (this.selectedRequest === "Service Request") {
  //             this.addRequestForm.controls.association.setValue('');
  //             this.addRequestForm.controls.associationUnit.setValue('');
  //             this.serviceRequestAssociationUnittrigger.closePanel();
  //             this.associationUnitDdlAutocompleteList = this.associationUnitDdl;

  //             this.addRequestForm.controls.memberName.setValue('');
  //             this.serviceRequestmemberListDdlUnittrigger.closePanel();
  //             this.memberListDdlAutocompleteList = this.memberListDdl;

  //           } else if (this.selectedRequest === "Board Task") {
  //             this.frmCreateBoardTask.controls.association.setValue('');

  //           } else if (this.selectedRequest === "ARC Request") {
  //             this.frmCreateBoardTask.controls.association.setValue('');

  //           } else if (this.selectedRequest === "Violation") {
  //             this.frmCreateViolation.controls.association.setValue('');
  //           }

  //           this.emailToCaseAssociationtrigger.closePanel();
  //           this.associationDdlAutocompleteList = this.associationDdl;
  //         }
  //       });
  //   }

  //   if (this.emailToCaseAssociationViolationtrigger !== undefined) {
  //     this.emailToCaseAssociationViolationtrigger.panelClosingActions
  //       .subscribe(e => {
  //         if (!(e && e.source)) {
  //           if (this.selectedRequest === "Violation") {
  //             this.frmCreateViolation.controls.association.setValue('');

  //             this.emailToCaseAssociationViolationtrigger.closePanel();
  //             this.associationDdlAutocompleteList = this.associationDdl;

  //             this.violatedByAssociationAutoCompleteUnitDdl = this.violatedByAssociationUnitDdl;
  //             this.frmCreateViolation.controls.violatedByAssociationUnit.setValue('');
  //             this.violatedByAssociationUnitTrigger.closePanel();

  //             this.reportedByAutoCompleteDdl = this.reportedByDdl;
  //             this.frmCreateViolation.controls.reportedByUser.setValue('');
  //             this.reportedByTrigger.closePanel();
  //           }
  //         }
  //       });
  //   }

  //   if (this.violatedByAssociationUnitTrigger !== undefined) {
  //     this.violatedByAssociationUnitTrigger.panelClosingActions
  //       .subscribe(e => {
  //         if (!(e && e.source)) {
  //           this.violatedByAssociationAutoCompleteUnitDdl = this.violatedByAssociationUnitDdl;
  //           this.frmCreateViolation.controls.violatedByAssociationUnit.setValue('');
  //           this.violatedByAssociationUnitTrigger.closePanel();
  //         }
  //       });
  //   }

  //   if (this.reportedByTrigger !== undefined) {
  //     this.reportedByTrigger.panelClosingActions
  //       .subscribe(e => {
  //         if (!(e && e.source)) {
  //           this.reportedByAutoCompleteDdl = this.reportedByDdl;
  //           this.frmCreateViolation.controls.reportedByUser.setValue('');
  //           this.reportedByTrigger.closePanel();
  //         }
  //       });
  //   }


  //   if (this.emailToCaseAssociationServicetrigger !== undefined) {
  //     this.emailToCaseAssociationServicetrigger.panelClosingActions
  //       .subscribe(e => {
  //         if (!(e && e.source)) {
  //           if (this.selectedRequest === "Service Request") {
  //             this.addRequestForm.controls.association.setValue('');

  //             this.addRequestForm.controls.associationUnit.setValue('');
  //             this.serviceRequestAssociationUnittrigger.closePanel();
  //             this.associationUnitDdlAutocompleteList = this.associationUnitDdl;

  //             this.addRequestForm.controls.memberName.setValue('');
  //             this.serviceRequestmemberListDdlUnittrigger.closePanel();
  //             this.memberListDdlAutocompleteList = this.memberListDdl;
  //           }
  //           this.emailToCaseAssociationServicetrigger.closePanel();
  //           this.associationDdlAutocompleteList = this.associationDdl;
  //         }
  //       });
  //   }

  //   if (this.serviceRequestAssociationUnittrigger !== undefined) {
  //     this.serviceRequestAssociationUnittrigger.panelClosingActions
  //       .subscribe(e => {
  //         if (!(e && e.source)) {
  //           this.addRequestForm.controls.associationUnit.setValue('');
  //           this.serviceRequestAssociationUnittrigger.closePanel();
  //           this.associationUnitDdlAutocompleteList = this.associationUnitDdl;

  //           this.addRequestForm.controls.memberName.setValue('');
  //           this.serviceRequestmemberListDdlUnittrigger.closePanel();
  //           this.memberListDdlAutocompleteList = this.memberListDdl;
  //         }
  //       });

  //   }

  //   if (this.serviceRequestAssociationUnittrigger !== undefined) {
  //     this.serviceRequestmemberListDdlUnittrigger.panelClosingActions
  //       .subscribe(e => {
  //         if (!(e && e.source)) {
  //           this.addRequestForm.controls.memberName.setValue('');
  //           this.serviceRequestmemberListDdlUnittrigger.closePanel();
  //           this.memberListDdlAutocompleteList = this.memberListDdl;
  //         }
  //       });
  //   }
  // }

  // /**Auto complete Display Function**/
  // displayFnAutoCompleteAssociation(association) {
  //   if (association != null && association.AssociationName != null) {
  //     return association.AssociationName;
  //   } else association;
  // }

  // /**Auto complete filter on change**/
  // onInputChanged(searchStr: string): void {
  //   this.associationDdlAutocompleteList = [];
  //   this.associationDdlAutocompleteList = this.associationDdl.filter(option =>
  //     option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
  // }

  // /*BoardTask Form*/
  // createForms() {
  //   /*BoardTask Form*/
  //   this.frmCreateBoardTask = this.formBuilder.group({
  //     caseId: [''],
  //     title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
  //     caseCategory: ['', Validators.required],
  //     association: ['', Validators.required],
  //     caseOriginatingType: ['', Validators.required],
  //     caseSubCategory: ['', Validators.required],
  //     dueDate: ['', Validators.required],
  //     priority: ['', Validators.required],
  //     comment: ['', [Validators.required, Validators.minLength(1), ValidationService.noWhiteSpace]],
  //     assignTo: ['', Validators.required]
  //   });



  //   /*Violation Form*/
  //   this.frmCreateViolation = this.formBuilder.group({
  //     association: ['', Validators.required],
  //     reportedByUser: ['', Validators.required],
  //     violatedByAssociationUnit: [''],
  //     title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
  //     violationDate: ['', Validators.required],
  //     description: ['', [Validators.required, Validators.minLength(1), ValidationService.noWhiteSpace]],
  //   });

  //   /*Service Request Form*/
  //   this.addRequestForm = this.formBuilder.group({
  //     serviceRequestDetailId: [''],
  //     customerType: ['', Validators.required],
  //     caseType: ['', Validators.required],
  //     association: ['', Validators.required],
  //     associationUnit: ['', Validators.required],
  //     isAuthorized: [''],
  //     memberName: ['', Validators.required],
  //     firstName: [''],
  //     lastName: [''],
  //     email: [''],
  //     mobile: [''],
  //     phoneofCaller: [''],
  //     title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
  //     comment: ['', [Validators.required, Validators.minLength(1), ValidationService.noWhiteSpace]],
  //     priority: ['', Validators.required],
  //     caseOriginatingType: ['', Validators.required],
  //     caseCategory: ['', Validators.required],
  //     caseSubCategory: ['', Validators.required],
  //     unitRoleDetail: ['', Validators.required],
  //     assignTo: ['', Validators.required]
  //   });

  // }

  // setBoardTaskData() {
  //   this.frmCreateBoardTask.controls.caseOriginatingType.setValue('Email');
  //   this.frmCreateBoardTask.controls.title.setValue(this.cases.Title);
  //   this.frmCreateBoardTask.controls.comment.setValue(this.emailMessage.Body);
  //   var association = this.associationDdl.find(a => a.id === this.cases.AssociationId);
  //   this.frmCreateBoardTask.controls.association.setValue(association);
  // }

  // getCaseCategoryDdl() {
  //   let resData;
  //   this.boardTaskApiService.getCaseCategoryDdl(this.customerType, this.caseType).subscribe(res => {
  //     resData = res;
  //     this.caseCategoryDdl = resData.CaseType.CaseCategory;
  //     if (this.caseCategoryDdl.length > 0) {
  //       for (let i = 0; i < this.caseCategoryDdl.length; i++) {
  //         let model: CaseSubCategory = new CaseSubCategory();
  //         model.caseCategoryName = this.caseCategoryDdl[i].Name;
  //         model.caseSubCategoryNames = this.caseCategoryDdl[i].CaseSubCategories;
  //         this.caseSubCategoryDdlList.push(model);
  //       }
  //     }
  //   },
  //     (err) => {
  //       console.log(err);
  //     }
  //   )
  // }

  // onChangeCaseCategory(event) {
  //   this.frmCreateBoardTask.controls.caseSubCategory.setValue('');
  //   let caseSubcat = this.caseSubCategoryDdlList.find(x => x.caseCategoryName === event.value);
  //   this.caseSubCategoryDdl = caseSubcat.caseSubCategoryNames;
  // }

  // onSubmitBoardTask() {
  //   if (this.frmCreateBoardTask.valid) {
  //     this.isSubmitBtnDisabledBoardTask = true;
  //     let model = this.createBoardTaskFormModel();
  //     console.log("BTmodel", model);
  //     let resDataCreate;
  //     var formSelectedAssociation = this.frmCreateBoardTask.controls.association.value;
  //     this.emailtocaseService.createEmailToCase(model).subscribe(res => {
  //       this.isSubmitBtnDisabledBoardTask = false;
  //       resDataCreate = res;
  //       if (resDataCreate.success === true) {
  //         this.notificationService.showNotification("Board Task saved successfully");
  //         this.getData();
  //         this.isCaseDetailShow = false;
  //         this.BoardTask = false;
  //         this.resetBoardTaskForm();
  //         console.log(formSelectedAssociation);
  //       }
  //       else if (resDataCreate.Success === false) {
  //         this.notificationService.showNotification("Not Save");
  //       } else {
  //         this.notificationService.showNotification("Not Save");
  //       }
  //     });
  //   }
  // }

  // resetBoardTaskForm() {
  //   this.frmCreateBoardTask.reset();
  //   this.boardTaskFormDirective.resetForm();
  //   this.isSubmitBtnDisabledBoardTask = false;
  // }


  // createBoardTaskFormModel() {
  //   var formSelectedAssociation = this.frmCreateBoardTask.controls.association.value;
  //   console.log("formSelectedAssociation", formSelectedAssociation);
  //   const model: BoardTaskModel = {
  //     Domain: formSelectedAssociation.Domain,
  //     TypeOfDocument: this.typeOfDocument,
  //     Document: null,
  //     RequestId: "",
  //     Case:
  //     {
  //       id: this.cases.id,
  //       AssociationId: formSelectedAssociation.id,
  //       Title: this.frmCreateBoardTask.controls.title.value,
  //       AssociationName: formSelectedAssociation.AssociationName,
  //       CompanyCode: formSelectedAssociation.CompanyCode,
  //       CaseType: this.cases.CaseType,
  //       SubCaseType: this.subCaseType,
  //       CaseCategory: this.frmCreateBoardTask.controls.caseCategory.value,
  //       CaseSubCategory: this.frmCreateBoardTask.controls.caseSubCategory.value,
  //       Comments: this.frmCreateBoardTask.controls.comment.value,
  //       CustomerType: this.cases.CustomerType,
  //       CasePriority: this.frmCreateBoardTask.controls.priority.value,
  //       DueDate: new Date(this.frmCreateBoardTask.controls.dueDate.value).toUTCString(),
  //       FirstName: '',
  //       LastName: '',
  //       CaseOriginatingType: this.frmCreateBoardTask.controls.caseOriginatingType.value,
  //       IsAuthorized: IsAuthorized.Yes,
  //       StatusReason: this.cases.StatusReason,
  //       Phone: '',
  //       AssignedTo: this.frmCreateBoardTask.controls.assignTo.value.UserName,
  //       AssignedPartyType: AssignedPartyType.PROPVIVO,
  //       CaseDocuments: this.cases.CaseDocuments,
  //       CreatedByUserId: '',
  //       CreatedByUserName: '',
  //       ModifiedByUserId: '',
  //       ModifiedByUserName: ''
  //     }
  //   }
  //   return model;
  // }


  // /*Violation Form*/
  // setViolationData() {
  //   this.frmCreateViolation.controls.title.setValue(this.cases.Title);
  //   this.frmCreateViolation.controls.description.setValue(this.emailMessage.Body);
  //   if (this.cases.AssociationId !== null && this.cases.AssociationId !== '' && this.cases.AssociationId !== undefined) {
  //     var association = this.associationDdl.find(a => a.id === this.cases.AssociationId);
  //     this.frmCreateViolation.controls.association.setValue(association);
  //     this.violatedByAssociationUnitDdl = [];
  //     this.selectedAssociationId = this.cases.AssociationId;
  //     //this.onChangeAssociationViolation(this.cases.AssociationId);
  //     this.getAllAssociationUnitByAssociationId(this.cases.AssociationId);
  //   }
  // }

  // // Reported By
  // /**Auto complete Reported By  Display Function**/
  // displayFnAutoCompleteReportedBy(user) {
  //   if (user != null) {
  //     return user.UserName;
  //   } else return user;
  // }

  // /**Auto complete Reported By  filter change**/
  // onInputReportedByChanged(searchStr: string): void {
  //   this.reportedByAutoCompleteDdl = [];
  //   this.reportedByAutoCompleteDdl = this.reportedByDdl.filter(option =>
  //     option.UserName.toLowerCase().includes(searchStr.toLowerCase()));
  // }

  // /**Auto complete violated By association Unit Display Function**/
  // displayFnAutoCompleteViolatedByUnit(associationUnit) {
  //   if (associationUnit != null) {
  //     return associationUnit.Text;
  //   } else return associationUnit;
  // }

  // /**Auto complete violated By association Unit filter change**/
  // onInputViolatedByUnitChanged(searchStr: string): void {
  //   this.violatedByAssociationAutoCompleteUnitDdl = [];
  //   this.violatedByAssociationAutoCompleteUnitDdl = this.violatedByAssociationUnitDdl.filter(option =>
  //     option.Text.toLowerCase().includes(searchStr.toLowerCase()));
  // }


  // onChangeAssociationViolation(event) {
  //   if (event.isUserInput === true) {
  //     this.selectedAssociationId = event.source.value.id;
  //     this.violatedByAssociationUnitDdl = [];
  //     this.violatedByAssociationAutoCompleteUnitDdl = [];
  //     this.frmCreateViolation.controls.violatedByAssociationUnit.setValue('');
  //     this.frmCreateViolation.controls.reportedByUser.setValue('');
  //     this.getAllAssociationUnitByAssociationId(this.selectedAssociationId);
  //   }
  // }

  // getAllAssociationUnitByAssociationId(associationId) {
  //   let resData;
  //   this.commonService.getAllAssociationUnitByAssociation(associationId).subscribe(res => {
  //     resData = res;
  //     if (resData.AssociationUnit !== null && resData.AssociationUnit !== undefined && resData.AssociationUnit.length > 0) {
  //       let associationUnits = resData.AssociationUnit;
  //       associationUnits.map(associationUnit => {
  //         let unitAddress = this.commonService.getFullAssociationAddress(associationUnit);
  //         if (unitAddress !== null && unitAddress !== undefined) {
  //           let dropdownModelAssociationUnit = new DropdownModelAssociationUnit();
  //           dropdownModelAssociationUnit.CreatedByUnitAddress1 = associationUnit.AssociationUnitAddress1;
  //           dropdownModelAssociationUnit.CreatedByUnitAddress2 = associationUnit.AssociationUnitAddress2;
  //           dropdownModelAssociationUnit.CreatedByUnitCity = associationUnit.AssociationUnitCity;
  //           dropdownModelAssociationUnit.CreatedByUnitState = associationUnit.AssociationUnitState;
  //           dropdownModelAssociationUnit.CreatedByUnitId = associationUnit.id;
  //           dropdownModelAssociationUnit.CreatedByUnitZip = associationUnit.AssociationUnitZip;
  //           dropdownModelAssociationUnit.CreatedByUnitNumber = associationUnit.AssociationUnitNumber;
  //           dropdownModelAssociationUnit.Text = unitAddress;
  //           this.violatedByAssociationUnitDdl.push(dropdownModelAssociationUnit);
  //         }
  //       });
  //       this.violatedByAssociationAutoCompleteUnitDdl = this.violatedByAssociationUnitDdl;
  //     }
  //   })
  // }

  // onChangeAssociationUnit(event) {
  //   let resData;
  //   let createdByUnitId = event.source.value.CreatedByUnitId;
  //   this.frmCreateViolation.controls.reportedByUser.setValue('');
  //   this.violationApiService.getReportedByUser(this.selectedAssociationId, createdByUnitId).subscribe(res => {
  //     resData = res;
  //     if (resData.Success) {
  //       this.reportedByAutoCompleteDdl = resData.User;
  //       this.reportedByDdl = resData.User;
  //     } else {
  //       this.reportedByAutoCompleteDdl = [];
  //       this.reportedByDdl = [];
  //     }
  //   })
  // }

  // onSubmitViolation() {
  //   if (!this.frmCreateViolation.valid) {
  //     return;
  //   }
  //   console.log("this.frmCreateViolation.value", this.frmCreateViolation.value);
  //   this.isSubmitBtnDisabledViolation = true;
  //   let CaseRequest = {
  //     Case: this.createRequestModel(),
  //     Violations: this.createCaseUnitModel(),
  //     TypeOfDocument: this.typeOfDocument,
  //     AssociationId: this.frmCreateViolation.value.association.id,
  //     Domain: this.frmCreateViolation.value.association.Domain,
  //     Document: null,
  //   };
  //   console.log("CaseRequest", CaseRequest);
  //   this.emailtocaseService.createEmailToCase(CaseRequest).subscribe(
  //     (response: any) => {
  //       this.isSubmitBtnDisabledViolation = false;
  //       if (response.success === true) {
  //         this.Violation = false;
  //         this.isCaseDetailShow = false;
  //         this.getData();
  //         this.resetViolationForm();
  //         this.notificationService.showNotification("Violation saved Successfully");
  //       } else if (response.Success === false) {
  //         this.notificationService.showNotification("Not Save");
  //       } else {
  //         this.notificationService.showNotification("Not Save");
  //       }
  //     });
  // }

  // resetViolationForm() {
  //   this.frmCreateViolation.reset();
  //   this.violationFormDirective.resetForm();
  // }

  // // Request Model
  // createRequestModel() {
  //   let model: ViolationCase = {
  //     id: this.cases.id,
  //     Title: this.frmCreateViolation.value.title,
  //     AssociationId: this.frmCreateViolation.value.association.id,
  //     AssociationName: this.frmCreateViolation.value.association.AssociationName,
  //     CaseType: this.cases.CaseType,
  //     CustomerTypeId: '',
  //     SubCaseType: SubCaseTypeEnum.Violation,
  //     CaseCategory: CaseTypeEnum.Violations,
  //     CaseSubCategory: CaseTypeEnum.Violations,
  //     CasePriority: CasePriority.Medium,
  //     Description: this.frmCreateViolation.value.description,
  //     CustomerType: this.customerType,
  //     AssociationUnitId: this.frmCreateViolation.controls.violatedByAssociationUnit.value.CreatedByUnitId,
  //     CreatedByUserId: this.userId,
  //     CreatedByUserName: this.userName,
  //     CaseOriginatingType: CaseOriginatingType.Website,
  //     IsAuthorized: IsAuthorized.Yes,
  //     StatusReason: StatusReason.InProgress,
  //     UserProfileId: this.userId,
  //     CompanyCode: this.frmCreateViolation.value.association.CompanyCode,
  //     CaseDocuments: this.cases.CaseDocuments
  //   }
  //   return model;
  // }
  // // Case Unit Model
  // createCaseUnitModel() {
  //   let model1: Violation = {
  //     id: "",
  //     ViolatedOn: new Date(this.frmCreateViolation.controls.violationDate.value).toUTCString(),
  //     ViolatedByUnitNumber: this.frmCreateViolation.controls.violatedByAssociationUnit.value.CreatedByUnitNumber,
  //     ViolatedByAddress1: this.frmCreateViolation.controls.violatedByAssociationUnit.value.CreatedByUnitAddress1,
  //     ViolatedByAddress2: this.frmCreateViolation.controls.violatedByAssociationUnit.value.CreatedByUnitAddress2,
  //     ViolatedByCity: this.frmCreateViolation.controls.violatedByAssociationUnit.value.CreatedByUnitCity,
  //     ViolatedByState: this.frmCreateViolation.controls.violatedByAssociationUnit.value.CreatedByUnitState,
  //     ViolatedByZip: this.frmCreateViolation.controls.violatedByAssociationUnit.value.CreatedByUnitZip,
  //     ViolatedByAssociationUnitId: this.frmCreateViolation.controls.violatedByAssociationUnit.value.CreatedByUnitId,
  //     FineStatus: FineStatus.TobeDetermined,
  //     ViolationStatus: ViolationStatus.Opened,
  //     FineAmount: null,
  //     ReportedByUnitId: null,
  //     ReportedByUserId: this.frmCreateViolation.controls.reportedByUser.value.UserProfileId,
  //     ReportedByUserName: this.frmCreateViolation.controls.reportedByUser.value.UserName
  //   }
  //   return model1
  // }

  // /*Service Request Form*/

  // setServiceRequestData() {
  //   this.addRequestForm.controls.caseOriginatingType.setValue('Email');
  //   this.addRequestForm.controls.title.setValue(this.cases.Title);
  //   this.addRequestForm.controls.comment.setValue(this.emailMessage.Body);

  //   if (this.cases.AssociationId !== null && this.cases.AssociationId !== '' && this.cases.AssociationId !== undefined) {
  //     var association = this.associationDdl.find(a => a.id === this.cases.AssociationId);
  //     this.addRequestForm.controls.association.setValue(association);
  //     this.selectedAssociationServiceRequestId = "";
  //     this.selectedAssociationServiceRequestId = this.cases.AssociationId;
  //     this.getAllAssociationUnitByAssociationIdForServiceRequest(this.cases.AssociationId);
  //     //this.onChangeAssociationServiceRequest(this.cases.AssociationId);
  //   }
  // }


  // onSubmitSerivceRequest() {
  //   if (!this.addRequestForm.valid) {
  //     return;
  //   }
  //   var formSelectedAssociation = this.addRequestForm.controls.association.value;
  //   let CaseRequest = {
  //     Case: this.createServiceRequestModel(),
  //     ServiceRequest: this.createServiceCaseUnitModel(),
  //     TypeOfDocument: TypeOfDocument.CaseDocuments,
  //     Domain: formSelectedAssociation.Domain,
  //     Document: null,
  //   };
  //   console.log("CaseRequest", CaseRequest);
  //   this.isSubmitBtnDisabledServiceRequest = true;
  //   this.emailtocaseService.createEmailToCase(CaseRequest).subscribe(
  //     (response: any) => {
  //       this.isSubmitBtnDisabledServiceRequest = false;
  //       if (response.success === true) {
  //         this.ServiceRequest = false;
  //         this.isCaseDetailShow = false;
  //         this.getData();
  //         this.resetServiceRequestForm();
  //         this.notificationService.showNotification("Service Request saved successfully.");
  //       } else if (response.Success === false) {
  //         this.notificationService.showNotification("Not Save");
  //       } else {
  //         this.notificationService.showNotification("Not Save");
  //       }
  //     });
  // }

  // resetServiceRequestForm() {
  //   this.addRequestForm.reset();
  //   this.serivceRequestFormDirective.resetForm();
  //   this.addRequestForm.controls.isAuthorized.setValue("Yes");
  //   this.isAuthorizedDisplay = true;
  // }

  // // Request Model
  // createServiceRequestModel() {
  //   let model: CaseRequestModel = {
  //     id: this.cases.id,
  //     Title: this.addRequestForm.controls.title.value,
  //     AssociationId: this.addRequestForm.controls.association.value.id,
  //     AssociationName: this.addRequestForm.controls.association.value.AssociationName,
  //     CaseType: this.addRequestForm.controls.caseType.value.Name,
  //     CaseTypeId: this.addRequestForm.controls.caseType.value.CaseTypeId,
  //     SubCaseType: SubCaseTypeEnum.ServiceRequest,
  //     CaseCategory: this.addRequestForm.controls.caseCategory.value.Name,
  //     CaseSubCategory: this.addRequestForm.controls.caseSubCategory.value,
  //     CasePriority: this.addRequestForm.controls.priority.value,
  //     Description: this.addRequestForm.controls.comment.value,
  //     CustomerType: this.addRequestForm.controls.customerType.value.customerTypeName,
  //     CustomerTypeId: this.addRequestForm.controls.customerType.value.customerTypeId,
  //     FirstName: this.addRequestForm.controls.firstName.value !== null ? this.addRequestForm.controls.firstName.value : '',
  //     LastName: this.addRequestForm.controls.lastName.value !== null ? this.addRequestForm.controls.lastName.value : '',
  //     Phone: this.addRequestForm.controls.mobile.value !== null ? this.addRequestForm.controls.mobile.value : '',
  //     PhoneofCaller: this.addRequestForm.controls.phoneofCaller.value !== null ? this.addRequestForm.controls.phoneofCaller.value : '',
  //     AssociationUnitId: this.addRequestForm.controls.associationUnit.value.CreatedByUnitId,
  //     CreatedByUserId: this.userId,
  //     CreatedByUserName: this.userName,
  //     CaseOriginatingType: this.addRequestForm.controls.caseOriginatingType.value,
  //     AssignedPartyType: AssignedPartyType.PROPVIVO,
  //     AssignedTo: this.addRequestForm.controls.assignTo.value.UserName,
  //     IsAuthorized: this.addRequestForm.controls.isAuthorized.value,
  //     StatusReason: StatusReason.New,
  //     UserProfileId: this.addRequestForm.controls.memberName.value.UserProfileId,
  //     Email: this.addRequestForm.controls.email.value,
  //     CompanyCode: this.addRequestForm.controls.association.value.CompanyCode,
  //     UserName: this.addRequestForm.controls.memberName.value.UserName,
  //     UnitRoleId: this.addRequestForm.controls.unitRoleDetail.value.id,
  //     UnitRoleName: this.addRequestForm.controls.unitRoleDetail.value.UnitRoleName,
  //     CaseDocuments: this.cases.CaseDocuments
  //   }
  //   return model;
  // }
  // // Case Unit Model
  // createServiceCaseUnitModel() {
  //   let model1: CaseUnitModel = {
  //     id: this.addRequestForm.controls.serviceRequestDetailId.value,
  //     CreatedByUnitId: this.addRequestForm.controls.associationUnit.value.CreatedByUnitId,
  //     CreatedByUnitAddress1: this.addRequestForm.controls.associationUnit.value.CreatedByUnitAddress1,
  //     CreatedByUnitAddress2: this.addRequestForm.controls.associationUnit.value.CreatedByUnitAddress2,
  //     CreatedByUnitCity: this.addRequestForm.controls.associationUnit.value.CreatedByUnitCity,
  //     CreatedByUnitState: this.addRequestForm.controls.associationUnit.value.CreatedByUnitState,
  //     CreatedByUnitZip: this.addRequestForm.controls.associationUnit.value.CreatedByUnitZip,
  //     CreatedByUnitNumber: this.addRequestForm.controls.associationUnit.value.CreatedByUnitNumber,
  //   }
  //   return model1
  // }

  // getMasterData() {
  //   let resData;

  //   this.serviceRequestService.getMasterData().subscribe(res => {
  //     resData = res;
  //     if (resData.CustomerTypes !== null && resData.CustomerTypes !== undefined) {
  //       this.customerTypeDdl = resData.CustomerTypes;
  //       if (this.customerTypeDdl.length > 0) {
  //         for (let i = 0; i < this.customerTypeDdl.length; i++) {
  //           let model: CustomerType = new CustomerType();
  //           model.customerTypeId = this.customerTypeDdl[i].id;
  //           model.customerTypeName = this.customerTypeDdl[i].Name;
  //           model.documentType = this.customerTypeDdl[i].DocumentType;
  //           model.caseTypes = this.customerTypeDdl[i].CaseTypes;
  //           this.customerTypeDdlList.push(model);

  //           for (let j = 0; j < this.customerTypeDdl[i].CaseTypes.length; j++) {
  //             let model1: CaseTypes = new CaseTypes();
  //             model1.CaseTypeId = this.customerTypeDdl[i].CaseTypes[j].CaseTypeId;
  //             model1.Name = this.customerTypeDdl[i].CaseTypes[j].Name;
  //             model1.CaseCategory = this.customerTypeDdl[i].CaseTypes[j].CaseCategory;
  //             this.caseTypeDdlList.push(model1);

  //             for (let k = 0; k < this.customerTypeDdl[i].CaseTypes[j].CaseCategory.length; k++) {
  //               let model2: CaseCategory = new CaseCategory();
  //               model2.CaseCategoryId = this.customerTypeDdl[i].CaseTypes[j].CaseCategory[k].CaseCategoryId;
  //               model2.Name = this.customerTypeDdl[i].CaseTypes[j].CaseCategory[k].Name;
  //               model2.CaseSubCategories = this.customerTypeDdl[i].CaseTypes[j].CaseCategory[k].CaseSubCategories;
  //               this.caseCategoryServiceRequestDdlList.push(model2);

  //               for (let l = 0; l < this.customerTypeDdl[i].CaseTypes[j].CaseCategory[k].CaseSubCategories.length; l++) {
  //                 let model3: CaseSubCategories = new CaseSubCategories();
  //                 model3.caseSubCategoryNames = this.customerTypeDdl[i].CaseTypes[j].CaseCategory[k].CaseSubCategories[l];
  //                 this.caseSubCategoryServiceRequestDdlList.push(model3);
  //               }
  //             }
  //           }
  //         }
  //       }
  //     }
  //   })
  // }

  // onChangeAssociationUnitService(event) {
  //   let resData;
  //   this.memberListDdl = [];
  //   this.memberListDdlAutocompleteList = [];
  //   this.addRequestForm.controls.memberName.setValue('');
  //   this.serviceRequestService.getAssociationMember(this.selectedAssociationServiceRequestId, event.source.value.CreatedByUnitId).subscribe(res => {
  //     resData = res;
  //     if (resData.Success === true) {
  //       this.memberListDdl = resData.Users;
  //       this.memberListDdlAutocompleteList = resData.Users;
  //     }
  //   });
  // }

  // onChangeCustomerType(event) {
  //   this.addRequestForm.controls.caseType.setValue('');
  //   this.addRequestForm.controls.caseCategory.setValue('');
  //   this.addRequestForm.controls.caseSubCategory.setValue('');
  //   let caseType = this.customerTypeDdlList.find(x => x.customerTypeName === event.value.customerTypeName);
  //   this.caseTypeDdl = caseType.caseTypes.filter(z => z.Name === CaseTypeEnum.Homeowners || z.Name === CaseTypeEnum.Other)
  // }

  // onChangeCaseType(event) {
  //   this.addRequestForm.controls.caseCategory.setValue('');
  //   this.addRequestForm.controls.caseSubCategory.setValue('');
  //   let caseCategory = this.caseTypeDdlList.find(x => x.Name === event.value.Name);
  //   this.caseCategoryDdl = caseCategory.CaseCategory.filter(z => z.Name !== CaseTypeEnum.ARC && z.Name !== CaseTypeEnum.Violations); //caseCategory.CaseCategory;
  // }

  // onChangeCaseCategoryServiceRequest(event) {
  //   this.addRequestForm.controls.caseSubCategory.setValue('');
  //   let caseSubcat = this.caseCategoryServiceRequestDdlList.find(x => x.Name === event.value.Name);
  //   this.caseSubCategoryDdl = caseSubcat.CaseSubCategories;
  // }

  // /**Auto complete Display Function**/
  // displayFnAutoCompleteAssociationUnit(associationUnit) {
  //   if (associationUnit != null && associationUnit.Text != null) {
  //     return associationUnit.Text;
  //   } else associationUnit;
  // }

  // /**Auto complete filter on change**/
  // onInputChangedAssociationUnit(searchStr: string): void {
  //   this.associationUnitDdlAutocompleteList = [];
  //   this.associationUnitDdlAutocompleteList = this.associationUnitDdl.filter(option =>
  //     option.Text.toLowerCase().includes(searchStr.toLowerCase()));
  // }

  // /**Auto complete Display Function**/
  // displayFnAutoCompleteMember(member) {
  //   if (member != null && member.UserName != null) {
  //     return member.UserName;
  //   } else member;
  // }

  // /**Auto complete filter on change**/
  // onInputChangedMember(searchStr: string): void {
  //   this.memberListDdlAutocompleteList = [];
  //   this.memberListDdlAutocompleteList = this.memberListDdl.filter(option =>
  //     option.UserName.toLowerCase().includes(searchStr.toLowerCase()));
  // }

  // onChangeAssociationServiceRequest(event) {
  //   if (event.isUserInput === true) {
  //     this.selectedAssociationServiceRequestId = event.source.value.id;
  //     this.associationUnitDdl = [];
  //     this.associationUnitDdlAutocompleteList = [];
  //     this.addRequestForm.controls.associationUnit.setValue('');
  //     this.addRequestForm.controls.memberName.setValue('');
  //     this.getAllAssociationUnitByAssociationIdForServiceRequest(this.selectedAssociationServiceRequestId);
  //   }
  // }

  // getAllAssociationUnitByAssociationIdForServiceRequest(associationId) {
  //   let resData;
  //   this.commonService.getAllAssociationUnitByAssociation(associationId).subscribe(res => {
  //     resData = res;
  //     if (resData.AssociationUnit !== null && resData.AssociationUnit !== undefined && resData.AssociationUnit.length > 0) {
  //       this.associationUnitDataList = resData.AssociationUnit;
  //       this.associationUnitDataList.map(associationUnit => {
  //         let unitAddress = this.commonService.getFullAssociationAddress(associationUnit);
  //         if (unitAddress !== null && unitAddress !== undefined) {
  //           let dropdownModelAssociationUnit = new DropdownModelAssociationUnit();
  //           dropdownModelAssociationUnit.CreatedByUnitAddress1 = associationUnit.AssociationUnitAddress1;
  //           dropdownModelAssociationUnit.CreatedByUnitAddress2 = associationUnit.AssociationUnitAddress2;
  //           dropdownModelAssociationUnit.CreatedByUnitCity = associationUnit.AssociationUnitCity;
  //           dropdownModelAssociationUnit.CreatedByUnitState = associationUnit.AssociationUnitState;
  //           dropdownModelAssociationUnit.CreatedByUnitId = associationUnit.id;
  //           dropdownModelAssociationUnit.CreatedByUnitZip = associationUnit.AssociationUnitZip;
  //           dropdownModelAssociationUnit.CreatedByUnitNumber = associationUnit.AssociationUnitNumber;
  //           dropdownModelAssociationUnit.Text = unitAddress;
  //           this.associationUnitDdl.push(dropdownModelAssociationUnit);
  //         }
  //         this.associationUnitDdlAutocompleteList = this.associationUnitDdl;
  //       })
  //     }
  //   })
  // }



  // setMobileNumber(event) {
  //   let ctrlValue = this.addRequestForm.controls.phone.value;
  //   let newCtrlValue;
  //   if (ctrlValue) {
  //     if (ctrlValue.length < 10) {
  //     }
  //     else {
  //       ctrlValue = this.addRequestForm.controls.phone.value;
  //       newCtrlValue = this.convertMobileNumber(ctrlValue);
  //       this.addRequestForm.controls.phone.setValue(newCtrlValue);
  //     }
  //     if (event.inputType === 'deleteContentBackward') {
  //       this.addRequestForm.controls.phone.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
  //     }
  //   }
  // }

  // //for validation of Authorized fields
  // formControlValueChanged() {
  //   const firstName = this.addRequestForm.get('firstName');
  //   const lastName = this.addRequestForm.get('lastName');
  //   const emailAddress = this.addRequestForm.get('email');
  //   const phoneNumber = this.addRequestForm.get('mobile');
  //   const memberName = this.addRequestForm.get('memberName');
  //   this.addRequestForm.get('isAuthorized').valueChanges.subscribe(
  //     (mode: string) => {
  //       if (mode === IsAuthorized.No) {
  //         this.isAuthorizedDisplay = false;
  //         firstName.setValidators([Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]);
  //         lastName.setValidators([Validators.required, Validators.minLength(1), Validators.maxLength(50), ValidationService.noWhiteSpace]);
  //         emailAddress.setValidators([Validators.required, ValidationService.emailValidator]);
  //         phoneNumber.setValidators([Validators.required, Validators.minLength(13), Validators.maxLength(13)]);
  //         //this.addRequestForm.controls.memberName.setValue('');
  //       }
  //       else if (mode === IsAuthorized.Yes) {
  //         this.isAuthorizedDisplay = true;
  //         firstName.clearValidators();
  //         lastName.clearValidators();
  //         emailAddress.clearValidators();
  //         phoneNumber.clearValidators();
  //         this.resetAuthorizedValue();
  //       }
  //       firstName.updateValueAndValidity();
  //       lastName.updateValueAndValidity();
  //       emailAddress.updateValueAndValidity();
  //       phoneNumber.updateValueAndValidity();
  //       // memberName.updateValueAndValidity();
  //     });
  // }

  // onChangeMember(event) {
  //   if (event.source.value.UserUnitRole !== null) {
  //     let unitRole = this.unitRoleDdl.find(x => x.UnitRoleName === event.source.value.UserUnitRole)
  //     this.addRequestForm.controls.unitRoleDetail.setValue(unitRole);
  //   }
  // }

  // resetAuthorizedValue() {
  //   this.addRequestForm.controls.firstName.setValue('');
  //   this.addRequestForm.controls.lastName.setValue('');
  //   this.addRequestForm.controls.email.setValue('');
  //   this.addRequestForm.controls.mobile.setValue('');
  // }


  // getUnitRole() {
  //   let resData;
  //   this.serviceRequestService.getUnitRole().subscribe(res => {
  //     resData = res;
  //     if (resData.Success === true) {
  //       this.unitRoleDdl = resData.UnitRoles;
  //     }
  //   },
  //     (err) => {
  //       console.log(err);
  //     }
  //   )
  // }

  // onChangeUnitRole(event) {
  //   var unitrole = this.addRequestForm.value.unitRoleDetail.UserUnitRole
  //   if (event.value.UnitRoleName !== unitrole) {
  //     this.addRequestForm.controls.memberName.setValue('');
  //   }
  // }

  // /*Create ARC*/

  // createARC() {
  //   let navigationExtras: NavigationExtras = {
  //     queryParams: {
  //       "caseId": this.setCaseId
  //     }
  //   };
  //   this.router.navigate([AppRouteUrl.mainCreateArcPMRouteUrl], navigationExtras);
  // }

  // /*Method for conversion*/
  // convertMobileNumber(ctrlValue) {
  //   return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  // }


}