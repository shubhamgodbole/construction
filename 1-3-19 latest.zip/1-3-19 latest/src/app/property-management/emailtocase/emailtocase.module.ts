import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmailtocaseComponent } from './emailtocase.component';
import { Routes, RouterModule } from '@angular/router';
// import { MatInputModule, MatListModule, MatSelectModule, MatRadioModule, MatDatepickerModule, MatAutocompleteModule, MatBottomSheetModule, MatButtonModule, MatButtonToggleModule } from '@angular/material';
// import { NumberOnlyDirectiveModule } from 'src/app/shared/directives/allow-only-number/only-number.module';
// import { ReactiveFormsModule, FormsModule } from '@angular/forms';
// import { HideIfUnauthorizedModule } from 'src/app/shared/directives/hideIfUnAuth/hide-if-unauthorized.module';
// import { NoDataFoundModule } from 'src/app/shared/component/no-data-found/no-data-found.module';
// import { SafeModule } from 'src/app/shared/pipes/safe/safe.module';
import { ServicesEmailModule } from '../services-email/services-email.module';

const routes: Routes = [
  {
    path: '',
    component: EmailtocaseComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    // MatInputModule,
    // MatListModule,
    // MatSelectModule,
    // MatRadioModule,
    // MatDatepickerModule,
    // MatAutocompleteModule,
    // MatBottomSheetModule,
    // MatButtonModule,
    // SafeModule,
    // NumberOnlyDirectiveModule,
    // MatButtonToggleModule,
    // ReactiveFormsModule,
    // FormsModule,
    // HideIfUnauthorizedModule,
    // NoDataFoundModule,
    RouterModule.forChild(routes),
    ServicesEmailModule,  
  ],
  declarations: [EmailtocaseComponent]
})
export class EmailtocaseModule { }
