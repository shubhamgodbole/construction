import { Component, OnInit, ViewChild } from '@angular/core';
import { NotificationService } from 'src/app/shared/services/notification.service';
import { MatAutocompleteTrigger } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { DropdownModelAssociationUnit } from 'src/app/shared/common/models';
import { ViolationApiService } from 'src/app/services/violation-api.service';
import { FormGroupDirective, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ValidationService } from 'src/app/shared/services/validation.service';
import { DisplayPriority, CommonConstant } from 'src/app/shared/common/constant.model';

@Component({
  selector: 'app-leveloneform',
  templateUrl: './leveloneform.component.html',
  styleUrls: ['./leveloneform.component.scss']
})
export class LeveloneformComponent implements OnInit {
  notificationService: NotificationService;

  @ViewChild('formDirectiveLevelOneForm') violationFormDirective: FormGroupDirective;
  frmCreateLevelOneForm: FormGroup;
  isSubmitBtnDisabledLevelOneForm: boolean;
  priorityDdl: any;

  //For Association
  associationDdl: any[] = [];
  associationDdlAutocompleteList: any[] = [];
  @ViewChild('associationAutoComplete', { read: MatAutocompleteTrigger })
  associationtrigger: MatAutocompleteTrigger;


  //association unit Reported By drop down autocomplate
  associationUnitDdl: any[] = [];
  associationUnitDdlAutocompleteList: any[];
  /*Reset mat auto compelte*/
  @ViewChild('associationUnitAutoComplete', { read: MatAutocompleteTrigger })
  associationUnitTrigger: MatAutocompleteTrigger;



  memberListDdl: any[] = [];
  memberListDdlAutocompleteList: any[] = [];
  @ViewChild('memberAutoComplete', { read: MatAutocompleteTrigger })
  memberUnittrigger: MatAutocompleteTrigger;

  /*End Form*/





  selectedAssociationId: string = "";

  constructor(public commonService: CommonService,
    private violationApiService: ViolationApiService,
    private readonly formBuilder: FormBuilder) {
    this.priorityDdl = DisplayPriority.PriorityList;

  }

  ngOnInit() {
    this.createForm();
    this.getAssociationDdl();
  }


  createForm() {
    this.frmCreateLevelOneForm = this.formBuilder.group({
      association: ['', Validators.required],
      caseType: ['New'],
      associationUnit: ['', Validators.required],
      isAuthorized: ['', Validators.required],
      userProfile: ['', Validators.required],
      firstName: [''],
      lastName: [''],
      caseOriginatingType: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.maxLength(13), Validators.minLength(13)]],
      email: ['', [ValidationService.emailValidator]],
      title: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(200), ValidationService.noWhiteSpace]],
      description: ['', [Validators.minLength(1), Validators.pattern(CommonConstant.WhiteSpacePattern)]],
      priority: ['', Validators.required]
    });

    this.frmCreateLevelOneForm.controls.caseOriginatingType.setValue('Email');

  }

  getAssociationDdl() {
    let resData;
    this.commonService.getAssociation().subscribe(res => {
      resData = res;
      if (resData.Success === true) {
        this.associationDdl = resData.AssociationList;
        this.associationDdlAutocompleteList = resData.AssociationList;
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  onChangeAssociationViolation(event) {
    if (event.isUserInput === true) {
      this.associationUnitDdl = [];
      this.associationUnitDdlAutocompleteList = [];
      // this.frmCreateViolation.controls.violatedByAssociationUnit.setValue('');
      // this.frmCreateViolation.controls.reportedByUser.setValue('');
      this.getAllAssociationUnitByAssociationId(event.source.value.id);
    }
  }

  getAllAssociationUnitByAssociationId(associationId) {
    let resData;
    this.commonService.getAllAssociationUnitByAssociation(associationId).subscribe(res => {
      resData = res;
      if (resData.AssociationUnit !== null && resData.AssociationUnit !== undefined && resData.AssociationUnit.length > 0) {
        let associationUnits = resData.AssociationUnit;
        associationUnits.map(associationUnit => {
          let unitAddress = this.commonService.getFullAssociationAddress(associationUnit);
          if (unitAddress !== null && unitAddress !== undefined) {
            let dropdownModelAssociationUnit = new DropdownModelAssociationUnit();
            dropdownModelAssociationUnit.CreatedByUnitAddress1 = associationUnit.AssociationUnitAddress1;
            dropdownModelAssociationUnit.CreatedByUnitAddress2 = associationUnit.AssociationUnitAddress2;
            dropdownModelAssociationUnit.CreatedByUnitCity = associationUnit.AssociationUnitCity;
            dropdownModelAssociationUnit.CreatedByUnitState = associationUnit.AssociationUnitState;
            dropdownModelAssociationUnit.CreatedByUnitId = associationUnit.id;
            dropdownModelAssociationUnit.CreatedByUnitZip = associationUnit.AssociationUnitZip;
            dropdownModelAssociationUnit.CreatedByUnitNumber = associationUnit.AssociationUnitNumber;
            dropdownModelAssociationUnit.Text = unitAddress;
            this.associationUnitDdl.push(dropdownModelAssociationUnit);
          }
        });
        this.associationUnitDdlAutocompleteList = this.associationUnitDdl;
      }
    })
  }


  onChangeAssociationUnit(event) {
    let resData;
    let createdByUnitId = event.source.value.CreatedByUnitId;
    //this.frmCreateViolation.controls.reportedByUser.setValue('');
    this.violationApiService.getReportedByUser(this.selectedAssociationId, createdByUnitId).subscribe(res => {
      resData = res;
      if (resData.Success) {
        this.memberListDdlAutocompleteList = resData.User;
        this.memberListDdl = resData.User;
      } else {
        this.memberListDdlAutocompleteList = [];
        this.memberListDdl = [];
      }
    })
  }

  onChangeMember(event) {
    if (event.source.value !== null) {
      // let unitRole = this.unitRoleDdl.find(x => x.UnitRoleName === event.source.value.UserUnitRole)
      // this.addRequestForm.controls.unitRoleDetail.setValue(unitRole);
    }
  }


  onSubmitLevelOneForm() {

  }

  setPhoneNumberForLevelOnePhone(event) {
    let ctrlValue = this.frmCreateLevelOneForm.controls.phoneNumber.value;
    let newCtrlValue;
    if (ctrlValue) {
      if (ctrlValue.length < 10) {
      }
      else {
        ctrlValue = this.frmCreateLevelOneForm.controls.phoneNumber.value;
        newCtrlValue = this.convertMobileNumber(ctrlValue);
        this.frmCreateLevelOneForm.controls.phoneNumber.setValue(newCtrlValue);
      }
      if (event.inputType === 'deleteContentBackward') {
        this.frmCreateLevelOneForm.controls.phoneNumber.setValue(ctrlValue.replace(/[^0-9 ]/g, ""));
      }
    }
  }

  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }

  /*Reset mat auto compelte*/
  ngAfterViewInit() {
    if (this.associationtrigger !== undefined) {
      this.associationtrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.frmCreateLevelOneForm.controls.association.setValue('');
            this.associationtrigger.closePanel();
            this.associationDdlAutocompleteList = this.associationDdl;

            this.frmCreateLevelOneForm.controls.associationUnit.setValue('');
            this.associationUnitTrigger.closePanel();
            this.associationUnitDdlAutocompleteList = this.associationUnitDdl;

            this.frmCreateLevelOneForm.controls.userProfile.setValue('');
            this.memberUnittrigger.closePanel();
            this.memberListDdlAutocompleteList = this.memberListDdl;

          }
        });
    }

    if (this.associationUnitTrigger !== undefined) {
      this.associationUnitTrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.frmCreateLevelOneForm.controls.associationUnit.setValue('');
            this.associationUnitTrigger.closePanel();
            this.associationUnitDdlAutocompleteList = this.associationUnitDdl;

            this.frmCreateLevelOneForm.controls.userProfile.setValue('');
            this.memberUnittrigger.closePanel();
            this.memberListDdlAutocompleteList = this.memberListDdl;
          }
        });
    }

    if (this.memberUnittrigger !== undefined) {
      this.memberUnittrigger.panelClosingActions
        .subscribe(e => {
          if (!(e && e.source)) {
            this.frmCreateLevelOneForm.controls.userProfile.setValue('');
            this.memberUnittrigger.closePanel();
            this.memberListDdlAutocompleteList = this.memberListDdl;
          }
        });
    }
  }

  /*auto complete*/
  /**Auto complete Display Function**/
  displayFnAutoCompleteAssociation(association) {
    if (association != null && association.AssociationName != null) {
      return association.AssociationName;
    } else association;
  }

  /**Auto complete filter on change**/
  onInputChanged(searchStr: string): void {
    this.associationDdlAutocompleteList = [];
    this.associationDdlAutocompleteList = this.associationDdl.filter(option =>
      option.AssociationName.toLowerCase().includes(searchStr.toLowerCase()));
  }


  /**Auto complete Display Function**/
  displayFnAutoCompleteAssociationUnit(associationUnit) {
    if (associationUnit != null && associationUnit.Text != null) {
      return associationUnit.Text;
    } else associationUnit;
  }

  /**Auto complete filter on change**/
  onInputChangedAssociationUnit(searchStr: string): void {
    this.associationUnitDdlAutocompleteList = [];
    this.associationUnitDdlAutocompleteList = this.associationUnitDdl.filter(option =>
      option.Text.toLowerCase().includes(searchStr.toLowerCase()));
  }

  /**Auto complete Display Function**/
  displayFnAutoCompleteMember(member) {
    if (member != null && member.UserName != null) {
      return member.UserName;
    } else member;
  }

  /**Auto complete filter on change**/
  onInputChangedMember(searchStr: string): void {
    this.memberListDdlAutocompleteList = [];
    this.memberListDdlAutocompleteList = this.memberListDdl.filter(option =>
      option.UserName.toLowerCase().includes(searchStr.toLowerCase()));
  }

}
