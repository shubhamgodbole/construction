import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeveloneformComponent } from './leveloneform.component';

describe('LeveloneformComponent', () => {
  let component: LeveloneformComponent;
  let fixture: ComponentFixture<LeveloneformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeveloneformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeveloneformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
