import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing.module';
import { NavigationComponent } from './components/navigation/navigation.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


import 'hammerjs';
import { UserIdleModule } from 'angular-user-idle';
import { TagInputModule } from 'ngx-chips';

import {
  MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTreeModule
} from '@angular/material';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { HttpRequestInterceptor } from './interceptor/http.request.interceptor';
import { Http, HttpModule } from '@angular/http';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { MatMomentDatetimeModule } from '@mat-datetimepicker/moment';
import { NumberOnlyDirectiveModule } from './shared/directives/allow-only-number/only-number.module';
import { AppConfig } from './app.config';
import { ConfirmDialogComponent } from './shared/component/confirm-dialog/confirm-dialog.component';
import { ThankYouComponent } from './shared/component/thank-you/thank-you.component';
import { CountUpModule } from 'countup.js-angular2';
import { RateAndReviewDialogComponent } from './shared/component/rate-and-review-dialog/rate-and-review-dialog.component';
import { RatingModule } from './shared/component/rating/rating.module';
import { NoCaseNoteFoundModule } from './shared/component/no-case-note-found/no-case-note-found.module';
import { NoDataFoundModule } from './shared/component/no-data-found/no-data-found.module';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { SafeModule } from './shared/pipes/safe/safe.module';
import { HeaderModule } from './components/header/header.module';
import { GlobalAssociationModule } from './shared/component/global-association/global-association.module';
import { DisplayTimeElapsedModule } from './shared/modules/display-time-elapsed.module';
import { CorporateProgressModule } from './shared/component/corporate-progress/corporate-progress.module';
import { CommonModule, DatePipe } from '@angular/common';
import { CorporatePaymentModule } from './corporate/corporate-payment/corporate-payment.module';
import { MessageComponent } from './shared/component/message/message.component';
import { NotificationComponent } from './shared/component/notification/notification.component';
import { PaymentConfirmDialogComponent } from './shared/component/payment-confirm-dialog/payment-confirm-dialog.component';
import { CookieService } from 'ngx-cookie-service';
import { AllowOnlyPriceModule } from './shared/directives/allow-only-price/allow-only-price.module';
import { AllowOnlyDateModule } from './shared/directives/allow-only-date/allow-only-date.module';
import { PmLandingComponent } from './property-management/pm-landing/pm-landing.component';
import { PaymentTypeModule } from './components/manage-payment/payment-type/payment-type.module';
import { WelcomeDialogComponent } from './shared/component/welcome-dialog/welcome-dialog.component';
import { CsrMeetingComponent } from './property-management/csr-landing/csr-meeting/csr-meeting.component';
import { CsrTaskTodoComponent } from './property-management/csr-landing/csr-task-todo/csr-task-todo.component';
import { NotificationSliderModule } from './components/header/notification-slider/notification-slider.module';
import { HighlightModule } from './shared/pipes/highlight/highlight.module';
import { OnlyAlphabetsModule } from './shared/directives/allow-only-alphabets/only-alphabets.module';
//import { EmailsComponent } from './property-management/csr-landing/emails/emails.component';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { FilterUniqueArrayModule } from './shared/pipes/filterUniqueArray/filter-unique-array.module';
import { LeveloneformComponent } from './property-management/leveloneform/leveloneform.component';
import { LevelonecaseComponent } from './property-management/csr-landing/levelonecase/levelonecase.component';
import { CommonConstant } from './shared/common/constant.model';
//import { UserFeedbackComponent } from './property-management/user-feedback/user-feedback.component';

@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    ConfirmDialogComponent,
    ThankYouComponent,
    RateAndReviewDialogComponent,
    MessageComponent,
    NotificationComponent,
    PaymentConfirmDialogComponent,
    PmLandingComponent,
    WelcomeDialogComponent,
   // AnnouncementsComponent,
    CsrMeetingComponent,
    CsrTaskTodoComponent,
    //EmailsComponent,
    LeveloneformComponent,
    LevelonecaseComponent,
    
  ],
  imports: [
    CommonModule,
    DisplayTimeElapsedModule,
    BrowserModule,
    RatingModule,
    PaymentTypeModule,
    NoCaseNoteFoundModule,
    CorporateProgressModule,
    NoDataFoundModule,
    HeaderModule,
    GlobalAssociationModule,
    SafeModule,
    FilterUniqueArrayModule,
    HighlightModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    CorporatePaymentModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    BrowserAnimationsModule,
    HttpModule,
    MatDatepickerModule,
    MatMomentDatetimeModule,
    MatDatetimepickerModule,
    NumberOnlyDirectiveModule,
    OnlyAlphabetsModule,
    AllowOnlyDateModule,
    AllowOnlyPriceModule,
    NgbModule,
    HttpModule,
    CountUpModule,
    TagInputModule, 
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory
    }),
    UserIdleModule.forRoot({ idle: CommonConstant.Idle, timeout: CommonConstant.Timeout, ping: CommonConstant.Ping }),
    NotificationSliderModule,
    BsDatepickerModule.forRoot(),
  ],
  providers: [
    DatePipe,
    AppConfig,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpRequestInterceptor,
      multi: true
    },
     CookieService,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  bootstrap: [AppComponent],
  entryComponents: [ConfirmDialogComponent, ThankYouComponent, RateAndReviewDialogComponent,WelcomeDialogComponent]
})
export class AppModule { }